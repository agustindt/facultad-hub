---
tipo: moc
estado: activo
tags: [moc, facultad]
---

# 🎓 Facultad

Vault de estudio. Cada materia es una carpeta con la misma estructura; las reglas están en
[[Convenciones]].

## Cursando ahora — 4º año, 2º semestre

| Materia | Próxima fecha clave | Estado |
|---|---|---|
| [[OAE]] — Organización y Administración de Empresas | **31/08** Entrega 1 · **07/09** Parcial 1 | 🟢 Cursando |
| [[Economia]] — Economía (Cátedra A) | **11/09** Parcial 1 · **29/10** Parcial 2 | 🟢 Cursando — U1 y U2 cargadas |
| [[CompuGrafica]] — Computación Gráfica | *sin fechas cargadas* | 🚧 Esqueleto — falta el programa |
| Ingeniería de Software III | *sin fechas publicadas* | ⚠️ Sin dar de alta — ver `00-Sistema/_scrape/ing-software-iii.md` |

## Cursadas

| Materia | Cuándo |
|---|---|
| [[Ing-Software-II]] — Ingeniería de Software II | 4º año, 1er semestre |

## Sistema

- [[Convenciones]] — cómo se nombra, se etiqueta y se enlaza acá
- `00-Sistema/Plantillas/` — plantillas de concepto, unidad, TP, entrega, clase y materia

## Cómo usar el grafo

Abrí la vista de grafo (⌘ + clic en el ícono de la barra izquierda) y vas a ver los colores:

| Color | Qué es |
|---|---|
| 🟢 Verde | Conceptos — las notas atómicas, el corazón de la red |
| 🔵 Azul | Unidades |
| 🟠 Naranja | Trabajos prácticos |
| 🌸 Rosa | Proyecto de cátedra y entregas |
| 🟡 Amarillo | Seguimiento (cronograma, condiciones, trackers) |
| 🟣 Violeta | MOCs — las puertas de entrada |
| 🩵 Celeste | Notas de clase |

Para estudiar: abrí un concepto y mirá el **grafo local** con profundidad 2. Eso te muestra
la vecindad de la idea, que es lo que se pregunta en un parcial integrador.

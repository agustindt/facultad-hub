---
scrape_fecha: 2026-08-13
---
# Scrape del campus UCC — índice

Campus: `https://presencial.ucc.edu.ar` (Moodle, campus **presencial**; el
`campusvirtual.ucc.edu.ar` del sitio público es solo una landing).
Alcance acordado con Agustín antes de empezar: **Computación Gráfica a fondo, Economía
completa cruzada con `~/Downloads/Economia`, y solo el delta de OAE.** Las otras 8 materias
que aparecen en el campus quedaron fuera por decisión suya — están listadas abajo.

| Materia | Slug | ¿Ya está en el vault? | Completitud | Archivo |
|---|---|---|---|---|
| Computación Gráfica (`CC0820173`) | `compugrafica` | ✅ Sí — `CompuGrafica/` | **baja** | [[compugrafica]] |
| Economía Cátedra A (`CC0820104A`) | `economia` | ❌ No | **alta** | [[economia]] |
| Organización y Administración de Empresas (`CC0820136`) | `oae` | ✅ Sí — `OAE/` | **media** | [[oae]] |

## Materias que Agustín cursa y NO están en el vault

### Confirmada y scrapeada

- **ECONOMIA (A)** — `CC0820104A`, curso 15046. Cátedra A, Prof. Mgter. Francisco J.
  Boggione (teórico) y Lic. Francisco N. Hiza (práctico). Jueves 18:30–20:30 teórico,
  viernes práctico (A1 17:15 / A2 19:45). **Aula activa y con material 2026 real** —
  presentación fechada 2026, dos teóricos de unidad subidos, tres fechas de evaluación
  publicadas (11/09, 29/10, 12/11). Es la materia más urgente de dar de alta.
  → Al crearla, **sufijá los archivos de seguimiento** (`cronograma-eco.md`,
  `condiciones-eco.md`) para no chocar con los stems de OAE, como manda `Convenciones.md`.

### Detectadas en el campus, NO scrapeadas (fuera del alcance acordado)

No sé si las cursás este semestre: el filtro de fechas del campus no es confiable (marca
Computación Gráfica como "Pasado" e Ingeniería de Software II como "En progreso", y el brief
dice lo contrario en ambos casos). Van con el código y el ID de curso para que sea fácil
retomarlas.

| Materia | Código | Curso | Filtro del campus |
|---|---|---|---|
| INGENIERIA DE SOFTWARE III | `CC0820184` | 15011 | Pasados |
| LENGUAJES FORMALES Y AUTOMATAS | `CC0810200` | 15106 | En progreso |
| REDES TELEINFORMATICAS | `CC0810131` | 15132 | En progreso |
| REDES TELEINFORMATICAS II | `CC0810210` | 15005 | Pasados |
| SEGURIDAD Y AUDITORIA INFORMATICA | `CC0810217` | 15113 | En progreso |
| SISTEMAS OPERATIVOS | `CC0810211` | 15111 | En progreso |
| TALLER DE TRABAJO EN EQUIPO | `CC0810273` | 15192 | En progreso |

Además aparece **INGENIERIA DE SOFTWARE II** (`CC0810202`, curso 15108), que **sí está en el
vault** como materia ya cursada (`Ing-Software-II/`), y **"Guía para estudiantes"** (`GPE`,
curso 2703), que no es una materia sino el aula de ayuda del campus.

**No di de alta ninguna carpeta ni comando**, como pide el brief.

## Cambios detectados en materias que SÍ están en el vault

### 🔴 OAE — el aula del campus está desactualizada (hallazgo principal)

El aula de OAE (curso **12680**, el único ID fuera del rango 15xxx) **es un shell de
2020–2022, no la cursada 2026**. Tres pruebas:

1. Fechas de entrega que el campus muestra hoy: "Caso práctico KPI-Tablero de Comando" →
   **12/09/2022**; "CASO NATIONAL INDUSTRIAL PRODUCT" → **31/10/2020**.
2. El programa publicado se llama **"Programa 2022"**.
3. El foro de presentación remite a una carpeta de Drive **"-Actividades 2021-"**.

**Consecuencia práctica: no actualices `OAE/00-Seguimiento/` con nada de este scrape.** Lo
que ya tenés en el vault es más nuevo y más correcto que lo que publica el campus. El aula
apunta repetidamente al **Google Drive de la cátedra** como el lugar donde se cursa y se
entrega — pero **no hay ni un link al Drive publicado**. Ese es el pendiente real.

Contradicciones registradas (sin tocar el vault): 7 unidades en el aula vs. 8 en el vault ·
"tres entregas y una defensa" vs. 4 entregas + informe + defensa · el parcial del aula se
llama "PARCIAL U. 1, 2 y 3" vs. U1–U4 en el vault · la promoción directa con ≥7 no figura en
ningún lado del campus.

**Novedades reales de OAE:**

- **Mail de Pilar Jular: `0722206@ucc.edu.ar`** (dato nuevo, de la Hoja de Ruta Parte II).
- **Horarios confirmados:** teórico lunes 12–14, práctico lunes 18–20 (por las salas de Zoom).
- **La guía de TPs que faltaba existe:** `OAE GUIA TP- PARTE 2- U5. 6 Y 7`, en la sección
  UNIDAD 5. La numeración de la Hoja de Ruta llega hasta **Tp 13**, bastante más allá del TP8
  que figuraba como límite. **Sin descargar** — necesita tu OK.
- Aparece un docente que no está en el vault: **"profe Marchesini"**, a cargo de una comisión
  de práctico. Puede ser un resabio de 2022.
- **Notas cargadas: ninguna.** Las 13 líneas del libro de calificaciones están vacías.
- **Anuncios nuevos: ninguno.** El curso ni siquiera tiene foro de novedades.
- **Material subido después del 11/08/2026: no se puede saber** — el campus no muestra fechas
  de subida a los estudiantes.

### 🟡 Computación Gráfica — el aula está prácticamente vacía

Cero archivos, cero tareas, cero mensajes en los foros, cero eventos de calendario.
Verificado en los tres índices de recursos del curso. Lo único que hay es el texto de
bienvenida, dos descripciones de sección y dos salas de Zoom.

- **Docente: John Coppens** (del texto de bienvenida; la lista de 62 participantes muestra a
  todos "Sin roles", así que no se puede confirmar el rol formal ni conseguir su mail).
- **Stack técnico: Python + formatos de imagen (JPEG / PNG / SVG).** La hipótesis del brief
  (OpenGL / WebGL / Processing / Unity / Blender) **queda descartada** en cuanto a lo
  publicado: no se menciona ninguna de esas herramientas.
- **El programa NO está en el campus.** El docente remite al **SIUCC** y a su **sitio
  personal**. Sin eso no hay unidades numeradas ni bibliografía.
- **No hay condiciones de cursada, ni cronograma, ni parciales, ni TPs publicados.**
- **Las secciones 5, 6 y 7 del aula están ocultas** (el índice salta de "Creación/edición" a
  "Biblioteca"). Ahí deberían estar las unidades que faltan. Conviene re-scrapear en unas
  semanas.
- ⚠️ El aula cae bajo el filtro **"Pasados"** del campus: sus fechas están mal configuradas o
  es un clon del dictado anterior.

## Pendientes para Agustín

### 1. Archivos para descargar (esperando tu OK)

Ninguno se descargó todavía. Con tu autorización van a `~/Downloads/campus-ucc/<slug>/`, y
**el paso de moverlos a `99-Material-Catedra/` lo hacés vos** — en OAE es obligatorio porque
esa carpeta está bloqueada por el sistema operativo.

**OAE — prioridad alta:**

- `OAE GUIA TP- PARTE 2- U5. 6 Y 7` (Word, sección UNIDAD 5) ← **es el que te faltaba**
- `GUÍA DE TRABAJO DE PROYECTO Y DISEÑO` (sección Proyecto)
- `Guia de TRABAJOS PRACTICOS Parte I` (sección Presentación)
- `Hoja de ruta parte I - Unidad 1, 2 y 3`
- Opcional: los ~30 archivos de material de estudio de U3 a U7 (filminas, casos, apuntes)

**Economía — prioridad alta:**

- `Un 0 - INTRODUCCIÓN A LA MATERIA CÁT A.pdf` (10 diapositivas; ya lo leí, tiene docentes,
  horarios, unidades, bibliografía, fechas de parciales y condiciones)
- `UN 1 - TEÓRICO INTRODUCCIÓN A LA ECONOMÍA`
- `UN 2 - TEÓRICO TEORÍA DE LA PRODUCCIÓN Y DE LOS COSTOS`
- Los tres libros de la sección BIBLIOGRAFÍA (Mochón & Beker, Mankiw, Horngren) — pesados, y
  dos de ellos **ya los tenés** en `~/Downloads/Economia/BIBLIOGRAFIA/`

**Computación Gráfica:** nada. El aula no tiene un solo archivo.

### 2. Datos para conseguir a mano

| Qué | Dónde / a quién |
|---|---|
| Programa, régimen de cursada, cronograma y horarios de **Computación Gráfica** | SIUCC y el sitio personal de John Coppens (el docente remite ahí explícitamente) |
| Mail de contacto de **John Coppens** | No figura en el campus |
| El **Drive de la cátedra de OAE** — es donde corre la cursada real | Preguntar en clase; no hay ningún link en el campus |
| Si OAE tiene **7 u 8 unidades** en 2026, y si el proyecto son **3 o 4 entregas** | Cátedra de OAE |
| Si el **Parcial 1 de OAE** cubre U1–U3 o U1–U4 | Cátedra de OAE. ⚠️ No abrí el cuestionario "PARCIAL U. 1, 2 y 3": puede arrancar un cronómetro |
| **Promoción directa ≥7 y asistencia mínima en OAE** | No figuran en el campus |
| En qué **comisión de práctico de Economía** estás (A1 viernes 17:15 o A2 viernes 19:45) | Lo sabés vos |
| **Qué unidades entran en cada parcial de Economía** | Cátedra. El reparto del programa 2019 (I-II-III / IV-V-VI-VII) **no** está confirmado para 2026 |
| Si Economía exige **TPs y monografía** para regularizar | Cátedra. El régimen 2026 **no los menciona**; el programa 2019 **sí los exigía** |
| Inicial del JTP de Economía: **"Francisco M. Hiza"** (aula) vs **"Francisco N. Hiza"** (PDF) | Cátedra |

### 3. Sobre `~/Downloads/Economia`

La revisé. **Es material de 2016–2019 de otra cátedra** (programa del año lectivo 2019,
docente Ramiro Manuel García). Pesa 221 MB y tres de sus carpetas — `CLASES`,
`GUÍA DE TRABAJOS PRÁCTICOS` y `NOTAS PARCIALES` — están **vacías**.

🚩 La cátedra 2026 pide explícitamente, en su propia presentación: **"NO USAR MATERIAL DE
ESTUDIO VIEJO/AÑOS ANTERIORES"**. Y en la misma diapositiva aclara que **"PRESENTACIONES DE
CLASES (NO SON EL MATERIAL DE ESTUDIO)"** — los PDF de teórico son apoyo, la fuente es el
libro.

Lo único de esa carpeta que tapa un hueco real es
**`Sapag Chain - Preparacion y evaluacion de Proyectos.pdf`**: es bibliografía obligatoria de
la Unidad VI de 2026 y **no está publicada en el aula**. El detalle archivo por archivo está
en [[economia]].

### 4. Para el próximo scrape

- **Computación Gráfica en 2–3 semanas**, cuando se abran las secciones 5, 6 y 7.
- **Economía en 2–3 semanas**, cuando suban los teóricos de las unidades 3 a 7 (las secciones
  ya tienen el encabezado "DOCUMENTOS DE LA CLASE" pero sin archivos).
- **OAE:** el campus no va a moverse. Lo que hay que mirar es el Drive.

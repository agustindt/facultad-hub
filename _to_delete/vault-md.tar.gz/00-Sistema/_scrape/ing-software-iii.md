---
scrape_fecha: 2026-08-13
scrape_fuente: https://github.com/ingsoft3ucc/TPs_2026
materia_nombre_campus: "INGENIERIA DE SOFTWARE III"
materia_codigo: CC0820184
slug: ing-software-iii
anio: 4
semestre: 2
carrera: "Ingeniería en Sistemas — Facultad de Ingeniería, UCC"
plan: 2016
comision: "Cátedra práctica"
existe_en_vault: false
carpeta_vault: null
completitud: alta
fuente_tipo: repositorio-git
---

# Ingeniería de Software III — scrape del repo de la cátedra

> **Fuente distinta a las demás.** Esta materia no se scrapeó del campus: todo el material
> operativo vive en un **repositorio público de GitHub**,
> [`ingsoft3ucc/TPs_2026`](https://github.com/ingsoft3ucc/TPs_2026). El aula del campus
> (curso 15011) quedó fuera del alcance acordado y no se revisó — puede tener las fechas
> del calendario, que es justo lo que le falta al repo.
>
> Último commit del repo al momento del scrape: **12/08/2026** ("El video del TP2 ya se
> puede ver desde el README").

## Docentes

| Nombre | Rol | Mail |
|---|---|---|
| Ing. Ariel Schwindt | Docente de la cátedra práctica | No figura |

## Cursada

- **Días y horarios:** no figuran en el repo.
- **Aulas:** no figuran.
- **Modalidad:** presencial. Estructura de cada clase, textual: *"bloque teórico + pausa +
  demo en vivo + presentación del TP + **manos a la obra** (trabajás sobre tu propio TP en el
  aula, con soporte)"*.
- **Inicio / fin:** no figuran.
- **Requisito material:** *"Traé tu notebook con Docker funcionando desde la C2."*

⚠️ Esta es una materia **de práctica**, y lo aclara: *"La teoría acá es la de la práctica: los
fundamentos que necesitás para resolver el TP de la semana y para defenderlo — no repite ni
reemplaza a la materia teórica."* Habría entonces una cátedra teórica aparte que el repo no cubre.

## Programa

12 clases. No hay unidades numeradas al estilo de las otras materias: la unidad de avance es
**el TP de la semana**.

| # | Clase | Tipo | Tema | ¿Filminas? | ¿TP publicado? |
|---|---|---|---|---|---|
| 1 | C1 | Contenido | Cultura DevOps + Git para equipos | ✅ PDF | ✅ TP1 |
| 2 | C2 | Contenido | Contenedores: Docker + Compose | ✅ PDF | ✅ TP2 |
| 3 | C3 | Contenido | Plataformas DevOps + planificación ágil | — | *próximamente* |
| 4 | C4 | Contenido | CI: Pipelines as Code | — | *próximamente* |
| 5 | **P1** | **Defensa** | **Defensa oral de TPs 1–4** | — | — |
| 6 | C5 | Contenido | Testing en el pipeline: unit tests + coverage + análisis estático | — | *próximamente* |
| 7 | C6 | Contenido | CD: environments, aprobaciones y deployment patterns | — | *próximamente* |
| 8 | C7 | Contenido | Contenedores en el pipeline + pruebas e2e | — | *próximamente* |
| 9 | C8 | Contenido | Infraestructura como Código | — | *próximamente* |
| 10 | C9 | Contenido | DevSecOps + Observabilidad + Continuous Feedback | — | *próximamente* |
| 11 | **P2** | **Defensa** | **Defensa oral de TPs 5–9** | — | — |
| 12 | **R** | **Recuperatorio** | Se vuelve a presentar el bloque desaprobado | — | — |

**Objetivo de la materia** (textual):

> "Vas a construir, con tus manos y semana a semana, el **sistema de entrega profesional** completo de una aplicación: integración continua con gates de calidad, entrega continua con aprobaciones, releases inmutables verificadas end-to-end, infraestructura como código, seguridad automatizada y observabilidad. No es una materia de 'ver herramientas': es una materia de **construir el sistema y poder defender cada decisión**."

**Bibliografía:** no hay. El repo es la fuente de verdad, más las filminas por clase.

## Condiciones de aprobación

⚠️ **El régimen es distinto a todo lo demás del vault: no hay parciales escritos.**

> "**No hay parciales escritos**: tus notas son **dos**, y salen de las dos presentaciones (P1 sobre los TPs 1–4, P2 sobre los TPs 5–9). La materia se aprueba **trabajando todas las semanas** — está diseñada para que cada TP tome una semana si venís al día, y para que se acumule mal si no."

### Regular

- **Las dos presentaciones aprobadas**, cada una con **nota ≥ 4** (escala 1–10).
- Las dos notas **van por separado: no se promedian ni se compensan entre sí**.
- Los 9 TPs **no llevan nota propia**: son lo que se defiende en la presentación que les toca.

### Promoción

No figura régimen de promoción. El repo solo habla de regularizar y de rendir final.

### Recuperatorios

> "**Recuperatorio (clase 12): es tu única segunda oportunidad, y alcanza para un solo bloque.** Si una presentación quedó abajo de 4, en la clase 12 volvés a presentar **ese bloque completo** — los TPs 1–4 o los 5–9, según cuál haya sido. Si **las dos** quedaron abajo de 4, la materia queda **libre** (la recursás) — y lo mismo si vas al recuperatorio y tampoco lo aprobás."

Nota de la cátedra: *"Ante la duda, avisá temprano y lo acomodamos en el momento, no en la clase 12."*

### TPs

Obligatorios los 9, pero sin nota individual. Se entregan cargando la **URL del repo público**
en un formulario por presentación, antes de la clase de defensa.

**Ponderación de cada TP dentro de la nota de su presentación:**

| P1 | TP1 Git | TP2 Docker | TP3 Planificación | TP4 CI |
|---|---|---|---|---|
| Peso | 5 % | **35 %** | 20 % | **40 %** |

| P2 | TP5 Testing | TP6 CD | TP7 Contenedores + e2e | TP8 IaC | TP9 DevSecOps |
|---|---|---|---|---|---|
| Peso | 20 % | 25 % | 25 % | 15 % | 15 % |

**Criterios con que se mira cada TP:**

| Criterio | Peso |
|---|---|
| Configuración técnica (funcionando y reproducible — evidencias) | 25 % |
| Claridad y justificación en `decisiones.md` + `evidencias.md` | 25 % |
| **Defensa oral: comprensión y argumentación** | **50 %** |

**La regla que ordena todo** (textual):

> "*si no lo podés explicar, no lo aprobás — aunque funcione.* Y su reversa: un repo con cicatrices bien explicadas vale más que uno perfecto defendido con silencios."

### Escala de notas

1 a 10. Aprueba con ≥ 4.

### Final

El **TP Integrador** es condición para rendir el final. Se valida **en vivo** en la mesa. El
enunciado se publica en `trabajos/` durante la cursada — todavía no está.

## Cronograma

| Sem | Fecha | Teórico | Práctico / Hitos |
|---|---|---|---|
| 1 | *(sin fecha)* | C1 — Cultura DevOps + Git para equipos | TP1 Git colaborativo |
| 2 | *(sin fecha)* | C2 — Docker + Compose | TP2 Contenedores |
| 3 | *(sin fecha)* | C3 — Plataformas DevOps + planificación ágil | TP3 |
| 4 | *(sin fecha)* | C4 — CI: Pipelines as Code | TP4 |
| 5 | *(sin fecha)* | — | **P1 — Defensa oral TPs 1–4** |
| 6 | *(sin fecha)* | C5 — Testing en el pipeline | TP5 |
| 7 | *(sin fecha)* | C6 — CD: environments y aprobaciones | TP6 |
| 8 | *(sin fecha)* | C7 — Contenedores en el pipeline + e2e | TP7 |
| 9 | *(sin fecha)* | C8 — Infraestructura como Código | TP8 |
| 10 | *(sin fecha)* | C9 — DevSecOps + Observabilidad | TP9 |
| 11 | *(sin fecha)* | — | **P2 — Defensa oral TPs 5–9** |
| 12 | *(sin fecha)* | — | **Recuperatorio** (un solo bloque) |

🚩 **El repo no tiene ni una sola fecha de calendario.** Numera las clases pero no las fecha.
Sin eso no se puede armar el cronograma real ni saber cuándo caen P1 y P2 — que son las dos
únicas notas de la materia.

## Fechas clave

| Fecha | Evento | Tipo |
|---|---|---|
| — | P1 — Defensa oral TPs 1–4 (clase 5) | Defensa |
| — | P2 — Defensa oral TPs 5–9 (clase 11) | Defensa |
| — | Recuperatorio (clase 12) | Recuperatorio |

**Ninguna tiene fecha publicada.** Es lo primero que hay que conseguir.

## Trabajos prácticos

| # | TP | Clase | Entrega | Estado | ¿Consigna publicada? |
|---|---|---|---|---|---|
| 1 | Git colaborativo | C1 | Antes de P1 | Publicado | ✅ [`trabajos/01-git-colaborativo.md`](https://github.com/ingsoft3ucc/TPs_2026/blob/main/trabajos/01-git-colaborativo.md) (794 líneas) |
| 2 | Contenedores: Docker + Compose | C2 | Antes de P1 | Publicado | ✅ [`trabajos/02-docker-compose.md`](https://github.com/ingsoft3ucc/TPs_2026/blob/main/trabajos/02-docker-compose.md) (978 líneas) |
| 3 | Planificación ágil | C3 | Antes de P1 | **No liberado** | ❌ |
| 4 | CI: Pipelines as Code | C4 | Antes de P1 | **No liberado** | ❌ |
| 5 | Testing en el pipeline | C5 | Antes de P2 | **No liberado** | ❌ |
| 6 | CD: environments y aprobaciones | C6 | Antes de P2 | **No liberado** | ❌ |
| 7 | Contenedores en el pipeline + e2e | C7 | Antes de P2 | **No liberado** | ❌ |
| 8 | Infraestructura como Código | C8 | Antes de P2 | **No liberado** | ❌ |
| 9 | DevSecOps + Observabilidad | C9 | Antes de P2 | **No liberado** | ❌ |
| — | **Integrador** | — | Para rendir el final | **No liberado** | ❌ |

Cada enunciado tiene la misma estructura: guía paso a paso sugerida (no se entrega) + el TP
entregable (sí se entrega y se defiende), con marco teórico, riel GitHub, riel Azure,
entregables, preguntas de defensa y tabla de evaluación.

### Consignas textuales

#### TP1 — Git colaborativo

**Objetivo:** *"Poner a funcionar —y defender— el flujo de trabajo con el que un equipo integra código: ramas, Pull Requests, revisión, protecciones sobre `main` y versionado de la entrega."*

**Tareas:**

> **1. Repositorio** — Repositorio **público** en la plataforma elegida (GitHub, Azure Repos u otra). `.gitignore` en la raíz (el base alcanza: la app del semestre se elige en el TP2).
>
> **2. Protecciones** — `main` protegida: **imposible pushear directo** — ni siquiera para vos, que sos el administrador (sin bypass). Todo cambio entra por Pull Request. **Evidencia del rechazo**: la salida del intento de push directo a `main`.
>
> **3. Pull Requests** — Al menos **2 PRs mergeados**, y uno de ellos tiene que haber requerido **resolver un conflicto de merge** (lo fabricás a propósito, §4.6). Todo cambio al repositorio entra por PR — incluidos los dos archivos de la entrega.
>
> **4. Versionado** — Tag `v1.0.0` (semver) sobre `main`, con su **release** publicada y notas de qué incluye.

**Entregables:** URL del repo público · `decisiones.md` (por qué Git no pudo resolver el conflicto solo · qué problemas encontraste y cómo los solucionaste · declaración de uso de IA) · `evidencias.md` con las 4 capturas marcadas 📸 (push directo rechazado, aviso de conflicto en el PR, marcadores del conflicto, release publicada).

**Preguntas de defensa publicadas:**

> - ¿Para qué sirve proteger `main` si en el equipo "se tienen confianza"? ¿Qué pasó cuando intentaste pushear directo?
> - ¿Qué es una rama *realmente* para Git? ¿Y por qué el merge que hiciste en GitHub no aparecía en tu máquina hasta que hiciste `pull`?
> - ¿Qué pasa cuando dos personas modifican la misma línea? Mostrame tu conflicto y explicame por qué Git no pudo resolverlo solo.
> - El code review es la práctica central de un equipo y en este TP trabajaste solo: ¿qué buscarías vos en el Pull Request de un compañero, y qué NO discutirías nunca en una revisión?
> - ¿Qué significa el número de versión que le pusiste al tag?

Nota de la cátedra: la estrategia de branching (GitHub Flow), la convención de nombres de rama
y el tipo de merge **los da la guía** — en el **TP4** hay que elegirlos y justificarlos.

#### TP2 — Contenedores: la app del semestre

**Objetivo:** *"Contenerizar la aplicación que vas a usar durante todo el semestre: Dockerfiles multi-stage para back y front, orquestación completa con compose, e imágenes publicadas en un registry."*

**Tareas:**

> **1. Elección de la app del semestre** — App con backend + frontend + base de datos (propia o de GitHub), corriendo localmente. Justificación en `decisiones.md` según los criterios de la guía. **Esta app es la que vas a usar en TP4–TP9 y en el Integrador.**
>
> **2. Dockerfiles** — Dockerfile **multi-stage** para el backend y para el frontend, cada uno con **su** `.dockerignore`. Si tu frontend es una SPA servida por nginx, su `nginx.conf` con el proxy hacia el backend.
>
> **3. Compose** — `docker-compose.yml` que levanta el sistema completo (front + back + BD) con `docker compose up -d`, incluyendo: volumen para persistencia de la BD, comunicación entre servicios por nombre, `depends_on` con `healthcheck` de la BD, y secretos vía `.env` no commiteado (con `.env.example` commiteado).
>
> **4. Publicación** — Imágenes de back y front publicadas en un registry gratuito (ghcr.io o Docker Hub) con tag semver (`v0.1.0`) y visibilidad **pública** (las dos). `docker-compose.registry.yml`: la variante que **baja** las imágenes en vez de construirlas, probada de verdad.
>
> **5. Arranque documentado** — Un `README.md` con los pasos exactos para levantar tu sistema en una máquina limpia, empezando por el `cp .env.example .env`.

**Entregables:** URL del repo público · `decisiones.md` (qué app elegiste y por qué contra los criterios · decisiones de contenerización: imágenes base, multi-stage, qué persiste · problemas y soluciones) · `evidencias.md` (`docker compose up -d` desde cero funcionando end-to-end · prueba de persistencia con `down`/`up` y `down -v` · comparación de tamaño imagen final vs SDK · imágenes publicadas en el registry).

**Preguntas de defensa publicadas:**

> - ¿Qué diferencia hay entre imagen y contenedor? ¿Y entre `CMD` y `ENTRYPOINT`?
> - ¿Por qué tu Dockerfile es multi-stage? ¿Qué pasaría si no lo fuera?
> - ¿Qué pasa con los datos si borro el contenedor de la BD? ¿Y con `docker compose down -v`?
> - ¿Cómo se encuentra el backend con la BD? ¿Qué es `db` en tu connection string?
> - ¿Por qué `depends_on` solo no alcanza y hace falta el healthcheck?
> - ¿Por qué el `.env` no está en el repo? ¿Dónde van a vivir esos secretos cuando esto corra en un pipeline?
> - En vivo: cloná tu repo en una carpeta limpia y levantalo siguiendo **tu propio `README`**.

> 📌 **Dónde van `decisiones.md` y `evidencias.md`:** en la **raíz** del repositorio. Si ya
> tenés uno del TP1, se sigue escribiendo abajo con un título `## TP2 — Contenedores`. El
> historial del semestre es uno solo. Y entran **por PR**, no directo a `main`.

## Proyecto integrador

**Sí tiene, y es el eje de la materia.** No es un trabajo aparte: es la misma app creciendo
capa por capa.

- Desde el **TP2** se elige una **app full-stack** (frontend + backend + base de datos), propia
  o adaptada de un repo público. Esa app acompaña toda la materia.
- **Un solo repo** — la app entra al mismo repo del TP1. *"Los TPs no son entregables sueltos:
  son **capas sobre el mismo artefacto** (el pipeline del TP4 corre los tests del TP5, el CD del
  TP6 despliega la imagen del TP7)."*
- **Un tag por TP**: al cerrar cada TP se etiqueta ese commit (`git tag -a tp2 -m "TP2 cerrado"`).
  Cada TP queda con su snapshot congelado, y en la defensa se navega el estado exacto.
- **Cambio de app**: permitido **hasta el TP4 inclusive**. Después hay que consultar.
- **Es individual.** *"Los TPs son individuales: tu repo, tus decisiones, tu defensa."*
- El **Integrador** pide la cadena completa y es condición para rendir el final. *"Si venís al
  día, al llegar a P2 lo tenés ~80 % hecho."*
- Guía de selección de app: [`elegir-app.md`](https://github.com/ingsoft3ucc/TPs_2026/blob/main/elegir-app.md)
  — 5 criterios y un test de 20 minutos para hacer **antes** de comprometerse. La cátedra la
  llama *"el documento que más dolores de cabeza evita"*.
- Sample de referencia de la cátedra (para inspirarse, **no** para entregar):
  [`ingsoft3ucc/demo-fullstack`](https://github.com/ingsoft3ucc/demo-fullstack) — .NET 8 +
  React/Vite + PostgreSQL.

## Material publicado

| Archivo | Tipo | Unidad | URL | ¿Reemplaza a? |
|---|---|---|---|---|
| `README.md` | Reglamento operativo (134 líneas) | Toda la materia | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/README.md) | No |
| `Clase01-presentacion.pdf` | Filminas | C1 | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/clases/Clase01/Clase01-presentacion.pdf) | No |
| `Clase02-presentacion.pdf` | Filminas | C2 | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/clases/Clase02/Clase02-presentacion.pdf) | No |
| `01-git-colaborativo.md` | Enunciado TP1 | C1 | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/trabajos/01-git-colaborativo.md) | No |
| `02-docker-compose.md` | Enunciado TP2 | C2 | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/trabajos/02-docker-compose.md) | No |
| `elegir-app.md` | Guía de selección de app | TP2 | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/elegir-app.md) | No |
| `smoke-test-vigencia.md` | Doc operativo de la cátedra | — | [Ver](https://github.com/ingsoft3ucc/TPs_2026/blob/main/smoke-test-vigencia.md) | No |

**Videos** (no están en el repo, van por Releases — el `git clone` queda liviano):

| Video | Tipo | URL |
|---|---|---|
| Clase 1 | Grabación de la clase | `releases/download/clase01/Clase01-video.mp4` |
| TP1 | Guía en video del TP | `releases/download/tp01/TP01-video.mp4` |
| Clase 2 | Grabación de la clase | `releases/download/clase02/Clase02-video.mp4` |
| TP2 | Guía en video del TP | `releases/download/tp02/TP02-video.mp4` |

**Ventaja enorme sobre las otras materias:** el repo es público y versionado. Un `git pull`
trae todo lo nuevo, y `git log` dice exactamente qué cambió y cuándo. No hace falta scrapear.

## Estado personal

- **Notas cargadas:** ninguna. No hay notas hasta P1.
- **Asistencia:** no se registra en el repo. La materia *"se aprueba trabajando todas las semanas"*.
- **Entregas hechas / pendientes:** no se puede saber desde el repo de la cátedra — tu entrega
  vive en **tu propio repo público**, cuya URL se carga en el formulario. **Dato a completar
  por vos:** ¿ya tenés el repo del TP1? ¿Elegiste la app del semestre?

## Novedades y anuncios

| Fecha | Anuncio |
|---|---|
| 12/08/2026 | Último commit del repo: *"El video del TP2 ya se puede ver desde el README"* |

El repo se actualiza semana a semana: *"Este repo se va llenando a medida que avanza la
cursada: el enunciado de cada TP y las filminas de cada clase se publican en la semana que
corresponde."*

## Requisitos técnicos

**Es la materia con más stack de todas.**

| Capa | Herramientas |
|---|---|
| Control de versiones | Git · GitHub (protecciones de rama, PRs, tags, releases) |
| Contenedores | Docker · Docker Compose · registry (ghcr.io o Docker Hub) |
| CI/CD | GitHub Actions (riel canónico) · Azure DevOps / Azure Pipelines (riel alternativo) |
| Calidad | Unit tests + coverage · análisis estático · SonarQube Cloud |
| Seguridad | Secret scanning · CodeQL · DevSecOps |
| IaC | Infraestructura como Código (herramienta no especificada todavía) |
| Observabilidad | Monitoreo y continuous feedback (sin especificar) |
| App de referencia | .NET 8 + React/Vite + PostgreSQL (el sample; tu app puede ser otro stack) |

**Tres rieles posibles:**

1. **Riel GitHub (canónico)** — GitHub Actions + servicios gratuitos verificados **sin tarjeta
   de crédito**. Es el de las demos, trae guía paso a paso completa y **fallback local
   documentado** (self-hosted runner + docker-compose).
2. **Riel Azure** — Azure DevOps / Azure, el stack de la certificación **AZ-400**. Ojo: *"los
   minutos hosted de Azure Pipelines requieren organización vinculada a una suscripción"*.
3. **Tier libre** — AWS, GCP, GitLab u otra, con el mismo contrato de entregables y soporte
   limitado. *"GitLab pide tarjeta para validar sus runners compartidos."*

**Repos públicos: obligatorio.** *"las funciones que la materia usa (protecciones, Actions
ilimitado, environments con aprobaciones, secret scanning, CodeQL, SonarQube Cloud) son
gratuitas **solo** en repos públicos."*

**Requisito de máquina:** notebook con Docker funcionando, desde la C2.

## 🤖 Política de uso de IA — leer

Es la única materia del vault con una política explícita, y **te afecta directamente** porque
usás Claude para estudiar y para el vault.

> "La IA (ChatGPT, Copilot, Claude…) está **permitida y alentada** — es como se trabaja hoy. Con una condición innegociable:
> 1. **Declarás** en `decisiones.md` qué partes fueron asistidas por IA.
> 2. **Verificaste** lo que la IA produjo (y contás cómo).
> 3. **Podés defenderlo**: si en la defensa no podés explicar una decisión que la IA tomó por vos, ese punto **no se aprueba**."

Y explícitamente incluye a los agentes, no solo a los que escriben texto:

> "**Las tres valen también para la IA que opera, no solo para la que escribe.** Hoy hay agentes que investigan un incidente y proponen la causa raíz, que generan y corren el plan de pruebas de un release, o que configuran el pipeline solos. Si usás uno, la vara es la misma: declarado, verificado y defendible."

**Consecuencia práctica:** todo lo que hagas con Claude para esta materia tiene que quedar
anotado en `decisiones.md` de tu repo, con cómo lo verificaste.

## ⚠️ Faltantes y dudas

1. **No hay ni una fecha de calendario en todo el repo.** Numera 12 clases pero no las fecha.
   Sin eso no se sabe cuándo caen **P1** ni **P2**, que son las dos únicas notas de la materia.
   Es lo más urgente. Probablemente esté en el aula del campus (curso 15011) o se dio en clase.
2. **El aula del campus no se revisó** (quedó fuera del alcance acordado). Es el lugar más
   probable para las fechas y para la fecha límite de entrega de cada presentación.
3. **Días, horarios y aula física:** no figuran.
4. **Mail del docente:** no figura en el repo.
5. **7 de los 9 TPs no están publicados** (TP3 a TP9) + el Integrador. Se van liberando semana
   a semana.
6. **Filminas de las clases 3 a 12:** no publicadas.
7. **Existe una cátedra teórica aparte** que este repo no cubre y de la que no se sabe nada:
   docente, programa, régimen ni si tiene parciales propios. El repo solo dice que la teoría de
   la práctica *"no repite ni reemplaza a la materia teórica"*.
8. **No se sabe si ya empezaste.** ¿Tenés el repo del TP1 con las protecciones? ¿Elegiste la app
   del semestre? ¿Hiciste el test de 20 minutos de `elegir-app.md`? Eso lo sabés vos y define
   qué tan atrasado estás: al 13/08 ya se dictaron C1 y C2, o sea que **TP1 y TP2 deberían
   estar en marcha**.
9. **La materia no está dada de alta en el vault** — hay que crearla. Sugerencia de sufijo para
   los archivos de seguimiento: `-isw3` (`cronograma-isw3.md`, `condiciones-isw3.md`), que no
   choca con nada.
10. **Ojo con el nombre de carpeta:** ya existe `Ing-Software-II/` en el vault. Conviene
    `Ing-Software-III/` para que se distingan de un vistazo.

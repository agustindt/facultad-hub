---
scrape_fecha: 2026-08-13
scrape_fuente: https://presencial.ucc.edu.ar/course/view.php?id=15046
materia_nombre_campus: "ECONOMIA (A)"
materia_codigo: CC0820104A
slug: economia
anio: 4
semestre: 2
carrera: "Ingeniería (categoría campus: 08- Ingeniería) — Facultad de Ingeniería, UCC"
plan: 2016
comision: "Cátedra A"
existe_en_vault: false
carpeta_vault: null
completitud: alta
---

# Economía (Cátedra A) — scrape del campus

> **Materia nueva: no existe en el vault.** Según el brief no le doy de alta carpeta ni
> comando — eso lo hacés vos después.
>
> Dos fuentes se cruzaron acá: (1) el aula virtual 2026, y (2) la carpeta
> `~/Downloads/Economia` que me pediste revisar, que resultó ser material de **2016–2019**
> de otra cátedra. Todo lo marcado como 2026 sale del campus; lo de la carpeta vieja está
> aislado en su propia sección al final y **no se mezcló** con lo actual.

## Docentes

| Nombre | Rol | Mail |
|---|---|---|
| Mgter. Francisco J. Boggione | Profesor Titular — clases teóricas | 2360849@ucc.edu.ar |
| Lic. Francisco N. Hiza | Jefe de Trabajos Prácticos — clases prácticas | 2665395@ucc.edu.ar |

- Ambos mails salen del PDF "Un 0 - INTRODUCCIÓN A LA MATERIA CÁT A" (slide 2), edición 2026.
- ⚠️ **Discrepancia menor en la inicial del JTP:** el texto de bienvenida del aula dice
  "Lic. Francisco **M.** Hiza"; el PDF de la cátedra dice "Lic. Francisco **N.** Hiza".
  No sé cuál es la correcta.

## Cursada

- **Días y horarios** (textual del PDF de presentación 2026):
  - **Jueves 18:30 a 20:30 hs — CLASES TEÓRICAS**
  - **Viernes — CLASES PRÁCTICAS**, en dos comisiones:
    - **A1: 17:15 a 19:15 hs**
    - **A2: 19:45 a 21:45 hs**
  - ⚠️ **No figura en qué comisión de práctico estás inscripto (A1 o A2).** El campus no
    tiene grupos asignados: la lista de participantes muestra "No hay grupos" para todos.
- **Aulas:** no figuran en el campus.
- **Modalidad:** presencial, con aula virtual de apoyo montada sobre la plantilla PIED.
  Requisito de acceso declarado en el aula: *"REQUISITOS PARA ACCEDER AL CURSO: INSCRIBIRSE
  EN LA MATERIA Y AUTOMATRICULARSE"*.
- **Inicio / fin:** no figuran.

## Programa

⚠️ **Hay dos numeraciones de unidades distintas conviviendo, y no coinciden.** Esto importa
mucho para armar el vault, así que van las dos.

### (a) Numeración del PDF de la cátedra 2026 — 6 unidades

Es la que usa el docente para la bibliografía obligatoria. La tomo como la **oficial de esta cursada**.

| # | Unidad | Temas | Bibliografía obligatoria |
|---|---|---|---|
| I | Introducción a la Economía | ver contenidos 1–2 abajo | Mochón Morcillo, Francisco y Beker, Víctor. *"Economía - Principios y Aplicaciones"* |
| II | Microeconomía: Teoría de la Producción y de los Costos | contenidos 3–4 | Mochón Morcillo y Beker, *"Economía - Principios y Aplicaciones"* |
| III | Microeconomía: Demanda y Mercados | contenidos 5–7 | Mochón Morcillo y Beker, *"Economía - Principios y Aplicaciones"* |
| IV | Economía de Empresas | contenidos 11–13 | Brealey, Richard A., Myers, Stewart C. y Allen, Franklin. *"Principios de Finanzas Corporativas"* · Horngren Ch., Datar S., Foster G. *"Contabilidad de Costos"* · García, Norberto y Arnoletto, José L. *"Introducción a la Contabilidad"* |
| V | Macroeconomía | contenidos 8–10 | Sachs, Jeffrey D. y Larraín B., Felipe. *"Macroeconomía en la economía global"* |
| VI | Proyectos de Inversión | contenidos 17–19 | Sapag Chain, Nassir. *"Proyectos de inversión: formulación y evaluación"* |

### (b) Numeración de las secciones del aula virtual — 7 unidades

El aula está organizada en UNIDAD 1 a UNIDAD 7, y **invierte el orden de Macroeconomía y
Economía de Empresas** respecto del PDF, además de separar Proyectos de Inversión en dos.

| Sección | Título en el aula | Contenidos numerados | Material de lectura obligatoria declarado en la sección |
|---|---|---|---|
| UNIDAD 1 | Introducción a la economía | 1, 2 | Mochón & Beker cap. 1 · Mankiw *"Principios de Economía"* 7ª ed. 2015, Parte 1 |
| UNIDAD 2 | Teoría de la Producción y de los Costos | 3, 4 | Mochón & Beker cap. 5 y cap. 2 (2.3 La Oferta) · Mankiw cap. 13 |
| UNIDAD 3 | Demanda y Mercados | 5, 6, 7 | Mochón & Beker caps. 3, 4, 6, 7, 8, 9, 10, 11 · Mankiw caps. 4, 5, 6, 7, 14, 15, 16, 17, 18, 21 |
| UNIDAD 4 | **Macroeconomía** | 8, 9, 10 | Mochón & Beker caps. 12 a 23 |
| UNIDAD 5 | **Economía de empresas** | 11, 12, 13 | Horngren, *"Contabilidad de Costos"* |
| UNIDAD 6 | Ingeniería Económica | 14, 15, 16 | Blank, Leland y Tarquin, Anthony. *"Ingeniería económica"* |
| UNIDAD 7 | Formulación y evaluación de proyectos de inversión | — | **La sección está vacía**: solo el título, sin objetivos, contenidos ni bibliografía |

**Ojo con el choque:** el PDF 2026 no lista "Ingeniería Económica" como unidad propia (la
absorbe en VI Proyectos de Inversión) y ordena Economía de Empresas antes que Macroeconomía.
El aula hace lo contrario. Hay que confirmarle al docente cuál manda para el orden de cursada
y, sobre todo, **qué unidades entran en cada parcial**.

### Objetivos generales (textual del aula)

> "Capacitar a los futuros ingenieros en reconocer la relación entre ingeniería (tecnología) y economía (asignación de recursos escasos).
> Capacitar en la utilización de los elementos básicos de las ciencias económicas aplicados a las empresas y a la sociedad, con énfasis en criterios y herramientas para la toma de decisiones y la evaluación de proyectos en el ámbito de problemas de ingeniería."

### Contenidos numerados (textual del aula, 1 a 16)

**UNIDAD 1 — Introducción a la economía.** *Objetivo: entender los problemas económicos básicos, sus variables y los modelos micro y macroeconómicos en su relación con los problemas de ingeniería.*

> 1. Economía positiva y normativa. Teoría económica y política económica. Los instrumentos del análisis económico. Modelos e investigación. Variables económicas.
> 2. El principio de escasez. Los factores de la producción. La frontera de las posibilidades de producción. Costo de oportunidad. Problemas económicos básicos. Economía de mercado y economía planificada. Problemas económicos de ingeniería.

**UNIDAD 2 — Teoría de la Producción y de los Costos.** *Objetivo: entender la teoría de la producción y de los costos como explicativos de la oferta de las empresas.*

> 3. La empresa y la producción. Tecnologías. Cadenas de abastecimiento. Funciones de producción. Producto total, medio y producto marginal. El corto plazo y los rendimientos decrecientes. Isocuantas. Tasa marginal de sustitución técnica. Rendimientos de escala. Eficiencia técnica y económica. Isocostos. Sendero de expansión. El equilibrio del productor respecto a la tecnología. Función de producción Cobb-Douglas.
> 4. Costos de corto plazo. Fijos y variables. Costo total, medio y marginal. El equilibrio del productor respecto a la tasa de producción. Costos de largo plazo. Costos medios y marginales de largo plazo. Economías y deseconomías de escala. El equilibrio del productor respecto al tamaño de planta. Escala mínima eficiente.

**UNIDAD 3 — Demanda y Mercados.** *Objetivos: conocer el comportamiento de la demanda y el proceso de formación de precios; identificar las variables del mercado de factores en los mercados industriales y su relación con la distribución del ingreso; reconocer las fallas de mercado, bienes públicos y externalidades, y el rol del Estado en el desarrollo sustentable.*

> 5. Teoría de la utilidad. La utilidad total y marginal. Equilibrio del consumidor. La demanda. Función de demanda. Elasticidad-precio, elasticidad-ingreso, elasticidades cruzadas. El excedente del consumidor.
> 6. Clasificación de mercados. Mercados de bienes y servicios. Equilibrio del productor respecto al mercado. Principio marginal de maximización de beneficios. Precio y producción en competencia perfecta y en monopolio. Competencia monopolística. Oligopolios. Índice de Herfindhal. Defensa de la competencia.
> 7. Mercado de factores. Demanda y oferta. Distribución del ingreso. Mercado del trabajo. Sindicatos. Mercado de capitales. Rendimientos y riesgo. Eficiencia económica y fallas del mercado. Mercados estrechos. Externalidades. Bienes públicos. El rol del Estado. Regulaciones. Medio ambiente y desarrollo sustentable. Economía ambiental.

**UNIDAD 4 — Macroeconomía.** *Objetivo: conocer los problemas macroeconómicos como marco de referencia en la economía de las empresas: contabilidad pública, flujo de la renta, política fiscal y monetaria, comercio internacional.*

> 8. Problemas macroeconómicos. Objetivos. Instrumentos de política macroeconómica. Demanda y oferta agregada. Contabilidad Nacional. Producto Bruto y Neto. Métodos del gasto, del ingreso y del valor agregado. Matriz insumo producto y coeficientes técnicos.
> 9. Consumo y ahorro. Demanda de inversión. Modelo de Keynes. Flujo circular del ingreso. Presupuesto público y Política fiscal. Sector financiero. El Dinero. Intermediarios financieros. Política monetaria. Desempleo, Inflación.
> 10. Economía internacional. Comercio exterior. Balanza de pagos. Mercado de divisas. Crecimiento económico y desarrollo. Mercados comunes. Nueva economía y tecnologías de la información.

**UNIDAD 5 — Economía de empresas.** *Objetivos: comprender los sistemas de información contable como lenguaje de los negocios; identificar la estructura financiera de las empresas y fuentes de financiamiento; aplicar diversos métodos de contabilidad de costos.*

> 11. Empresas e integrantes. Sistemas de información contable. Contabilidad general. Estados financieros básicos. Balances. Cuenta de pérdidas y ganancias. Procedimientos contables. Auditorías. Depreciación funcional y contable. Distintos métodos. Impuesto a las ganancias. IVA.
> 12. Estructura financiera de las empresas. Giro del capital circulante. Fuentes de financiamiento. Inversiones y el mercado de capitales. Indicadores y ratios de perfomance. Solvencia, Rentabilidad. Tablero de comando financiero.
> 13. Contabilidad de costos. Elementos. Costeo por absorción. Costos indirectos de fabricación. Costos por órdenes y procesos. Costos en producción conjunta. Costos basados en actividades. Costeo variable. Estimación de costos. Métodos estadísticos y de ingeniería. Enfoque de la teoría de las restricciones.

**UNIDAD 6 — Ingeniería Económica.** *Objetivos: comprender y aplicar técnicas de ingeniería económica para toma de decisiones; entender y aplicar criterios de decisión bajo riesgo y bajo incertidumbre; comprender las variables y aplicar criterios para la formulación y evaluación de proyectos de inversión.*

> 14. Valor del dinero en el tiempo. Tasas de interés. Factores de equivalencias de pago único y anualidades. Efecto de la inflación. Bases para comparación de alternativas. Flujo de fondos. Período de análisis y valor residual. Tasa de descuento. Análisis beneficio-costo. Alternativa nula. Valor Presente (VAN). Tasa interna de retorno (TIR). Otros indicadores.
> 15. Reemplazo de equipos. Vida de servicio económica. Análisis de costo presente. Análisis de Punto de equilibrio. Fabricar o comprar. Alquilar o comprar. Selección de equipos.
> 16. Teoría de decisión. Riesgo e incertidumbre. Escenarios. La matriz de pagos. Criterios de decisión bajo riesgo. Probabilidades. Valor esperado. Árboles de decisión. Métodos de Simulación (Montecarlo). Criterios de decisión bajo incertidumbre. Laplace, Hurwics, Savage.

**UNIDAD 7 — Formulación y evaluación de proyectos de inversión.** Sección vacía en el aula, sin contenidos publicados.

## Condiciones de aprobación

Fuente: PDF de presentación de la cátedra 2026 (slide 6) y texto de bienvenida del aula.
**Ambas fuentes coinciden**, lo cual es buena señal.

### Regular

- Asistir como mínimo al **65 % de las clases**.
- Aprobar **2 exámenes parciales teórico-prácticos con nota ≥ 4 (cuatro)**.
- Se puede recuperar **1 parcial por aplazo o por ausencia**, debiendo aprobarlo y alcanzar
  con todos los parciales rendidos un **promedio ≥ 4**. Textual: *"(se promedian las 3 notas)"*.

### Promoción

Ojo: en esta materia la promoción es **solo del práctico**, no de la materia completa.

- Asistir como mínimo al **65 % de las clases**.
- Aprobar **2 exámenes parciales teórico-prácticos con nota ≥ 7 (siete)**.
- Se puede recuperar **1 parcial por ausencia** (⚠️ **por ausencia solamente** — no por
  aplazo, a diferencia de la regularidad), debiendo aprobarlo y alcanzar un **promedio ≥ 7**.
- Textual: *"La condición de promoción de práctico se conserva hasta los turnos programados
  para la primera época ordinaria de exámenes inmediata posterior al cierre de condiciones
  del dictado de la asignatura."*

### Recuperatorios

- **1 solo recuperatorio.** Fecha: **jueves 12/11/2026**, en horario del teórico.
- Para regularidad: recupera aplazo **o** ausencia. Para promoción: solo ausencia.

### TPs

**No hay ninguna tarea ni entrega creada en el aula virtual** y **el régimen 2026 no
menciona trabajos prácticos ni monografía como condición**. Las condiciones publicadas para
2026 son únicamente asistencia + 2 parciales.

⚠️ Esto **contradice** el programa 2019 que está en tu carpeta de Downloads, que sí exigía
"Aprobar los Trabajos prácticos y la Monografía" para la regularidad. Ver la sección de
material viejo más abajo. **Dato a confirmar con el docente** — es la diferencia más
importante entre las dos fuentes.

Sí existen clases prácticas semanales (viernes) y el PDF menciona "DINÁMICA DE CLASES:
TEÓRICO-PRÁCTICO" entre las consideraciones, pero sin régimen de entregas publicado.

### Escala de notas

No está publicada. Solo se conocen los umbrales: 4 para aprobar/regularizar, 7 para promoción
del práctico.

### Examen final

| Condición | Formato |
|---|---|
| Regulares y libres | Ejercicios prácticos (escrito) + teórico oral |
| Promoción (del práctico) | Solo teórico oral |

## Cronograma

| Sem | Fecha | Teórico | Práctico / Hitos |
|---|---|---|---|
| — | Jueves (semanal) | Clase teórica 18:30–20:30 | — |
| — | Viernes (semanal) | — | Clase práctica A1 17:15–19:15 / A2 19:45–21:45 |
| — | **11/09/2026** | — | **Primer parcial** (en horario del práctico) |
| — | **29/10/2026** | **Segundo parcial** (en horario del teórico) | — |
| — | **12/11/2026** | **Recuperatorio** (en horario del teórico) | — |

⚠️ **No hay cronograma semana a semana publicado para 2026.** Solo se conocen los días fijos
y las tres fechas de evaluación. No se sabe qué unidad se ve cada semana ni qué unidades
entran en cada parcial.

## Fechas clave

| Fecha | Evento | Tipo |
|---|---|---|
| 11/09/2026 | Primer parcial teórico-práctico (horario del práctico, viernes) | Parcial |
| 29/10/2026 | Segundo parcial teórico-práctico (horario del teórico, jueves) | Parcial |
| 12/11/2026 | Recuperatorio (horario del teórico, jueves) | Recuperatorio |

Los tres días de la semana declarados en el PDF coinciden con el calendario 2026: 11/09 es
viernes, 29/10 y 12/11 son jueves. ✔️

⚠️ **No se publicó qué unidades cubre cada parcial.** El programa 2019 dividía I-II-III en el
primero y IV-V-VI-VII en el segundo, pero ese reparto **no está confirmado para 2026** y la
numeración de unidades cambió. No lo asumas.

## Trabajos prácticos

| # | TP | Unidad | Entrega | Estado | ¿Consigna publicada? |
|---|---|---|---|---|---|
| — | *Ninguno creado en el aula virtual* | — | — | — | No |

### Consignas textuales

*No hay ninguna consigna publicada en el campus.* La carpeta `GUÍA DE TRABAJOS PRÁCTICOS`
de tu Downloads está **vacía**.

## Proyecto integrador

**No figura para 2026.** El aula no tiene proyecto ni trabajo final integrador.

Antecedente (2019, no vigente): el programa de ese año exigía una **monografía grupal** sobre
un tema económico propuesto por los alumnos y aceptado por la cátedra, presentada al final del
semestre y expuesta en clase, con TPs en grupos de 2 o 3. **Nada de esto aparece en el
material 2026.** Ver sección de material viejo.

## Material publicado

Todo lo que hay en el aula (6 archivos, ninguna carpeta, ninguna URL):

| Archivo | Tipo | Subido | Unidad | URL | ¿Reemplaza a? |
|---|---|---|---|---|---|
| INTRODUCCIÓN A LA MATERIA (`Un 0 - INTRODUCCIÓN A LA MATERIA CÁT A.pdf`, 10 diapositivas) | PDF (export de PowerPoint) | No figura la fecha; el contenido dice 2026 | Presentación Materia | https://presencial.ucc.edu.ar/mod/resource/view.php?id=1184984 | No |
| UN 1 - TEÓRICO INTRODUCCIÓN A LA ECONOMÍA | Archivo | No figura | UNIDAD 1 | https://presencial.ucc.edu.ar/mod/resource/view.php?id=1184978 | No |
| UN 2 - TEÓRICO TEORÍA DE LA PRODUCCIÓN Y DE LOS COSTOS | Archivo | No figura | UNIDAD 2 | https://presencial.ucc.edu.ar/mod/resource/view.php?id=1184977 | No |
| MOCHON & BEKER - Economía Principios y Aplicaciones | Archivo (libro) | No figura | BIBLIOGRAFÍA — obligatoria Unidades I-II-III-IV | https://presencial.ucc.edu.ar/mod/resource/view.php?id=1092061 | No |
| Mankiw Principios de Economia 7 ed 2017 | Archivo (libro) | No figura | BIBLIOGRAFÍA | https://presencial.ucc.edu.ar/mod/resource/view.php?id=1092062 | No |
| Horngren - Contabilidad de Costos | Archivo (libro) | No figura | BIBLIOGRAFÍA | https://presencial.ucc.edu.ar/mod/resource/view.php?id=1092063 | No |

**Pista de versionado:** los tres archivos de cátedra tienen IDs `11849xx` y los tres libros
`10920xx`. Los libros son de una carga anterior (probablemente el aula del año pasado); los
teóricos de unidad son de esta cursada. Ningún archivo aparece marcado como reemplazo de otro.

**Faltan los teóricos de las unidades 3 a 7.** Las secciones 3, 4, 5 y 6 del aula tienen el
encabezado "DOCUMENTOS DE LA CLASE" pero **sin ningún archivo debajo** — se van a ir subiendo
durante el semestre.

⚠️ **Bibliografía obligatoria que la cátedra pide y NO está en el aula:** Brealey/Myers/Allen
*"Principios de Finanzas Corporativas"* (U-IV), García y Arnoletto *"Introducción a la
Contabilidad"* (U-IV), Sachs y Larraín *"Macroeconomía en la economía global"* (U-V), y
Sapag Chain *"Proyectos de inversión"* (U-VI). De estos, **solo Sapag Chain está en tu
carpeta de Downloads** (edición vieja).

## Estado personal

- **Notas cargadas:** ninguna. El libro de calificaciones no tiene ni un solo ítem: solo
  "Total del curso", sin nota, rango 0–100. Los parciales no están cargados como actividades.
- **Asistencia:** no hay actividad de asistencia en el aula. El 65 % se controla en papel/clase.
- **Entregas hechas / pendientes:** ninguna, no hay tareas creadas.
- **Grupo de práctico:** sin asignar en el campus ("No hay grupos"). No se puede saber desde
  acá si vas a A1 o A2.

## Novedades y anuncios

| Fecha | Anuncio |
|---|---|
| — | *Ninguno* |

Los cuatro foros del aula están en **0 debates**: "Avisos" (aparece duplicado, dos foros con
el mismo nombre y descripción), "Foro social" y "Foro de presentación". El docente todavía no
publicó nada.

## Requisitos técnicos

Ninguno declarado. Es una materia de lápiz y papel + planilla de cálculo. Único dato del PDF:
la cátedra usa **Kahoot** para repasos en clase.

Consideraciones adicionales que la cátedra remarca (textual, slide 8):

> "PUNTUALIDAD · ASISTENCIAS · AUSENCIAS · DINÁMICA DE CLASES: TEÓRICO-PRÁCTICO · PARTICIPACIÓN · PRESTAR ATENCIÓN EN CLASES Y TOMAR NOTA · PRESENTACIONES DE CLASES (NO SON EL MATERIAL DE ESTUDIO) · NO USAR MATERIAL DE ESTUDIO VIEJO/AÑOS ANTERIORES · CONSULTAS · KAHOOT DE REPASO"

Dos de esas viñetas son directamente accionables para el vault:

1. **"PRESENTACIONES DE CLASES (NO SON EL MATERIAL DE ESTUDIO)"** — los PDF de teórico son
   apoyo, no reemplazan la bibliografía. Al armar las notas, la fuente de verdad es el libro.
2. **"NO USAR MATERIAL DE ESTUDIO VIEJO/AÑOS ANTERIORES"** — ver la sección siguiente.

## 📂 Carpeta `~/Downloads/Economia` — material viejo (2016–2019)

Revisada a pedido tuyo. **No es material de esta cursada.** Es un volcado de la carpeta
pública de Google Drive de la cátedra de un año anterior: las fechas de los archivos van de
**septiembre 2016 a agosto 2019**, y el programa que contiene es del **año lectivo 2019, con
otro docente: RAMIRO MANUEL GARCIA**. Pesa 221 MB.

La cátedra 2026 pide explícitamente **no** estudiar de material de años anteriores. Lo dejo
listado como referencia y como pista de qué buscar, no como fuente.

| Ruta | Archivo | Peso | Fecha | ¿Sirve? |
|---|---|---|---|---|
| `BIBLIOGRAFIA/` | Blank y Tarquin - Ingenieria Economica.pdf | 140 MB | 30/09/2017 | Bibliografía de la U-VI del aula ("Ingeniería Económica"). El libro no cambia de año a año; la edición sí puede. |
| `BIBLIOGRAFIA/` | Horngren - Contabilidad de Costos.pdf | 35 MB | 30/09/2017 | **Ya está en el aula 2026**, más nuevo. Usá el del campus. |
| `BIBLIOGRAFIA/` | MOCHON & BEKER - Economia Principios y Aplicaciones.pdf | 46 MB | 30/09/2017 | **Ya está en el aula 2026.** Usá el del campus. |
| `BIBLIOGRAFIA/` | Sapag Chain - Preparacion y evaluacion de Proyectos.pdf | 4 MB | 04/08/2019 | Bibliografía obligatoria de la U-VI 2026 y **no está en el aula**. Es el único del lote que tapa un hueco real. |
| `DOCUMENTOS-ARTÍCULOS/` | Calculadora TEA.xlsx | 27 KB | 19/10/2017 | Herramienta, no material de estudio. Puede seguir sirviendo para ingeniería económica. |
| `DOCUMENTOS-ARTÍCULOS/` | ejemplos TEA El Salvador.pdf | 3,6 MB | 19/10/2017 | Ejemplos viejos. |
| `DOCUMENTOS-ARTÍCULOS/` | ipc_que_es_06_16.pdf | 1,4 MB | 27/09/2016 | INDEC, 2016. **Datos desactualizados**, no usar para macro. |
| `DOCUMENTOS-ARTÍCULOS/` | Mercado de Trabajo principales indicadores - 2trim16.pdf | 92 KB | 27/09/2016 | Idem, 2º trimestre 2016. |
| `MONOGRAFÍAS/` | Monografia de Economia.pdf | 144 KB | 19/10/2018 | Monografía de ejemplo. La monografía **no está en el régimen 2026**. |
| `PROGRAMA/` | PROGRAMA 2019.pdf | 24 KB | 04/08/2019 | Programa oficial 2019, 6 páginas. Útil solo como referencia histórica. |
| `CLASES/` | *(vacía)* | — | — | — |
| `GUÍA DE TRABAJOS PRÁCTICOS/` | *(vacía)* | — | — | — |
| `NOTAS PARCIALES/` | *(vacía)* | — | — | — |

**Qué aporta el programa 2019 que el campus 2026 no tiene** (útil como hipótesis, **no como dato**):

- La asignatura figura con código **20104** en la Facultad de Ingeniería (coincide con el
  `CC0820104A` del campus).
- Tenía **7 unidades** (I a VII), con la misma numeración que las secciones del aula actual —
  o sea, **el aula 2026 está clonada de la estructura vieja**, y por eso choca con el PDF nuevo
  de 6 unidades. Esto explica la contradicción.
- Calendario de 28 clases: parcial 1 en la clase 11 (unidades I, II y III), parcial 2 en la
  clase 26 (unidades IV, V, VI y VII), clase 27 presentación de monografías, clase 28
  recuperatorio. **Este reparto de unidades por parcial es de 2019 — no lo des por válido.**
- Régimen 2019 de regularidad: 65 % de asistencia, **aprobar los TPs y la monografía**, y 2
  parciales ≥ 4. La exigencia de TPs y monografía **desapareció** del régimen 2026.
- Mencionaba una **carpeta pública en Google Drive de la UCC bajo el nombre "Economía"** con
  material de apoyo, los TPs y el desarrollo de la monografía. Si la cátedra sigue usando ese
  canal, ahí estarían los TPs que faltan en el campus. **Vale la pena preguntarlo.**

## ⚠️ Faltantes y dudas

1. **Choque de numeración de unidades.** El PDF 2026 define 6 unidades; el aula tiene 7 con
   otro orden (Macro y Economía de Empresas invertidas). Antes de crear `01-Unidades/` hay que
   resolver cuál se usa. Mi lectura: el PDF 2026 es el vigente y el aula quedó clonada de 2019,
   pero **hay que confirmarlo con el docente**.
2. **Qué unidades entra en cada parcial: no publicado.** Es el dato más importante que falta
   para el seguimiento y no lo inventé. El reparto 2019 (I-II-III / IV-V-VI-VII) es solo una
   pista.
3. **Régimen de TPs y monografía: contradictorio entre fuentes.** 2026 no los menciona; 2019
   los exigía para regularizar. Preguntable en la primera clase práctica.
4. **En qué comisión de práctico estás (A1 viernes 17:15 o A2 viernes 19:45).** El campus no
   asigna grupos. Lo sabés vos.
5. **Aulas físicas:** no figuran en el campus.
6. **Fechas de inicio y fin de cursada:** no figuran.
7. **Cronograma semana a semana 2026:** no existe. Solo los 3 hitos de evaluación.
8. **UNIDAD 7 del aula está completamente vacía** (solo el título).
9. **Teóricos de las unidades 3 a 7: todavía no subidos.** Las secciones tienen el
   encabezado "DOCUMENTOS DE LA CLASE" sin archivos. Conviene re-scrapear en unas semanas.
10. **4 de los libros de bibliografía obligatoria del PDF 2026 no están en el aula:**
    Brealey/Myers/Allen, García y Arnoletto, Sachs y Larraín, y Sapag Chain (este último sí
    está en tu Downloads, edición 2019).
11. **Fechas de subida de los archivos del aula: no visibles** desde la vista de estudiante.
    Puse las que se pueden inferir por el ID del recurso, y lo marqué como inferencia.
12. **Escala de notas: no publicada.**
13. **La carpeta pública de Google Drive de la cátedra** (mencionada en el programa 2019) no
    se verificó: no hay link en el aula 2026 y no tengo acceso. Si sigue viva, ahí estarían
    los TPs.
14. **Inicial del JTP ambigua:** "Francisco M. Hiza" (aula) vs "Francisco N. Hiza" (PDF).
15. **Materia no dada de alta en el vault** — por diseño, según el brief. Requiere carpeta,
    `CLAUDE.md`, comando `/economia` y archivos de seguimiento sufijados (`cronograma-eco.md`,
    `condiciones-eco.md`) para no chocar con los stems de OAE.

---
scrape_fecha: 2026-08-13
scrape_fuente: https://presencial.ucc.edu.ar/course/view.php?id=15133
materia_nombre_campus: "COMPUTACION GRAFICA"
materia_codigo: CC0820173
slug: compugrafica
anio: 4
semestre: 2
carrera: "Ingeniería en Computación / Ingeniería de Sistemas (categoría campus: 08- Ingeniería)"
plan: 2016
comision: null
existe_en_vault: true
carpeta_vault: "CompuGrafica/"
completitud: baja
---

# Computación Gráfica — scrape del campus

> **Advertencia de lectura.** El aula virtual de esta materia está prácticamente vacía:
> no hay archivos, ni tareas, ni cuestionarios, ni entradas en ningún foro, ni eventos de
> calendario. Todo lo que sigue sale de las descripciones de sección y del texto de
> bienvenida del docente. El programa, el cronograma y las condiciones de cursada **no
> están publicados en el campus** — el docente remite al SIUCC y a su sitio personal.

## Docentes

| Nombre | Rol | Mail |
|---|---|---|
| John Coppens | Docente a cargo (no figura el rol formal) | No figura |

- El nombre sale del texto de bienvenida: *"Mi nombre es John Coppens y a partir de este momento estaré a disposición para transitar juntos/as este recorrido formativo virtual."*
- La lista de participantes (62 personas) muestra a **todos** con "Sin roles", así que no se puede confirmar por ahí quién es titular, adjunto o JTP. No hay ayudantes identificables.

## Cursada

- **Días y horarios:** no figuran en el campus.
- **Aulas:** no figuran. Hay una sala de **Zoom** ("Reunión Computación Gráfica", herramienta externa LTI) — no se abrió para no lanzar una sesión de videoconferencia.
- **Modalidad:** el aula está montada sobre la plantilla de **Educación a Distancia (PIED)** de la UCC, con foros sincrónicos/asincrónicos y Zoom. El curso figura en el campus **presencial** (`presencial.ucc.edu.ar`). Ambigüedad sin resolver: parece bimodal, pero no está declarado.
- **Inicio / fin:** no figuran. Dato relevante: en "Acceso a Mis Cursos" la materia cae en el filtro **"Pasados"**, no en "En progreso" — las fechas del aula están mal configuradas o corresponden a un dictado anterior.

## Programa

El programa **no está publicado en el aula**. El docente escribe textualmente:

> "Programa: El programa de la materia está disponible en el SIUCC. (También en mi sitio)."

Lo único que hay son dos secciones temáticas con su descripción. Se transcriben tal cual porque son, hoy, la mejor aproximación al programa:

| # | Unidad | Temas | Bibliografía |
|---|---|---|---|
| — | **Fundamentos** (sección 3) | Representación de colores en la computación: precisión, resolución · Mezcla de colores: ¿aditivo o sustractivo? · Almacenamiento de imágenes: rasterizado con pérdida (JPEG), rasterizado sin pérdida (PNG), vectorizado (SVG) · Introducción a programación en Python y librerías para el manejo de los diferentes formatos | No se indica |
| — | **Creación/edición** (sección 4) | Creación de imágenes (manual y por computadora) · Modificación de imágenes · Efecto de la edición sobre la calidad · Resultado de operaciones: rotación, escala y otros efectos · Inicio del proyecto de un editor de gráficos vectoriales | No se indica |

**Objetivos de la materia** (textual del aula):

> "Un introducción a las formas de representación de gráficos y almacenamiento en las computadoras.
> Algunas palabras sobre la importancia de gráficos en la computación
> Herramientas para la creación de los diferentes tipos de gráficos.
> Creación de programas para crear imágenes en diferentes formatos."

**Bibliografía** (textual):

> "Considerando que la materia trata de brindar un panorama amplio de diferentes temas, no hay literatura que cubre todos los aspectos. Wikipedia es sin duda una de las fuentes de información mas importantes para los detalles técnicos. Mi sitio personal es una fuente importante."

⚠️ El índice del curso salta de la sección 4 a la sección 8 (Biblioteca): **las secciones 5, 6 y 7 existen pero están ocultas** para el estudiante. Ahí es donde probablemente estén las unidades restantes.

## Condiciones de aprobación

**No hay ninguna condición de cursada publicada en el aula.** Ni asistencia, ni parciales, ni notas mínimas, ni régimen de promoción. Lo único que dice el campus sobre evaluación es la modalidad del final:

> "La modalidad de examen final: Es personal, i.e. aún si algunos trabajos se realizaron en grupos (particularmente en este caso), en el examen cada alumno tendrá que presentar y defender sus realizaciones."

### Regular
No figura.

### Promoción
No figura.

### Recuperatorios
No figura.

### TPs
No hay ninguna tarea creada en el aula. Se infiere de la descripción de la sección "Creación/edición" que existe un **proyecto de editor de gráficos vectoriales**, y del texto del final que **algunos trabajos se hacen en grupo** — pero no hay consigna, ni fecha, ni régimen de entrega publicados.

### Escala de notas
No figura.

## Cronograma

| Sem | Fecha | Teórico | Práctico / Hitos |
|---|---|---|---|
| — | — | *No publicado* | *No publicado* |

No hay cronograma en el aula ni eventos en el calendario del curso.

## Fechas clave

| Fecha | Evento | Tipo |
|---|---|---|
| — | *Ninguna publicada* | — |

Calendario del curso consultado (`/calendar/view.php?course=15133`): **"No hay eventos próximos"**.

## Trabajos prácticos

| # | TP | Unidad | Entrega | Estado | ¿Consigna publicada? |
|---|---|---|---|---|---|
| — | *Ninguno creado en el aula* | — | — | — | No |

### Consignas textuales

*No hay ninguna consigna publicada.* El único trabajo mencionado, sin consigna formal, es el proyecto del editor vectorial descripto en la sección "Creación/edición".

## Proyecto integrador

**Probable, pero sin consigna publicada.** La descripción de la sección "Creación/edición" dice:

> "Inicio del proyecto de un editor para gráficos vectoriales, que permite inserción de elementos básicos, como rectángulos, líneas, elipses, curvas de Bézier, polígonos, estrellas y otras."

Y el texto del final sugiere que se trabaja en grupos: *"aún si algunos trabajos se realizaron en grupos (particularmente en este caso)"*. No hay fechas, ni criterios de evaluación, ni tamaño de grupo.

## Material publicado

| Archivo | Tipo | Subido | Unidad | URL | ¿Reemplaza a? |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

**Cero archivos.** Verificado en los tres índices de recursos del curso:

- `/mod/resource/index.php?id=15133` → "No hay Archivos en este curso"
- `/mod/folder/index.php?id=15133` → "No hay Carpetas en este curso"
- `/mod/url/index.php?id=15133` → "No hay URLs en este curso"

Las únicas actividades del aula son 3 foros (todos vacíos) y 2 herramientas externas de Zoom.

**Nada para descargar en esta materia.**

## Estado personal

- **Notas cargadas:** ninguna. El libro de calificaciones tiene dos ítems, ambos sin nota: "Introducción a la materia" (herramienta externa, sin rango) y "Reunión Computación Gráfica" (rango 0–10, sin calificar). Total del curso: sin nota, rango 0–100.
- **Asistencia:** no hay actividad de asistencia en el aula. No hay registro.
- **Entregas hechas / pendientes:** ninguna, porque no hay tareas creadas.

## Novedades y anuncios

| Fecha | Anuncio |
|---|---|
| — | *Ninguno* |

Los tres foros del aula están en **0 debates**:

- "Novedades y Avisos generales" (foro general) — 0 debates
- "Foro de presentación" — 0 debates
- "Foro de consultas" — 0 debates

Es decir: el docente todavía no publicó ningún aviso en el aula.

## Requisitos técnicos

Lo único declarado, en la descripción de la sección "Fundamentos":

- **Lenguaje: Python.** Textual: *"Introducción a programación en Python, y librerías para el manejo de los diferentes formatos."*
- **Formatos de imagen a manejar:** JPEG (rasterizado con pérdida), PNG (rasterizado sin pérdida), SVG (vectorizado).
- **Zoom** para los encuentros sincrónicos (integrado como herramienta externa LTI en el aula).

**No se nombran librerías, versiones ni entorno concretos.** No hay mención de OpenGL, WebGL, Processing, Unity ni Blender en ninguna parte del aula — la hipótesis del brief sobre el stack queda descartada en cuanto a lo publicado: **el stack es Python + formatos de imagen**, orientado a escribir programas que generen imágenes, no a 3D en tiempo real.

Actividad opcional mencionada en la presentación: grabar un video de presentación personal y subirlo a Google Drive o YouTube (**OPCIONAL**, palabra del docente).

## ⚠️ Faltantes y dudas

1. **Programa oficial — no está en el campus.** El docente remite a dos lugares fuera del aula: el **SIUCC** y su **sitio personal**. Hay que buscarlo ahí. Sin esto no hay unidades numeradas ni bibliografía.
2. **Secciones 5, 6 y 7 del aula están ocultas.** El índice del curso pasa de "Creación/edición" (4) directo a "Biblioteca" (8). Muy probablemente contengan el resto de las unidades. Se van a ir abriendo durante la cursada — conviene volver a scrapear en unas semanas.
3. **Régimen de cursada: 100% ausente.** No hay asistencia mínima, ni cantidad de parciales, ni notas mínimas, ni condiciones de regularidad o promoción. Hay que pedírselo al docente o buscarlo en el SIUCC.
4. **Cronograma: no existe** en el aula ni en el calendario. Sin fechas de parciales ni de entregas.
5. **Días, horarios y aula física:** no figuran en el campus. Están en el SIUCC / horario de la carrera.
6. **Mail de contacto del docente:** no figura. La lista de participantes no expone roles ni mails.
7. **Sala de Zoom no abierta a propósito.** "Reunión Computación Gráfica" (`/mod/lti/view.php?id=1100095`) redirige a Zoom; no se lanzó para no iniciar una videoconferencia. Puede contener el horario recurrente de los encuentros — conviene que lo mires vos.
8. **"Introducción a la materia"** (`/mod/lti/view.php?id=1100093`) es otra herramienta externa (Zoom), tampoco abierta, por el mismo motivo.
9. **El proyecto del editor vectorial no tiene consigna.** Se sabe que existe y que hay trabajos grupales, pero no hay documento, fecha ni criterios. No se inventó nada.
10. **Fechas del aula mal configuradas.** La materia aparece bajo el filtro "Pasados" del campus. Puede ser un error de la cátedra o que el aula sea un clon del dictado anterior. Vale la pena confirmarlo antes de asumir que el contenido publicado es de esta cursada.
11. **Carrera y plan exactos:** el campus solo categoriza la materia como "08- Ingeniería". El nombre completo de la carrera y el plan 2016 vienen del brief, no del campus.

---
scrape_fecha: 2026-08-13
scrape_fuente: https://presencial.ucc.edu.ar/course/view.php?id=12680
materia_nombre_campus: "ORGANIZACION Y ADMINISTRACION DE EMPRESAS"
materia_codigo: CC0820136
slug: oae
anio: 4
semestre: 2
carrera: "Ingeniería (categoría campus: 08- Ingeniería) — Facultad de Ingeniería, UCC"
plan: 2016
comision: "Cátedra B (Jular) — a confirmar"
existe_en_vault: true
carpeta_vault: "OAE/"
completitud: media
aula_desactualizada: true
---

# OAE — scrape del campus (delta)

> 🔴 **LEER ESTO ANTES DE TOCAR EL VAULT DE OAE.**
>
> **El aula de OAE en el campus está desactualizada: es un shell de 2020–2022, no la
> cursada 2026.** Lo verifiqué con tres pruebas independientes (abajo). Las fechas,
> condiciones y estructura de unidades que hay ahí **contradicen** lo que ya tenés cargado
> en el vault, y **lo que está en el vault es lo correcto**.
>
> Por eso este archivo **no propone cambiar nada** de `00-Seguimiento/`. Sirve para dos
> cosas: (1) inventariar material de estudio del aula que sí es reutilizable, y (2) dejar
> asentadas las contradicciones para que no vuelvan a aparecer en el próximo scrape.

## 🔍 Por qué digo que el aula está desactualizada

Tres evidencias, ninguna interpretable de otra forma:

1. **Fechas de entrega de las tareas, tal como las muestra el campus hoy:**
   - "Caso práctico KPI-Tablero de Comando" (UNIDAD 4) → **lunes, 12 de septiembre de 2022**
   - "CASO NATIONAL INDUSTRIAL PRODUCT" (UNIDAD 5) → **sábado, 31 de octubre de 2020**
2. **El programa publicado se llama literalmente "Programa 2022".**
3. **El foro de presentación remite a una carpeta de Drive llamada "-Actividades 2021-".**

A eso se suma: **ninguna** de las 13 líneas del libro de calificaciones tiene nota (todas
"( Vacío )"), y el aula **no tiene foro de novedades** — pese a que el texto de bienvenida
dice "revisá el foro de novedades generales". Ese foro no existe en el curso.

**Interpretación:** la cátedra reutiliza el mismo shell año a año sin limpiarlo, y la
cursada 2026 real corre por otro canal. El aula apunta a Google Drive de forma insistente
("Se realiza en grupos de no más de 4 alumnos, **en el Drive**"), así que el Drive de la
cátedra es casi seguro donde vive la cursada viva. **Eso explica por qué el ID del curso es
12680 y todo lo demás está en el rango 15xxx: es el aula vieja, nunca se creó una nueva.**

## Docentes

| Nombre | Rol | Mail |
|---|---|---|
| Ing. Judith Disderi | Docente (cátedra A, según el vault) | No figura en el campus |
| Mgter./Lic. Pilar Jular | Docente (cátedra B, según el vault) — firma la Hoja de Ruta | **0722206@ucc.edu.ar** |
| Prof. Marchesini | Docente a cargo de una comisión de práctico | No figura |

**Novedades respecto de lo que ya tenías:**

- **Mail de Pilar Jular: `0722206@ucc.edu.ar`** — dato nuevo, sale de la Hoja de Ruta Parte II.
  Textual: *"Si necesitan un asesoramiento más personalizado no duden en contactarse con el
  docente Pilar Jular: 0722206@ucc.edu.ar."*
- **Aparece un tercer docente, "profe Marchesini"**, que no está en el vault. El aula dice:
  *"Habrá una carpeta para quienes pertenecen a la comisión de práctico del profe Marchesini
  y otra carpeta para quienes pertenecen a la comisión de Jular."* ⚠️ Puede ser de un año
  anterior — dado el estado del aula, no lo daría por vigente sin confirmar.
- El texto de bienvenida lo firma Pilar Jular: *"mi nombre es Pilar Jular y junto a la Ing.
  Judith Disderi estaremos acompañandolos en la materia."*

## Cursada

- **Días y horarios** (de las dos salas de Zoom recurrentes del aula):
  - **ZOOM RECURRENTE OAE TEÓRICO — LUNES 12 A 14 HS**
  - **ZOOM RECURRENTE OAE PRÁCTICO — LUNES 18 A 20 HS**
  - ✔️ Consistente con lo que ya sabías ("clases los lunes"), y ahora con horarios.
- **Modalidad:** virtual/bimodal. Textual: *"La modalidad virtual ofrece una amplia
  flexibilidad en tiempos y espacios... Cada quince días publicaremos una nueva clase."*
- **Aulas:** no figuran (es por Zoom).
- **Inicio / fin:** no figuran.

## Programa

⚠️ **El aula tiene 7 unidades. El vault tiene 8.** No resolví la diferencia y no la toqué.

| # | Unidad (título en el aula) | Temas | Bibliografía obligatoria |
|---|---|---|---|
| 1 | *(sección UNIDAD 1)* | Ya cargada en el vault | Robbins y Coulter, *Administración* |
| 2 | *(sección UNIDAD 2)* | Ya cargada en el vault | Robbins y Coulter, *Administración* |
| 3 | Estructuras organizacionales / RR.HH. | Sistema de RR.HH., proceso de administración de RR.HH., contrato psicológico | Robbins y Coulter · Chiavenato, *Gestión del Talento Humano* (complementaria) |
| 4 | **Tablero de Comando** | Control de gestión. Tablero de Comando: concepto, objetivos, funciones, arquitectura, metodología para su construcción. Cuadro de Mando Integral (CMI): perspectivas, matriz, inductores. Indicadores de gestión: concepto, tipos, clasificación | Pérez Alfaro, *Control de Gestión y Tablero de Comando*, caps. 1 y 2 · Irazábal, *Tablero Integral de Comando*, Parte II |
| 5 | **Toma de decisiones y Planificación** | Toma de decisiones: concepto, proceso, racionalidad, tipos de problemas y decisiones, condiciones para decidir, estilos, prejuicios y errores, técnicas. Decisiones inherentes a cada función gerencial. Planificación: concepto, propósitos, tipos de planes. Proceso de Administración Estratégica. Análisis FODA. Estrategias organizacionales | Robbins y Coulter, caps. 6, 7 y 8 |
| 6 | **RSU / Responsabilidad Social** | RSE, desarrollo sostenible, ODS, PROÉTICA | Robbins y Coulter, cap. 5 |
| 7 | **Control y Auditoría Interna** | Control: concepto, proceso, tipos, cualidades de un sistema de control efectivo y sus disfuncionalidades. Auditoría: concepto, elementos, tipos, etapas, proceso. Riesgo y Control Interno: concepto, importancia, factores y tipos de riesgo, objetivos del control interno. Influencia del control interno en auditoría. Normas generales y particulares del Control Interno | Robbins y Coulter, cap. 17 · Pungitore, *Sistemas Administrativos y Control Interno*, caps. 2, 7 y 8 |

**Objetivos declarados por unidad** (textual, para las que todavía no cursaste):

- **U5:** *"Identificar los pasos de los procesos de toma de decisión y planificación · Realizar el análisis FODA de una organización · Aplicar herramientas y técnicas de toma de decisión y planificación."*
- **U7:** *"Reconocer el control como mecanismo de realimentación de un sistema · Identificar los tipos y el proceso de control y de auditoría · Reconocer la importancia de la auditoría en la adecuada gestión organizacional · Aplicar normas de control interno."*

**Bibliografía obligatoria general del aula** (textual del texto de bienvenida):

> "1-Robbins, Stephen P. y Coulter Mary, "Administración", Ed. Pearson Educación, Naucalpan de Juárez, México, 2010: 2 y 2005: 6 ejemplares en Biblioteca.
> 2. Irazábal, América Alicia. "Tablero Integral de Comando", Ed. Aplicación Tributaria S.A., Buenos Aires, 2007: 2, 2004: 1 y , 2001: 2 ejemplares en Biblioteca
> 3. Pérez Alfaro, Alfredo. "Control de Gestión y Tablero de Comando", Ed. Depalma, Buenos Aires, 2000, 4 ejemplares en Biblioteca"

Aparecen además, sin estar en esa lista: **Chiavenato** (*Gestión del Talento Humano*,
marcada "Bibliografía Complementaria") y **Pungitore** (*Sistemas Administrativos y Control
Interno*, citada como obligatoria en U7).

## Condiciones de aprobación

⚠️ **Lo que dice el aula NO coincide con lo que tenés en el vault.** Dado que el aula es de
2022, **mantené lo del vault**. Dejo el texto del aula solo para que quede el registro.

Textual del aula (2022):

> "El curso se aprueba, realizando todas las actividades obligatorias del práctico y del teórico, aprobando el primer parcial y entregando el trabajo grupal Integrador Final (Trabajo práctico de Proyecto y Diseño)."
>
> "Se debe aprobar el 80% de los trabajos obligatorios, y el primer y único parcial que solo tendrá una instancia de recuperación y el Trabajo Final Integrador. Si te encuentras en estas condiciones, podrás rendir el final."

### Regular
Según el aula: 80 % de los trabajos obligatorios aprobados + parcial aprobado + Trabajo Final
Integrador entregado. **No menciona porcentaje de asistencia.** No menciona promoción directa.

### Promoción
**El aula no habla de promoción directa en ningún lado.** El vault dice que tu objetivo es
promoción con ≥7 — ese dato **no se puede verificar contra el campus**. Confirmalo con la
cátedra.

### Recuperatorios
Una sola instancia de recuperación del parcial ("el primer y único parcial que solo tendrá
una instancia de recuperación").

### TPs
Obligatorios. Se aprueba con el **80 %** de los trabajos obligatorios. Sin penalidad por
entrega tardía declarada.

### Escala de notas
No publicada. Los ítems del libro de calificaciones usan rangos mezclados: 0–10, 0–100, y uno
cualitativo **Regular–Excelente** (el "Mapa Conceptual de las Unidades I y II").

## Cronograma

De la **Hoja de Ruta Parte II** (`Hoja de Ruta U. 4 - 5 - 6 y 7.pdf`, 2 páginas). ⚠️ **Las
fechas vienen sin año** y son casi con certeza del ciclo 2022. Las transcribo textuales
porque la secuencia de temas y actividades sí sirve, pero **las fechas no las uses**.

| Unidad | Período (sin año) | Encuentros | Actividades obligatorias | Plazo límite | Lectura / estudio |
|---|---|---|---|---|---|
| **U4** Tablero de Comando | 6/9 → 23/9 | 2 teóricos · 3 prácticos | 1- Actividad repaso teoría y Caso Pasa · 2- Actividades prácticas propuestas por el docente **+ TP 7** | — | PowerPoint y PDF del aula · Pérez Alfaro / Irazábal |
| **U5** Toma de decisiones y Planificación | 20/9 → 7/10 | 2 teóricos · 2 prácticos | 1- Caso Uber / Netflix — grupal, en clase · 2- Cuadernillo de actividades prácticas (**TP 9, 10 y 11**) | "En clase" | *Funciones Gerenciales – Planificación* y *– Toma de decisiones* · Robbins caps. 6, 7 y 8 |
| **U6** RSU | 18/10 → 21/10 | 1 teórico · 1 práctico | 1- Guía GestionaRSE: Cultura y Público Interno · 2- Encuesta de opinión sobre informe GestionaRSE · 3- Cuadernillo (**Tp 12**) | 1- "25 Y 2/10" · 2- "13/11" | *OAE-RSU-Proética* · Robbins cap. 5 |
| **U7** Control y Auditoría | 25/10 → 4/11 | 2 teóricos · 2 prácticos | 1- Caso El aeropuerto internacional de Denver — grupal, en clase · 2- Consultas sobre última entrega del Trabajo de Proyecto y Diseño · 3- Cuadernillo (**Tp 13**) | 1- "En clase" · 2- "1 y 4/11" | *Auditoría y control* y *Funciones gerenciales: control* · Robbins cap. 17 |

🚩 **Prueba adicional de que el documento está viejo:** los plazos de la U6 ("25 Y 2/10")
caen **antes** del propio período de la unidad (18/10 → 21/10). El documento es internamente
inconsistente. No es una fuente de fechas confiable.

Hay también una **Hoja de Ruta Parte I** (Unidades 1, 2 y 3) publicada en la sección de
presentación, que no abrí porque esas unidades ya las tenés cargadas.

Dato suelto con fecha, de la U4: el archivo "Actividad de repaso teórico" está descripto como
*"Para enviar por mail antes del 20 de set y trabajarlo en forma grupal"* — también sin año.

## Fechas clave

| Fecha | Evento | Tipo |
|---|---|---|
| — | *Ninguna fecha vigente publicada en el campus* | — |

**No hay ni una sola fecha de 2026 en el aula.** Las únicas fechas con año que muestra el
campus son las de entrega de dos tareas, y son de **2020 y 2022**. Las fechas que tenés en el
vault (parcial 07/09/2026, entregas 31/08, 28/09, 12/10, 26/10, informe 02/11, defensa
09/11) **no salen de este campus y no se pudieron verificar acá**.

## Trabajos prácticos

| # | TP | Unidad | Entrega | Estado | ¿Consigna publicada? |
|---|---|---|---|---|---|
| — | Repaso de FODA | U2 | Sin fecha | Sin entrega | Sí (tarea) |
| — | Caso Waltmart | U? | — | Sin entrega | Sí (tarea) |
| — | Actividad Obligatoria 1 | U1 | — | Sin entrega | Sí (tarea) |
| — | Actividad Obligatoria 3 | U? | — | Sin entrega | Sí (tarea) |
| — | ACTIVIDAD OBLIGATORIA U2 | U2 | — | Sin entrega | Sí (tarea) |
| — | Mapa Conceptual de las Unidades I y II | U1–U2 | — | Sin entrega | Sí (tarea, escala Regular–Excelente) |
| — | Caso práctico KPI-Tablero de Comando | U4 | **12/09/2022** | Sin entrega | Sí (tarea) |
| TP 7 | Actividades prácticas U4 (cuadernillo) | U4 | Sin fecha | — | En la Guía TP Parte 2 — **sin descargar** |
| — | CASO NATIONAL INDUSTRIAL PRODUCT | U5 | **31/10/2020** | Sin entrega | Sí (tarea) |
| — | Caso Netflix | U5 | Sin fecha | Sin entrega | Sí (tarea) |
| TP 9, 10, 11 | Cuadernillo de actividades prácticas U5 | U5 | Sin fecha | — | En la Guía TP Parte 2 — **sin descargar** |
| Tp 12 | Cuadernillo de actividades prácticas U6 | U6 | Sin fecha | — | En la Guía TP Parte 2 — **sin descargar** |
| — | ACTIVIDAD OBLIGATORIA- RSE | U6 | Sin fecha | Sin entrega | Sí (tarea) |
| Tp 13 | Cuadernillo de actividades prácticas U7 | U7 | Sin fecha | — | En la Guía TP Parte 2 — **sin descargar** |

**Sobre los TP5–TP8 que el brief marcaba como vacíos:** la guía existe y está publicada —
**`OAE GUIA TP- PARTE 2- U5. 6 Y 7`**, en la sección UNIDAD 5. Es un archivo de Word.
**No lo descargué**: bajarlo requiere tu OK, y al ser `.doc` el navegador lo baja en vez de
mostrarlo. Está en la lista de descargas propuestas al final de la sesión.

La numeración que usa la Hoja de Ruta (TP 7 en U4; TP 9, 10, 11 en U5; Tp 12 en U6; Tp 13 en
U7) sugiere que el cuadernillo llega **al menos hasta TP 13**, bastante más allá del TP8 que
figuraba como límite en el vault. El detalle está adentro de esa guía.

### Consignas textuales

Solo una consigna está publicada completa en el campus (descripción de un archivo de U2):

**Caso Mary Kay — Cultura Organizativa**

> "Caso Mary Kay- haga un video de no más de 5 minutos que abarque la explicación o desarrollo a estas consignes :
> 1. Caracterice la filosofía de la fundadora
> 2. Qué transmite Mary Kay a sus vendedoras? Las consultoras son empleadas?
> 3. Caracterice la cultura o personalidad de Mary Kay – compañía
> 4. Transcriba los 4 ejes de aprendizaje según el texto
> 5. Qué perfil tienen las consultoras en Argentina?"

El resto de las consignas está dentro de los archivos de las guías, sin descargar.

## Proyecto integrador

**Sí tiene** — "TRABAJO PRACTICO DE PROYECTO Y DISEÑO", con sección propia en el aula
(sección 7). Consigna textual publicada:

> "IMPORTANTE: TRABAJO PRACTICO DE PROYECTO Y DISEÑO- LEER
>
> Este trabajo práctico, tiene valor de nota de segundo parcial. Se realiza en grupos de no más de 4 alumnos, en el Drive.
>
> Los grupos deben informarse en la segunda clase de práctico por mail a su profesor de práctico.
>
> En la cuarta clase de práctico y por el mismo medio deben informar la empresa en la que llevarán a cabo el trabajo de campo. Allí constará la empresa, la actividad o rubro , el número de empleados aproximado, si trabajarán analizando toda la empresa o un área en particular,
>
> Habrá una carpeta para quienes pertenecen a la comisión de práctico del profe Marchesini y otra carpeta para quienes pertenecen a la comisión de Jular.
>
> Son tres entregas y una defensa, y tendrá una nota integradora."

**Coincide con el vault:** vale como nota del segundo parcial. ✔️

⚠️ **Discrepancia con el vault:** el aula dice **"tres entregas y una defensa"**; el vault
tiene **cuatro entregas** (31/08, 28/09, 12/10, 26/10) **+ informe final** (02/11) **+
defensa oral** (09/11). Puede ser que el esquema haya cambiado de 2022 a 2026, o que en el
vault el informe final cuente aparte. **No lo toqué.** Es de las cosas que conviene confirmar
en clase.

Material del proyecto en el aula: `GUÍA DE TRABAJO DE PROYECTO Y DISEÑO` (archivo) y un
"Foro de Consultas Trabajo de Campo" (0 debates).

## Material publicado

Inventario completo del aula, por sección. **Ninguno tiene fecha de subida visible** desde la
vista de estudiante, así que **no puedo decir cuáles se subieron después del 11/08/2026** —
que era una de las preguntas del brief. Por lo que muestra el resto del aula, sospecho que
**ninguno**.

| Archivo | Tipo | Unidad | Nota |
|---|---|---|---|
| Programa 2022 | Archivo | Presentación | ⚠️ Del ciclo 2022 |
| Administración - Robbins | URL | Presentación | Enlace al libro |
| Hoja de ruta parte I - Unidad 1, 2 y 3 | Archivo | Presentación | — |
| **Guia de TRABAJOS PRACTICOS Parte I** | Archivo | Presentación | Cubre U1–U3 |
| ZOOM RECURRENTE OAE TEORICO LUNES 12 A 14 HS | Herramienta externa | Presentación | Zoom, no abierto |
| ZOOM RECURRENTE OAE PRACTICO LUNES 18 A 20 HS | Herramienta externa | Presentación | Zoom, no abierto |
| Filminas teórico U 1 | Archivo | U1 | Ya cursada |
| MÉTODO DE RELEVAMIENTO DE INFORMACIÓN | Archivo | U1 | *"Leerlo detenidamente a fin de poder ir a hacer el trabajo de campo con total solvencia y seguridad"* — sirve para el proyecto |
| CAMBIOS QUE FRACASAN | Archivo | U1 | Para el foro |
| Instructivo Glosario OAE | Archivo | U1 | — |
| Filminas teórico U 2 | Archivo | U2 | Ya cursada |
| Caso Mary Kay - Cultura Organizativa | Archivo | U2 | Consigna transcripta arriba |
| Matriz de incertidumbre ambiental | Archivo | U2 | — |
| OAE UNIDAD 3 ESTRUCTURAS ORGANIZACIONALES | Archivo | U3 | — |
| MAPA CONCEPTUAL DEL SISTEMA DE RRHH | Archivo | U3 | — |
| Proceso de Administración de RR.HH. | Archivo | U3 | *"PDF para desarrollo de clase teórica 4, que es la segunda clase de Unidad 3"* |
| Contrato Psicológico | Archivo | U3 | — |
| Gestión del Talento Humano- Chiavenato | Archivo | U3 | Bibliografía complementaria |
| **GUÍA DE TRABAJO DE PROYECTO Y DISEÑO** | Archivo | Proyecto | 🔺 Alta prioridad |
| Indicadores TdC | Archivo | U4 | — |
| OAE U4 TABLERO DE COMANDO | Archivo | U4 | — |
| Resumen TABLERO DE COMANDO | Archivo | U4 | Apunte |
| BSC-Matriz de tablero de comando | Archivo | U4 | — |
| Ejemplo de Tablero de Comando | Archivo | U4 | Modelo de estudio |
| Ejemplo TdC Logística | Archivo | U4 | — |
| Libro Control de Gestión y Tablero de Comando | Archivo | U4 | Bibliografía obligatoria, caps. 1 y 2 |
| Actividad de repaso teórico | Archivo | U4 | *"Para enviar por mail antes del 20 de set"* |
| U5 FUNCIONES GERENCIALES- PLANIFICACIÓN | Archivo | U5 | — |
| U5 FUNCIONES GERENCIALES TOMA DE DECISIONES | Archivo | U5 | — |
| CASO UBER | Archivo | U5 | Para clase |
| **OAE GUIA TP- PARTE 2- U5. 6 Y 7** | Archivo (Word) | U5 | 🔺 **Lo que buscabas.** Sin descargar |
| **Hoja de ruta U 4 - 5 - 6 - y 7** | Archivo (PDF) | U5 | Leída, transcripta arriba |
| OAE- RSU- PROETICA | Archivo | U6 | — |
| GUIA GESTIONARSE | Archivo | U6 | Guía de relevamiento y diagnóstico del área PROÉTICA – ICDA – UCC |
| VIDEO SOBRE DESARROLLO SOSTENIBLE | Archivo | U6 | — |
| CASO LAS HERMANAS BASILOTTA | Archivo | U6 | Para clase |
| VIDEO ODS: 17 OBJETIVOS DE DESARROLLO SOSTENIBLE | Archivo | U6 | — |
| U7- Audioria y Control | Archivo | U7 | (typo de la cátedra) |
| U7- Funciones Gerenciales: Control | Archivo | U7 | — |
| Pautas para clase teórica | Archivo | U7 | — |
| Mejora de eficiencia en costes estructurales | Archivo | U7 | Para práctico |
| Caso: El aeropuerto internacional de Denver | Archivo | U7 | — |
| Caso Sky Chefs | URL | U7 | — |
| Ejercicio Autoría | Archivo | U7 | Para teoría, en clase |
| Ejercicio sobre Auditoría AUSJAL | Archivo | U7 | Para práctico |

**¿Algún archivo reemplaza a otro?** No hay indicios de reemplazo. Ninguno está versionado ni
marcado como actualizado.

## Estado personal

- **Notas cargadas:** **ninguna.** Las 13 líneas del libro de calificaciones están en
  "( Vacío )", incluido el ítem del parcial. El total del curso, sin nota.
- **Asistencia:** no hay actividad de asistencia en el aula. Sin registro.
- **Entregas hechas / pendientes:** las 5 tareas con seguimiento figuran **"Sin entrega"**
  (Repaso de FODA, Caso práctico KPI-Tablero de Comando, CASO NATIONAL INDUSTRIAL PRODUCT,
  Caso Netflix, ACTIVIDAD OBLIGATORIA- RSE).
  ⚠️ Esto **no significa que no hayas entregado nada**: el vault dice que el TP1 está
  entregado y el TP2 resuelto. Significa que **las entregas de esta cursada no pasan por el
  aula del campus** — van por el Drive, como dice la consigna del proyecto.

## Novedades y anuncios

| Fecha | Anuncio |
|---|---|
| — | *Ninguno. El curso no tiene foro de novedades.* |

Los cuatro foros que sí existen están todos en **0 debates**: "Foro de presentación",
"Foro de consultas", "Foro de Consultas Trabajo de Campo" y "Foro de consultas U4".

El único contenido con forma de aviso es la descripción del "Foro de consultas U4", que
propone un enlace de lectura:

> "https://reliabilityweb.com/sp/articles/entry/los-indicadores-de-gestion — Con este enlace de resumen pero a su vez variado en contenido los invito a relacionarlo con los Temas de las Unidades 1, 2 y 3. Empecemos a movilizar las redes neuronales para ser más adaptativos a este mundo cambiante!"

**Respuesta directa a la pregunta del brief: no hay anuncios nuevos. No hay anuncios, punto.**

## Requisitos técnicos

Ninguno particular. Zoom para las clases y Google Drive para el trabajo grupal y las entregas.

## ⚠️ Faltantes y dudas

1. **El aula del campus es de 2020–2022, no de 2026.** Es el hallazgo principal. No uses nada
   de su cronograma ni de sus condiciones para actualizar `00-Seguimiento/`.
2. **Dónde vive la cursada 2026.** El aula apunta al **Drive de la cátedra** pero **no hay un
   solo link al Drive publicado en el campus**. No pude llegar ahí. Es el pendiente más
   importante: ahí deberían estar las consignas, fechas y entregas reales.
3. **7 unidades en el aula vs. 8 en el vault.** No sé cuál es la correcta para 2026 ni qué
   unidad sobra o falta.
4. **"Tres entregas y una defensa" (aula) vs. 4 entregas + informe final + defensa (vault).**
   Sin resolver.
5. **El parcial del aula se llama "PARCIAL U. 1, 2 y 3"**, mientras que el vault dice que el
   Parcial 1 cubre **U1–U4**. 🚫 **No abrí ese cuestionario** — el brief prohíbe iniciar
   instancias evaluadas y un cuestionario de Moodle puede arrancar un cronómetro al abrirse.
   Verificalo vos, o preguntá en clase.
6. **Promoción directa con ≥7: no figura en el campus.** El aula solo habla de aprobar y
   rendir final. Tu objetivo de promoción no se pudo verificar.
7. **Porcentaje de asistencia mínimo: no figura.** El aula no menciona asistencia en ningún
   lado.
8. **`OAE GUIA TP- PARTE 2- U5. 6 Y 7` sin descargar** — es un `.doc`, el navegador lo baja
   en vez de mostrarlo, y bajarlo necesita tu OK. **Es el archivo que te faltaba** para
   completar los TPs más allá del TP4.
9. **`GUÍA DE TRABAJO DE PROYECTO Y DISEÑO` y `Guia de TRABAJOS PRACTICOS Parte I` sin
   descargar**, por el mismo motivo.
10. **Fechas de subida de los archivos: no visibles** desde la vista de estudiante. Por eso
    **no puedo responder si hay material subido después del 11/08/2026**. Mi lectura, por el
    estado general del aula, es que no hay nada nuevo — pero es una inferencia, no un dato.
11. **"Profe Marchesini" no está en el vault.** Puede ser un docente de práctico vigente o un
    resabio de 2022.
12. **Las dos salas de Zoom no se abrieron** (teórico y práctico), para no lanzar
    videoconferencias. Podrían tener info de horario o grabaciones.
13. **La Hoja de Ruta Parte I (U1, U2, U3) no se abrió** — esas unidades ya están cargadas en
    el vault y no era prioridad. Si querés el cronograma completo, está ahí.

# Test de renderizado

## 1. Mermaid flowchart

```mermaid
flowchart LR
    E["Entorno<br/>organizacional"] --> C{{"CRITERIO<br/>GERENCIAL"}}
    K["Cultura<br/>organizacional"] --> C
    style C fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

## 2. Mermaid quadrantChart

```mermaid
quadrantChart
    title Matriz de incertidumbre
    x-axis "Estable" --> "Dinamico"
    y-axis "Simple" --> "Complejo"
    quadrant-1 "Celda 4"
    quadrant-2 "Celda 3"
    quadrant-3 "Celda 1"
    quadrant-4 "Celda 2"
```

## 3. Mermaid mindmap

```mermaid
mindmap
  root((Roles<br/>Mintzberg))
    Interpersonales
      Representante
      Lider
      Enlace
    Informativos
      Monitor
      Difusor
      Portavoz
```

## 4. SVG inline con variables de tema

<svg viewBox="0 0 400 120" width="100%" style="max-width:400px">
  <rect x="10" y="10" width="180" height="50" rx="8" fill="var(--background-modifier-border)"/>
  <text x="100" y="40" text-anchor="middle" fill="var(--text-normal)" font-size="14">SVG + var(--text-normal)</text>
  <circle cx="300" cy="35" r="25" fill="#7C5CFF"/>
  <path d="M 10 90 L 390 90" stroke="var(--text-accent)" stroke-width="3"/>
</svg>

## 5. Mermaid con subgraph

```mermaid
flowchart TD
    subgraph VIS["VISIBLE"]
        A[Personas] --- B[Beneficios]
    end
    subgraph INV["INVISIBLE"]
        C[Valores] --- D[Proposito]
    end
    VIS --> INV
```

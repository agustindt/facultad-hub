---
tipo: concepto
materia:
unidad:
parcial:
autor:
estado: borrador
tags: []
---

# {{title}}

> Definición en una sola oración.

## Desarrollo

## Por qué importa

Para qué sirve saber esto / qué decisión permite tomar.

## Conexiones

- [[ ]] — por qué se conecta
- [[ ]] — por qué se conecta

## En el parcial

Cómo suele preguntarse.

---
Fuente:

---
tipo: unidad
materia:
unidad:
parcial:
estado: pendiente
tags: []
---

# {{title}}

**Clase:** · **Material:** · **TP asociado:**

## Conceptos de la unidad

- [[ ]]

## Idea que ordena la unidad

Una frase: qué hilo une todos los conceptos de acá.

## Ligada a

- Unidad anterior: [[ ]]
- Unidad siguiente: [[ ]]

## Estado

- [ ] Teoría vista en clase
- [ ] Resumen escrito
- [ ] Conceptos atomizados
- [ ] Autoevaluación hecha
- [ ] TP entregado

---
tipo: clase
materia:
unidad:
fecha:
tags: []
---

# {{date}} — Clase

**Unidad:** [[ ]] · **Docente:**

## Lo que se vio

## Lo que dijo la profe que va al parcial

## Conceptos nuevos (crear nota para cada uno)

- [[ ]]

## Dudas que me quedaron

## Tareas que salieron de esta clase

- [ ]

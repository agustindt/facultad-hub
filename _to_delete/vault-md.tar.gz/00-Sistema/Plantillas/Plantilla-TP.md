---
tipo: tp
materia:
unidad:
estado: pendiente
fecha-clase:
tags: []
---

# {{title}}

**Unidad:** [[ ]] · **Fecha:** · **Entregado:** no

## Consigna

> Transcribir textual de la guía de cátedra. No inventar si todavía no se liberó.

## Conceptos que aplica

- [[ ]]

## Resolución

## Devolución de la cátedra

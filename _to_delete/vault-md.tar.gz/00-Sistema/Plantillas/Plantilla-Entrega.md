---
tipo: entrega
materia:
proyecto:
vencimiento:
estado: sin-empezar
nota:
tags: []
---

# {{title}}

**Vence:** · **Estado:** sin empezar · ⚠️ entrega tardía = −1 punto

## Qué pide la cátedra

## Conceptos que hay que aplicar

- [[ ]]

## Desarrollo

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Puntualidad
- [ ] Claridad conceptual y análisis propio

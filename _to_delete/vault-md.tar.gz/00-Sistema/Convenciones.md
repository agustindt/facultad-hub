---
tipo: sistema
tags: [sistema]
---

# Convenciones del vault

Reglas para que el grafo siga teniendo sentido dentro de un año. Si vas a inventar
una convención nueva, escribila acá primero.

## Estructura por materia

```
<Materia>/
├── <Materia>.md          ← MOC de la materia (puerta de entrada)
├── CLAUDE.md             ← contexto para Claude Code (no es una nota)
├── 00-Seguimiento/       cronograma, condiciones, trackers
├── 01-Unidades/          una carpeta por unidad, con la nota índice adentro
├── 02-TPs/               un TP por nota
├── 03-Proyecto-Catedra/  entregas y material del proyecto
├── 04-Conceptos/         notas atómicas ← el corazón del grafo
├── 05-Recursos/          links, papers, videos
├── 06-Clases/            notas de clase fechadas
└── 99-Material-Catedra/  PDFs y PPTs oficiales (no se editan)
```

## Los 3 tipos de nota que importan

| Tipo | Rol | Regla |
|---|---|---|
| **MOC** | Índice navegable (materia, unidad) | No contiene teoría propia: solo enlaza |
| **Concepto** | Una sola idea, autocontenida | Si necesita un "y además..." de otro tema, es otra nota |
| **Registro** | Clase, TP, entrega | Fechada, refleja un hecho puntual |

## Frontmatter

```yaml
---
tipo: concepto | unidad | tp | entrega | clase | moc | seguimiento
materia: OAE
unidad: U2              # si aplica
parcial: 1              # en qué parcial entra
autor: Robbins          # para conceptos con autor de referencia
estado: pendiente | borrador | estudiado | dominado
tags: [OAE, U2, cultura]
---
```

`estado` es lo que se filtra antes de un parcial. Buscá `estado: pendiente` y sabés
exactamente qué te falta.

## Nombres de archivo

- Conceptos: **sin prefijo**, en lenguaje natural → `Cultura Organizacional.md`.
  Así el wikilink se lee como una frase: "...moldeada por la [[Cultura Organizacional]]".
- Unidades: `U2-Entorno-y-Cultura-Organizacional.md`
- TPs: `TP2-Nombre.md` · Entregas: `Entrega-1-Ambiente-Organizacional.md`
- Clases: `2026-08-10 - Clase U2.md` (fecha ISO adelante, ordena solo)

## Diagramas: Mermaid, nunca ASCII

**Prohibido el ASCII art** (`──→`, `├──`, `████`) para diagramas conceptuales. Se ve mal, no
escala, no se puede copiar a un informe y en el celular se rompe. Aplica igual a teóricos
(unidades, conceptos) y prácticos (TPs, entregas).

- Regla general: bloque ` ```mermaid `. Obsidian lo renderiza **nativo**, sin plugins.
- `flowchart LR/TD` cubre el 90% de los casos: procesos, ciclos, jerarquías, causa-efecto.
- Para **matrices de 2×2** (incertidumbre ambiental, etc.): `quadrantChart`.
- Para **mapas de un tema**: `mindmap`.
- Cuando Mermaid no da (barras proporcionales, pirámides, superposiciones), **SVG inline**
  con `var(--text-normal)` / `var(--background-modifier-border)` para que respete el tema
  claro/oscuro. Es la excepción, no el default.

Paleta fija, para que todas las notas se lean como un sistema:

| Color | Uso |
|---|---|
| `#7C5CFF` violeta | el concepto central / el resultado del diagrama |
| `#4DB6AC` verde | entorno, externo, entrada |
| `#FFA726` naranja | cultura, interno, institucional |

Siempre `color:#fff` en los nodos con fill, o el texto desaparece en tema oscuro.

**Dos trampas de sintaxis:**

1. Dentro de un nodo, `**negrita**` **no se interpreta** — sale con los asteriscos a la vista.
   En `flowchart` hay que usar `<b>` / `<i>` / `<br/>` (HTML).
2. En `mindmap` ni siquiera el HTML es confiable: **texto plano**, y se distingue con
   MAYÚSCULAS en vez de negrita. `<br/>` sí funciona para cortar línea.

Banco de tipos de diagrama probados: `00-Sistema/_test-render.md`.

## Cómo se enlaza (esto es lo que arma la red)

1. **Todo concepto cita a su unidad** y la unidad lo lista de vuelta.
2. **Todo concepto tiene un bloque `## Conexiones`** con 3-6 enlaces a conceptos
   hermanos, con una frase que diga *por qué* están conectados. Un enlace sin
   explicación no sirve para estudiar.
3. **Los conceptos transversales no se duplican por materia.** Si Porter aparece en
   OAE y en otra materia, es la misma nota, enlazada desde las dos.
4. **Las entregas enlazan a los conceptos que aplican**, no al revés. Así, al abrir
   `Cultura Organizacional` los backlinks te muestran dónde lo usaste en la práctica.

## Vistas útiles

- **Grafo local** (abrir nota → panel derecho, profundidad 2): la vecindad de un concepto.
- **Grafo global** con filtro `path:OAE`: el mapa de la materia.
- Colores del grafo: verde = conceptos · azul = unidades · naranja = TPs ·
  rosa = proyecto · amarillo = seguimiento · violeta = MOCs · celeste = clases.

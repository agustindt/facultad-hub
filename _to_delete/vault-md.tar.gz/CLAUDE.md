# Vault de Facultad — contexto

Vault de Obsidian de Agustín Di Tomaso. Ingeniería en Sistemas, 4º año, UCC.
Esta carpeta es la raíz. Cada materia tiene su propio `CLAUDE.md` con lo suyo.

## Lo primero: las reglas

**`00-Sistema/Convenciones.md` manda.** Leelo antes de escribir o proponer cualquier
cosa. Resumen de lo que más se rompe:

- **Wikilinks siempre, rutas nunca.** `[[Isocuanta]]`, no `Economia/04-Conceptos/...`.
- **Sin stems duplicados en todo el vault.** Obsidian resuelve por nombre de archivo:
  dos notas con el mismo nombre en materias distintas son una colisión.
- **Mermaid, jamás ASCII art.** Dentro de un nodo `**negrita**` no funciona: `<b>` y `<br/>`.
  En `mindmap`, texto plano y MAYÚSCULAS. Paleta fija `#7C5CFF` · `#4DB6AC` · `#FFA726`,
  siempre con `color:#fff`.
- **Fórmulas en LaTeX**, `$...$` o `$$...$$`. Nunca sueltas en prosa.
- **Nunca alias con pipe dentro de una tabla markdown** — rompe el parser.
- Toda nota de concepto lleva `## Conexiones` con 3 a 6 wikilinks, cada uno con una frase
  que explique **por qué** se conectan.

## `## En el parcial` no es decorativo

Ese bloque se convierte automáticamente en **tarjeta de repaso espaciado**: el hub lo lee
y lo muestra como consigna antes de revelar la nota. Escribí una consigna concreta y
accionable, con el error típico si lo sabés. "Es un tema importante" no sirve para nada.

## Materias

| Carpeta | Materia | Estado |
|---|---|---|
| `OAE/` | Organización y Administración de Empresas | Cursando · parcial 07/09 |
| `Economia/` | Economía, Cátedra A | Cursando · parciales 11/09 y 29/10 |
| `CompuGrafica/` | Computación Gráfica | Cursando |
| `Ing-Software-III/` | Ingeniería de Software III | Cursando · sin fechas publicadas |
| `Ing-Software-II/` | Ingeniería de Software II | Ya cursada |

## La regla de oro de este vault

**Un hueco declarado vale más que un dato inventado.** Todo el vault está construido así:
donde falta información hay una sección `## Faltantes` o `## Faltante` que dice exactamente
qué falta y por qué. Si no sabés algo, no lo completes: declaralo.

Dos casos donde esto importa especialmente:

- **Qué unidades entran en cada parcial de Economía no está publicado.** Hay dos fuentes que
  se contradicen. No lo asumas.
- **Las unidades 3 a 7 de Economía salen de apuntes de compañeros de 2025**, no de material
  de cátedra 2026, que no existe todavía. Cada nota lo declara al pie.

## El hub

`00-Sistema/_hub/` es una app web que corre local sobre este vault (`node server.js`,
puerto 4177). Lee y escribe los mismos `.md`: no hay copia ni base de datos.

**No edites nada dentro de `00-Sistema/_hub/`** salvo que te lo pidan explícitamente, y
nunca toques `00-Sistema/_hub/datos/` — ahí viven claves de API y estado local.

Lo que el hub deriva solo, por si te lo preguntan:

- **Repaso**: tarjetas desde los bloques `## En el parcial`, con SM-2 recortado a la fecha del parcial.
- **Cobertura**: los temas de `<Materia>/00-Seguimiento/programa-<sufijo>.md` contra las notas que existen.
- **Calendario**: fechas parseadas de las tablas de `00-Seguimiento/`.
- **Salud**: wikilinks rotos, stems duplicados, `estado` fuera de convención, conceptos huérfanos.
- **Código**: repos de GitHub vinculados por materia.

## Estructura de una materia

```
<Materia>/
├── <Materia>.md          MOC — solo enlaza, no tiene teoría propia
├── CLAUDE.md             contexto de esa materia
├── 00-Seguimiento/       cronograma, condiciones, programa, trackers
├── 01-Unidades/          una carpeta por unidad, con su nota índice
├── 02-TPs/               un TP por nota
├── 03-Proyecto-Catedra/
├── 04-Conceptos/         notas atómicas ← el corazón del grafo
├── 05-Recursos/
├── 06-Clases/            notas fechadas: `2026-08-14 - Clase U3.md`
└── 99-Material-Catedra/  PDFs oficiales, no se editan
```

Los archivos de `00-Seguimiento/` van **sufijados por materia** (`cronograma-eco.md`,
`condiciones-oae.md`) porque el stem tiene que ser único en todo el vault.

---
tipo: moc
materia: Economia
tags: [Economia, moc]
---

# Economía — Cátedra A

> Materia de 4º año, 2º semestre. Ingeniería, UCC. **Prof. Mgter. Francisco J. Boggione**
> (teórico) y **Lic. Francisco N. Hiza** (práctico).

**Seguimiento:** [[cronograma-eco]] · [[condiciones-eco]]

## Por qué esta materia existe en Ingeniería

La cátedra lo contesta de entrada, y conviene tenerlo a mano porque es la pregunta de apertura
más probable:

> "Los Ingenieros somos parte del aparato productivo de un país y nuestros proyectos y obras de ingeniería serán evaluados por su calidad, su **eficiencia técnica** y su **eficiencia económica** […] El ingeniero buscará siempre optimizar la producción y se enfrentará permanentemente […] con el desafío de producir un bien o de prestar un servicio, **administrando recursos limitados y buscando satisfacer necesidades y deseos ilimitados**."

## Unidades

| # | Unidad | Estado |
|---|---|---|
| 1 | [[U1-Introduccion-a-la-Economia]] | Teórico de cátedra 2026 |
| 2 | [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] | Teórico de cátedra 2026 |
| 3 | [[U3-Demanda-y-Mercados]] | ⚠️ Apuntes de compañeros 2025 |
| 4 | [[U4-Macroeconomia]] | ⚠️ Apuntes de compañeros 2025 |
| 5 | [[U5-Economia-de-Empresas]] | ⚠️ Apuntes de compañeros 2025 |
| 6 | [[U6-Ingenieria-Economica]] | ⚠️ Apuntes de compañeros 2025 |
| 7 | [[U7-Proyectos-de-Inversion]] | ⚠️ Apuntes de compañeros 2025 · sección vacía en el campus |

> ⚠️ **Las unidades 3 a 7 están escritas desde apuntes de compañeros de 2025, no desde
> material de la cátedra.** La cátedra todavía no publicó los teóricos de esas unidades: en el
> aula, las secciones 3 a 6 tienen el encabezado "DOCUMENTOS DE LA CLASE" sin ningún archivo
> debajo. Cada nota de esas unidades declara su fuente al pie y hay que revisarla cuando
> aparezca el teórico oficial. Las unidades 1 y 2 sí salen del material de cátedra 2026.

> ⚠️ **Hay dos numeraciones de unidades conviviendo.** El PDF 2026 de la cátedra define **6**
> unidades (con Economía de Empresas antes que Macroeconomía y sin "Ingeniería Económica" como
> unidad propia); el aula virtual tiene **7** con otro orden. La tabla de acá arriba sigue la
> del **aula**, porque es la que vas a ver al abrir el campus. Hay que preguntar cuál manda.

## Conceptos

### Fundamentos (U1)

- [[Escasez]] — el axioma del que sale todo lo demás
- [[Costo de Oportunidad]] — la consecuencia inmediata de la escasez
- [[Frontera de Posibilidades de Producción]] — la escasez, dibujada
- [[Problema Económico de Toda Sociedad]] — qué, cómo y para quién producir
- [[Sistemas de Organización Económica]] — autoridad, mercado y mixto
- [[Factores de Producción]] — K, L y RN
- [[Microeconomía y Macroeconomía]] — los dos enfoques

### Producción (U2)

- [[Función de Producción]] · [[Corto Plazo y Largo Plazo]]
- [[Producto Total Medio y Marginal]] · [[Máximo Técnico y Óptimo Técnico]]
- [[Ley de Rendimientos Decrecientes]] · [[Etapas de la Producción]]
- [[Rendimientos de Escala]]
- [[Isocuanta]] · [[Tasa Marginal de Sustitución Técnica]]
- [[Isocosto]] · [[Eficiencia Económica en Tecnología]] · [[Sendero de Expansión]]

### Costos (U2)

- [[Costo Económico]] — por qué el costo del economista no es el del contador
- [[Costos Fijos Variables y Totales]] · [[Costos Medios]] · [[Costo Marginal]]
- [[Relación entre Costo Marginal y Costo Medio]] — la regla que más se pregunta
- [[Costos de Largo Plazo]] · [[Economías y Deseconomías de Escala]] · [[Escala Mínima Eficiente]]

### Demanda y mercados (U3)

- [[Utilidad Total y Marginal]]
- [[Ley de la Utilidad Marginal Decreciente]]
- [[Equilibrio del Consumidor]]
- [[Curva de Demanda]]
- [[Elasticidad Precio de la Demanda]]
- [[Elasticidad Ingreso y Cruzada]]
- [[Excedente del Consumidor]]
- [[Clasificación de Mercados]]
- [[Equilibrio de Mercado]]
- [[Maximización de Beneficios]]
- [[Competencia Perfecta]]
- [[Monopolio]]
- [[Discriminación de Precios]]
- [[Competencia Monopolística]]
- [[Oligopolio]]
- [[Concentración y Defensa de la Competencia]]
- [[Mercado de Trabajo]]
- [[Fallas del Mercado]]
- [[Externalidades]]
- [[Bienes Públicos]]
- [[Rol del Estado y Desarrollo Sustentable]]

### Macroeconomía (U4)

- [[Objeto de la Macroeconomía]]
- [[Producto Bruto Interno]]
- [[Métodos de Cálculo del PBI]]
- [[PBI Nominal y PBI Real]]
- [[Producción Potencial y Brecha]]
- [[Matriz Insumo-Producto]]
- [[Ingreso Nacional e Ingreso Disponible]]
- [[Demanda y Oferta Agregada]]
- [[Consumo Ahorro e Inversión]]
- [[Flujo Circular del Ingreso]]
- [[Política Fiscal]]
- [[El Dinero y los Intermediarios Financieros]]
- [[Política Monetaria]]
- [[Inflación]]
- [[Desempleo y Curva de Phillips]]
- [[Balanza de Pagos y Mercado de Divisas]]

### Economía de empresas (U5)

- [[La Empresa y sus Actividades]]
- [[Sistemas de Información Contable]]
- [[Estados Contables Básicos]]
- [[Valuación de Activos]]
- [[Depreciación]]
- [[Impuestos: Ganancias e IVA]]
- [[Estructura Financiera de la Empresa]]
- [[Ciclo del Capital Circulante]]
- [[Fuentes de Financiamiento]]
- [[Ratios e Indicadores de Performance]]
- [[Contabilidad de Costos]]
- [[Costeo por Absorción]]
- [[Costeo Variable]]
- [[Costeo por Órdenes y por Procesos]]
- [[Costeo Basado en Actividades]]
- [[Teoría de las Restricciones]]

### Ingeniería económica (U6)

- [[Valor del Dinero en el Tiempo]]
- [[Interés Simple e Interés Compuesto]]
- [[Tasas Nominales y Tasas Efectivas]]
- [[Costo Financiero Total]]
- [[Inflación e Interés]]
- [[Factores de Equivalencia]]
- [[Anualidades y Perpetuidades]]
- [[Sistemas de Amortización de Deuda]]
- [[Flujo de Fondos]]
- [[Tasa de Descuento]]
- [[Valor Actual Neto]]
- [[Tasa Interna de Retorno]]
- [[Comparación de Alternativas]]
- [[Reemplazo de Equipos]]
- [[Punto de Equilibrio]]
- [[Matriz de Pagos]]
- [[Decisiones bajo Riesgo]]
- [[Decisiones bajo Incertidumbre]]

### Proyectos de inversión (U7)

- [[Proyecto de Inversión]]
- [[Tipos de Proyectos]]
- [[Ciclo de Vida del Proyecto]]
- [[Estudios de Factibilidad]]
- [[Tamaño y Localización]]
- [[Erogaciones Relevantes]]
- [[Evaluación Privada y Evaluación Social]]
- [[Precios Privados y Precios Sociales]]
- [[Análisis de Sensibilidad y Escenarios]]

## Trabajos prácticos

Sin TPs publicados en el campus. Hay clases prácticas los viernes.

## Clases

<!-- Se agregan a medida que se cursan. -->

## Bibliografía obligatoria

| Unidad | Libro |
|---|---|
| I, II, III | Mochón Morcillo, F. y Beker, V. *Economía — Principios y Aplicaciones*, McGraw-Hill, 4ª ed. 2008 |
| IV — Economía de Empresas | Brealey, Myers y Allen, *Principios de Finanzas Corporativas* · Horngren, Datar y Foster, *Contabilidad de Costos* · García y Arnoletto, *Introducción a la Contabilidad* |
| V — Macroeconomía | Sachs, J. y Larraín, F. *Macroeconomía en la economía global* |
| VI — Proyectos de Inversión | Sapag Chain, N. *Proyectos de inversión: formulación y evaluación* |

Complementaria en el aula: Mankiw, *Principios de Economía*, 7ª ed.

**De estos, están en el campus:** Mochón & Beker, Mankiw y Horngren. **Falta conseguir:**
Brealey, García y Arnoletto, y Sachs y Larraín. Sapag Chain está en `~/Downloads/Economia/`
(edición 2019).
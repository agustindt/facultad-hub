# Economía (Cátedra A) — contexto para Claude Code

<!-- Este archivo NO es una nota de Obsidian: es el contexto que carga /economia. -->

## Estado de cursada

4º año, 2º semestre 2026. Cátedra A. Al 14/08/2026 están cargadas las **7 unidades**, pero con
dos procedencias muy distintas:

- **U1 y U2** salen de los teóricos oficiales de la cátedra 2026.
- **U3 a U7** salen de **apuntes de compañeros de 2025** (Valentina, camila arenel, y tres
  manuscritos de iPad de nov 2025), porque la cátedra todavía no publicó esos teóricos. Cada
  nota de esas unidades lo declara al pie y muchas tienen una sección `## Faltante` con lo que
  el material no cubre. **Hay que revisarlas cuando aparezca el teórico oficial de cada una.**

Eso no contradice la regla de "no usar material viejo": no hay material nuevo con qué
reemplazarlo todavía, y esto es de un año atrás con la numeración de unidades actual, no el
volcado 2016–2019 de otra cátedra que está en `~/Downloads/Economia`.

## Docentes

- **Mgter. Francisco J. Boggione** — Profesor Titular, clases teóricas — 2360849@ucc.edu.ar
- **Lic. Francisco N. Hiza** — JTP, clases prácticas — 2665395@ucc.edu.ar
  (el aula lo escribe "Francisco M. Hiza"; el PDF de cátedra, "N.")

## Cursada

Teórico jueves 18:30–20:30. Práctico viernes: A1 17:15–19:15, A2 19:45–21:45.
**Falta saber en qué comisión de práctico está Agustín.**

## Evaluación

Dos parciales teórico-prácticos: **11/09/2026** y **29/10/2026**. Recuperatorio **12/11/2026**.
Regular con ≥4 y 65 % de asistencia; promoción **del práctico** con ≥7. Final: escrito
práctico + oral teórico (los promocionados rinden solo el oral).

## Método

Aprendizaje asistido y progresivo, unidad por unidad, en el orden real de cursada:
diagnóstico → explicación guiada socrática → resumen incremental → atomizar conceptos →
autoevaluación → repaso espaciado. **Nunca volcar un resumen completo de una sola vez.**

## Reglas de esta materia

- Se respeta `00-Sistema/Convenciones.md`.
- Archivos de seguimiento sufijados con `-eco` (`cronograma-eco.md`, `condiciones-eco.md`)
  para no chocar stems con OAE.
- **Es materia técnica**: las fórmulas van en LaTeX (`$...$` inline, `$$...$$` bloque), nunca
  en prosa. Los gráficos de curvas, en Mermaid o SVG inline — nunca ASCII.
- La cátedra avisó dos cosas que mandan sobre cómo estudiar:
  1. *"Las presentaciones de clases NO son el material de estudio"* — la fuente es Mochón & Beker.
  2. *"No usar material de estudio viejo / años anteriores"* — la carpeta `~/Downloads/Economia`
     es un volcado 2016–2019 de otra cátedra: sirve para los libros, no para el programa.
- No inventar fechas, consignas ni el reparto de unidades por parcial: **no está publicado**.

## Ojo con esto

- **Dos numeraciones de unidades conviven** (6 en el PDF 2026, 7 en el aula, con Macro y
  Economía de Empresas invertidas). Sin resolver.
- **No se publicó qué unidades entran en cada parcial.** El campo `parcial: 1` del frontmatter
  de U1 y U2 es una **hipótesis de trabajo**, no un dato de la cátedra.

## Qué falta

- [ ] Comisión de práctico (A1 o A2)
- [ ] Qué unidades entran en cada parcial
- [ ] Si los TPs y la monografía cuentan para regularizar
- [ ] Teóricos oficiales de las unidades 3 a 7 (para verificar las notas escritas desde apuntes 2025)
- [ ] Bibliografía obligatoria de U-IV y U-V (no está en el campus)

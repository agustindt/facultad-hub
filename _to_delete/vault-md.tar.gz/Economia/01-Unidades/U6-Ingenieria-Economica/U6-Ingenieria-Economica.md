---
tipo: unidad
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, ingenieria-economica, finanzas, decisiones]
---

# U6 — Ingeniería Económica

**Materia:** [[Economia]] · Anterior: [[U5-Economia-de-Empresas]] · Siguiente: [[U7-Proyectos-de-Inversion]]

> Es la unidad más matemática de la materia, y tiene una sola idea abajo de todo: **el dinero
> tiene fecha**. De ahí sale todo lo demás — primero se aprende a mover plata en el tiempo,
> después a medir proyectos con esa maquinaria, y al final a decidir cuando el futuro no está
> escrito.

## La idea que unifica la unidad

Si tenés esto, la mitad se deduce sola:

> **Montos ubicados en momentos distintos no se comparan ni se suman. Primero se llevan todos a
> una misma fecha; recién ahí se decide.**

Textual del apunte: *"Cuando se habla de una suma de dinero, se debe especificar la fecha, de
lo contrario la información es incompleta → El dinero cambia de valor a través del tiempo."*

Y el precio de esa diferencia entre fechas es la **tasa de interés**, que en el mundo de los
proyectos se llama [[Tasa de Descuento]] y no es otra cosa que el
[[Costo de Oportunidad]] del capital.

## Mapa de la unidad

```mermaid
flowchart TD
    VT["<b>EL DINERO TIENE FECHA</b><br/>valor del dinero en el tiempo"] --> EQ["<b>1. EQUIVALENCIA FINANCIERA</b><br/>mover plata de una fecha a otra"]
    EQ --> TA["Tasas: nominal, efectiva,<br/>real y CFT"]
    EQ --> FA["Factores de equivalencia<br/>anualidades y perpetuidades"]
    FA --> AM["Sistemas de<br/>amortización"]
    EQ --> FF["<b>2. INDICADORES DE PROYECTO</b><br/>arranca en el flujo de fondos"]
    FF --> D["Tasa de descuento<br/>d = costo de oportunidad"]
    D --> CON["Con valor tiempo:<br/><b>VAN</b> y <b>TIR</b>"]
    D --> SIN["Sin valor tiempo:<br/>RBC · BPA · PRC · PE"]
    CON --> ALT["Comparación<br/>de alternativas"]
    SIN --> ALT
    ALT --> REP["<b>3. REEMPLAZO</b><br/>defensor vs desafiante"]
    ALT --> MP["<b>4. FUTURO INCIERTO</b><br/>matriz de pagos"]
    MP --> R["Con RIESGO<br/>hay probabilidades"]
    MP --> I["Con INCERTIDUMBRE<br/>no hay probabilidades"]
    style VT fill:#4DB6AC,color:#fff
    style EQ fill:#FFA726,color:#fff
    style FF fill:#FFA726,color:#fff
    style CON fill:#7C5CFF,color:#fff
    style MP fill:#7C5CFF,color:#fff
```

## Bloque 1 — Equivalencia financiera

Cómo se mueve un monto de una fecha a otra, y a qué precio.

| Concepto | Qué resuelve |
|---|---|
| [[Valor del Dinero en el Tiempo]] | Por qué un peso hoy no es un peso mañana: inflación, costo de oportunidad y riesgo |
| [[Interés Simple e Interés Compuesto]] | Sobre qué base se calcula el interés de cada período |
| [[Tasas Nominales y Tasas Efectivas]] | Por qué la tasa de pizarrón no es la que pagás: TNA, TEA y capitalización |
| [[Costo Financiero Total]] | La tasa real de un préstamo, con gastos e impuestos adentro |
| [[Inflación e Interés]] | Cuándo la tasa real es negativa y qué hace el banco central con la tasa de política |
| [[Factores de Equivalencia]] | Capitalizar y actualizar: la maquinaria de toda la unidad |
| [[Anualidades y Perpetuidades]] | Series de pagos iguales, con fin y sin fin |
| [[Sistemas de Amortización de Deuda]] | Francés, alemán y americano: cómo se reparte capital e interés |

## Bloque 2 — Indicadores de proyecto

Con la maquinaria puesta, medir si un proyecto conviene.

| Concepto | Qué resuelve |
|---|---|
| [[Flujo de Fondos]] | El insumo de todo: ingresos y egresos ordenados por momento |
| [[Tasa de Descuento]] | El rendimiento mínimo exigido, contra el que se mide todo |
| [[Valor Actual Neto]] | Cuánta riqueza agrega el proyecto, **en pesos** |
| [[Tasa Interna de Retorno]] | Cuánto rinde el proyecto, **en porcentaje** |
| [[Comparación de Alternativas]] | Los métodos con y sin valor tiempo, y cuándo usar cada uno |
| [[Punto de Equilibrio]] | Cuánto hay que vender para no perder — es un indicador de riesgo |

## Bloque 3 — Decisiones de reemplazo

| Concepto | Qué resuelve |
|---|---|
| [[Reemplazo de Equipos]] | Defensor contra desafiante, costo presente mínimo y vida útil económica |

## Bloque 4 — Decisión bajo riesgo e incertidumbre

Cuando el resultado depende de algo que no controlás.

| Concepto | Qué resuelve |
|---|---|
| [[Matriz de Pagos]] | El formato común: alternativas contra estados de la naturaleza |
| [[Decisiones bajo Riesgo]] | Hay probabilidades: valor esperado, varianza, árboles y Montecarlo |
| [[Decisiones bajo Incertidumbre]] | No hay probabilidades: Maximin, Maximax, Laplace, Hurwicz y Savage |

## Las fórmulas que hay que poder escribir de memoria

Equivalencia:

$$VP = \frac{VF}{(1+i)^n} \qquad TEA = \left(1+\frac{TNA}{n}\right)^n - 1$$

$$VP_{\text{anualidad}} = A \times \frac{(1+i)^n-1}{i(1+i)^n} \qquad VP_{\text{perpetuidad}} = \frac{A}{i}$$

Evaluación (el apunte **no escribe** las dos primeras: salen de aplicar el factor de
actualización a cada flujo — verificalas contra el teórico oficial):

$$VAN = \sum_{t=0}^{n} \frac{FF_t}{(1+d)^t} \qquad \sum_{t=0}^{n} \frac{FF_t}{(1+TIR)^t} = 0$$

$$P \times Q = CF + CVu \times Q$$

Decisión:

$$VE(\text{decisión}) = \sum_i V_i \times P_i$$

## Las distinciones que se confunden — la lista de control

Esta unidad se aprueba o se pierde en estas cinco:

1. **Interés vs. tasa de interés.** El interés es un **monto, en pesos**; la tasa es un
   **porcentaje por período**. Y $i$ y $n$ siempre en el mismo período: es el error de arrastre
   más común de los prácticos.
2. **TNA vs. TEA vs. CFT.** La TNA es de pizarrón; la TEA agrega la capitalización; el CFT
   agrega además gastos e impuestos. **Dos préstamos se comparan por CFT**, no por TNA.
3. **VAN vs. TIR.** El VAN está en pesos y toma la tasa como dato; la TIR está en porcentaje y
   la devuelve como resultado. Y pueden ordenar distinto: *"Entre dos proyectos excluyentes, el
   mayor VAN maximiza la ganancia. Pero si considero que tengo un monto fijo de capital a
   invertir, los proyectos de mayor TIR maximizan la ganancia."*
4. **Riesgo vs. incertidumbre.** Con **riesgo** se conocen o se pueden asignar probabilidades a
   los estados de la naturaleza; con **incertidumbre**, no. Toda la separación de métodos sale
   de ahí y de ningún otro lado.
5. **Sistema francés vs. alemán.** En el francés lo constante es la **cuota**; en el alemán, el
   **capital**. Por eso el alemán paga menos intereses totales y el francés arranca con cuotas
   más chicas.

## Un bloque del apunte que vive en otra unidad

El apunte abre con una lista de **formas de financiamiento** (bancario: préstamos con y sin
garantía, sindicados, tarjetas, venta de cheques de terceros; mercado de capitales: cheques
propios y de terceros, facturas electrónicas, acciones, fideicomiso financiero; más venture
capital, capital semilla, subsidios y préstamos no reembolsables, FFF, microcréditos,
incubadoras y aceleradoras). Ese contenido corresponde a
[[Fuentes de Financiamiento]] — no lo dupliqué acá, pero **está en el material de esta unidad**
y puede caer.

## Faltante

Temas del programa oficial que el material **no cubre o cubre a medias**:

- **Período de análisis y valor residual.** El apunte fija el horizonte igual para ambos equipos
  en el reemplazo, pero **nunca define valor residual** ni el período de análisis como tema.
- **Alquilar o comprar.** No aparece. Sí está *fabricar o comprar*, con internalizar y
  outsourcing.
- **Selección de equipos.** Sólo aparece como el duelo defensor/desafiante dentro del reemplazo,
  no como tema propio.
- **Probabilidades.** Sólo se nombran la distribución normal (Gauss) y la beta (optimista,
  pesimista y más frecuente). No hay desarrollo.
- **Otros indicadores.** Están RBC, BPA, PRC y PE. Nada más.

Y lo transversal, que es lo más grave para practicar: **el material no trae prácticamente
ningún ejemplo numérico resuelto** —ni de TEA, ni de VAN, ni de cuadro de amortización, ni una
matriz de pagos con números. El único ejemplo numérico de toda la unidad es el de inflación 3 %
contra interés 2 % en [[Inflación e Interés]].

## En el parcial

Es la unidad con más cuentas del segundo bloque, y las consignas se arman encadenadas: un flujo
de fondos que después hay que evaluar.

- **Equivalencia:** pasar TNA a TEA; actualizar o capitalizar un monto; valor presente de una
  anualidad o de una perpetuidad.
- **Financiamiento:** comparar dos préstamos por CFT (no por TNA) y describir los tres sistemas
  de amortización por el comportamiento de la cuota.
- **Evaluación:** armar el flujo, calcular VAN y concluir contra la tasa de descuento; definir
  la TIR y su criterio; clasificar los indicadores en los que consideran y los que no consideran
  el valor tiempo del dinero.
- **Reemplazo:** los tres motivos, el criterio de costo presente mínimo y la vida útil económica
  como el mínimo costo anual equivalente.
- **Decisión:** armar una matriz de pagos, calcular valor esperado con probabilidades, y aplicar
  Maximin / Maximax / Laplace / Hurwicz / Savage sin ellas.

**El error más caro:** sumar montos de períodos distintos sin actualizarlos. Todo lo demás de la
unidad es una consecuencia de no cometerlo — ver [[Valor del Dinero en el Tiempo]].

**El segundo más caro:** comparar la TIR contra cero. La TIR se compara **contra la tasa
exigida** — ver [[Tasa Interna de Retorno]].

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

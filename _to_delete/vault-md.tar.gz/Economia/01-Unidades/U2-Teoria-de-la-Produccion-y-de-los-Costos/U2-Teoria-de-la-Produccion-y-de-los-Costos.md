---
tipo: unidad
materia: Economia
unidad: U2
parcial: 1
estado: estudiado
tags: [Economia, U2, produccion, costos]
---

# U2 — Teoría de la Producción y de los Costos

**Materia:** [[Economia]] · Anterior: [[U1-Introduccion-a-la-Economia]]

> Esta unidad son **dos teóricos en uno**, y esa es la clave para estudiarla: primero
> producción (qué se puede hacer con los factores), después costos (cuánto cuesta hacerlo).
> **No son dos temas: son el mismo, visto desde los dos lados.** Cada curva de costos es el
> reflejo especular de una curva de producción.

## Objetivo de la unidad

> "Entender la teoría de la producción y de los costos como explicativos de la oferta de las empresas."

## La idea que unifica toda la unidad

Si entendés esto, la mitad de la unidad se deduce sola:

> **Cuando la productividad sube, los costos medios bajan. Cuando la productividad cae, los costos medios suben.**

Textual de la cátedra:

> "la evolución de los costos está condicionada por las características de producción: cuando aumente la productividad de algún factor los costos medios se reducirán, mientras que si la productividad empieza a reducirse, lógicamente, los costos medios se incrementarán."

De ahí sale que la curva de producto medio tenga forma de **∩** y la de costo medio forma de
**U**: son la misma información dada vuelta.

| Producción | ↔ | Costos |
|---|---|---|
| [[Producto Total Medio y Marginal|Producto medio]] (PMe) — forma de ∩ | ↔ | [[Costos Medios]] (CVMe) — forma de U |
| [[Producto Total Medio y Marginal|Producto marginal]] (PMg) — forma de ∩ | ↔ | [[Costo Marginal]] (CMg) — forma de U |
| Máximo del PMe = **óptimo técnico** | ↔ | Mínimo del CVMe |
| [[Ley de Rendimientos Decrecientes]] | ↔ | Tramo creciente del CMg |
| [[Rendimientos de Escala]] crecientes | ↔ | [[Economías y Deseconomías de Escala|Economías de escala]] |

## Mapa de la unidad

```mermaid
flowchart TD
    T["<b>TECNOLOGÍA</b><br/>cómo se combinan los factores"] --> FP["<b>Función de producción</b><br/>q = F(L, K)"]
    FP --> CP["<b>CORTO PLAZO</b><br/>al menos un factor fijo"]
    FP --> LP["<b>LARGO PLAZO</b><br/>todos los factores varían"]
    CP --> PROD["Producto total,<br/>medio y marginal"]
    PROD --> LEY["Ley de rendimientos<br/>decrecientes"]
    LEY --> ET["Las 3 etapas<br/>de la producción"]
    LP --> RE["Rendimientos<br/>de escala"]
    LP --> ISO["Isocuantas<br/>+ Isocostos"]
    ISO --> EF["<b>Eficiencia económica</b><br/>tangencia"]
    EF --> SE["Sendero de<br/>expansión"]
    style T fill:#4DB6AC,color:#fff
    style FP fill:#7C5CFF,color:#fff
    style EF fill:#7C5CFF,color:#fff
    style LEY fill:#FFA726,color:#fff
```

## Las cuatro relaciones que hay que poder escribir

$$PMg = \frac{\Delta PT}{\Delta L} \qquad PMe = \frac{PT}{L}$$

$$CT = CF + CV \qquad CMg = \frac{\Delta CT}{\Delta Q}$$

Y la condición de minimización de costos, que es **la** fórmula de la unidad:

$$\frac{w}{r} = \frac{PMg_L}{PMg_K} \qquad \Longleftrightarrow \qquad \frac{PMg_L}{w} = \frac{PMg_K}{r}$$

La segunda forma es la que hay que saber interpretar: *el producto marginal obtenido por el
último peso gastado tiene que ser el mismo, cualquiera sea el factor.* Si un peso puesto en
trabajo rinde más que un peso puesto en capital, conviene mover plata hacia el trabajo — y
recién cuando rinden igual no queda nada por ganar.

## Los conceptos de esta unidad

### Producción

| Concepto | Qué resuelve |
|---|---|
| [[Función de Producción]] | Qué máximo se puede producir con una combinación de factores |
| [[Corto Plazo y Largo Plazo]] | La distinción que ordena toda la unidad |
| [[Producto Total Medio y Marginal]] | Las tres curvas del corto plazo |
| [[Máximo Técnico y Óptimo Técnico]] | Los dos puntos con nombre propio |
| [[Ley de Rendimientos Decrecientes]] | Por qué el producto marginal termina cayendo |
| [[Etapas de la Producción]] | Dónde conviene producir y por qué |
| [[Rendimientos de Escala]] | Qué pasa cuando se mueven **todos** los factores |
| [[Isocuanta]] | Todas las combinaciones que dan el mismo producto |
| [[Tasa Marginal de Sustitución Técnica]] | A cuánto capital renunciar por una unidad de trabajo |
| [[Isocosto]] | Todas las combinaciones que cuestan lo mismo |
| [[Eficiencia Económica en Tecnología]] | El punto de tangencia: la combinación óptima |
| [[Sendero de Expansión]] | Cómo se mueve ese óptimo al crecer la escala |

### Costos

| Concepto | Qué resuelve |
|---|---|
| [[Costo Económico]] | Por qué el costo del economista incluye lo que el contador no ve |
| [[Costos Fijos Variables y Totales]] | La clasificación básica del corto plazo |
| [[Costos Medios]] | Costo por unidad: CFMe, CVMe, CTMe |
| [[Costo Marginal]] | Cuánto cuesta la unidad siguiente |
| [[Relación entre Costo Marginal y Costo Medio]] | La regla del corte en el mínimo |
| [[Costos de Largo Plazo]] | La curva envolvente |
| [[Economías y Deseconomías de Escala]] | Por qué la CMeL tiene forma de U |
| [[Escala Mínima Eficiente]] | El tamaño de planta óptimo |

## Distinciones que se confunden — la lista de control

Esta unidad se aprueba o se pierde en estas cinco:

1. **Eficiencia técnica vs. eficiencia económica.** Técnica: producir el máximo con los
   recursos dados. Económica: producir esa cantidad **al menor costo**. *Todos* los puntos de
   una [[Isocuanta]] son técnicamente eficientes; **uno solo** es económicamente eficiente.
2. **Rendimientos decrecientes vs. rendimientos decrecientes de escala.** Los primeros son de
   **corto** plazo (un factor varía, el resto fijo). Los segundos son de **largo** plazo
   (varían todos, en la misma proporción). Distinto plazo, distinto fenómeno.
3. **Máximo técnico vs. óptimo técnico.** Máximo: donde el producto **total** es máximo
   ($PMg = 0$). Óptimo: donde el producto **medio** es máximo ($PMg = PMe$). El óptimo viene
   **antes**.
4. **Corto plazo vs. largo plazo.** No se miden en meses: la distinción es **únicamente** si
   existen o no factores fijos.
5. **Función de producción vs. isocuanta.** La función relaciona **un** factor variable con el
   producto. La isocuanta muestra **todas** las combinaciones de factores que dan el mismo
   producto. La cátedra le dedicó una diapositiva entera a esta diferencia — mala señal para
   quien la ignore.

## En el parcial

Es la unidad con más cuentas del primer bloque.

- **Tabla de producción**: te dan PT y L, y hay que completar PMg y PMe, marcar el máximo y el
  óptimo técnico e identificar las tres etapas.
- **Curvas**: dibujar PT / PMe / PMg alineadas verticalmente y explicar por qué el PMg corta al
  PMe en su máximo.
- **Costos**: completar una tabla de CF, CV, CT, CFMe, CVMe, CTMe y CMg. Es mecánico pero se
  presta a errores de arrastre — verificá que $CTMe = CFMe + CVMe$.
- **Conceptual**: la condición de minimización de costos y su interpretación económica.
- **Gráfico**: por qué la CMeL es la envolvente de las curvas de corto plazo.

**El error más caro:** decir que la curva de costo marginal corta a la de costo medio "en
cualquier punto". Corta **siempre en el mínimo** del costo medio, y hay una razón matemática
para eso — ver [[Relación entre Costo Marginal y Costo Medio]].

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (Cátedra A, 2026, 22 diapositivas)

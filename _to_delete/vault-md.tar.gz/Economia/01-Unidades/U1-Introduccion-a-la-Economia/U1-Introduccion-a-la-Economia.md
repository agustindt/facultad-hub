---
tipo: unidad
materia: Economia
unidad: U1
parcial: 1
estado: estudiado
tags: [Economia, U1, introduccion]
---

# U1 — Introducción a la Economía

**Materia:** [[Economia]] · Siguiente: [[U2-Teoria-de-la-Produccion-y-de-los-Costos]]

> La unidad entera se sostiene sobre **una sola idea**: los recursos son limitados y las
> necesidades no. Todo lo demás — costo de oportunidad, la FPP, las tres preguntas, los
> sistemas económicos — son consecuencias de esa tensión.

> ⚠️ El campo `parcial: 1` es una **hipótesis de trabajo**. La cátedra no publicó qué unidades
> entran en cada parcial.

## Objetivo de la unidad

> "Entender los problemas económicos básicos, sus variables y los modelos micro y macroeconómicos en su relación con los problemas de ingeniería."

## La cadena lógica de toda la unidad

Si te tomás cinco minutos antes del parcial, que sean estos. Este esquema es literalmente la
diapositiva de cierre del teórico, y de él cuelga cada concepto:

```mermaid
flowchart LR
    N["NECESIDADES<br/>ilimitadas"] --> E
    R["RECURSOS<br/>limitados"] --> E
    E["<b>ESCASEZ</b>"] -->|obliga| EL["Necesidad<br/>de ELEGIR"]
    EL -->|implica| RN["Renunciar a<br/>otras opciones"]
    RN -->|significa| CO["<b>COSTO DE<br/>OPORTUNIDAD</b>"]
    CO --> PE["EL PROBLEMA<br/>ECONÓMICO"]
    style N fill:#4DB6AC,color:#fff
    style R fill:#4DB6AC,color:#fff
    style E fill:#FFA726,color:#fff
    style CO fill:#7C5CFF,color:#fff
    style PE fill:#7C5CFF,color:#fff
```

Leído en una frase: **como las necesidades son ilimitadas y los recursos no, hay escasez; la
escasez obliga a elegir; elegir es renunciar; y a eso que se renuncia se lo llama costo de
oportunidad.** El problema económico es cómo emplear esos recursos escasos para producir lo
suficiente.

## Contenidos

### 1. Economía positiva y normativa · instrumentos del análisis · variables económicas

### 2. El principio de escasez · factores de producción · FPP · costo de oportunidad · problemas económicos básicos · economía de mercado y planificada

## Los conceptos de esta unidad

| Concepto | Por qué importa |
|---|---|
| [[Escasez]] | Es el axioma. Sin escasez no habría economía |
| [[Costo de Oportunidad]] | La consecuencia inmediata, y el concepto más transversal de toda la carrera |
| [[Frontera de Posibilidades de Producción]] | La escasez y el costo de oportunidad, dibujados en un gráfico |
| [[Problema Económico de Toda Sociedad]] | Las tres preguntas: qué, cómo y para quién producir |
| [[Sistemas de Organización Económica]] | Las tres formas de contestar esas preguntas |
| [[Factores de Producción]] | K, L y RN: con qué se produce |
| [[Actividad Económica]] | El circuito productores ↔ consumidores |
| [[Microeconomía y Macroeconomía]] | Los dos lentes con los que se mira todo lo que viene después |

## Definición de Economía que da la cátedra

Tres formulaciones del teórico, que conviene poder decir de memoria:

> "Estudio del modo en que la sociedad **gestiona sus recursos que son escasos** frente a las necesidades que son ilimitadas."

> "La ECONOMÍA estudia la **asignación de recursos escasos** para obtener un conjunto ordenado de objetivos. Del griego **OIKOS** (hogar), **NOMOS** (normas)."

> "La ECONOMÍA se ocupa de la manera en que se **administran los recursos escasos**, con el objeto de **producir** diversos bienes y **distribuirlos** para su consumo entre los miembros de la sociedad."

Las tres dicen lo mismo con distinto énfasis: **asignar** (el problema), **producir y
distribuir** (las dos operaciones), **escasez** (la restricción).

## Por qué un ingeniero estudia esto

La cátedra dedica la primera diapositiva entera a justificarlo, así que es material de examen:

- Los proyectos de ingeniería se evalúan por **calidad**, **eficiencia técnica** y
  **eficiencia económica**. Las tres, no solo la segunda.
- Las decisiones del ingeniero se fundamentan *"no solo en el carácter técnico, sino también en
  el económico y humano (impacto social y ambiental)"*.
- El trabajo del ingeniero busca *"una relación óptima entre el **rendimiento**, la
  **confiabilidad** y el **costo**"*.

Es el mismo trípode que vas a ver formalizado en la U2: la **eficiencia técnica** (producir el
máximo con los recursos dados) y la **eficiencia económica** (hacerlo al menor costo) son cosas
distintas, y la segunda es la que decide.

## En el parcial

Esta unidad casi no tiene cuentas: se juega en **definir bien y encadenar**.

1. **Definir Economía** y explicar por qué la escasez es el punto de partida.
2. **Costo de oportunidad**: definirlo, y calcularlo sobre una tabla de FPP. Ojo — es lo único
   con número de la unidad.
3. **Las tres preguntas** y el carácter de cada una: qué producir → **económico**; cómo producir
   → **técnico**; para quién → **social**. Ese apareo se pregunta tal cual.
4. **FPP**: identificar en el gráfico los puntos eficiente, ineficiente e inalcanzable, y saber
   qué desplaza la curva.
5. **Micro vs macro**: dar un ejemplo de cada una.

**La trampa clásica:** confundir *ineficiente* con *inalcanzable*. Un punto **dentro** de la
FPP es ineficiente (hay recursos ociosos: podés producir más de un bien sin resignar el otro,
o sea costo de oportunidad **cero**). Un punto **fuera** es inalcanzable con la tecnología
actual. Solo los puntos **sobre** la curva son eficientes.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (Cátedra A, 2026, 11 diapositivas)

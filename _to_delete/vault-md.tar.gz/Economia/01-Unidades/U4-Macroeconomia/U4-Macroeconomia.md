---
tipo: unidad
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, macroeconomia]
---

# U4 — Macroeconomía

**Materia:** [[Economia]] · Anterior: [[U3-Demanda-y-Mercados]] · Siguiente: [[U5-Economia-de-Empresas]]

> Hasta acá todo era **una** empresa, **un** mercado, **un** consumidor. Esta unidad cambia la
> lente: mira el sistema económico entero. Y tiene una estructura muy clara que conviene ver antes
> de estudiar: primero se aprende a **medir** (contabilidad nacional), después a **explicar** cómo
> se determina el nivel de actividad, después a **actuar** sobre él con políticas, y al final se
> abre la economía al **resto del mundo**.

## El objetivo, textual

El material no trae un objetivo de cátedra, pero sí el propósito de la macroeconomía, y funciona
como enunciado de la unidad:

> "La Macroeconomía estudia el funcionamiento de la economía en su conjunto, es decir, del comportamiento global del sistema económico. Su propósito es obtener una visión simplificada de la economía, pero que al mismo tiempo permita **conocer y actuar** sobre el nivel de la actividad económica de un país determinado o de un conjunto de países."

*Conocer* es la primera mitad de la unidad; *actuar*, la segunda.

## La idea que unifica todo

Si te queda una sola frase de la unidad, que sea ésta:

> "El PIB (la producción total de una economía) es igual a los ingresos generados en esa economía. Los términos 'producción' e 'ingreso' (o renta) se utilizan como si fueran sinónimos (de hecho, lo son)."

De ahí se deduce media unidad: por qué hay **tres** métodos de cálculo del PBI que dan el mismo
número, por qué el flujo circular cierra, y por qué "medir la producción" y "medir el ingreso" son
la misma tarea hecha desde dos ventanillas.

## Cómo se encadenan los cuatro bloques

```mermaid
flowchart TD
    A["<b>1. CONTABILIDAD NACIONAL</b><br/>cómo se mide la economía<br/>PBI · ingreso nacional"] --> B["<b>2. DETERMINACIÓN DEL INGRESO</b><br/>qué fija el nivel de actividad<br/>oferta y demanda agregada · Keynes"]
    B --> C["<b>3. POLÍTICAS</b><br/>cómo se actúa sobre el nivel de actividad<br/>fiscal · monetaria"]
    C --> D["<b>4. SECTOR EXTERNO</b><br/>la economía abierta<br/>balanza de pagos · divisas"]
    D --> B
    C --> E["Los dos problemas que se atacan:<br/><b>INFLACIÓN y DESEMPLEO</b>"]
    E --> B
    style A fill:#4DB6AC,color:#fff
    style B fill:#7C5CFF,color:#fff
    style C fill:#FFA726,color:#fff
    style D fill:#4DB6AC,color:#fff
    style E fill:#7C5CFF,color:#fff
```

La flecha de vuelta no es decorativa: las políticas y el sector externo **modifican** el nivel de
actividad, que es lo que el bloque 2 explica y el bloque 1 mide. El circuito es el mismo del
[[Flujo Circular del Ingreso]].

## Las fórmulas que hay que poder escribir de memoria

La identidad central, con cada término identificado:

$$PBI_{pm} = C + I + G + (X - M)$$

$C$ consumo privado de las familias · $I$ inversión bruta de las empresas · $G$ gasto público ·
$X$ exportaciones · $M$ importaciones, que **restan** porque son gasto sobre producción que no es
del país.

Las cuatro ecuaciones puente de la contabilidad nacional:

$$P_{mercado} = C_{factores} + Imp.Indirectos - Subsidios$$
$$YD = YP - Impuestos\ directos$$
$$Nacional = Interno + Saldo\ de\ remesas$$
$$Neto = Bruto - Depreciaciones$$

El reparto del ingreso y las propensiones:

$$Y = C + S \qquad PMC = \frac{\Delta C}{\Delta Y} \qquad 0 < PMC < 1 \qquad PMC + PMS = 1$$

El multiplicador y el efecto multiplicador del dinero:

$$\Delta Y = k \cdot \Delta I \quad \text{con} \quad k = \frac{\Delta Y}{\Delta I}
\qquad\qquad D_n = D_0 \cdot (1-c)^n$$

Y las del sector real y externo:

$$Tasa\ de\ desocupación = \frac{Desocupados}{PEA} \qquad Saldo\ BP = Variación\ de\ reservas$$

## Los conceptos de esta unidad

### Punto de partida

| Concepto | Qué resuelve |
|---|---|
| [[Objeto de la Macroeconomía]] | Qué mira la macro, cuáles son los objetivos y cuáles los instrumentos |

### Bloque 1 — Contabilidad nacional: cómo se mide

| Concepto | Qué resuelve |
|---|---|
| [[Producto Bruto Interno]] | El indicador más amplio, y cómo leer sus siglas |
| [[Métodos de Cálculo del PBI]] | Gasto, ingreso y valor agregado: tres caminos, un número |
| [[PBI Nominal y PBI Real]] | Qué parte del aumento es producción y qué parte es precio |
| [[Producción Potencial y Brecha]] | El techo con precios estables, y qué es crecer |
| [[Matriz Insumo-Producto]] | Tema del programa **no cubierto** por el material — hueco declarado |
| [[Ingreso Nacional e Ingreso Disponible]] | La cadena de restas hasta el bolsillo de la familia |

### Bloque 2 — Determinación del ingreso: qué fija el nivel de actividad

| Concepto | Qué resuelve |
|---|---|
| [[Demanda y Oferta Agregada]] | El cruce que determina PBI real y nivel general de precios |
| [[Consumo Ahorro e Inversión]] | Las propensiones y el modelo del multiplicador |
| [[Flujo Circular del Ingreso]] | Entradas y salidas: por qué el circuito cierra y por qué se altera |

### Bloque 3 — Políticas (y los dos problemas que atacan)

| Concepto | Qué resuelve |
|---|---|
| [[Política Fiscal]] | Gasto público e impuestos; déficit, superávit y resultado primario |
| [[El Dinero y los Intermediarios Financieros]] | Tasas activa y pasiva, spread y creación de dinero bancario |
| [[Política Monetaria]] | Cantidad de dinero, tasa de interés y coeficiente de caja |
| [[Inflación]] | Qué es, cómo se mide y de dónde sale |
| [[Desempleo y Curva de Phillips]] | Las tres tasas de empleo y la disyuntiva de corto plazo |

### Bloque 4 — Sector externo

| Concepto | Qué resuelve |
|---|---|
| [[Balanza de Pagos y Mercado de Divisas]] | Comercio internacional, las tres cuentas, reservas y tipo de cambio |

## Cierre del programa: crecimiento, integración y nueva economía

Tres temas del programa que el material trata brevemente y que no tienen nota propia. Dónde está
cada uno:

- **Crecimiento económico y desarrollo** → dentro de [[Producción Potencial y Brecha]]. Crecer es
  expandir el PBI potencial, o sea desplazar hacia afuera la
  [[Frontera de Posibilidades de Producción]]; las fuentes son trabajo, capital físico y tecnología.
  Desarrollo es otra cosa: la brecha de niveles de vida, medida con ingreso por habitante,
  analfabetismo, estructura sanitaria, desempleo y distribución del ingreso.
- **Mercados comunes** → dentro de [[Balanza de Pagos y Mercado de Divisas]], como parte de la
  categoría regional: uniones aduaneras con arancel externo común, áreas de libre comercio con
  arancel propio ante terceros y unión económica o monetaria. El material **no usa la expresión
  "mercado común"** ni la define.
- **Nueva economía y tecnologías de la información** → no tiene nota. Lo que dice el material, en
  tres líneas: las TIC "procesan, almacenan y comunican información"; la globalización es "la
  interdependencia económica creciente del conjunto de los países del mundo", con indicadores como
  la reducción de costos de transporte, la difusión de la tecnología, la movilidad internacional de
  capital y el aumento del ratio $(X+M)/PBI$; y la economía del conocimiento son las actividades de
  uso intensivo de tecnología y capital humano calificado (software, biotecnología, industria
  satelital, inteligencia artificial, nanotecnología). El beneficio que el material destaca es el
  **aumento de la productividad**.

## Distinciones que se confunden — la lista de control

Esta unidad se aprueba o se pierde en estas seis:

1. **Nominal vs. real.** El nominal valúa a precios corrientes e incluye la inflación; el real, a
   precios del año base. **El crecimiento se mide siempre en términos reales.**
2. **Interno vs. nacional / bruto vs. neto / precios de mercado vs. costo de factores.** Son tres
   ejes independientes, cada uno con su ecuación puente. Se mueven de a uno.
3. **Impuestos directos vs. indirectos.** Los directos gravan la renta, la propiedad o la riqueza y
   se restan para llegar al ingreso disponible; los indirectos gravan el consumo y separan los
   precios de mercado del costo de factores.
4. **Objetivo vs. instrumento.** "Baja inflación" es objetivo; "tasa de interés" es instrumento. La
   producción potencial, en la lista del material, aparece del lado de las variables-instrumento.
5. **Propensión marginal vs. media.** La marginal trabaja con **variaciones** ($\Delta C / \Delta Y$),
   la media con **totales** ($C/Y$). Keynes decía que la media era decreciente; la marginal está
   entre 0 y 1.
6. **Denominador de las tasas de empleo.** Actividad y empleo van sobre la población total de
   referencia; **desocupación va sobre la PEA**. Es el error más caro de la unidad.

## Lo que el material no cubre — huecos declarados

Estos apuntes son de compañeros, no de la cátedra, y tienen agujeros identificados. Antes del
parcial hay que taparlos con la bibliografía:

| Tema del programa | Estado |
|---|---|
| Matriz insumo-producto y coeficientes técnicos | **Sin cubrir.** No hay definición, ni lectura de la matriz, ni coeficientes |
| El dinero | Sin definición ni funciones; tampoco agregados monetarios ni tipos de intermediarios |
| Multiplicador (fórmula cerrada) | Sólo está definido como $\Delta Y/\Delta I$ y descrita la cadena de gasto |
| Multiplicador monetario (fórmula cerrada) | Sólo el proceso y el ejemplo numérico del coeficiente de caja |
| Mercado de divisas | Hay tipo de cambio, pero no regímenes cambiarios ni devaluación/apreciación |
| Brecha del producto | Nombrada como "por encima o por debajo del potencial", nunca como variable con fórmula |
| Gráficos | Varios del apunte original eran imágenes que no llegaron al texto: cruz keynesiana, curva de Phillips, IPC de Laspeyres, gráfico del resultado fiscal |

## En el parcial

Es la unidad con más definiciones para memorizar y con dos o tres cuentas seguras.

- **Cálculo del PBI** por el método del gasto (sumar C, G, IB y X; restar M) o por valor agregado
  a partir de una tabla de sectores.
- **Conversión entre agregados**: de PBIpm a PNNcf o al ingreso disponible, aplicando las ecuaciones
  puente de a una.
- **Tasas de empleo**: las tres, con el denominador correcto.
- **Inflación**: variación porcentual del IPC y su efecto sobre el PBI real.
- **Conceptual de políticas**: dado un escenario, elegir fiscal o monetaria, expansiva o
  restrictiva, nombrar los instrumentos con su signo y decir el costo (déficit, inflación o
  desempleo).
- **Gráfico**: oferta y demanda agregadas con los ejes bien puestos —nivel general de precios y PBI
  real—, marcando el equilibrio macroeconómico.

**El error más caro:** calcular la tasa de desocupación sobre la población total en vez de sobre la
PEA. El segundo: tratar un aumento del PBI nominal como crecimiento — ver
[[PBI Nominal y PBI Real]].

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, `MACROECONOMIA — manuscrito iPad, nov 2025` y `SEGUNDO PARCIAL — sección Macroeconomía` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad. Ojo: el archivo del segundo parcial numera esta misma unidad como U7; acá se respeta la numeración del programa de la cátedra.

---
tipo: unidad
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, demanda, mercados]
---

# U3 — Demanda y Mercados

**Materia:** [[Economia]] · Anterior: [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · Siguiente: [[U4-Macroeconomia]]

> Esta unidad **cierra la microeconomía**. En U2 se explicó de dónde sale la oferta (de los
> costos); acá se explica de dónde sale la demanda (de la utilidad), se cruzan las dos en el
> mercado, se ve qué pasa cuando ese mercado tiene una sola empresa en lugar de mil, y se
> termina en las tres cosas que el mercado **no** resuelve solo.

## ⚠️ Qué parcial

**No está declarado en el frontmatter a propósito: las fuentes se contradicen.** El programa 2019
ubicaba las unidades I, II y III en el **primer** parcial, mientras que el resumen titulado
"SEGUNDO PARCIAL" de un año posterior lista Mercados como contenido del **segundo**. Nada de esto
está confirmado para 2026 —la cátedra todavía no publicó el reparto de unidades por parcial—, así
que **hay que preguntárselo al docente** antes de armar el cronograma de estudio.

## Objetivo de la unidad

**El material de esta tanda no trae un objetivo formal de la unidad** como sí lo tenía U2. Lo
más cercano a una declaración de propósito es la frase con la que el propio material cierra el
programa, y que vale la pena tener presente porque explica por qué esta unidad está en una
carrera de ingeniería:

> "OBJETIVO DEMANDADO POR LA SOCIEDAD A LA INGENIERÍA: DESARROLLO SUSTENTABLE."

## La idea que unifica toda la unidad

Una sola regla recorre la unidad de punta a punta, cambiando de disfraz:

> **Seguí haciendo la cosa mientras lo que suma la unidad siguiente sea mayor que lo que cuesta. Pará justo cuando se igualan.**

| Quién decide | Qué compara | Regla |
|---|---|---|
| El **consumidor** | Utilidad por peso gastado en cada bien | $\dfrac{UMg_x}{P_x} = \dfrac{UMg_y}{P_y}$ |
| La **empresa** (cualquier estructura) | Ingreso marginal contra costo marginal | $IMg = CMg$ |
| La empresa en **competencia perfecta** | Precio contra costo marginal | $P = CMg$ |
| La empresa que contrata un **factor** | Valor del producto marginal contra el precio del factor | $w = PMg_L \times P$ |
| El **mercado** en equilibrio | Lo que vale la última unidad contra lo que cuesta | $UMg = CMg$ |

Si te aprendés esa columna de la derecha, tenés el esqueleto de la unidad entera. Y fijate que
la última fila es la síntesis de las anteriores: el equilibrio de mercado es el punto donde la
regla del consumidor y la regla de la empresa dan el mismo número.

## Mapa de la unidad

```mermaid
flowchart TD
    U["<b>UTILIDAD</b><br/>placer subjetivo de consumir"] --> LEY["Ley de utilidad<br/>marginal decreciente"]
    LEY --> EQC["<b>EQUILIBRIO DEL CONSUMIDOR</b><br/>utilidad por peso igualada"]
    EQC --> D["<b>CURVA DE DEMANDA</b><br/>pendiente negativa"]
    D --> EL["Elasticidades<br/>precio &middot; ingreso &middot; cruzada"]
    D --> M["<b>EQUILIBRIO DE MERCADO</b><br/>Qd = Qo y UMg = CMg"]
    O["OFERTA<br/>viene de los costos de U2"] --> M
    M --> MAX["Principio marginal<br/>IMg = CMg"]
    MAX --> EST["<b>ESTRUCTURAS DE MERCADO</b><br/>competencia perfecta &middot; monopolio<br/>competencia monopolística &middot; oligopolio"]
    EST --> CONC["Concentración y defensa<br/>de la competencia"]
    FAC["MERCADO DE FACTORES<br/>trabajo, tierra, capital"] --> F
    EST --> F["<b>FALLAS DEL MERCADO</b><br/>poder de mercado &middot; información<br/>externalidades"]
    F --> E["<b>ROL DEL ESTADO</b><br/>eficiencia e igualdad"]
    E --> DS["Desarrollo<br/>sustentable"]
    style U fill:#4DB6AC,color:#fff
    style O fill:#4DB6AC,color:#fff
    style FAC fill:#4DB6AC,color:#fff
    style D fill:#7C5CFF,color:#fff
    style M fill:#7C5CFF,color:#fff
    style EST fill:#7C5CFF,color:#fff
    style F fill:#FFA726,color:#fff
    style E fill:#FFA726,color:#fff
    style DS fill:#7C5CFF,color:#fff
```

## Los conceptos de esta unidad

### Bloque 1 — Del consumidor a la demanda

| Concepto | Qué resuelve |
|---|---|
| [[Utilidad Total y Marginal]] | Qué es la utilidad, y por qué el agua es barata y los diamantes caros |
| [[Ley de la Utilidad Marginal Decreciente]] | Por qué la unidad siguiente siempre vale menos |
| [[Equilibrio del Consumidor]] | Cómo reparte el presupuesto entre bienes: la condición de óptimo |
| [[Curva de Demanda]] | De dónde sale la demanda, y cuándo se mueve *sobre* la curva y cuándo la curva se desplaza |

### Bloque 2 — Medir la demanda

| Concepto | Qué resuelve |
|---|---|
| [[Elasticidad Precio de la Demanda]] | Cuánto responde la cantidad al precio, y qué le pasa al ingreso total |
| [[Elasticidad Ingreso y Cruzada]] | La clasificación de bienes: sustitutos, complementarios, inferiores, normales |
| [[Excedente del Consumidor]] | Lo que gana el comprador por encima de lo que paga — **el material lo cubre a medias** |

### Bloque 3 — El mercado y la decisión de la empresa

| Concepto | Qué resuelve |
|---|---|
| [[Clasificación de Mercados]] | Las cuatro estructuras y los cuatro criterios que las separan |
| [[Equilibrio de Mercado]] | El cruce de oferta y demanda, los ajustes y la intervención del Estado |
| [[Maximización de Beneficios]] | $IMg = CMg$: la regla que vale para todas las estructuras |

### Bloque 4 — Las cuatro estructuras de mercado

| Concepto | Qué resuelve |
|---|---|
| [[Competencia Perfecta]] | El modelo de referencia: $P = CMg$, cierre, salida y beneficio cero |
| [[Monopolio]] | Una sola empresa: cómo se determinan cantidad, precio y beneficio |
| [[Discriminación de Precios]] | Cobrar distinto a cada quien para capturar más excedente |
| [[Competencia Monopolística]] | Muchos oferentes, producto diferenciado y exceso de capacidad |
| [[Oligopolio]] | Pocas empresas, decisiones interconectadas y teoría de los juegos |
| [[Concentración y Defensa de la Competencia]] | Los índices de Lerner y Herfindahl, y qué puede hacer el gobierno |

### Bloque 5 — Los mercados de factores

| Concepto | Qué resuelve |
|---|---|
| [[Mercado de Trabajo]] | Demanda derivada, $IPMg_L$, salario de equilibrio y salario mínimo |

### Bloque 6 — Lo que el mercado no resuelve

| Concepto | Qué resuelve |
|---|---|
| [[Fallas del Mercado]] | El óptimo de Pareto y la tipología de las tres fallas |
| [[Externalidades]] | Por qué se produce de más o de menos cuando el efecto no pasa por un precio |
| [[Bienes Públicos]] | Rivalidad, exclusión y por qué el mercado no puede proveerlos |
| [[Rol del Estado y Desarrollo Sustentable]] | Eficiencia e igualdad, los tres instrumentos y el cierre ambiental |

## Distinciones que se confunden — la lista de control

1. **Cantidad demandada vs. demanda.** Sólo el precio del propio bien te mueve **sobre** la curva; ingreso, gustos y precios de otros bienes **desplazan** la curva entera.
2. **Elasticidad vs. pendiente.** En una demanda lineal la pendiente es constante y la elasticidad **no**: es elástica arriba (precio alto, cantidad baja) e inelástica abajo.
3. **Cierre vs. salida.** Cierre es de **corto** plazo ($P < CVMe$) y el costo fijo se paga igual, hundido. Salida es de **largo** plazo ($P < CTMe$) y no se paga nada.
4. **Beneficio económico vs. beneficio contable.** Con beneficio económico cero, el contable es **positivo**: la contabilidad no registra los costos implícitos.
5. **Cómo se lee el precio en monopolio.** La cantidad sale de $IMg = CMg$, pero el precio se lee **subiendo hasta la curva de demanda**, no hasta el $CMg$. Es el error más caro de la unidad.
6. **Eficiencia vs. equidad.** Un óptimo de Pareto puede ser eficiente y a la vez profundamente desigual. Por eso el rol del Estado tiene **dos** razones y no una.

## En el parcial

Es una unidad larga, y se rinde en tres frentes:

- **Conceptual y de enumeración.** La tabla de las cuatro estructuras de mercado, la tipología de las tres fallas, la clasificación de bienes por rivalidad y exclusión, los tres instrumentos del Estado. Son puntos enteros si la lista está completa.
- **Gráfico.** El equilibrio del monopolista con sus tres puntos, el ajuste del mercado ante un desplazamiento de oferta o demanda, la curva de oferta de la empresa competitiva.
- **Numérico.** Calcular una elasticidad y clasificarla, decir qué le pasa al ingreso total, y calcular un índice de Herfindahl a partir de cuotas de mercado (acordate de elevar al cuadrado **antes** de sumar).

**El error más caro:** en el gráfico del monopolio, leer el precio sobre la curva de costo
marginal. La cantidad sale del cruce $IMg = CMg$; el precio, de subir hasta la demanda — ver
[[Monopolio]].

## Estado del material

Estas notas salen de **apuntes de compañeros de 2025**, no del teórico oficial 2026, que para
esta unidad todavía no se publicó. Dos huecos ya detectados y declarados en las notas
correspondientes: el **excedente del consumidor** (nombrado pero nunca definido) y los
**sindicatos** (ausentes por completo, aunque el programa los pide). Ver también los faltantes
parciales en [[Concentración y Defensa de la Competencia]] y [[Bienes Públicos]].

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, `MERCADOS — manuscrito iPad (nov 2025)`, `SEGUNDO PARCIAL — Google Docs, sección Unidad 3` y `Resumen temas coloquio — sección demanda/mercados` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

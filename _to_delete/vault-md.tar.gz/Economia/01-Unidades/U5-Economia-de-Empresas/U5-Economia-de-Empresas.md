---
tipo: unidad
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, empresa, contabilidad, costos]
---

# U5 — Economía de Empresas

**Materia:** [[Economia]] · Anterior: [[U4-Macroeconomia]] · Siguiente: [[U6-Ingenieria-Economica]]

> Ésta es la unidad donde la empresa **deja de ser una curva y pasa a ser una organización con
> libros contables**. En U2 la empresa era una función de producción; acá tiene balance, deudas,
> proveedores que le financian el ciclo y un sistema para saber cuánto cuesta cada producto.
> **Es la misma empresa, con el microscopio adentro.**

## Objetivo de la unidad

**El material no trae un objetivo de unidad enunciado por la cátedra.** Lo más parecido es la
definición de empresa, que sí funciona como brújula de todo el resto:

> "Una empresa se puede definir como un conjunto de factores de producción coordinados, cuya función es producir bienes y servicios. Objetivo: maximizar su beneficio."

Y, dentro del bloque de costos, los tres objetivos declarados de la contabilidad de costos:

> "a) Proveer de información útil para la asignación de valor monetario a productos o servicios. b) Proveer información de uso interno de los directivos de la empresa, que permita el desarrollo de las tareas de planeación, control y toma de decisiones. c) Visualizar desviaciones para tomar las medidas correctivas (optimización de los recursos)."

## La idea que ordena los tres bloques

Toda la unidad son **tres preguntas sobre la misma empresa**, y cada bloque contesta una:

| Bloque | La pregunta | El instrumento |
|---|---|---|
| **1. Contabilidad general** | ¿Qué pasó? | Los estados contables, obligatorios, mirando al pasado y hacia afuera |
| **2. Estructura financiera** | ¿Con qué plata, y alcanza? | El lado derecho del balance, el ciclo del circulante y los ratios |
| **3. Contabilidad de costos** | ¿Cuánto cuesta cada cosa que hago? | Los sistemas de costeo, opcionales, mirando al futuro y hacia adentro |

La bisagra entre los bloques 1 y 2 es una sola frase, y conviene tenerla escrita:

> "La adquisición de los bienes que conforman el ACTIVO de la empresa (**estructura económica**), obliga a disponer de RECURSOS FINANCIEROS, que constituyen la fuente de financiamiento de la empresa (**estructura financiera**)."

Y la bisagra entre 1 y 3 es la distinción **costo / gasto**: el costo se identifica con el
producto, el gasto con el período. De dónde caiga cada erogación depende qué queda en el activo
y qué baja al resultado.

## Mapa de la unidad

```mermaid
flowchart TD
    E["<b>LA EMPRESA</b><br/>factores de producción coordinados<br/>objetivo: maximizar beneficio"] --> ACT["4 actividades:<br/>financiamiento · inversión<br/>operaciones · beneficios"]
    ACT --> SIC["<b>SISTEMAS DE<br/>INFORMACIÓN CONTABLE</b>"]
    SIC --> CG["<b>Contabilidad general</b><br/>OBLIGATORIA · pasado · externa"]
    SIC --> CC["<b>Contabilidad de costos</b><br/>OPCIONAL · futuro · interna"]
    CG --> EC["Estados contables<br/>A = P + PN"]
    EC --> EE["<b>Estructura económica</b><br/>el ACTIVO"]
    EC --> EF["<b>Estructura financiera</b><br/>PASIVO + PN"]
    EF --> FF["Fuentes de<br/>financiamiento"]
    EE --> CCIRC["Ciclo del capital<br/>circulante"]
    FF --> RAT["<b>RATIOS</b><br/>¿gana? ¿puede pagar?"]
    CCIRC --> RAT
    CC --> Q1["¿Qué se inventaría?<br/>absorción vs. variable"]
    CC --> Q2["¿Cómo se acumula?<br/>órdenes · procesos · ABC"]
    style E fill:#7C5CFF,color:#fff
    style SIC fill:#7C5CFF,color:#fff
    style CG fill:#4DB6AC,color:#fff
    style CC fill:#FFA726,color:#fff
    style RAT fill:#7C5CFF,color:#fff
    style Q1 fill:#FFA726,color:#fff
    style Q2 fill:#FFA726,color:#fff
```

## Las ecuaciones de la unidad

Las cuatro de los estados contables:

$$A = P + PN \qquad \text{Beneficio} = \text{Ingresos} - \text{Costos} - \text{Gastos}$$

$$\text{Saldo final} = \text{Saldo inicial} + \text{Beneficio} - \text{Dividendos} + \text{Aportes}$$

$$\text{Caja final} = \text{Caja inicial} + \text{Fondos Generados} - \text{Fondos Usados}$$

Las dos del ciclo del circulante:

$$CO = \text{Días de inventarios} + PCC \qquad CE = CO - \text{Período de cuentas por pagar}$$

Las cuatro de rentabilidad:

$$\text{Margen Bruto} = \frac{\text{Ventas} - CMV}{\text{Ventas}} \qquad ROA = \frac{\text{U. Neta}}{\text{Activos}} \qquad ROE = \frac{\text{U. Neta}}{PN}$$

Y la del costeo variable:

$$\text{Contribución Marginal} = \text{Ventas totales} - \text{Costos variables totales}$$

## Los conceptos de esta unidad

### Bloque 1 — Contabilidad general

| Concepto | Qué resuelve |
|---|---|
| [[La Empresa y sus Actividades]] | Qué es una empresa y las cuatro actividades en que entra todo lo que hace |
| [[Sistemas de Información Contable]] | Las dos ramas, devengado vs. percibido, partida doble y auditorías |
| [[Estados Contables Básicos]] | Los cuatro informes y sus cuatro ecuaciones |
| [[Valuación de Activos]] | PEPS, UEPS y PPP: a qué precio se valúa lo que se consume |
| [[Depreciación]] | La funcional y la contable, y los métodos para repartirla |
| [[Impuestos: Ganancias e IVA]] | El tema que el material casi no cubre — leer la sección Faltante |

### Bloque 2 — Estructura financiera

| Concepto | Qué resuelve |
|---|---|
| [[Estructura Financiera de la Empresa]] | El lado derecho del balance, y qué pasa en una crisis |
| [[Ciclo del Capital Circulante]] | Los dos relojes: ciclo económico y ciclo financiero |
| [[Fuentes de Financiamiento]] | Dos clasificaciones cruzadas: por origen y por titularidad |
| [[Ratios e Indicadores de Performance]] | ROA, ROE, EBITDA, liquidez y solvencia |

### Bloque 3 — Contabilidad de costos

| Concepto | Qué resuelve |
|---|---|
| [[Contabilidad de Costos]] | Costo vs. gasto, los elementos del costo y los métodos de estimación |
| [[Costeo por Absorción]] | Todos los costos de fabricación son inventariables |
| [[Costeo Variable]] | Sólo los variables; contribución marginal y punto de equilibrio |
| [[Costeo por Órdenes y por Procesos]] | Cómo se acumulan los costos según cuán parecidos sean los productos |
| [[Costeo Basado en Actividades]] | Los productos consumen actividades, no costos |
| [[Teoría de las Restricciones]] | Nota abierta: el programa lo pide y no hay material |

## Lo que engancha con la U2

Esta unidad no arranca de cero: retoma la teoría de costos de
[[U2-Teoria-de-la-Produccion-y-de-los-Costos]] y le pone contabilidad encima. Vale tener el
puente explícito, porque en el parcial se cruzan:

| En U2 (economista) | En U5 (contador) |
|---|---|
| [[Costos Fijos Variables y Totales]]: la partición fijo/variable | Es exactamente la partición que necesita el [[Costeo Variable]] para existir |
| [[Costo Marginal]]: cuánto cuesta la unidad siguiente | "Costeo marginal o variable: **una unidad más**" — la misma pregunta, respondida con criterio contable |
| [[Costos Medios]]: el costo por unidad | El costo unitario promedio del costeo por procesos: costos del período ÷ unidades del período |
| [[Costo Económico]]: incluye los costos implícitos | La contabilidad **no** los ve: el costo contable y el económico no son el mismo número |
| [[Maximización de Beneficios]] (U3) | El ROE es su traducción contable: cuánto rinde la plata de los dueños |

**El puente que más se usa:** en U2 la amortización del equipo era el ejemplo canónico de costo
fijo. Acá esa misma amortización tiene método de cálculo ([[Depreciación]]) y es el costo cuyo
tratamiento separa absorción de variable.

## Distinciones que se confunden — la lista de control

La unidad se aprueba o se pierde en estas ocho:

1. **Costo vs. gasto.** El costo se identifica con el **producto**; el gasto, con el **período**.
   No es sinónimo de "importante" ni de "grande".
2. **Devengado vs. percibido.** Devengado = cuando se produce el hecho (la venta). Percibido =
   cuando se cobra. **Los estados contables usan devengado.**
3. **Costeo por absorción vs. costeo variable.** Lo único que cambia son los **CIF fijos**:
   absorción los inventaria, variable los manda a resultado del período. Todo lo demás es igual.
4. **Estructura económica vs. estructura financiera.** Económica = **activo**. Financiera =
   **pasivo + PN**. Mismo número, dos lecturas.
5. **Ciclo económico vs. ciclo financiero.** El económico corre desde la **compra**; el financiero,
   desde el **pago**. El financiero es siempre más corto: la diferencia es lo que te financia el
   proveedor.
6. **ROA vs. ROE.** ROA = utilidad sobre **activos**, ignora cómo está financiada la empresa.
   ROE = utilidad sobre **patrimonio neto**, es la rentabilidad del accionista.
7. **Liquidez vs. solvencia.** Misma pregunta —¿puede pagar?— a **corto** y a **largo** plazo.
8. **Depreciación vs. amortización.** Mismo proceso: depreciación para **tangibles**, amortización
   para **intangibles**. Y los terrenos no se deprecian.

## Faltante

De los 29 temas del programa, hay cuatro que **el material no cubre o cubre a medias**. Están
declarados como tales en las notas correspondientes:

| Tema del programa | Estado |
|---|---|
| Impuesto a las ganancias (11) | Sólo menciones sueltas. **Del IVA no hay una sola línea** — ver [[Impuestos: Ganancias e IVA]] |
| Inversiones y el mercado de capitales (15) | **No tratado** — ver [[Fuentes de Financiamiento]] |
| Tablero de comando financiero (18) | **No tratado** — ver [[Ratios e Indicadores de Performance]] |
| Enfoque de la teoría de las restricciones (29) | **No tratado, cero menciones** — ver [[Teoría de las Restricciones]] |

Además, huecos parciales: no hay ejemplos numéricos en toda la unidad (ni de valuación PEPS/UEPS/PPP,
ni de depreciación, ni de absorción vs. variable, ni de ABC), no están las fórmulas de los métodos
de depreciación, ni las de los ratios financieros, ni la del punto de equilibrio, ni las de los
giros individuales del ciclo del circulante.

## En el parcial

Es una unidad **más conceptual y menos gráfica** que la U2: casi todo son definiciones, listas
ordenadas y comparaciones de dos columnas. Lo que se puede anticipar:

- **La comparación estrella:** costeo por absorción vs. costeo variable. Preparala como una sola
  frase (qué hace cada uno con los CIF fijos) más la tabla completa.
- **Listas para enumerar de memoria:** las cuatro actividades empresariales, los tres tipos de
  auditoría, los cuatro privilegios de cobro en la quiebra (laborales → hipotecarios → comunes →
  accionistas), las tres causas de la depreciación funcional, los cinco pasos del ABC.
- **Cuentas cortas:** valuar consumo y stock por PEPS/UEPS/PPP; calcular CO y CE; calcular ROA,
  ROE y contribución marginal.
- **Clasificaciones:** partidas en activo/pasivo/PN y corriente/no corriente; erogaciones en costo
  vs. gasto; fuentes de financiamiento por origen **y** por titularidad (son dos columnas, no una).
- **Elegir un sistema de costeo** dado un tipo de empresa, justificando con la unidad de costeo.

**El error más caro:** creer que el costeo variable saca del producto *todos* los costos fijos. Sólo
cambia de casillero los costos **fijos de fabricación** (CIF fijos); los de administración, ventas
y financiación ya eran gasto del período en los dos métodos.

**Segundo error más caro:** restar mal en el ciclo financiero. El giro de proveedores se **resta**,
porque el proveedor te financia y por lo tanto te acorta el ciclo.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: unidad
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos, inversion]
---

# U7 — Formulación y Evaluación de Proyectos de Inversión

**Materia:** [[Economia]] · Anterior: [[U6-Ingenieria-Economica]]

> Esta unidad es **la aplicación de la U6 a un caso concreto**. Allá aprendiste a calcular
> [[Valor Actual Neto]] y [[Tasa Interna de Retorno]] sobre un flujo dado; acá el trabajo es
> **construir ese flujo** —de dónde salen los ingresos, los egresos, el tamaño, la
> localización— y decidir **con qué precios** se lo valúa: los de la empresa o los de la
> sociedad.

## La idea que unifica la unidad

Todo el estudio de proyectos son dos movimientos, en este orden:

> **Formulación** = definir todo lo que afecta al flujo de ingresos y egresos, y medir su
> magnitud. **Evaluación** = determinar la rentabilidad de esa inversión y comparar
> alternativas.

Si tenés eso claro, cada tema de la unidad cae en un casillero: mercado, tamaño, localización y
costos son **formulación**; VAN, TIR, sensibilidad y precios sociales son **evaluación**.

## El ciclo de vida: gastar poco para descartar, gastar mucho sólo en lo que sobrevive

```mermaid
flowchart LR
    P["<b>PERFIL</b><br/>información existente,<br/>juicio y experiencia<br/>estimaciones globales"] --> PF["<b>PREFACTIBILIDAD</b><br/>fuentes secundarias<br/>variables principales<br/>con cierta aproximación"]
    PF --> F["<b>FACTIBILIDAD</b><br/>fuentes primarias<br/>antecedentes precisos"]
    P -.->|"si hay razón<br/>para abandonar"| X["ABANDONO DE LA IDEA<br/>antes de destinar recursos"]
    F --> D["<b>EVALUACIÓN</b><br/>VAN · TIR"]
    style P fill:#4DB6AC,color:#fff
    style PF fill:#4DB6AC,color:#fff
    style F fill:#FFA726,color:#fff
    style D fill:#7C5CFF,color:#fff
    style X fill:#FFA726,color:#fff
```

Las tres etapas se diferencian por **la fuente de la información**: lo que ya existe → fuentes
secundarias → fuentes primarias. Cada salto cuesta más plata, y por eso sólo se paga si la etapa
anterior no encontró motivo para abandonar.

## Los conceptos de esta unidad

### Formulación

| Concepto | Qué resuelve |
|---|---|
| [[Proyecto de Inversión]] | Qué es un proyecto y las dos grandes etapas de su estudio |
| [[Tipos de Proyectos]] | Las dos clasificaciones: productivos/infraestructura y nuevos/de cambio |
| [[Ciclo de Vida del Proyecto]] | Perfil, prefactibilidad, factibilidad: qué se sabe en cada una |
| [[Estudios de Factibilidad]] | Las seis viabilidades y la diferencia entre económica y financiera |
| [[Tamaño y Localización]] | La ingeniería básica: cuánto producir y dónde |
| [[Erogaciones Relevantes]] | Qué costos entran al flujo en un proyecto de cambio |

### Evaluación

| Concepto | Qué resuelve |
|---|---|
| [[Evaluación Privada y Evaluación Social]] | Las dos preguntas: conviene a la empresa vs. conviene a la sociedad |
| [[Precios Privados y Precios Sociales]] | La corrección por impuestos, subsidios y externalidades (FPC) |
| [[Análisis de Sensibilidad y Escenarios]] | Cómo se mide el riesgo del proyecto |

## Lo que ya sabés de la U6 y acá se aplica

| De U6 | Cómo aparece en U7 |
|---|---|
| [[Flujo de Fondos]] | Es el cash flow del proyecto, a valores constantes y con impuesto a las ganancias |
| [[Valor Actual Neto]] | Indicador de eficiencia económica operativa |
| [[Tasa Interna de Retorno]] | El otro indicador; se compara contra la tasa exigida |
| [[Tasa de Descuento]] | En la evaluación social se reemplaza por la tasa social o intergeneracional |
| [[Comparación de Alternativas]] | La evaluación es, textualmente, comparación de alternativas |

## Las tres distinciones que se confunden

1. **Factibilidad económica vs. financiera.** Económica: la inversión debe ser **rentable**.
   Financiera: debe existir **disponibilidad de recursos**. Son independientes.
2. **Eficiencia económica operativa vs. financiera** (dentro de la evaluación privada). La
   primera mide la rentabilidad **del proyecto** con el flujo del proyecto; la segunda, la
   rentabilidad **de los inversores** con el flujo de los inversionistas.
3. **Sensibilidad vs. escenarios.** Sensibilidad: **una** variable, el resto fijo. Escenarios:
   **varias a la vez**, en rangos pesimistas y optimistas.

## ⚠️ Faltantes

**Esta unidad se escribió sin material de cátedra.** La sección de la Unidad 7 en el aula
virtual **está vacía**: la cátedra no publicó ningún contenido. Consecuencias concretas, para
que las tengas presentes al estudiar:

- **No hay lista de temas del programa** contra la cual chequear que estas notas estén
  completas. Puede faltar contenido entero sin que haya forma de detectarlo.
- **Hay una sola fuente**: el apunte de una compañera de febrero 2025. Nada está contrastado
  contra un segundo material.
- El esquema **"Etapas en el ciclo de vida del proyecto" está en blanco** en el apunte (era una
  imagen). Sólo se conservan las tres etapas de preinversión —perfil, prefactibilidad,
  factibilidad—. **No hay nada sobre ejecución, puesta en marcha ni operación.**
- El apunte nombra los indicadores como **"VAN, TIR y PR"** y **nunca define el PR**.
- Las **fórmulas del flujo de fondos y del análisis beneficio-costo eran imágenes**: quedan sólo
  los símbolos ($B_j$, $C_j$, $I_0$, $n$, $V_r$), no las expresiones.
- Las viabilidades **comercial, técnica, legal y ambiental** sólo aparecen enumeradas, sin
  definición.
- **No hay ejercicios ni ejemplos numéricos resueltos**, así que todo lo que dice el bloque "En
  el parcial" está deducido del contenido, no de consignas reales de la cátedra.
- El campo `parcial: 2` es una **hipótesis de trabajo**: la cátedra no publicó qué unidades
  entran en cada parcial.

## En el parcial

Con el material que hay, lo defendible es esto:

- **Conceptual, muy probable**: definir proyecto de inversión; separar formulación de evaluación;
  ordenar perfil / prefactibilidad / factibilidad por fuente de información.
- **Listas para memorizar**: los seis tipos de proyecto de cambio, las cinco erogaciones
  relevantes, los cinco factores limitantes del tamaño, los tres de localización, las seis
  viabilidades.
- **Cuadro comparativo**: evaluación privada vs. social — beneficiario, precios, impuestos,
  externalidades, tasa de descuento.
- **Cuenta corta y concreta**: pasar de precios de mercado a precios sociales con
  $P_{social} = P_{mercado} \times FPC$, con $FPC = 0{,}70$ para edificios y máquinas.
- **Cálculo grande**: VAN y TIR sobre un flujo, que es contenido de [[U6-Ingenieria-Economica]]
  y acá se aplica al flujo del proyecto.

**El error más caro** de la unidad: usar precios de mercado en una evaluación social, o dejar el
impuesto a las ganancias adentro. Para la sociedad el impuesto no es un costo — el Estado
redistribuye, no crea ni consume riqueza.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

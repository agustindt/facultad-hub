---
tipo: concepto
materia: Economia
unidad: U3
autor: Vilfredo Pareto
estado: pendiente
tags: [Economia, U3, fallas]
---

# Fallas del Mercado

> **Una falla de mercado tiene lugar cuando un mercado no asigna eficientemente los recursos por
> sí mismo.** Son tres, se enumeran siempre juntas, y todas se definen contra el mismo patrón:
> el óptimo de Pareto que alcanzaría la competencia perfecta.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Primero el patrón: el óptimo de Pareto

Vilfredo Pareto (1848-1923) estableció que, en ciertas condiciones, **la competencia perfecta
asigna eficientemente los recursos**.

> "Una situación es eficiente, en el sentido de Pareto, cuando **no es posible mejorar el bienestar de una persona sin empeorar el de otra**."

Equivalente: una asignación es un óptimo de Pareto si no existe otra que permita mejorar la
posición de un individuo sin que los otros se vean perjudicados.

**Frontera de posibilidades de utilidad:** el gráfico análogo al de la frontera de posibilidades
de producción, pero con la utilidad de dos consumidores (o grupos), uno en cada eje. Los puntos
**de** la frontera son eficientes en el sentido de Pareto; cualquier punto **debajo** de la
frontera es ineficiente.

Y el resultado que cierra el círculo con todo el bloque de mercados:

> "El equilibrio competitivo conseguido mediante el sistema de precios permite alcanzar un óptimo de Pareto. Por consiguiente, la regla $P = CMg$ muestra una situación que no desea ser alterada ni por los consumidores ni por las empresas."

## La tipología: las tres fallas

| Falla | Definición del material | Caso extremo |
|---|---|---|
| **Competencia imperfecta — poder de mercado** | Capacidad que tiene un solo actor económico (o un grupo pequeño) de ejercer influencia en los precios del mercado. También llamados **mercados estrechos** | El **monopolio** |
| **Información imperfecta** | Los mercados suministran muy escasa información a consumidores o productores para tomar decisiones bien documentadas. **Información asimétrica** | — |
| **Externalidades** | Cuando algunas de las variables que afectan la utilidad o el beneficio de quien toma las decisiones se encuentran bajo el control de **otro** sujeto decisor | Los **bienes públicos**, caso extremo de externalidad positiva |

```mermaid
flowchart TD
    A["<b>ÓPTIMO DE PARETO</b><br/>no se puede mejorar a uno<br/>sin empeorar a otro"] --> B["Lo alcanza la<br/>COMPETENCIA PERFECTA<br/>con P = CMg"]
    B --> C{"¿Se cumplen<br/>las condiciones?"}
    C -->|"no"| D["<b>FALLA DEL MERCADO</b>"]
    D --> E["Poder de mercado<br/>competencia imperfecta"]
    D --> F["Información<br/>imperfecta o asimétrica"]
    D --> G["Externalidades"]
    E --> H["<b>ROL DEL ESTADO</b><br/>eficiencia e igualdad"]
    F --> H
    G --> H
    style A fill:#7C5CFF,color:#fff
    style B fill:#4DB6AC,color:#fff
    style D fill:#FFA726,color:#fff
    style H fill:#7C5CFF,color:#fff
```

## Por qué las tres son la misma cosa vista de tres modos

En los tres casos se rompe el supuesto que hacía funcionar el mecanismo de precios:

- Con **poder de mercado**, el precio deja de ser igual al costo marginal — y ya no hay $P = CMg$.
- Con **información imperfecta**, el precio deja de transmitir bien lo que la gente valora.
- Con **externalidades**, hay costos o beneficios que **no pasan por ningún precio**: quedan afuera del cálculo de quien decide.

De ahí la puerta de entrada a la intervención pública: el rol del Estado es **promover la
eficiencia y la igualdad**, y ésas son las dos grandes razones por las cuales el gobierno debe
intervenir en la economía, para cambiar la manera en que las personas asignarían los recursos.

## Conexiones

- [[Competencia Perfecta]] — es el modelo que **sí** alcanza el óptimo de Pareto: la referencia contra la que se define toda falla
- [[Monopolio]] — el caso extremo de la primera falla, y el único con una pérdida de eficiencia cuantificada en el material
- [[Externalidades]] — la tercera falla, desarrollada aparte porque tiene su propia lógica de sobre y subproducción
- [[Bienes Públicos]] — el material los presenta como caso extremo de externalidad positiva, o sea como falla derivada
- [[Rol del Estado y Desarrollo Sustentable]] — la consecuencia práctica: las fallas son la justificación de la intervención
- [[Frontera de Posibilidades de Producción]] — la frontera de posibilidades de **utilidad** es su gráfico análogo, con consumidores en lugar de bienes

## En el parcial

**Definir falla de mercado y enumerar las tres de la tipología con un ejemplo de cada una.** Es
casi seguro que aparece, y vale entera sólo si la enumeración está completa: poder de mercado,
información imperfecta, externalidades. Aparte, **definir óptimo de Pareto con la frase exacta**
("no es posible mejorar el bienestar de una persona sin empeorar el de otra") y saber que quien
lo alcanza es la competencia perfecta vía $P = CMg$. El error clásico es confundir *eficiencia*
con *equidad*: un óptimo de Pareto puede ser tremendamente desigual y seguir siendo eficiente.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `Resumen temas coloquio` y `SEGUNDO PARCIAL — Google Docs` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, fallas]
---

# Externalidades

> **Cuando lo que decide uno afecta a otro sin pasar por ningún precio.** Si el efecto es un
> costo, el mercado produce **de más**; si es un beneficio, produce **de menos**. Ese par de
> conclusiones es todo lo que hay que retener.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## La definición

> "Cuando algunas de las variables que afectan la utilidad o el beneficio de quien toma las decisiones se encuentra bajo el control de **otro sujeto decisor**."

Es la tercera de las [[Fallas del Mercado]], y la más contraintuitiva de las tres: no falla
porque haya poca competencia ni poca información, sino porque hay efectos reales que **no
aparecen en ningún precio** y por lo tanto nadie los tiene en cuenta al decidir.

## Las dos direcciones — la tabla que se pregunta

| | **Externalidad negativa** | **Externalidad positiva** |
|---|---|---|
| Qué se produce sobre terceros | **Costos** causados a terceros **sin compensación** | **Beneficios** causados a terceros **sin retribución** |
| Qué hace el mercado | Produce una cantidad **mayor** que la socialmente deseable | Produce una cantidad **menor** que la socialmente deseable |

La lógica en una línea: quien decide sólo mira **su** costo y **su** beneficio. Si parte del
costo lo paga otro, le sale barato y hace de más. Si parte del beneficio se lo lleva otro, le
rinde poco y hace de menos.

```mermaid
flowchart TD
    A["<b>EXTERNALIDAD</b><br/>una variable que afecta a quien decide<br/>está bajo control de otro"] --> B["NEGATIVA<br/>costos a terceros<br/>sin compensación"]
    A --> C["POSITIVA<br/>beneficios a terceros<br/>sin retribución"]
    B --> D["<b>El mercado produce MÁS<br/>de lo socialmente deseable</b>"]
    C --> E["<b>El mercado produce MENOS<br/>de lo socialmente deseable</b>"]
    E --> F["Caso extremo:<br/>BIENES PÚBLICOS"]
    style A fill:#7C5CFF,color:#fff
    style B fill:#FFA726,color:#fff
    style C fill:#4DB6AC,color:#fff
    style D fill:#7C5CFF,color:#fff
    style E fill:#7C5CFF,color:#fff
```

## El caso extremo: los bienes públicos

> "Los bienes públicos pueden considerarse un **caso extremo de externalidad positiva**, dado que benefician de una manera indivisible a toda una comunidad, independientemente de que los individuos deseen o no comprarlos."

Es la razón por la que el mercado no los provee y la provisión queda en manos del Estado — ver
[[Bienes Públicos]]. Llevá esa frase textual: conecta dos temas que suelen preguntarse por
separado.

## Dónde reaparecen en el programa

Las externalidades no se quedan en la teoría de las fallas: vuelven en dos lugares concretos del
material.

- **Recursos naturales:** el ingreso que genera un recurso natural puede variar por "externalidades positivas o negativas", junto con las variaciones de la demanda, el cambio en el uso del suelo y la durabilidad.
- **Economía ambiental:** es, literalmente, "la rama de la economía que analiza las externalidades negativas y positivas relacionadas con la optimización en la explotación de los recursos naturales". El tema ambiental de la unidad **es** un tema de externalidades.

## Conexiones

- [[Fallas del Mercado]] — es una de las tres fallas de la tipología, y la nota madre del tema
- [[Bienes Públicos]] — el material los define como caso extremo de externalidad positiva
- [[Rol del Estado y Desarrollo Sustentable]] — la economía ambiental estudia externalidades, y los instrumentos del Estado son la respuesta
- [[Equilibrio de Mercado]] — la cantidad de equilibrio deja de ser la socialmente deseable justamente cuando hay externalidades
- [[Evaluación Privada y Evaluación Social]] — es la razón de fondo de que un proyecto rinda distinto para el privado que para la sociedad
- [[Precios Privados y Precios Sociales]] — los precios sociales existen para incorporar lo que el precio de mercado deja afuera

## En el parcial

**Definir externalidad y decir, para cada signo, en qué dirección se equivoca el mercado:**
negativa → se produce **más** de lo socialmente deseable; positiva → se produce **menos**. Es una
pregunta de dos renglones que se pierde por invertir el par. Truco para no equivocarse: pensá en
quién paga y quién cobra — si el costo lo paga un tercero, para el que decide es barato y hace de
más. Tené listo también el enganche con los bienes públicos como **caso extremo de externalidad
positiva**.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `Resumen temas coloquio` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

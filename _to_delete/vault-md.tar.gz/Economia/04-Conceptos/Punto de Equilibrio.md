---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, indicadores]
---

# Punto de Equilibrio

> La cantidad que hay que vender para que los ingresos igualen a los costos totales. **No mide
> rentabilidad: mide riesgo** — cuanto más alto el punto de equilibrio, más tenés que vender
> para no perder.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Qué es

> "determina la cantidad de ventas que deben realizarse para que los ingresos netos sean iguales a los costos totales **en el corto plazo**. A mayor PE, mayor riesgo."

Dos cosas de esa frase que se pasan por alto: es un indicador de **corto plazo** (ver
[[Corto Plazo y Largo Plazo]]) y su lectura no es "cuánto gano" sino **"cuánto riesgo corro"**.

## La condición

$$P \times Q = CF + CVu \times Q$$

- **P** — precio de venta unitario, en **pesos por unidad**
- **Q** — cantidad vendida, en **unidades físicas** — es la incógnita
- **CF** — [[Costos Fijos Variables y Totales|costos fijos]] del período, en **pesos**
- **CVu** — costo variable unitario, en **pesos por unidad**

A la izquierda está el ingreso total; a la derecha, el costo total. El punto de equilibrio es
el $Q$ que los iguala. Despejando:

$$Q_{PE} = \frac{CF}{P - CVu}$$

El denominador $P - CVu$ es lo que cada unidad deja para cubrir los costos fijos. De ahí sale
la lectura del riesgo: **si los costos fijos son altos o el margen por unidad es chico, el
punto de equilibrio se va para arriba** y necesitás vender mucho antes de empezar a ganar.

## Dónde entra en la unidad

| | |
|---|---|
| **Grupo de métodos** | Los que **no** tienen en cuenta el valor del dinero en el tiempo, junto con RBC, BPA y PRC |
| **Qué unidad tiene el resultado** | Cantidad física $Q$, no pesos |
| **Qué lee** | Riesgo operativo, no rentabilidad |

Por eso nunca reemplaza al [[Valor Actual Neto]]: son preguntas distintas. El VAN te dice si el
proyecto agrega valor; el PE te dice qué tan al filo estás de la pérdida.

## Faltante

El apunte da la condición y la lectura de riesgo, pero **no desarrolla el punto de equilibrio
en pesos** (el monto de ventas, en vez de la cantidad), **no da ejemplos numéricos**, no
grafica las rectas de ingreso y costo total, y no trata el punto de equilibrio con mezcla de
productos.

## Conexiones

- [[Costos Fijos Variables y Totales]] — la fórmula es literalmente esa clasificación despejada
- [[Costeo Variable]] — el margen $P - CVu$ es la contribución marginal del costeo variable
- [[Comparación de Alternativas]] — el PE es uno de los métodos que no consideran el valor tiempo
- [[Valor Actual Neto]] — responden preguntas distintas: valor agregado contra riesgo operativo
- [[Maximización de Beneficios]] — el PE es donde el beneficio es cero, no donde es máximo
- [[Corto Plazo y Largo Plazo]] — el apunte lo define explícitamente como indicador de corto plazo

## En el parcial

**Plantear $P \times Q = CF + CVu \times Q$, despejar $Q$ y decir qué significa el resultado:
la cantidad a vender para no ganar ni perder, y que a mayor punto de equilibrio mayor riesgo.**
Es una cuenta de dos líneas, así que lo que se evalúa es la interpretación.

Dos errores: confundir el **costo variable unitario** con el costo variable total (si el
enunciado te da el total, dividilo por la cantidad antes), y decir que en el punto de
equilibrio "la empresa maximiza beneficios" — en el punto de equilibrio el beneficio es
**cero**.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

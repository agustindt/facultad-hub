---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, contabilidad-nacional]
---

# Matriz Insumo-Producto

> El programa la pide junto con los coeficientes técnicos, pero **los apuntes de 2025 no la
> tratan**. Lo único que hay es el terreno donde se apoya: el método del valor agregado por
> sectores.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Lo único que el material sí trae

El punto de contacto es el tercer método de [[Métodos de Cálculo del PBI]], que es sectorial:

$$PBI_{pm} = \sum_i (VBP_i - Compras\ de\ insumos_i)$$

donde $VBP_i$ es el valor bruto de la producción del sector $i$ y lo que se le resta son las
compras de insumos de ese mismo sector. Esa resta —producción bruta menos insumos comprados a
otros sectores— es la operación que una matriz insumo-producto ordena en forma de tabla de doble
entrada. Y el material sí define los sectores sobre los que se arma esa apertura:

| Sector | Qué comprende | Ejemplos del material |
|---|---|---|
| Primario | Extracción directa y sin transformaciones de bienes de la naturaleza | Agricultura, ganadería, minería |
| Secundario | Actividades artesanales e industriales manufactureras, que transforman lo que viene del primario | Industria extractiva y de equipos, bienes de uso y de consumo |
| Terciario | Servicios a la sociedad, a las personas y a las empresas | Bancos, telefonía, transporte |

También está la definición de valor agregado que la matriz usa como fila de cierre: "la diferencia
entre el precio de venta de un bien (sin tener en cuenta los impuestos indirectos) y el costo de
los bienes intermedios adquiridos para producirlo".

## Faltante

Esto es un hueco declarado, no un resumen. El material **no contiene**:

- qué es una matriz insumo-producto ni cómo se lee (qué representan las filas, qué las columnas,
  qué es la demanda final y qué el consumo intermedio);
- la definición de **coeficiente técnico** ni su fórmula;
- el modelo de Leontief, la matriz de requerimientos totales o cualquier inversión de matriz;
- ejercicios resueltos, ejemplos numéricos o una matriz de muestra;
- para qué se usa en la práctica (simulación de impactos sectoriales).

**No completes este hueco de memoria en el parcial.** Hasta que salga el teórico 2026 hay que
buscarlo en la bibliografía de la cátedra; en el vault esta nota queda como marcador.

## Conexiones

- [[Métodos de Cálculo del PBI]] — el método del valor agregado es el que se apoya en esta herramienta
- [[Producto Bruto Interno]] — el total que la matriz descompone por sector
- [[Objeto de la Macroeconomía]] — la matriz es un instrumento de la contabilidad nacional, que es la base de todo lo macro
- [[Flujo Circular del Ingreso]] — la otra forma, ésta sí cubierta, de representar los flujos entre agentes

## En el parcial

Con este apunte **no se puede responder una consigna de matriz insumo-producto**. Lo que sí se
puede: calcular el PBI por valor agregado a partir de una tabla de sectores (valor bruto de
producción menos compras de insumos, sector por sector, y recién después la suma) y clasificar
actividades en primario, secundario y terciario. Antes del parcial, conseguir el desarrollo de
coeficientes técnicos por fuera de estos apuntes: es el único tema del programa que quedó sin
cubrir por completo.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025` (única de las tres fuentes que roza el tema, vía el método del valor agregado) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

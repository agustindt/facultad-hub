---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos, transversal]
---

# Costo de Oportunidad

> Aquello a lo que se debe **renunciar** para obtener algo. En bienes: la cantidad de otros
> bienes o servicios a la que hay que renunciar para conseguirlo.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

Las dos definiciones que da la cátedra, textuales:

> "El Costo de Oportunidad de una **decisión** es aquello a lo que se debe renunciar para obtener algo."
>
> "El Costo de Oportunidad de un **bien o servicio** es la cantidad de otros bienes o servicios a la que se debe renunciar para conseguirlo."

La primera es general; la segunda es la que se usa para calcular sobre la
[[Frontera de Posibilidades de Producción]].

## El punto que cambia todo: no es lo que pagás

El costo de oportunidad **no es el precio**. Es el valor de la **mejor alternativa
sacrificada**. Por eso una decisión puede tener costo contable cero y costo de oportunidad
altísimo: usar un galpón propio para almacenar no cuesta un peso de alquiler, pero cuesta el
alquiler que se dejó de cobrar.

Esta distinción reaparece formalizada en la U2 como [[Costo Económico]] frente al costo
contable, y es la base de toda la evaluación de proyectos de la U6/U7.

## Cómo se calcula sobre la FPP

Es el único cálculo de la U1. Con la tabla del teórico:

| Opción | Bienes de consumo | Bienes de capital | Costo de oportunidad |
|---|---|---|---|
| A | 0 | 18 | — |
| B | 1 | 17 | **1** |
| C | 2 | 14 | **3** |
| D | 3 | 9 | **5** |
| E | 4 | 0 | **9** |

El costo de oportunidad de cada unidad adicional de consumo es **cuántos bienes de capital se
resignan** al pasar de una opción a la siguiente:

$$CO = \frac{\Delta \text{Bien sacrificado}}{\Delta \text{Bien obtenido}}$$

De A a B se resigna 1 (18 → 17). De B a C, 3 (17 → 14). De C a D, 5. De D a E, 9.

**Y ahí está lo importante: el costo de oportunidad crece.** 1, 3, 5, 9. No es constante.

## Por qué crece (la pregunta de desarrollo)

Porque los recursos **no son igualmente aptos** para todos los usos. Al principio se pasan a
producir consumo los recursos que peor rendían en capital — se pierde poco. A medida que se
insiste, hay que mover recursos cada vez más especializados en capital, y cada unidad adicional
de consumo cuesta más. Eso es exactamente lo que hace que la FPP sea **cóncava** y no una
recta.

Si el costo de oportunidad fuera constante, la FPP sería una línea recta — y eso implicaría que
todos los recursos son perfectamente sustituibles entre usos, que no es el caso real.

<svg viewBox="0 0 440 175" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="149" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="152" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="104" y2="104" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="107" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">7</text><line x1="34" x2="382" y1="59" y2="59" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="62" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">13</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="34" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)"/><line x1="113.1" x2="113.1" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="113.1" cy="35.1" r="3.4" fill="var(--background-modifier-border,#8886)"/><text x="113.1" y="160" text-anchor="middle" font-size="8" fill="var(--background-modifier-border,#8886)" font-weight="600">B</text><line x1="192.2" x2="192.2" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="192.2" cy="57.9" r="3.4" fill="var(--background-modifier-border,#8886)"/><text x="192.2" y="160" text-anchor="middle" font-size="8" fill="var(--background-modifier-border,#8886)" font-weight="600">C</text><line x1="271.3" x2="271.3" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="271.3" cy="95.8" r="3.4" fill="var(--background-modifier-border,#8886)"/><text x="271.3" y="160" text-anchor="middle" font-size="8" fill="var(--background-modifier-border,#8886)" font-weight="600">D</text><path d="M34 27.5 L39 27.5 L43.9 27.6 L48.9 27.8 L53.9 28 L58.9 28.3 L63.8 28.6 L68.8 29 L73.8 29.4 L78.7 29.9 L83.7 30.5 L88.7 31.1 L93.7 31.8 L98.6 32.6 L103.6 33.4 L108.6 34.3 L113.5 35.2 L118.5 36.2 L123.5 37.2 L128.5 38.3 L133.4 39.5 L138.4 40.7 L143.4 42 L148.3 43.4 L153.3 44.8 L158.3 46.3 L163.3 47.8 L168.2 49.4 L173.2 51 L178.2 52.7 L183.1 54.5 L188.1 56.3 L193.1 58.2 L198.1 60.2 L203 62.2 L208 64.3 L213 66.4 L217.9 68.6 L222.9 70.8 L227.9 73.1 L232.9 75.5 L237.8 77.9 L242.8 80.4 L247.8 83 L252.7 85.6 L257.7 88.3 L262.7 91 L267.7 93.8 L272.6 96.6 L277.6 99.5 L282.6 102.5 L287.5 105.5 L292.5 108.6 L297.5 111.8 L302.5 115 L307.4 118.3 L312.4 121.6 L317.4 125 L322.3 128.4 L327.3 131.9 L332.3 135.5 L337.3 139.1 L342.2 142.8 L347.2 146.6" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="351.2" y="149.6" font-size="9" fill="#7C5CFF" font-weight="600">FPP</text><text x="208.0" y="172" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Bienes de consumo — eje vertical: bienes de capital</text></svg>

*Si el costo de oportunidad fuera constante, la FPP sería una recta.*


## Conexiones

- [[Escasez]] — el costo de oportunidad es la medida concreta de la escasez: sin escasez, sería cero
- [[Frontera de Posibilidades de Producción]] — la pendiente de la FPP en cada punto **es** el costo de oportunidad
- [[Costo Económico]] — la versión formal del mismo concepto aplicada a la empresa, en la U2
- [[Problema Económico de Toda Sociedad]] — cada una de las tres preguntas implica renunciar a alguna alternativa
- [[Tasa Marginal de Sustitución Técnica]] — es el mismo razonamiento de "a cuánto de A renuncio por una unidad de B", pero entre factores

## En el parcial

Definición + cálculo sobre una tabla de FPP + **explicar por qué es creciente**. Esa última
parte es la que separa el 6 del 9: casi todos calculan bien y casi nadie justifica la
concavidad.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

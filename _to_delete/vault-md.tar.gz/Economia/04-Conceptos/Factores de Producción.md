---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, U2, produccion]
---

# Factores de Producción

> Los recursos con los que se produce: **capital (K)**, **trabajo (L)** y **recursos naturales
> (RN)**. Son los insumos que la producción transforma en bienes y servicios.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

| Factor | Símbolo | Qué es | Su retribución |
|---|---|---|---|
| **Capital** | $K$ | Bienes producidos que sirven para producir otros: máquinas, plantas, equipos | Interés / beneficio |
| **Trabajo** | $L$ | El aporte humano, físico e intelectual | Salario |
| **Recursos naturales** | $RN$ | Tierra, minerales, agua, energía | Renta |

La notación $K$ y $L$ (del inglés *capital* y *labour*) es la que se usa en toda la materia y
en toda la bibliografía: aparece en la [[Función de Producción]] $q = F(L, K)$, en las
[[Isocuanta|isocuantas]] y en el [[Isocosto]].

## El detalle que importa

**Capital, en economía, no es dinero.** Es el conjunto de bienes durables que se usan para
producir. El dinero para comprar una máquina es un medio de financiamiento; la máquina es el
capital. Confundirlos es el error más común de la unidad.

## Dónde reaparecen

En la U1 son "los recursos limitados" que fijan la posición de la
[[Frontera de Posibilidades de Producción]]. En la U2 se vuelven las variables de la
[[Función de Producción]], y la distinción entre los que se pueden mover y los que no es
exactamente lo que define el [[Corto Plazo y Largo Plazo]].

## Conexiones

- [[Escasez]] — son los recursos limitados de los que habla el principio de escasez
- [[Frontera de Posibilidades de Producción]] — la cantidad disponible de K, L y RN determina dónde está la curva
- [[Función de Producción]] — la función se escribe justamente en términos de estos factores
- [[Corto Plazo y Largo Plazo]] — la distinción es si estos factores pueden variar o no
- [[Actividad Económica]] — entran como insumos en el circuito productivo

## En el parcial

Nombrarlos con su símbolo. Y no confundir capital con dinero.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

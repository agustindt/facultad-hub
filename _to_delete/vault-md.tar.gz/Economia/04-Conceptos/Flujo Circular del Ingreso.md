---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, equilibrio-macro]
---

# Flujo Circular del Ingreso

> La economía como un **circuito cerrado** de bienes y pagos entre cuatro agentes. Todo lo que
> sale del circuito (ahorro, impuestos, importaciones) tiene que volver a entrar (inversión, gasto
> público, exportaciones).

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## La definición

> "Es la corriente de bienes y servicios y de pagos entre las empresas, las economías domésticas, el sector público y el resto del mundo."

Los cuatro agentes están nombrados ahí: **empresas, familias, sector público y resto del mundo**.
Sobre ese circuito se enchufan dos tipos de movimiento.

## Entradas y salidas: la tabla que hay que saber de memoria

> "**Entrada** es una adición al ingreso de las empresas que no proviene del gasto de los consumidores."
>
> "**Salida** [es] todo ingreso que no se reintegra al flujo circular."

| Entrada (agranda el flujo) | Salida (achica el flujo) |
|---|---|
| Inversión de las empresas ($I$) | Ahorro ($S$) |
| Gastos del sector público ($G$) | Impuestos ($T$) |
| Demanda de exportaciones de otros países ($X$) | Importaciones de bienes y servicios ($M$) |

Fijate el patrón: **cada agente aporta un par**. Por eso las tres filas se corresponden una a una
con los tres pares de términos de $PBI = C + I + G + (X - M)$ que están fuera del consumo.

```mermaid
flowchart LR
    F["<b>FAMILIAS</b><br/>economías domésticas"] -->|"gasto de consumo"| E["<b>EMPRESAS</b>"]
    E -->|"sueldos, alquileres,<br/>intereses, beneficios"| F
    F -->|"SALIDA"| S["ahorro"]
    I["inversión de<br/>las empresas"] -->|"ENTRADA"| E
    F -->|"SALIDA: impuestos"| SP["<b>SECTOR PÚBLICO</b>"]
    SP -->|"ENTRADA: gasto público"| E
    F -->|"SALIDA: importaciones"| RM["<b>RESTO DEL MUNDO</b>"]
    RM -->|"ENTRADA: exportaciones"| E
    style E fill:#7C5CFF,color:#fff
    style F fill:#7C5CFF,color:#fff
    style SP fill:#FFA726,color:#fff
    style RM fill:#4DB6AC,color:#fff
    style S fill:#FFA726,color:#fff
    style I fill:#4DB6AC,color:#fff
```

## Contablemente iguales, económicamente no

Ésta es la distinción fina de la nota, y es la que se pregunta:

> "Desde un punto de vista contable, las entradas son iguales a las salidas y, lo detraído del flujo del ingreso debe ser, por definición, igual a lo que se ha incorporado. Sin embargo, desde un punto de vista económico, pueden originarse alteraciones en el flujo circular debido a cambios en las entradas y en las salidas. Las salidas tienden a reducir el flujo circular y las entradas a aumentarlo."

O sea: la igualdad se cumple **ex post**, por definición contable. Pero las decisiones que generan
entradas y las que generan salidas las toman agentes distintos y por motivos distintos, y ese
desajuste es lo que hace que el flujo se expanda o se contraiga. Esa es la puerta de entrada al
multiplicador de [[Consumo Ahorro e Inversión]].

## Conexiones

- [[Métodos de Cálculo del PBI]] — el circuito es la razón visual de por qué producción, gasto e ingreso coinciden
- [[Consumo Ahorro e Inversión]] — el ahorro sale del circuito y la inversión lo reinyecta
- [[Política Fiscal]] — impuestos y gasto público son el par salida/entrada del Estado
- [[Balanza de Pagos y Mercado de Divisas]] — importaciones y exportaciones son el par del resto del mundo
- [[Ingreso Nacional e Ingreso Disponible]] — el tramo empresas→familias del circuito es la retribución a los factores
- [[El Dinero y los Intermediarios Financieros]] — quienes conectan el ahorro que sale con la inversión que entra

## En el parcial

**Dibujar el circuito con los cuatro agentes y rotular las tres entradas y las tres salidas
apareadas.** Después, la pregunta conceptual: por qué entradas y salidas son iguales desde el punto
de vista contable pero pueden alterar el flujo desde el punto de vista económico. El error clásico
es poner el ahorro como entrada (no lo es: es dinero que **se retira** del circuito) o dejar afuera
al resto del mundo, que en la versión completa siempre está.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

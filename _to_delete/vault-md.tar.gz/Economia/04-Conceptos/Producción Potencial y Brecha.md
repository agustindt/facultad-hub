---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, contabilidad-nacional]
---

# Producción Potencial y Brecha

> El PBI potencial es el **máximo que la economía puede producir sin que se disparen los precios**,
> con los factores a pleno empleo. El PBI efectivo puede quedar arriba o abajo de ese techo según
> la etapa del ciclo.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## La definición

> "El PIB potencial es el máximo nivel de producción que puede alcanzar la economía manteniendo estables los precios. PBI alcanzado con factores de producción a pleno empleo."

Y la versión de la otra fuente agrega la condición explícita:

> "El PIB potencial o natural es el máximo nivel de producción que puede alcanzar una economía utilizando plenamente sus recursos, sin generar presiones inflacionarias. El PIB efectivo puede estar por encima o por debajo de este nivel, dependiendo de la etapa del ciclo económico."

Fijate qué tipo de máximo es: **no** es un tope físico, es el tope compatible con precios
estables. Producir por encima del potencial es posible, pero se paga con inflación — que es
exactamente el mecanismo que describe la [[Desempleo y Curva de Phillips]].

| | Producción potencial | Producción efectiva |
|---|---|---|
| Qué es | El máximo con precios estables y factores a pleno empleo | Lo que la economía efectivamente produjo |
| Cómo se mueve | Crece cuando crece la capacidad productiva del país | Fluctúa con el ciclo económico |
| Rol en la unidad | Es una de las variables listadas entre los instrumentos de política | Es lo que mide el PBI real |

## Crecer es correr el techo, no llenarlo

Acá está la idea que unifica esta nota con U1:

> "El crecimiento económico supone la expansión del PIB potencial de un país, lo que en términos de la frontera de posibilidades de producción equivale a un desplazamiento hacia fuera."

Las **fuentes del crecimiento** son "los factores que explican el crecimiento de la producción de
un país":

| Fuente | En qué consiste |
|---|---|
| Trabajo | Aumento de la disponibilidad y de la calidad del trabajo |
| Capital físico | Aumento de la dotación |
| Tecnología | Mejora tecnológica: cambios en los procesos de producción o nuevos productos y servicios |

Y desarrollo no es lo mismo que crecimiento: desarrollo y subdesarrollo "hacen alusión a la brecha
real que separa los niveles de vida que se alcanzan en unos y otros países, y a los procesos que
llevan a elevar el nivel de vida". Se mide con un conjunto amplio de indicadores: ingreso por
habitante, analfabetismo, estructura sanitaria, estructura productiva y tecnológica, desempleo,
distribución interna del ingreso.

## Faltante

El material **no usa la expresión "brecha del producto" ni la define como variable**: sólo dice que
el PBI efectivo puede estar por encima o por debajo del potencial. Por lo tanto acá no hay:

- fórmula de la brecha (ni en niveles ni como porcentaje del potencial),
- nombres para los dos signos (brecha recesiva / inflacionaria),
- método de estimación del producto potencial,
- ningún dato ni serie de la economía argentina.

Si el teórico 2026 pide calcular una brecha, este apunte no alcanza.

## Conexiones

- [[Frontera de Posibilidades de Producción]] — el crecimiento es, textualmente, su desplazamiento hacia afuera
- [[PBI Nominal y PBI Real]] — el crecimiento se define sobre el producto real, nunca sobre el nominal
- [[Inflación]] — el potencial es el nivel a partir del cual producir más presiona los precios
- [[Desempleo y Curva de Phillips]] — "pleno empleo de los factores" es la otra cara del producto potencial
- [[Demanda y Oferta Agregada]] — a largo plazo la oferta agregada se representa vertical, en la capacidad productiva del país
- [[Rol del Estado y Desarrollo Sustentable]] — desarrollo es elevar el nivel de vida, no sólo mover el PBI

## En el parcial

**Definir producto potencial con las dos condiciones (pleno empleo de los factores y precios
estables) y explicar qué significa que el efectivo esté por encima.** La otra consigna probable es
la de crecimiento: enumerar las tres fuentes —trabajo, capital, tecnología— y traducirlas al
desplazamiento de la frontera de posibilidades de producción. El error clásico es confundir
*crecer* (correr el techo) con *recuperarse* (volver al techo), y usar crecimiento y desarrollo
como sinónimos.

---
Fuente: `SEGUNDO PARCIAL — sección Macroeconomía`, con aportes de `UNIDAD 4 — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, empleo]
---

# Desempleo y Curva de Phillips

> El desempleo se mide **sobre la población activa, no sobre la población total**. Y la curva de
> Phillips dice que bajarlo tiene un precio: más inflación.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Las categorías de población

La clasificación completa, que es lo primero que hay que tener ordenado porque todas las tasas
salen de acá:

| Categoría | Definición del material |
|---|---|
| **Ocupada** | Tiene por lo menos una ocupación: trabajó como mínimo una hora en la semana de referencia, en una actividad económica |
| **Desocupada** | No tiene ocupación pero busca activamente trabajo (desocupación abierta) y está disponible para trabajar |
| **Subocupada** | Ocupados que trabajan **menos de 35 horas** semanales por causas involuntarias y están dispuestos a trabajar más |
| **Sobreocupada** | Ocupados que trabajan **más de 45 horas** semanales |
| **PEA** (económicamente activa) | Personas que tienen una ocupación o que, sin tenerla, la buscan activamente |
| **Inactivos** | No tienen trabajo ni lo buscan activamente; quedan fuera de la PEA |

```mermaid
flowchart TD
    P["<b>POBLACIÓN TOTAL</b><br/>de referencia: 14 años y más"] --> PEA["<b>PEA</b><br/>población económicamente activa"]
    P --> IN["<b>INACTIVOS</b><br/>no trabajan ni buscan"]
    PEA --> OC["<b>OCUPADOS</b><br/>al menos 1 hora<br/>en la semana"]
    PEA --> DES["<b>DESOCUPADOS</b><br/>buscan activamente"]
    OC --> SUB["Subocupados<br/>&lt; 35 hs involuntarias"]
    OC --> SOB["Sobreocupados<br/>&gt; 45 hs"]
    style P fill:#4DB6AC,color:#fff
    style PEA fill:#7C5CFF,color:#fff
    style DES fill:#FFA726,color:#fff
```

**Ojo con una inconsistencia del apunte:** en un lugar define la PEA como "población ocupada más
población desocupada" y unas líneas después escribe
"PEA = ocupados + subocupados + desocupados". Las dos no pueden ser ciertas a la vez, porque los
subocupados **son** ocupados y estarían contados dos veces. Quedate con la primera, que es la que
repiten las tres fuentes; y si en el parcial piden la fórmula, escribí
$PEA = Ocupados + Desocupados$.

## Las tres tasas

Lo único que cambia entre ellas es el **denominador**, y ahí está el 90 % de los errores.

$$Tasa\ de\ actividad = \frac{PEA}{Población\ total\ de\ referencia}$$

$$Tasa\ de\ empleo = \frac{Población\ ocupada}{Población\ total\ de\ referencia}$$

$$Tasa\ de\ desocupación = \frac{Población\ desocupada}{PEA}$$

La población total de referencia es la de **14 años y más**. La tasa de desocupación es la única
que va sobre la PEA: mide el porcentaje de la población activa que no está empleada y busca
ocupación. Por eso una persona que deja de buscar trabajo **baja** la tasa de desempleo sin que
nadie haya conseguido empleo: sale de la PEA y desaparece del numerador y del denominador.

## La curva de Phillips

Versión original:

> "Muestra la existencia de una relación inversa entre la tasa de crecimiento de los salarios nominales y la tasa de desempleo, en el sentido de que cuanto mayor es una, menor es la otra."

Versión redefinida, que es la que se usa:

> "La versión convencional de la curva de Phillips muestra la relación existente entre la tasa de inflación y la tasa de desempleo, dada la estrecha relación existente entre el crecimiento de los salarios nominales y de los precios."

| | Curva de Phillips original | Curva de Phillips redefinida |
|---|---|---|
| Eje vertical | Tasa de crecimiento de los salarios nominales | Tasa de inflación |
| Eje horizontal | Tasa de desempleo | Tasa de desempleo |
| Pendiente | Negativa | Negativa |

Y el mecanismo económico detrás, que es lo que hay que saber explicar:

> "A corto plazo la sociedad enfrenta una disyuntiva entre inflación y desempleo. Un nivel bajo de desempleo se asocia con una demanda agregada alta, que a su vez ejerce presión al alza en los salarios y los precios de toda la economía."

Es decir: reducir el desempleo se logra a costa de aumentos en la tasa de inflación, y bajar las
tensiones de precios implica un agravamiento del desempleo. **La disyuntiva es de corto plazo** —el
material lo dice explícitamente— y es la que explica por qué ninguna política de demanda es gratis.

## Conexiones

- [[Inflación]] — el otro extremo de la disyuntiva; las dos notas se estudian juntas
- [[Política Fiscal]] — la restrictiva baja precios pagando con desempleo, exactamente lo que predice la curva
- [[Política Monetaria]] — misma disyuntiva, del lado de la tasa de interés y la cantidad de dinero
- [[Demanda y Oferta Agregada]] — la demanda agregada alta es el nexo causal entre bajo desempleo y suba de precios
- [[Producción Potencial y Brecha]] — el pleno empleo de los factores define el producto potencial
- [[Mercado de Trabajo]] — el mismo mercado, visto en U3 desde la oferta y la demanda de trabajo

## En el parcial

**Te dan una tabla de población (total, ocupados, desocupados, inactivos) y hay que calcular las
tres tasas.** Escribí el denominador antes que el numerador: actividad y empleo van sobre la
población total de referencia, desocupación va **sobre la PEA**. Ese es el error clásico y es el
más caro, porque una tasa de desempleo calculada sobre la población total da un número mucho más
chico y "creíble". La parte teórica: enunciar la curva de Phillips en su versión redefinida y
explicar por qué bajar el desempleo presiona los precios.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` y del `MACROECONOMIA — manuscrito iPad, nov 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

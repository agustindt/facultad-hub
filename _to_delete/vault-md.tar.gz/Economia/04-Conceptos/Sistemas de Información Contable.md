---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
autor: Carlos Slosse
estado: pendiente
tags: [Economia, U5, contabilidad]
---

# Sistemas de Información Contable

> **Contabilidad = identificar, medir, registrar y comunicar los eventos económicos de una
> organización.** De ahí salen dos sistemas paralelos: la contabilidad general, obligatoria y
> mirando hacia afuera, y la de costos, opcional y mirando hacia adentro.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Las dos ramas, y para quién trabaja cada una

| | **General / financiera** | **Administrativa / de costos** |
|---|---|---|
| ¿Obligatoria? | **Sí** | **No**, es opcional |
| Qué mide | Δ patrimonial y los costos y gastos totales, para determinar la utilidad o pérdida sobre las ventas | Valuación por productos; información financiera **y no financiera** sobre costos de adquisición o uso de recursos |
| Para quién | Accionistas (protección) y Gobierno (base tributaria); inversionistas, bancos, proveedores | Gerencia y personal interno, para la toma de decisiones |
| Orientación | Al **pasado** | Al **futuro** |
| Normas | Principios de contabilidad y normas de información financiera (NIF) | No sigue normas estrictas; análisis costo-beneficio |
| Frecuencia | Anual o trimestral | Frecuente y detallada |
| Rasgo propio | Influye vía remuneración por resultados | Diseñada para **influir en el comportamiento** de empleados y gerentes |

La [[Contabilidad de Costos]] no es una tercera cosa aparte: "proporciona información para la
contabilidad administrativa **y** para la financiera". Es el motor que alimenta a las dos.

```mermaid
flowchart TD
    C["<b>CONTABILIDAD</b><br/>identificar · medir<br/>registrar · comunicar"] --> F["<b>Financiera / General</b><br/>OBLIGATORIA<br/>usuarios externos"]
    C --> A["<b>Administrativa</b><br/>usuarios internos<br/>decisiones"]
    CC["<b>Contabilidad de costos</b><br/>costos de adquirir<br/>o usar recursos"] --> F
    CC --> A
    style C fill:#7C5CFF,color:#fff
    style F fill:#4DB6AC,color:#fff
    style A fill:#FFA726,color:#fff
```

La Ley de Sociedades Comerciales incorporó prescripciones sobre documentación y contabilidad,
**generales** para todas las sociedades comerciales y **particulares** para ciertos tipos (S.R.L.,
S.A.), que complementan el régimen del Código de Comercio.

## Procedimientos: partida doble y criterio de realización

> "No hay acreedor sin deudor, ni deudor sin acreedor. La suma de las partidas asentadas en el DEBE tiene que ser igual a la suma de las partidas asentadas en el HABER."

| | **Devengado** | **Percibido** |
|---|---|---|
| Cuándo se registra | Cuando se produce el hecho contable: la operación queda perfeccionada con la transacción | Cuando se paga o se cobra |
| Qué se genera | El **derecho** y la **obligación** | La **concreción** de ese derecho y esa obligación |
| Ejemplo | Asiento con la **venta** | Asiento con el **cobro** |
| Sirve para | Ver las transacciones en el momento en que se llevan a cabo | Ver ingresos y pagos en efectivo del período |

> **Los estados contables utilizan el método de lo devengado y no el de lo percibido.**

De ahí una consecuencia grande: el devengado exige capitalizar los activos de larga vida y
depreciarlos, y "esta idea de depreciación **no existe si se usa el método de lo percibido**". Es
decir, [[Depreciación]] **existe porque existe el devengado**.

## Auditorías

> "Verificación de cumplimiento de procedimientos y criterios contables establecidos por la Federación de Consejos de Ciencias Económicas de Argentina (FCCEA)."

Tres tipos: **interna** (de la empresa), **externa solicitada por la empresa** (auditoría
independiente de los estados patrimoniales) y **externa del gobierno** (inspección de sociedades
comerciales, AFIP, etc.).

Sobre el fraude, según **Carlos Slosse** (*Auditoría, un nuevo enfoque empresarial*): son
"revelaciones incorrectas e **intencionales**" en la preparación de información financiera —
manipulación de documentos, apropiación indebida de activos, omisión de transacciones, registro de
transacciones inexistentes, inadecuada aplicación de políticas contables.

**El reparto de responsabilidades es lo evaluable:** prevenir y detectar fraudes es responsabilidad
**de la gerencia**, mediante sistemas de control. El auditor sólo debe asegurarse de que un fraude o
error significativo no ocurrió o que, si ocurrió, está reflejado en los estados.

## Conexiones

- [[Estados Contables Básicos]] — son el producto final de la contabilidad general
- [[Contabilidad de Costos]] — el otro sistema, opcional, que alimenta a las dos ramas
- [[Depreciación]] — sólo tiene sentido bajo el criterio de lo devengado
- [[Valuación de Activos]] — PEPS, UEPS y PPP son políticas contables que la auditoría verifica
- [[La Empresa y sus Actividades]] — las cuatro actividades son los eventos que este sistema registra

## En el parcial

**Distinguir devengado de percibido con un caso concreto** (te venden en marzo y cobran en mayo:
¿en qué mes va el asiento con cada criterio?) **y decir cuál usan los estados contables — el
devengado.** El error clásico es contestar "percibido" porque suena a "lo real". Además: la tabla
financiera vs. administrativa por tres filas (usuarios, orientación, normas), los tres tipos de
auditoría y que **prevenir el fraude es responsabilidad de la gerencia, no del auditor**.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados]
---

# Equilibrio de Mercado

> **El precio de equilibrio es aquel para el cual la cantidad demandada es igual a la ofrecida.**
> En ese punto no hay ni escasez ni excedente — y además la última unidad vale para el
> comprador exactamente lo que le cuesta producirla al vendedor.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Las dos condiciones del equilibrio

No es una sola: el material insiste en que en $Q_E$ se cumplen **dos** cosas a la vez.

$$Q_d = Q_o \qquad \text{y} \qquad UMg = CMg$$

- **Del lado del comprador:** compra todas las unidades cuyo valor marginal ($UMg$) sea mayor o igual al precio que paga.
- **Del lado de la empresa:** produce hasta que su costo marginal ($CMg$) iguala el precio de venta.
- Por eso, en $Q_E$, el $CMg$ de la última unidad producida es igual al $UMg$ que esa misma unidad tiene para los consumidores.

La frase para acordarse: **todas las unidades entre 0 y $Q_E$ "valen más de lo que cuestan";
todas las mayores que $Q_E$ "cuestan más de lo que valen".** Producir menos deja valor sobre la
mesa; producir más destruye valor.

## Cómo se ajusta solo

El sistema de precios es un mecanismo **autorregulador**: no hace falta que nadie coordine.

| Situación | Qué pasa | Hacia dónde va el precio |
|---|---|---|
| $P > P_{eq}$ | $Q_d$ baja y $Q_o$ sube → **exceso de oferta** (excedente) | Tiende a **bajar** |
| $P < P_{eq}$ | $Q_d$ sube y $Q_o$ baja → **exceso de demanda** (escasez) | Tiende a **subir** |

Cuando hay escasez suben los precios y se incentiva la producción; cuando hay excedente los
precios bajan y se reduce la oferta.

## Los cuatro desplazamientos — la tabla que hay que saber de memoria

Los cambios en el **precio** producen movimientos a lo largo de la curva; los cambios en otras
variables (ingresos, gustos, costos de insumos, tecnología) **desplazan** las curvas.

| Situación | Desplazamiento | Precio de equilibrio | Cantidad de equilibrio |
|---|---|---|---|
| Aumenta la demanda | Hacia la derecha | Sube | Sube |
| Cae la demanda | Hacia la izquierda | Baja | Baja |
| Aumenta la oferta | Hacia la derecha | **Baja** | Sube |
| Cae la oferta | Hacia la izquierda | **Sube** | Baja |

El patrón: la **demanda** mueve precio y cantidad en el **mismo** sentido; la **oferta**, en
sentidos **opuestos**. Ejemplos del material: si aumentan los ingresos, la demanda de bienes
normales crece y se desplaza a la derecha; si suben los costos de las materias primas, la oferta
cae y se desplaza a la izquierda.

## Cuando el Estado no deja que el precio se ajuste

El Gobierno intenta mantener los precios en niveles que no son los de equilibrio, y eso genera
excesos que **ya no son transitorios**.

| | **Precios máximos** (generan escasez) | **Precios mínimos** (generan excedente) |
|---|---|---|
| Efecto directo | Desabastecimiento al precio oficial | Excedente de producción |
| Consecuencia 1 | Mercado negro | El consumidor paga un precio superior al de equilibrio |
| Consecuencia 2 | Tendencia a la corrupción: comprar al oficial y vender al paralelo | Tendencia a la corrupción: pequeñas variaciones en el mínimo mueven grandes sumas |
| Consecuencia 3 | Tendencia a la disminución de la calidad del producto | — |
| Ejemplo | Precio máximo de alquileres, garrafas, alimentos | Fijación de salario mínimo |

*Nota de cotejo: en el apunte `ECONOMIA FINAL` esta tabla quedó con las dos columnas cruzadas.
Acá se usó la versión coincidente de las otras dos fuentes.*

```mermaid
flowchart TD
    P1["Precio POR ENCIMA<br/>del equilibrio"] --> E1["Exceso de OFERTA"]
    E1 --> B1["El precio baja"]
    P2["Precio POR DEBAJO<br/>del equilibrio"] --> E2["Exceso de DEMANDA<br/>(escasez)"]
    E2 --> B2["El precio sube"]
    B1 --> EQ["<b>EQUILIBRIO</b><br/>Qd = Qo y UMg = CMg"]
    B2 --> EQ
    EST["El Estado fija un precio<br/>máximo o mínimo"] --> PERM["<b>El exceso deja de ser transitorio</b><br/>y se vuelve permanente"]
    style P1 fill:#FFA726,color:#fff
    style P2 fill:#FFA726,color:#fff
    style EQ fill:#7C5CFF,color:#fff
    style EST fill:#4DB6AC,color:#fff
    style PERM fill:#7C5CFF,color:#fff
```

## Conexiones

- [[Curva de Demanda]] — una de las dos curvas que se cruzan, y la que se desplaza con ingreso, gustos y precios relacionados
- [[Maximización de Beneficios]] — la condición $P = CMg$ del lado de la empresa es la que sostiene la mitad del equilibrio
- [[Competencia Perfecta]] — este equilibrio es el del mercado competitivo; en monopolio la lógica cambia
- [[Excedente del Consumidor]] — de acá sale la frase "hasta $Q_E$ todo vale más de lo que cuesta"
- [[Rol del Estado y Desarrollo Sustentable]] — los precios máximos y mínimos son uno de los instrumentos de intervención
- [[Fallas del Mercado]] — el equilibrio competitivo es la referencia contra la que se mide toda falla

## En el parcial

**Dado un shock ("suben los costos de la materia prima", "aumenta el ingreso de los
consumidores"), decir qué curva se desplaza, hacia dónde, y qué pasa con el precio y la cantidad
de equilibrio.** Es un clásico de opción múltiple y de gráfico. Truco de control: si se movió la
demanda, precio y cantidad van para el mismo lado; si se movió la oferta, van para lados
opuestos. Segunda consigna probable: **enumerar las consecuencias de un precio máximo y de uno
mínimo con un ejemplo de cada uno** — el error clásico es asignarle el desabastecimiento al
precio mínimo.

---
Fuente: `SEGUNDO PARCIAL — Google Docs, sección Unidad 3`, cotejado con `ECONOMIA FINAL` y `Resumen temas coloquio` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

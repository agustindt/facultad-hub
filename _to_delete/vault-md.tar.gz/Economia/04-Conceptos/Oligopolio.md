---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados, competencia]
---

# Oligopolio

> **Pocas empresas que se llevan la mayor parte de las ventas, y cuyas decisiones están
> interconectadas.** Es la única estructura donde cada empresa tiene que pensar en cómo va a
> reaccionar la otra: por eso acá aparece la teoría de los juegos.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Definición

> "Aquel mercado en el cual la mayor parte de las ventas es realizada por unas pocas empresas, que ofrecen productos similares o idénticos, cada una de las cuales es capaz de influir en el precio de mercado con sus propias actividades."

La palabra clave es **estratégica**: las decisiones de una empresa afectan a las demás, así que
nadie decide en el vacío. Las barreras de entrada que sostienen la estructura pueden ser **de
capital** (petroquímica) o **comerciales** (medicamentos).

## Las dos variantes: colusorio y no colusorio

| | **Colusorio** | **No colusorio** |
|---|---|---|
| Información sobre los rivales | Los rivales establecen acuerdos, explícitos o tácitos, que les permiten conocer el comportamiento y la reacción de los demás | No disponen de información sobre cómo reaccionarán sus competidores |
| Objetivo | Limitar la acción de las fuerzas de la competencia, acordar un precio común, maximizar los beneficios en conjunto | Cada una decide sin saber qué harán las demás |
| Nombre del acuerdo | **Colusión**; al grupo de empresas que actúa al unísono se lo llama **cártel** | — |
| Herramienta de análisis | — | **Teoría de los juegos** |

## El resultado central del tema

> "Los oligopolios maximizan sus beneficios totales cuando forman un cártel y actúan como monopolios. A pesar de esto, **el interés propio lleva a la competencia**."

Y el corolario que ordena toda la unidad: **cuantas más empresas conformen el oligopolio, más se
acercan la cantidad y el precio a los niveles de la competencia perfecta.** El oligopolio es,
literalmente, el terreno entre el monopolio y la competencia.

## Teoría de los juegos, en tres definiciones

- **Qué analiza:** cómo se comportan los individuos en **situaciones estratégicas**, es decir, aquellas en las que cada uno toma sus decisiones considerando cómo responderán los demás.
- **Regla clave:** la elección de estrategia de un jugador debe basarse en el supuesto de que cada adversario actuará buscando lo que más le conviene.
- **Equilibrio de Nash:** los agentes económicos que interaccionan entre sí seleccionan su mejor estrategia, dadas las estrategias que seleccionaron todos los demás.

**Dilema del prisionero:** muestra que el interés propio impide que las personas cooperen incluso
cuando la cooperación tiene ventajas mutuas. Aplicado al oligopolio: *los oligopolios no pueden
mantener la cooperación, incluso cuando ésta los beneficia*. Ése es el motivo por el que los
cárteles se rompen solos.

```mermaid
flowchart TD
    A["<b>OLIGOPOLIO</b><br/>pocas empresas<br/>decisiones interconectadas"] --> B["COLUSORIO<br/>acuerdo explícito o tácito"]
    A --> C["NO COLUSORIO<br/>sin información del rival"]
    B --> D["Colusión &rarr; CÁRTEL<br/>actúa como un monopolio<br/><b>beneficio conjunto máximo</b>"]
    C --> E["Teoría de los juegos<br/>equilibrio de Nash"]
    D --> F["Pero el interés propio<br/>rompe el acuerdo<br/>(dilema del prisionero)"]
    F --> G["<b>Cuantas más empresas,<br/>más cerca de la<br/>competencia perfecta</b>"]
    E --> G
    style A fill:#7C5CFF,color:#fff
    style D fill:#FFA726,color:#fff
    style E fill:#4DB6AC,color:#fff
    style G fill:#7C5CFF,color:#fff
```

## Qué hace el Estado con esto

Las autoridades a cargo de diseñar políticas emplean las **leyes antimonopolio** para evitar que
los oligopolios practiquen conductas que inhiben la competencia. Para eso primero hay que medir
el **poder de mercado**: el grado en que una única empresa o un número reducido de ellas controla
las decisiones sobre precios y producción en una industria. Cómo se mide, en
[[Concentración y Defensa de la Competencia]].

## Conexiones

- [[Clasificación de Mercados]] — es la fila de "pocas empresas, barreras fuertes, influencia alta"
- [[Monopolio]] — el cártel funciona **como** un monopolio: mismo resultado de precio y cantidad
- [[Competencia Perfecta]] — el límite hacia el que tiende el oligopolio cuando crece el número de empresas
- [[Concentración y Defensa de la Competencia]] — los índices ponen número al poder de mercado que acá se describe
- [[Matriz de Pagos]] — es la herramienta con la que se representan estos juegos estratégicos, incluido el dilema del prisionero
- [[5 Fuerzas de Porter]] — la rivalidad entre competidores y las barreras de entrada son el mismo fenómeno visto desde la estrategia

## En el parcial

**Distinguir oligopolio colusorio de no colusorio, nombrando colusión y cártel, y explicar por
qué el cártel es inestable.** La respuesta completa tiene dos partes: (1) coludidos maximizan el
beneficio **conjunto** actuando como monopolio; (2) pero cada uno gana más rompiendo el acuerdo,
y eso es el dilema del prisionero. Segunda consigna probable: **decir qué pasa con precio y
cantidad a medida que aumenta el número de empresas del oligopolio** — se acercan a los de
competencia perfecta. Tener a mano el nombre "equilibrio de Nash" y qué significa.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `SEGUNDO PARCIAL — Google Docs` y el manuscrito `MERCADOS` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, demanda]
---

# Excedente del Consumidor

> **Es la diferencia entre lo que el comprador estaba dispuesto a pagar y lo que efectivamente
> pagó.** El material de esta tanda lo nombra pero nunca lo define: acá está armado con las
> piezas sueltas que sí aparecen, y con el hueco declarado.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## ⚠️ Faltante

**El material no trae la definición formal ni el gráfico del excedente del consumidor.**
Aparece una sola vez, de pasada, en la sección de [[Discriminación de Precios]]: el objetivo del
monopolista que discrimina es *"maximizar los beneficios capturando una mayor proporción del
excedente del consumidor"*. No hay:

- definición explícita del concepto;
- la identificación del excedente como el **área entre la curva de demanda y el precio**;
- el excedente del **productor** ni el excedente total;
- el uso del excedente para medir la pérdida de eficiencia.

El programa de la unidad lo pide como tema propio ("El excedente del consumidor"), así que es un
punto a completar con el teórico de la cátedra cuando salga, o a preguntar en clase.

## Lo que sí dice el material, y que apunta a la idea

Tres afirmaciones sueltas que, juntas, son el razonamiento del excedente:

1. **La disposición a pagar es la utilidad marginal.** *"El precio es la disposición a pagar y se relaciona con UMg."* Cada unidad tiene, para el comprador, un valor propio.
2. **Se compra mientras el valor supere al precio.** *"El consumidor comprará todas aquellas unidades que tengan un valor marginal (UMg) mayor que el precio que paga."* Todas esas unidades le dejan una ganancia neta.
3. **Hasta el equilibrio, todo vale más de lo que cuesta.** *"Todas las unidades entre 0 y $Q_E$ valen más de lo que cuestan; todas las unidades mayores que $Q_E$ cuestan más de lo que valen."*

De ahí sale, sin decirlo con ese nombre: sobre las unidades que compra, el consumidor paga **un
solo precio** pero valora cada unidad **más** que ese precio (salvo la última). Esa diferencia
acumulada es el excedente.

```mermaid
flowchart TD
    A["Cada unidad tiene una<br/>DISPOSICIÓN A PAGAR<br/>(su utilidad marginal)"] --> B["La disposición a pagar<br/>cae unidad a unidad"]
    B --> C["Pero se paga<br/>UN SOLO PRECIO de mercado"]
    C --> D["<b>Diferencia acumulada a favor<br/>del comprador</b>"]
    E["El monopolista que discrimina<br/>intenta capturar ese diferencial"] --> D
    style A fill:#4DB6AC,color:#fff
    style D fill:#7C5CFF,color:#fff
    style E fill:#FFA726,color:#fff
```

## Lo que sí está: el ingreso total

Lo que el material **sí** identifica como área bajo la curva de demanda es el **ingreso total**,
no el excedente:

$$IT = P \times Q$$

> "La cantidad total pagada por los compradores y recibida como ingreso por los vendedores es igual al área de la caja bajo la curva de demanda $P \times Q$."

Ojo con no confundir las dos cosas al dibujar: la **caja** $P \times Q$ es lo que se paga; el
excedente es lo que queda **por encima** de esa caja y por debajo de la curva de demanda.

## Conexiones

- [[Discriminación de Precios]] — es el único lugar donde el material nombra el excedente: el monopolista discrimina para capturarlo
- [[Curva de Demanda]] — la curva es la escalera de disposiciones a pagar sobre la que se mide el excedente
- [[Ley de la Utilidad Marginal Decreciente]] — si todas las unidades valieran lo mismo no habría excedente que medir
- [[Equilibrio de Mercado]] — de ahí sale la frase "hasta $Q_E$ todo vale más de lo que cuesta"
- [[Elasticidad Precio de la Demanda]] — comparte el mismo gráfico y se presta a confundir el área $P \times Q$ con el excedente

## En el parcial

**Saber explicar en palabras por qué el comprador sale ganando aunque pague el precio de
mercado:** valora cada unidad según su utilidad marginal, que va cayendo, pero paga un único
precio por todas — la diferencia queda para él. Y saber distinguir en el gráfico la caja
$P \times Q$ (ingreso total del vendedor) del área que queda arriba (excedente). **Antes de
rendir, conseguí la definición y el gráfico formales**: con este material no alcanza para
resolver un ejercicio que pida calcular el área.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)` y `SEGUNDO PARCIAL — Google Docs, sección Unidad 3`, ambos con tratamiento incompleto del tema — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

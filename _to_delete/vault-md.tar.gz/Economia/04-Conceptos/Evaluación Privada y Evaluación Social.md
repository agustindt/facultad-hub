---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos, evaluacion]
---

# Evaluación Privada y Evaluación Social

> El mismo proyecto, dos preguntas distintas: **¿le conviene a la empresa?** y **¿le conviene a
> la sociedad?**. Cambia el beneficiario, cambian los precios y cambia qué cuenta como costo.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## La comparación

| | **Evaluación económica privada** | **Evaluación social** |
|---|---|---|
| Beneficio de… | La **empresa** | La **sociedad** |
| Precios | De **mercado** | De **factores**, más externalidades |
| Impuestos | Incide el impuesto a las ganancias | **Sin** impuestos ni subsidios |
| Qué cuantifica | Ingresos y egresos del proyecto | Costos y beneficios sociales **directos, indirectos e intangibles**, más las externalidades que el proyecto genere |

Que la social saque impuestos y subsidios no es un detalle: para la sociedad esos flujos **no
crean ni destruyen riqueza, la redistribuyen**. Ver [[Precios Privados y Precios Sociales]].

## Cómo se abre la evaluación privada

```mermaid
flowchart TD
    EP["<b>EVALUACIÓN PRIVADA</b><br/>precios de mercado<br/>+ impuesto a las ganancias"] --> EF["EFICIENCIA"]
    EP --> RI["RIESGO"]
    EF --> E1["Económica operativa<br/>rentabilidad del PROYECTO<br/>flujo del proyecto · VAN · TIR"]
    EF --> E2["Financiera o con recursos propios<br/>rentabilidad de los INVERSORES<br/>flujo de los inversionistas"]
    RI --> R1["Análisis de sensibilidad"]
    RI --> R2["Análisis de escenarios"]
    style EP fill:#7C5CFF,color:#fff
    style EF fill:#4DB6AC,color:#fff
    style RI fill:#FFA726,color:#fff
```

Los **dos flujos no son el mismo**: el del proyecto mide si el negocio rinde; el de los
inversionistas, qué les queda a los que pusieron el capital propio.

## El análisis beneficio-costo privado

El insumo es el **flujo de fondos (cash flow)**: ingresos y egresos —inversiones y costos de
operación— proyectados **a valores constantes** del año correspondiente, a precios de mercado y
con incidencia del impuesto a las ganancias.

| Símbolo | Qué es |
|---|---|
| $B_j$ | Ingresos del año $j$ |
| $C_j$ | Costos del año $j$ |
| $I_0$ | Inversión inicial |
| $n$ | Período de análisis |
| $V_r$ | Ingreso al final de $n$: valor de libros o valor de venta |

Y los indicadores, tal como los define el apunte:

- **VAN**: mide monetariamente, expresado en el momento presente, en cuánto varía la riqueza por
  hacer la inversión — cuánto se gana **por sobre lo que se quiere ganar**, después de recuperada
  la inversión.
- **TIR**: la tasa de interés que hace $VAN = 0$. Conviene invertir cuando la **tasa exigida es
  menor que la TIR**.

## La tasa social de descuento

Para la evaluación social el apunte da una tasa distinta según el destino del proyecto, y la
llama **intergeneracional**:

| Tipo de proyecto | Tasa social de descuento |
|---|---|
| Productivos | $d = 12\%$ |
| Salud, educación | $d = 6\%$ |

## Faltante

El apunte enumera los indicadores como "**VAN, TIR y PR**" pero **nunca define el PR**. Tampoco
transcribe la fórmula del análisis beneficio-costo (era una imagen): quedan sólo los símbolos.

## Conexiones

- [[Valor Actual Neto]] — el indicador principal de la eficiencia económica operativa
- [[Tasa Interna de Retorno]] — el otro indicador, y la regla de decisión contra la tasa exigida
- [[Flujo de Fondos]] — el insumo de las dos evaluaciones; lo que cambia son los precios con que se valúa
- [[Tasa de Descuento]] — la privada usa el costo de oportunidad del capital; la social, la intergeneracional
- [[Precios Privados y Precios Sociales]] — la corrección que convierte una evaluación en la otra
- [[Análisis de Sensibilidad y Escenarios]] — la pata de riesgo de la evaluación privada

## En el parcial

**Armar el cuadro privada vs. social de memoria**: beneficiario, precios, qué pasa con impuestos
y subsidios, y qué se cuantifica de más en la social (directos, indirectos, intangibles y
externalidades). Y adentro de la privada, **no confundir eficiencia económica operativa con
financiera**: la primera evalúa el proyecto, la segunda a los inversores, y usan flujos
distintos. Segundo error frecuente: aplicar el 12 % a un proyecto de salud — ahí va 6 %.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

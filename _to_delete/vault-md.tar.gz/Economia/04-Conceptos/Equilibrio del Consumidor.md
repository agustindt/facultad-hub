---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, consumidor]
---

# Equilibrio del Consumidor

> **El consumidor está en equilibrio cuando el último peso gastado en cada bien le rinde la
> misma utilidad.** Gráficamente: donde la curva de indiferencia es tangente a la recta de
> balance.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## El problema

> "EL PROBLEMA DEL CONSUMIDOR consiste en maximizar la satisfacción que le reporta el consumo de una serie de bienes, dado su nivel de ingresos y los precios de los distintos bienes."

Es una optimización con restricción, y necesita tres piezas:

| Pieza | Qué es |
|---|---|
| **Curva de isoutilidad o de indiferencia** | El conjunto de combinaciones ante las cuales el consumidor es indiferente, porque cada una le reporta el mismo nivel de utilidad |
| **Relación marginal de sustitución (RMS)** | La cantidad máxima del segundo bien a la que está dispuesto a renunciar, sin reducir su utilidad, para aumentar el consumo del primero en una unidad |
| **Restricción presupuestaria / recta de balance** | Las combinaciones máximas que puede comprar dados los precios y su ingreso |

$$R = P_x \cdot Q_x + P_y \cdot Q_y$$

La pendiente de la recta de balance es el **precio relativo** de los dos bienes: mide la tasa a
la que el consumidor *puede* intercambiar un bien por otro. La pendiente de la curva de
indiferencia (la RMS) mide la tasa a la que *querría* intercambiarlos.

## La condición de equilibrio, en sus dos formas

**Forma gráfica** — la que se dibuja:

> "El equilibrio del consumidor se alcanza cuando la relación marginal de sustitución del consumidor (la pendiente en un punto de la curva de indiferencia) es igual a la pendiente de la recta de balance, esto es, a la relación entre el precio de los dos bienes."

**Forma analítica** — el *principio de la igualdad de las utilidades marginales*: cada bien se
demanda hasta el punto en que la utilidad marginal del último peso gastado en él sea igual a la
del último peso gastado en cualquier otro bien.

$$\frac{UMg_x}{P_x} = \frac{UMg_y}{P_y}$$

## Por qué tiene que ser así

El argumento del material es de arbitraje, y conviene saberlo de memoria: si la igualdad **no**
se cumpliera, el consumidor podría subir su utilidad gastando menos en el bien que le da menor
utilidad por peso y más en el que le da mayor utilidad por peso. Mientras haya diferencia, hay
una mejora disponible; el óptimo es justo donde se agotó.

## Qué pasa cuando cambia un precio

Cuando baja el precio de uno de los bienes, la recta de balance **se desplaza hacia afuera y
cambia de pendiente** (porque cambió el precio relativo). El consumidor se mueve del óptimo
inicial a uno nuevo y cambian las cantidades compradas de **ambos** bienes. Repetir ese
ejercicio para cada precio posible es exactamente lo que genera la [[Curva de Demanda]].

## Es la misma tangencia que en la teoría de la producción

```mermaid
flowchart LR
    A["<b>CONSUMIDOR</b><br/>curva de indiferencia<br/>+ recta de balance"] --> B["Tangencia:<br/>RMS = Px/Py"]
    C["<b>EMPRESA</b><br/>isocuanta<br/>+ isocosto"] --> D["Tangencia:<br/>RMST = w/r"]
    B --> E["<b>ÓPTIMO<br/>DEL CONSUMIDOR</b>"]
    D --> F["<b>ÓPTIMO<br/>DE LA EMPRESA</b>"]
    style A fill:#4DB6AC,color:#fff
    style C fill:#FFA726,color:#fff
    style E fill:#7C5CFF,color:#fff
    style F fill:#7C5CFF,color:#fff
```

## Conexiones

- [[Utilidad Total y Marginal]] — la condición de óptimo se escribe con utilidades marginales
- [[Ley de la Utilidad Marginal Decreciente]] — es lo que da a las curvas de indiferencia su forma y garantiza un óptimo interior
- [[Curva de Demanda]] — se construye repitiendo este óptimo para cada precio
- [[Eficiencia Económica en Tecnología]] — la misma estructura de tangencia, con isocuanta e isocosto en lugar de indiferencia y balance
- [[Tasa Marginal de Sustitución Técnica]] — el análogo exacto de la RMS del lado de la producción
- [[Isocosto]] — la recta de balance es a esta unidad lo que el isocosto es a la anterior

## En el parcial

**Dibujar el óptimo del consumidor y escribir la condición en las dos formas** (tangencia
RMS = precio relativo, y utilidades marginales por peso igualadas), justificando con el
argumento de arbitraje: si no se cumple, mover gasto del bien que rinde menos al que rinde más
mejora la utilidad. Segundo ejercicio probable: **qué le pasa a la recta de balance si baja un
precio** — se desplaza hacia afuera *y cambia de pendiente*. El error clásico es desplazarla
paralela, que es lo que pasa cuando cambia el **ingreso**, no un precio.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

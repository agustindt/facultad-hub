---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, indicadores]
---

# Comparación de Alternativas

> El corte que ordena toda la caja de herramientas de la unidad: **métodos que consideran el
> valor del dinero en el tiempo (VAN y TIR) y métodos que no (RBC, BPA, PRC y PE).** Cuál usás
> depende de los datos que tengas y de qué querés responder.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## La clasificación que hay que saber de memoria

Hay varios métodos "dependiendo de los datos disponible, de su confiabilidad, del objetivo
perseguido, etc.", y se parten en dos grupos:

> "Los métodos Generales se clasifican en: métodos que **no** tienen en cuenta el valor del dinero en el tiempo: Relación B-C, Beneficio del Primer Año, Periodo de recupero de capital y Punto de equilibrio. Métodos que **sí** tienen en cuenta el valor del dinero en el tiempo: VAN y TIR."

```mermaid
flowchart TD
    M["<b>MÉTODOS GENERALES</b><br/>para evaluar alternativas"] --> SI["<b>SÍ consideran</b><br/>el valor tiempo del dinero"]
    M --> NO["<b>NO consideran</b><br/>el valor tiempo del dinero"]
    SI --> VAN["VAN<br/>en pesos"]
    SI --> TIR["TIR<br/>en porcentaje"]
    NO --> RBC["Relación<br/>Beneficio-Costo"]
    NO --> BPA["Beneficio del<br/>Primer Año"]
    NO --> PRC["Período de Recupero<br/>de Capital"]
    NO --> PE["Punto de<br/>Equilibrio"]
    style M fill:#4DB6AC,color:#fff
    style SI fill:#7C5CFF,color:#fff
    style NO fill:#FFA726,color:#fff
```

## Los indicadores, uno por uno

| Indicador | Qué mide | Fórmula / regla | Criterio |
|---|---|---|---|
| [[Valor Actual Neto]] | "en cuánto varía la riqueza por hacer la inversión", en **pesos** | $VAN=\sum \frac{FF_t}{(1+d)^t}$ | $VAN > 0$ |
| [[Tasa Interna de Retorno]] | La rentabilidad del proyecto, en **porcentaje** | La tasa que hace $VAN=0$ | Tasa exigida $<$ TIR |
| **Relación Beneficio-Costo (RBC)** | "compara el valor actual de los beneficios del proyecto con los costos actuales del mismo y la inversión inicial" | $RBC = \dfrac{\text{Ingresos a valor presente}}{\text{Costos a valor presente}}$ | $RBC > 1$ |
| **Beneficio del Primer Año (BPA)** | "La tasa de ingresos del primer año sobre la inversión" | $BPA = \dfrac{B_1}{I_0}\times 100$ | $BPA > d$; si no, "conviene postergar la inversión" |
| **Período de Recupero de Capital (PRC)** | "el tiempo (años) para que los ingresos netos igualen la inversión inicial $I_0$" | Los períodos $n$ en que los ingresos netos acumulados alcanzan $I_0$ | "A mayor tiempo de recupero, mayor es el riesgo" |
| [[Punto de Equilibrio]] | La cantidad de ventas donde ingresos $=$ costos totales | $P \times Q = CF + CVu \times Q$ | "A mayor PE, mayor riesgo" |

Unidades, que es donde se enreda: **VAN en pesos**, **TIR y BPA en porcentaje**, **RBC es un
número puro** (sin unidad, por eso se compara contra 1), **PRC en períodos** y **PE en unidades
físicas**.

> **Inconsistencia del apunte, ojo.** La RBC está listada entre los métodos que *no* tienen en
> cuenta el valor del dinero en el tiempo, pero su propia definición dice "valor actual de los
> beneficios" y "a valor presente". Preguntalo en clase o verificalo con el teórico oficial:
> no lo resuelvo acá porque el apunte no lo resuelve.

## La alternativa nula: siempre hay con qué comparar

> "Siempre existe una alternativa para comparar que es la alternativa nula, es decir, el flujo de fondo sin proyecto. […] El VAN de la alternativa nula = 0."

No hacer nada es una alternativa legítima y su VAN es cero. Cualquier proyecto tiene que
ganarle a eso.

## Fabricar o comprar

Es el caso típico que trata el apunte:

> "La decisión de fabricar o producir, obliga a un desembolso inicial fuerte, a menores egresos posteriores y a un efecto tributario basado en la depreciación del activo. No siempre son comparables las alternativas, por ser muy distintas las actividades vinculadas a cada opción."

Dos nombres para los dos sentidos: **internalizar** ("integración hacia proveedor o
distribuidor") y **outsourcing** ("tercerizar"). Y la regla de cierre, que vale también para
[[Reemplazo de Equipos]]: *"Si existen diferencias de ingresos y egresos: Análisis
Beneficio-Costo."* Si las alternativas sólo difieren en costos, comparás costos; si además
cambian los ingresos, va análisis beneficio-costo.

Cuando el resultado además depende de eventos que no controlás, la unidad se abre en
[[Decisiones bajo Riesgo]] (hay probabilidades) y [[Decisiones bajo Incertidumbre]] (no las
hay).

## Faltante

De los temas del programa, el apunte **no trata "alquilar o comprar"** (sólo fabricar o
comprar), **no define valor residual** ni el **período de análisis** como tema propio, y no da
la fórmula desarrollada del PRC. Tampoco hay ejemplos numéricos de ningún indicador.

## Conexiones

- [[Valor Actual Neto]] — el método principal del grupo que sí considera el valor tiempo
- [[Tasa Interna de Retorno]] — el otro, y el que ordena cuando el capital está racionado
- [[Punto de Equilibrio]] — indicador de riesgo operativo dentro del grupo que no considera el valor tiempo
- [[Reemplazo de Equipos]] — es un caso particular de comparación de alternativas, con defensor y desafiante
- [[Decisiones bajo Riesgo]] — qué hacer cuando a cada resultado se le puede asignar probabilidad
- [[Erogaciones Relevantes]] — qué costos entran a la comparación y cuáles no, incluido el efecto tributario de la depreciación en fabricar o comprar

## En el parcial

**Clasificar los seis indicadores en los dos grupos (con y sin valor tiempo) y decir el
criterio de aceptación de cada uno con su unidad.** Es una pregunta de tabla, casi literal del
apunte, y se responde entera o no se responde.

Errores caros: comparar RBC contra cero en lugar de contra **uno**; olvidar que el BPA se
compara contra la **tasa de descuento** $d$ y no contra un número fijo; y presentar el PRC como
si midiera rentabilidad — mide **riesgo** (cuánto tardás en recuperar), y por eso mismo ignora
todo lo que pasa después del recupero.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, finanzas]
---

# Estructura Financiera de la Empresa

> **Todos los recursos financieros empleados por la empresa para hacer posibles las inversiones en
> activos.** Es el lado derecho del balance leído al revés: no "qué debo", sino "de dónde salió la
> plata con la que compré todo lo que tengo".

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## La frase bisagra de toda la unidad

> "La adquisición de los bienes que conforman el ACTIVO de la empresa (**estructura económica**), obliga a disponer de RECURSOS FINANCIEROS, que constituyen la fuente de financiamiento de la empresa (**estructura financiera**)."

| | **Estructura económica** | **Estructura financiera** |
|---|---|---|
| Qué es | Los bienes que la empresa tiene | Los recursos con que los consiguió |
| Dónde está en el balance | **Activo** | **Pasivo + Patrimonio Neto** |
| Qué pregunta contesta | ¿En qué está puesta la plata? | ¿De dónde salió? |

Son el mismo número mirado de los dos lados. Por eso [[Estados Contables Básicos]] arranca con
$A = P + PN$: no es una identidad casual, es que **toda inversión tuvo que ser financiada por
alguien**.

## Las tres procedencias

*"Toda empresa requiere de recursos para realizar sus actividades. El inicio de una empresa o de un
nuevo proyecto implica una inversión, por lo que se requiere de recursos financieros."* Y esos
recursos se clasifican **según su procedencia**:

| Fuente | Dónde figura | Quién puso la plata |
|---|---|---|
| Inversiones de accionistas | **Patrimonio Neto** | Los dueños |
| Préstamos a largo plazo | **Pasivo No Corriente** | Terceros, a más de un año |
| Préstamos a corto plazo | **Pasivo Corriente** | Terceros, a menos de un año |

```mermaid
flowchart LR
    ACT["<b>ACTIVO</b><br/>estructura económica"] --- EQ["="]
    EQ --- PN["<b>Patrimonio Neto</b><br/>inversiones de accionistas"]
    EQ --- PNC["<b>Pasivo No Corriente</b><br/>préstamos a largo plazo"]
    EQ --- PC["<b>Pasivo Corriente</b><br/>préstamos a corto plazo"]
    style ACT fill:#4DB6AC,color:#fff
    style EQ fill:#7C5CFF,color:#fff
    style PN fill:#FFA726,color:#fff
    style PNC fill:#FFA726,color:#fff
    style PC fill:#FFA726,color:#fff
```

Ese reparto es **la** decisión financiera de la empresa, y de él dependen los ratios de solvencia de
[[Ratios e Indicadores de Performance]].

## Cuando la estructura no aguanta: la crisis

- **Convocatoria de acreedores** — procedimiento jurídico para **evitar la quiebra**.
- **Pedido de quiebra** e **intervención de la justicia**.
- **Síndico** — "en un concurso de acreedores o en una quiebra, persona que se encarga de liquidar
  el activo y el pasivo del deudor".

Y el orden de prelación, lo más preguntable porque es una lista corta y ordenada:

| Orden | **Privilegios para cobrar pasivos** |
|---|---|
| 1º | Laborales / Seguridad Social |
| 2º | Hipotecarios |
| 3º | Acreedores comunes |
| 4º | **Accionistas** |

Los accionistas cobran **últimos**: ésa es la contracara de ser dueño, el residuo es tuyo pero sólo
después de todos los demás.

Además, el **Procedimiento Preventivo de Crisis**: "mecanismo de negociación, requisito previo
**obligatorio** para aquellas empresas que hayan decidido despidos o suspensiones por razones de
fuerza mayor, causas económicas o tecnológicas". Se tramita ante el **Ministerio de Trabajo**, a
instancias del empleador o de los trabajadores representados por su sindicato; la propuesta debe ser
**homologada** por el ministerio, y el acuerdo **no impide** que los trabajadores recurran a la
justicia.

## Conexiones

- [[Estados Contables Básicos]] — la estructura financiera es literalmente el lado derecho del balance
- [[Fuentes de Financiamiento]] — abre cada una de estas tres procedencias y las clasifica por origen y titularidad
- [[Ciclo del Capital Circulante]] — cuanto más largo el ciclo, más financiamiento hace falta para sostenerlo
- [[Ratios e Indicadores de Performance]] — solvencia y liquidez miden si esta estructura aguanta; el ROA se define por **ignorarla**
- [[La Empresa y sus Actividades]] — "financiamiento" es la primera de las cuatro actividades

## En el parcial

**Explicar la diferencia entre estructura económica y estructura financiera y ubicar cada una en el
balance** — se contesta en tres líneas y se pierde por confundir los nombres: *económica = activo,
financiera = pasivo + PN*. Y saber **el orden de privilegios de cobro de memoria** (laborales →
hipotecarios → comunes → accionistas), porque se pregunta tal cual. El error clásico ahí es poner a
los accionistas primero "porque son los dueños": cobran **al final**.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

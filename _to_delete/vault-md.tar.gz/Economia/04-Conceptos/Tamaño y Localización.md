---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos, tecnico]
---

# Tamaño y Localización

> Las dos decisiones de la **ingeniería básica**: *cuánto* va a poder producir el proyecto y
> *dónde* se va a instalar. Ninguna de las dos se elige libremente — las dos son el resultado
> de una lista de restricciones.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## Tamaño: el techo lo pone el más bajo de los cinco

El punto de partida son el **techo de mercado** y las **economías de escala**. Sobre eso operan
cinco factores limitantes:

| Factor limitante | Qué restringe |
|---|---|
| **Mercado** | Los ingresos potenciales |
| **Tecnología** | La frontera de lo técnicamente posible |
| **Insumos** | Calidad y cantidad disponibles |
| **Capacidad financiera** | Cuánto se puede efectivamente invertir |
| **Factores institucionales** | El ambiente (marco institucional) |

La forma útil de leer la lista: **el tamaño factible es el menor de los cinco topes**. De nada
sirve un mercado enorme si no hay insumos, y de nada sirve la tecnología si no hay con qué
pagarla.

## Localización: dónde

Tres factores, y los tres son en el fondo el mismo: **costo de mover cosas**.

| Factor | Qué se mira |
|---|---|
| **Transporte** | Localización de los factores de producción **y** de la demanda |
| **Recursos logísticos** | Mano de obra, energía, infraestructura |
| **Costos de insumos** | Ubicación del mercado de insumos |

Ojo con el primero: el transporte tira para los dos lados a la vez —hacia los insumos y hacia
los clientes—, y la ubicación elegida es un compromiso entre ambos.

## Los factores cualitativos

El apunte los lista dentro del estudio técnico, justo antes de la selección de tamaño y
localización. No se cuantifican, pero condicionan la elección:

- **Madurez de la tecnología**: oportunidades y riesgos.
- **Calidad**: aseguramiento de especificaciones técnicas.
- **Flexibilidad**: capacidad de cambiar volumen y producto (riesgos de mercado).
- **Vulnerabilidad**: riesgos de faltantes de materia prima o insumos.

## Conexiones

- [[Economías y Deseconomías de Escala]] — son uno de los dos puntos de partida para definir el tamaño
- [[Escala Mínima Eficiente]] — el tamaño mínimo con el que el costo medio de largo plazo toca su piso
- [[Tipos de Proyectos]] — el proyecto de ampliación es una decisión de tamaño sobre una planta existente
- [[Fuentes de Financiamiento]] — la capacidad financiera es uno de los cinco límites al tamaño
- [[Estudios de Factibilidad]] — tamaño y localización son el corazón de la viabilidad técnica

## En el parcial

**Enumerar los cinco factores limitantes del tamaño y los tres de la localización**, y saber
usarlos sobre un caso: si te describen una empresa con demanda insatisfecha pero sin acceso a
crédito, el factor que fija el tamaño es la **capacidad financiera**, no el mercado. El error
típico es mezclar las dos listas — insumos aparece en las dos, pero por motivos distintos:
en tamaño por **cantidad y calidad disponibles**, en localización por **dónde está el mercado
de insumos**.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

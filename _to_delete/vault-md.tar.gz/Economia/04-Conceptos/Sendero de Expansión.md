---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion, largo-plazo]
---

# Sendero de Expansión

> El **lugar geométrico de los óptimos** para cada nivel de producto. Une las tangencias entre
> isocuantas e isocostos a medida que crece la escala.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

También llamado **curva costo-efectividad**. Textual:

> "La senda de expansión es el **lugar geométrico de los óptimos en cada nivel de producto** (tamaño o escala). Ilustra las tecnologías de menor costo para producir."

La construcción es directa: para cada nivel de producción hay una isocuanta; para cada
presupuesto hay un isocosto; la [[Eficiencia Económica en Tecnología|tangencia]] entre ellos da
**un** punto óptimo. Uniendo esos puntos para $Q = 100, 200, 300\dots$ sale el sendero.

Con los datos del gráfico del teórico:

| Punto | Producción | Isocosto |
|---|---|---|
| A | $Q = 100$ | \$1000 |
| B | $Q = 200$ | \$2000 |
| C | $Q = 300$ | \$3000 |

## Qué se lee en él

El sendero contesta una pregunta muy concreta: **si quiero producir más, ¿en qué proporción
conviene aumentar cada factor?**

- Si el sendero es una **recta que sale del origen**, la proporción $K/L$ óptima **no cambia**
  con la escala: crecer significa multiplicar todo por igual.
- Si se **curva hacia el eje del capital**, crecer conviene hacerlo volviéndose más intensivo
  en capital — es lo típico de la industria: al crecer se automatiza.
- Si se curva hacia el eje del trabajo, al revés.

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">11</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">23</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">34</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><line x1="97.3" x2="97.3" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="97.3" cy="114.2" r="3.4" fill="#7C5CFF"/><text x="97.3" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600"></text><line x1="128.9" x2="128.9" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="128.9" cy="95" r="3.4" fill="#7C5CFF"/><text x="128.9" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600"></text><line x1="171.1" x2="171.1" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="171.1" cy="69.4" r="3.4" fill="#7C5CFF"/><text x="171.1" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600"></text><path d="M48.9 29.2 L53.9 50.4 L58.9 65.6 L63.8 77.1 L68.8 86.1 L73.8 93.3 L78.7 99.2 L83.7 104.1 L88.7 108.3 L93.7 111.9 L98.6 115 L103.6 117.8 L108.6 120.2 L113.5 122.3 L118.5 124.2 L123.5 126 L128.5 127.5 L133.4 128.9 L138.4 130.2 L143.4 131.4 L148.3 132.5 L153.3 133.5 L158.3 134.5 L163.3 135.4 L168.2 136.2 L173.2 136.9 L178.2 137.6 L183.1 138.3 L188.1 138.9 L193.1 139.5 L198.1 140.1 L203 140.6 L208 141.1 L213 141.6 L217.9 142 L222.9 142.4 L227.9 142.8 L232.9 143.2 L237.8 143.6 L242.8 143.9 L247.8 144.3 L252.7 144.6 L257.7 144.9 L262.7 145.2 L267.7 145.5 L272.6 145.7 L277.6 146 L282.6 146.2 L287.5 146.5 L292.5 146.7 L297.5 146.9 L302.5 147.2 L307.4 147.4 L312.4 147.6 L317.4 147.8 L322.3 147.9 L327.3 148.1 L332.3 148.3 L337.3 148.5 L342.2 148.6 L347.2 148.8 L352.2 148.9 L357.1 149.1 L362.1 149.2 L367.1 149.4 L372.1 149.5 L377 149.7 L382 149.8" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M73.8 24.9 L78.7 37 L83.7 47.1 L88.7 55.6 L93.7 62.9 L98.6 69.3 L103.6 74.8 L108.6 79.7 L113.5 84.1 L118.5 88 L123.5 91.6 L128.5 94.8 L133.4 97.7 L138.4 100.3 L143.4 102.7 L148.3 105 L153.3 107.1 L158.3 109 L163.3 110.7 L168.2 112.4 L173.2 114 L178.2 115.4 L183.1 116.8 L188.1 118 L193.1 119.2 L198.1 120.4 L203 121.4 L208 122.4 L213 123.4 L217.9 124.3 L222.9 125.2 L227.9 126 L232.9 126.8 L237.8 127.5 L242.8 128.2 L247.8 128.9 L252.7 129.6 L257.7 130.2 L262.7 130.8 L267.7 131.4 L272.6 131.9 L277.6 132.5 L282.6 133 L287.5 133.5 L292.5 133.9 L297.5 134.4 L302.5 134.8 L307.4 135.2 L312.4 135.7 L317.4 136 L322.3 136.4 L327.3 136.8 L332.3 137.2 L337.3 137.5 L342.2 137.8 L347.2 138.2 L352.2 138.5 L357.1 138.8 L362.1 139.1 L367.1 139.4 L372.1 139.6 L377 139.9 L382 140.2" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M118.5 19.9 L123.5 26.8 L128.5 33.1 L133.4 38.8 L138.4 44 L143.4 48.7 L148.3 53.1 L153.3 57.2 L158.3 60.9 L163.3 64.4 L168.2 67.7 L173.2 70.7 L178.2 73.5 L183.1 76.2 L188.1 78.7 L193.1 81.1 L198.1 83.3 L203 85.4 L208 87.4 L213 89.2 L217.9 91 L222.9 92.7 L227.9 94.3 L232.9 95.9 L237.8 97.3 L242.8 98.7 L247.8 100.1 L252.7 101.3 L257.7 102.6 L262.7 103.7 L267.7 104.9 L272.6 105.9 L277.6 107 L282.6 108 L287.5 108.9 L292.5 109.9 L297.5 110.7 L302.5 111.6 L307.4 112.4 L312.4 113.2 L317.4 114 L322.3 114.8 L327.3 115.5 L332.3 116.2 L337.3 116.9 L342.2 117.5 L347.2 118.2 L352.2 118.8 L357.1 119.4 L362.1 120 L367.1 120.5 L372.1 121.1 L377 121.6 L382 122.1" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 75.8 L39 78.9 L43.9 81.9 L48.9 84.9 L53.9 87.9 L58.9 90.9 L63.8 93.9 L68.8 96.9 L73.8 100 L78.7 103 L83.7 106 L88.7 109 L93.7 112 L98.6 115 L103.6 118.1 L108.6 121.1 L113.5 124.1 L118.5 127.1 L123.5 130.1 L128.5 133.1 L133.4 136.2 L138.4 139.2 L143.4 142.2 L148.3 145.2 L153.3 148.2 L158.3 151.2 L163.3 154.2 L168.2 157.3" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 37.5 L39 40.5 L43.9 43.5 L48.9 46.5 L53.9 49.5 L58.9 52.5 L63.8 55.6 L68.8 58.6 L73.8 61.6 L78.7 64.6 L83.7 67.6 L88.7 70.6 L93.7 73.6 L98.6 76.7 L103.6 79.7 L108.6 82.7 L113.5 85.7 L118.5 88.7 L123.5 91.7 L128.5 94.8 L133.4 97.8 L138.4 100.8 L143.4 103.8 L148.3 106.8 L153.3 109.8 L158.3 112.8 L163.3 115.9 L168.2 118.9 L173.2 121.9 L178.2 124.9 L183.1 127.9 L188.1 130.9 L193.1 134 L198.1 137 L203 140 L208 143 L213 146 L217.9 149 L222.9 152.1 L227.9 155.1 L232.9 158.1" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M83.7 16.4 L88.7 19.5 L93.7 22.5 L98.6 25.5 L103.6 28.5 L108.6 31.5 L113.5 34.5 L118.5 37.5 L123.5 40.6 L128.5 43.6 L133.4 46.6 L138.4 49.6 L143.4 52.6 L148.3 55.6 L153.3 58.7 L158.3 61.7 L163.3 64.7 L168.2 67.7 L173.2 70.7 L178.2 73.7 L183.1 76.8 L188.1 79.8 L193.1 82.8 L198.1 85.8 L203 88.8 L208 91.8 L213 94.8 L217.9 97.9 L222.9 100.9 L227.9 103.9 L232.9 106.9 L237.8 109.9 L242.8 112.9 L247.8 116 L252.7 119 L257.7 122 L262.7 125 L267.7 128 L272.6 131 L277.6 134.1 L282.6 137.1 L287.5 140.1 L292.5 143.1 L297.5 146.1 L302.5 149.1 L307.4 152.1 L312.4 155.2 L317.4 158.2" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 152.6 L39 149.6 L43.9 146.6 L48.9 143.6 L53.9 140.5 L58.9 137.5 L63.8 134.5 L68.8 131.5 L73.8 128.5 L78.7 125.5 L83.7 122.4 L88.7 119.4 L93.7 116.4 L98.6 113.4 L103.6 110.4 L108.6 107.4 L113.5 104.4 L118.5 101.3 L123.5 98.3 L128.5 95.3 L133.4 92.3 L138.4 89.3 L143.4 86.3 L148.3 83.2 L153.3 80.2 L158.3 77.2 L163.3 74.2 L168.2 71.2 L173.2 68.2 L178.2 65.1 L183.1 62.1 L188.1 59.1 L193.1 56.1 L198.1 53.1 L203 50.1 L208 47.1 L213 44 L217.9 41 L222.9 38 L227.9 35 L232.9 32 L237.8 29 L242.8 25.9 L247.8 22.9 L252.7 19.9 L257.7 16.9" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="261.7" y="19.9" font-size="9" fill="#7C5CFF" font-weight="600">senda</text><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L) — eje vertical: Capital (K)</text></svg>

*Cada punto violeta es una tangencia. Unirlos da el sendero.*


## Para qué sirve después

Es el puente entre la teoría de la producción y los [[Costos de Largo Plazo]]. Cada punto del
sendero tiene un costo asociado (el del isocosto que lo toca), y ese par
*(cantidad producida, costo mínimo)* es exactamente lo que define la **curva de costo total de
largo plazo**. La curva de costos de largo plazo **es** el sendero de expansión, traducido de
un gráfico $K$–$L$ a un gráfico $Q$–$Costo$.

## Conexiones

- [[Eficiencia Económica en Tecnología]] — cada punto del sendero es una de esas tangencias
- [[Isocuanta]] — el sendero atraviesa un mapa de isocuantas, tocando cada una en su óptimo
- [[Isocosto]] — los isocostos sucesivos y paralelos son los que van marcando cada tangencia
- [[Costos de Largo Plazo]] — se construyen directamente a partir del sendero
- [[Rendimientos de Escala]] — la forma del sendero y el espaciado de las isocuantas cuentan la misma historia

## En el parcial

Definición como lugar geométrico de los óptimos y saber que de ahí salen los costos de largo
plazo. Suele venir como pregunta corta o como parte de una de desarrollo sobre largo plazo.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

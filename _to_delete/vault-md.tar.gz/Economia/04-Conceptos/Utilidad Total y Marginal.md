---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, consumidor]
---

# Utilidad Total y Marginal

> **Utilidad es el placer subjetivo de consumir.** La total es la de todo lo que consumiste;
> la marginal, la que agrega la última unidad. Toda la teoría del consumidor se apoya en
> distinguir esas dos.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Las tres definiciones, textuales

> "La **UTILIDAD** es el sentimiento subjetivo de placer o satisfacción que una persona experimenta como consecuencia de consumir un bien o un servicio."

> "La **Utilidad Total** es la utilidad que proporciona toda la cantidad consumida del bien."

> "La **Utilidad Marginal** es el aumento que se produce en la utilidad total cada vez que el consumo aumenta en una unidad."

| Magnitud | Qué mide | En símbolos |
|---|---|---|
| Utilidad total ($UT$) | La satisfacción acumulada de todo lo consumido | — |
| Utilidad marginal ($UMg$) | Lo que suma la **última** unidad | $UMg = \dfrac{\Delta UT}{\Delta Q}$ |
| Utilidad media ($UMe$) | Satisfacción promedio por unidad | $UMe = \dfrac{UT}{\text{unidades consumidas}}$ |

Que la $UMg$ vaya cayendo a medida que consumís más es la [[Ley de la Utilidad Marginal Decreciente]],
y es el único supuesto de conducta que hace falta para que la demanda tenga pendiente negativa.

## La distinción que se pregunta: valor vs. precio

*¿Por qué el agua es barata y los diamantes son caros?* Al agua la necesitamos para sobrevivir
y aun así vale poco. La respuesta del material es que **valor y precio se enganchan a cosas
distintas**:

| | Se relaciona con | Por qué |
|---|---|---|
| **Valor** — lo que se recibe del producto | La utilidad **media** ($UMe$) | Es el promedio de satisfacción de todo lo consumido |
| **Precio** — la disposición a pagar | La utilidad **marginal** ($UMg$) | Es lo que estás dispuesto a pagar por *una unidad más* |

Y el eslabón que cierra el razonamiento: *"la utilidad marginal depende del número de unidades
que posea esa persona. La escasez incrementa la disponibilidad a pagar."* Como de agua tenés
muchísima, la última unidad te agrega poco y pagás poco; de diamantes tenés cero, la primera
unidad te agrega muchísimo y pagás mucho.

```mermaid
flowchart LR
    A["Tenés MUCHAS unidades<br/>(agua)"] --> B["UMg baja"]
    B --> C["<b>Precio bajo</b>"]
    D["Tenés POCAS unidades<br/>(diamantes)"] --> E["UMg alta"]
    E --> F["<b>Precio alto</b>"]
    G["El VALOR (UMe)<br/>puede ser altísimo igual"] -.-> C
    style C fill:#4DB6AC,color:#fff
    style F fill:#7C5CFF,color:#fff
    style G fill:#FFA726,color:#fff
```

## Es la misma familia de curvas que en producción

Total, medio y marginal es el mismo trío que ya viste del lado de la empresa. Cambia el
contenido, no la mecánica: el marginal es la derivada del total y arrastra al medio.

## Conexiones

- [[Ley de la Utilidad Marginal Decreciente]] — es la propiedad que cumple la $UMg$, y sin ella no hay demanda decreciente
- [[Equilibrio del Consumidor]] — la regla de óptimo se escribe con utilidades marginales por peso gastado
- [[Curva de Demanda]] — el material dice que el precio de los bienes está relacionado con la $UMg$ que le generan al comprador
- [[Producto Total Medio y Marginal]] — el mismo trío total/medio/marginal, del lado de la producción
- [[Escasez]] — acá aparece como el motor del precio: menos unidades, mayor disposición a pagar

## En el parcial

Responder la pregunta del agua y los diamantes **usando los dos conceptos con nombre**: el
valor va con la $UMe$ y el precio va con la $UMg$, y la $UMg$ depende de cuántas unidades ya
tenés. El error típico es contestar "porque el diamante es más escaso" sin decir *por qué* la
escasez sube el precio — la escasez sube la **utilidad marginal**, y es ésa la que se paga.
Saber también escribir la $UMg$ como el incremento de la $UT$ al consumir una unidad más.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con el complemento del manuscrito `MERCADOS` (nov 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

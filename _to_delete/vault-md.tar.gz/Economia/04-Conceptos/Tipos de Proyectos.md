---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos]
---

# Tipos de Proyectos

> El apunte clasifica dos veces y por criterios distintos: **por lo que el proyecto produce**
> (productivos o de infraestructura) y **por su relación con una unidad productiva existente**
> (nuevos o de cambio). Son dos ejes independientes, no una sola lista.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## Eje 1 — según qué producen

| Tipo | Alcance | Ejemplos del apunte |
|---|---|---|
| **Productivos** | Sector primario, secundario, terciario | Una fábrica nueva; ampliar o cambiar la tecnología de una fábrica existente |
| **De infraestructura** | Obras públicas para servicios públicos y/o generadoras de condiciones impulsoras de desarrollo | Vialidad, electrificación, riego, telecomunicaciones, agua potable y saneamiento, salud, educación |

Esa segunda fila es la que explica por qué la unidad dedica media clase a la evaluación
social: los proyectos de infraestructura son públicos y no se juzgan solo por la ganancia del
que los hace.

## Eje 2 — según la unidad productiva

- **Proyectos nuevos**: unidades productivas nuevas, asociadas con empresas nuevas o
  existentes.
- **Proyectos de cambio o incrementales**: asociados con unidades productivas **ya
  existentes**.

Y los de cambio se subdividen en seis casos, que conviene saber de memoria porque son la lista
que después reaparece en los costos:

| Proyecto de… | En qué consiste |
|---|---|
| **Nuevo producto** | Incorpora maquinarias, equipos, etc.; se producen cambios en la operación |
| **Modificación de tecnología** | Sustitución de activos (maquinarias, equipos), con o sin aumento de capacidad |
| **Ampliación** | Aumento de capacidad de producción; incorpora equipos y cambia el nivel de operación |
| **Internalización** | Producir en la planta un insumo que se compraba o un proceso contratado a terceros |
| **Outsourcing (externalización)** | Externalizar parte de las actividades que hace la planta |
| **Abandono** | Reducir o suprimir la producción de ciertos productos, o cerrar la planta |

Fijate que **internalización y outsourcing son el mismo movimiento en direcciones opuestas**, y
que el abandono también es un proyecto de inversión: decidir dejar de hacer algo se evalúa con
las mismas herramientas que decidir empezarlo.

## Conexiones

- [[Erogaciones Relevantes]] — en los proyectos de cambio lo único que cuenta es la diferencia entre el antes y el después
- [[Reemplazo de Equipos]] — el proyecto de modificación de tecnología es exactamente ese problema de U6
- [[Evaluación Privada y Evaluación Social]] — los de infraestructura son los que piden evaluación social
- [[Proyecto de Inversión]] — la definición general que estas categorías dividen
- [[Tamaño y Localización]] — el proyecto de ampliación es, en el fondo, una decisión de tamaño

## En el parcial

**Clasificar un caso dado en los dos ejes a la vez.** Si te describen "una empresa que deja de
comprarle las cajas a un proveedor y las fabrica ella", la respuesta completa es: proyecto
productivo, de cambio o incremental, de **internalización**. El error típico es dar una sola
de las dos clasificaciones, o confundir internalización con outsourcing.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

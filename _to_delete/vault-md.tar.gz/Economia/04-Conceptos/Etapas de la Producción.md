---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion]
---

# Etapas de la Producción

> Las tres regiones en que se divide la curva de producción de corto plazo. Solo **una** tiene
> sentido económico.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Las tres etapas

| Etapa | Condición | Qué pasa | ¿Conviene? |
|---|---|---|---|
| **1** | $PMg > PMe$ | Rendimientos **crecientes**. *"La cantidad de insumo variable es insuficiente en relación al insumo fijo"* | ❌ No: falta factor variable |
| **2** | $PMg < PMe$, con $PMg > 0$ | Rendimientos **decrecientes**. **Región económica de producción** | ✅ **Sí** |
| **3** | $PMg < 0$ | *"Sobreutilización del insumo variable"*: las unidades adicionales **reducen** el producto total | ❌ No: absurdo |

Textual de la cátedra:

> "En la **ETAPA 1** Rendimientos crecientes → PMg > PMe (la cantidad de insumo variable es insuficiente en relación al insumo fijo).
> En la **ETAPA 2** Rendimientos decrecientes → PMg < PMe, con PMg > 0 → **Región económica de producción**.
> En la **ETAPA 3** Las unidades adicionales del insumo variable tienen como resultado una disminución del producto total (sobreutilización del insumo variable) PMg < 0."

## Dónde están las fronteras

```mermaid
flowchart LR
    E1["<b>ETAPA 1</b><br/>PMg &gt; PMe<br/><i>falta factor variable</i>"] -->|"ÓPTIMO TÉCNICO<br/>PMg = PMe"| E2["<b>ETAPA 2</b><br/>PMg &lt; PMe, PMg &gt; 0<br/><i>región económica</i>"]
    E2 -->|"MÁXIMO TÉCNICO<br/>PMg = 0"| E3["<b>ETAPA 3</b><br/>PMg &lt; 0<br/><i>sobreutilización</i>"]
    style E1 fill:#4DB6AC,color:#fff
    style E2 fill:#7C5CFF,color:#fff
    style E3 fill:#FFA726,color:#fff
```

Las fronteras son exactamente los dos puntos de
[[Máximo Técnico y Óptimo Técnico]]: el óptimo técnico separa la 1 de la 2, y el máximo técnico
separa la 2 de la 3.

<svg viewBox="0 0 440 180" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><rect x="34" y="14" width="217.5" height="140" fill="#4DB6AC" opacity=".10"/><text x="142.8" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Etapa 1</text><rect x="251.5" y="14" width="72.5" height="140" fill="#7C5CFF" opacity=".10"/><text x="287.8" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Etapa 2</text><rect x="324" y="14" width="58.0" height="140" fill="#FFA726" opacity=".10"/><text x="353.0" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Etapa 3</text><line x1="34" x2="382" y1="154" y2="154" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="157" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">-8</text><line x1="34" x2="382" y1="107.3" y2="107.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="110.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">6</text><line x1="34" x2="382" y1="60.7" y2="60.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="63.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">34</text><line x1="34" x2="34" y1="14" y2="154" stroke="var(--background-modifier-border,#8886)"/><line x1="251.5" x2="251.5" y1="14" y2="154" stroke="#4DB6AC" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><text x="251.5" y="165" text-anchor="middle" font-size="8" fill="#4DB6AC" font-weight="600">óptimo</text><line x1="324" x2="324" y1="14" y2="154" stroke="#FFA726" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><text x="324" y="165" text-anchor="middle" font-size="8" fill="#FFA726" font-weight="600">máximo</text><path d="M39 123.9 L43.9 120.6 L48.9 117.4 L53.9 114.2 L58.9 111.2 L63.8 108.2 L68.8 105.3 L73.8 102.4 L78.7 99.7 L83.7 97 L88.7 94.4 L93.7 91.8 L98.6 89.4 L103.6 87 L108.6 84.7 L113.5 82.5 L118.5 80.4 L123.5 78.3 L128.5 76.3 L133.4 74.4 L138.4 72.6 L143.4 70.9 L148.3 69.2 L153.3 67.6 L158.3 66.1 L163.3 64.7 L168.2 63.3 L173.2 62.1 L178.2 60.9 L183.1 59.7 L188.1 58.7 L193.1 57.7 L198.1 56.9 L203 56.1 L208 55.3 L213 54.7 L217.9 54.1 L222.9 53.6 L227.9 53.2 L232.9 52.9 L237.8 52.6 L242.8 52.5 L247.8 52.4 L252.7 52.3 L257.7 52.4 L262.7 52.5 L267.7 52.7 L272.6 53 L277.6 53.4 L282.6 53.9 L287.5 54.4 L292.5 55 L297.5 55.7 L302.5 56.5 L307.4 57.3 L312.4 58.2 L317.4 59.2 L322.3 60.3 L327.3 61.4 L332.3 62.7 L337.3 64 L342.2 65.4 L347.2 66.9 L352.2 68.4 L357.1 70 L362.1 71.7 L367.1 73.5 L372.1 75.4 L377 77.3 L382 79.3" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="82.3" font-size="9" fill="#4DB6AC" font-weight="600">PMe</text><path d="M34 127.3 L39 120.6 L43.9 114.1 L48.9 107.8 L53.9 101.8 L58.9 96 L63.8 90.4 L68.8 85.1 L73.8 80 L78.7 75.1 L83.7 70.5 L88.7 66.1 L93.7 62 L98.6 58.1 L103.6 54.4 L108.6 50.9 L113.5 47.7 L118.5 44.7 L123.5 42 L128.5 39.5 L133.4 37.2 L138.4 35.2 L143.4 33.4 L148.3 31.8 L153.3 30.5 L158.3 29.4 L163.3 28.5 L168.2 27.9 L173.2 27.5 L178.2 27.3 L183.1 27.4 L188.1 27.7 L193.1 28.3 L198.1 29.1 L203 30.1 L208 31.3 L213 32.8 L217.9 34.5 L222.9 36.5 L227.9 38.7 L232.9 41.1 L237.8 43.8 L242.8 46.7 L247.8 49.8 L252.7 53.2 L257.7 56.8 L262.7 60.6 L267.7 64.7 L272.6 69 L277.6 73.6 L282.6 78.4 L287.5 83.4 L292.5 88.6 L297.5 94.1 L302.5 99.8 L307.4 105.8 L312.4 112 L317.4 118.4 L322.3 125.1 L327.3 132 L332.3 139.1 L337.3 146.5" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="341.3" y="149.5" font-size="9" fill="#FFA726" font-weight="600">PMg</text><text x="208.0" y="177" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L)</text></svg>

*Las dos fronteras son el óptimo técnico (PMg = PMe) y el máximo técnico (PMg = 0).*


## Por qué las etapas 1 y 3 se descartan

Este es el razonamiento que hay que poder dar, no solo la tabla:

- **Etapa 3 es absurda siempre.** El producto marginal es negativo: estás **pagando** por un
  factor que **reduce** la producción. Sacando trabajadores producirías más y gastarías menos.
  No hay precio que justifique estar acá.
- **Etapa 1 es un poco más sutil.** El producto marginal es creciente y está por encima del
  medio: cada unidad nueva de factor variable rinde más que el promedio. Justamente por eso
  **conviene seguir contratando** — todavía no exprimiste el factor fijo, que ya estás pagando.
  Parar acá sería desaprovechar capital instalado.

Queda la **etapa 2**. Ahí, dónde exactamente ubicarse ya no lo decide la técnica: lo deciden
los precios de los factores y del producto. Ver
[[Eficiencia Económica en Tecnología]].

## Conexiones

- [[Producto Total Medio y Marginal]] — las etapas se delimitan comparando PMg con PMe
- [[Máximo Técnico y Óptimo Técnico]] — son las dos fronteras entre etapas
- [[Ley de Rendimientos Decrecientes]] — la etapa 2 es la zona donde la ley opera
- [[Eficiencia Económica en Tecnología]] — la técnica acota a la etapa 2; los precios eligen el punto exacto
- [[Costos Medios]] — la etapa 2 se corresponde con el tramo creciente del CVMe

## En el parcial

Delimitar las tres etapas sobre una tabla y **justificar por qué se descartan la 1 y la 3**.
La justificación de la etapa 1 es la que casi nadie da bien: no es que "rinde poco", es que
todavía rinde **cada vez más** y por eso conviene seguir.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

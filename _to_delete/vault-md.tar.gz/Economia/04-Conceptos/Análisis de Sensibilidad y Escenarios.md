---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
autor: Hertz
estado: pendiente
tags: [Economia, U7, proyectos, riesgo]
---

# Análisis de Sensibilidad y Escenarios

> Son la **pata de riesgo** de la evaluación privada. La diferencia entre los dos es una sola y
> hay que decirla siempre: la sensibilidad mueve **una** variable dejando el resto fija; los
> escenarios mueven **varias a la vez**.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## Qué es el riesgo, acá

> "El riesgo en los proyectos es la **variabilidad que puede esperarse de los flujos de fondos reales respecto a los estimados**."

Cuando hay proyectos con antecedentes similares, se mide con la **desviación estándar del
retorno esperado respecto al retorno medio**. Y los **riesgos asegurables** no se analizan: se
incluyen directamente en el flujo como **costo de primas de seguros**.

## Las tres técnicas

| | Cuántas variables mueve | Qué produce | Herramienta que nombra el apunte |
|---|---|---|---|
| **Análisis de sensibilidad** (unidimensional) | **Una**, el resto fijo | El valor máximo o mínimo que puede tomar esa variable para que el proyecto siga siendo aceptable | Función SOLVER de Excel |
| **Análisis de escenarios** (multidimensional, modelo de sensibilización de **Hertz**) | **Varias a la vez** | Los indicadores de eficiencia probados en otros escenarios, moviendo en rangos extremos **pesimistas y optimistas** las variables que más sensibilizan el resultado | — |
| **Simulación de Montecarlo** | Todas, por asignación **aleatoria** | La **distribución de probabilidades** de los valores que puede asumir el VAN | — |

En Montecarlo los valores se asignan según la distribución de probabilidades que se estime para
cada variable, dentro de un intervalo que **determina el evaluador**. Es decir: el resultado no
es un VAN, es una distribución de VAN.

## Las variables que se sensibilizan

El apunte da la lista para el análisis de escenarios, y es la que conviene tener a mano:

- Inversiones
- Precios de materias primas
- Rendimientos de procesos
- Volumen de ventas
- Precios de venta

## Conexiones

- [[Evaluación Privada y Evaluación Social]] — sensibilidad y escenarios son las dos técnicas de la pata de riesgo de la evaluación privada
- [[Valor Actual Neto]] — es la variable de salida que estas técnicas hacen variar
- [[Flujo de Fondos]] — el riesgo se define como la variabilidad de los flujos reales respecto de los estimados
- [[Decisiones bajo Riesgo]] — el marco de U6 donde se conocen las probabilidades, que es lo que Montecarlo supone
- [[Decisiones bajo Incertidumbre]] — el caso opuesto, cuando ni siquiera hay distribución de probabilidades

## En el parcial

**Explicar la diferencia entre sensibilidad y escenarios en una frase** (una variable vs.
varias) y saber qué devuelve cada técnica: la sensibilidad unidimensional devuelve **el valor
límite** de una variable para que el proyecto siga siendo aceptable; Montecarlo devuelve **una
distribución de probabilidades del VAN**, no un número. Nombrar el modelo de Hertz para el
análisis multidimensional suma. El error típico es describir escenarios pesimista/optimista y
llamarlo "análisis de sensibilidad".

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, macroeconomia]
---

# Objeto de la Macroeconomía

> La macroeconomía mira la economía **en conjunto**: no el precio de un bien ni la producción
> de una empresa, sino la inflación, el desempleo, la inversión y el crecimiento de un país entero.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Qué estudia y para qué

Textual, y sirve como definición de parcial:

> "La Macroeconomía estudia el funcionamiento de la economía en su conjunto, es decir, del comportamiento global del sistema económico."

> "Su propósito es obtener una visión simplificada de la economía, pero que al mismo tiempo permita **conocer y actuar** sobre el nivel de la actividad económica de un país determinado o de un conjunto de países."

Las dos palabras que hay que retener son *conocer* y *actuar*: la macro no es sólo descriptiva,
existe para justificar medidas de política. Se ocupa de los cambios en las **variables globales**:
inflación, inversión nacional, desempleo, crecimiento.

Las medidas de política macroeconómica tienen por objetivo mantener un crecimiento sostenible
en el mediano-largo plazo, conseguir estabilidad de precios, bajas tasas de desempleo, equilibrio
en las cuentas públicas y en la balanza de pagos.

## Los objetivos y con qué se mide cada uno

Esta tabla es la columna vertebral de toda la unidad: cada fila termina siendo una nota.

| Objetivo | Qué se busca | Con qué se mide |
|---|---|---|
| Actividad económica | Elevado nivel de producción y de consumo | El PBI, el indicador más amplio de la producción total |
| Nivel de empleo | Pleno empleo — es la variable que más directamente afecta a los individuos | Tasa de desempleo: % de la población activa que está desempleada |
| Nivel de precios | Baja inflación, nivel general de precios estable | IPC: costo de una canasta fija de bienes del consumidor medio |
| Tipo de cambio | Morigerar las fluctuaciones | Precio en moneda nacional de una unidad de moneda extranjera |
| Balanza de pagos | Equilibrio externo | Su saldo: hay déficit cuando las importaciones superan a las exportaciones |
| Déficit público | Equilibrio de las cuentas públicas | Diferencia entre gastos públicos e ingresos públicos |

## Objetivo no es lo mismo que instrumento

> "Un instrumento de política económica es una variable controlada por las autoridades económicas que puede influir en uno o en varios objetivos."

| Política | Instrumentos |
|---|---|
| Fiscal | Gasto público · Impuestos |
| Monetaria | Cantidad de dinero · Tasas de interés |
| Comercial y cambiaria | Aranceles · Tipo de cambio |
| De oferta | Capital · Trabajo · Tecnología |
| Otras variables | Nivel de precios y costos · Producción potencial |

```mermaid
flowchart LR
    F["<b>Política fiscal</b><br/>gasto público<br/>impuestos"] --> DA["<b>Nivel de actividad</b><br/>y nivel de precios"]
    M["<b>Política monetaria</b><br/>cantidad de dinero<br/>tasa de interés"] --> DA
    C["<b>Comercial y cambiaria</b><br/>aranceles<br/>tipo de cambio"] --> DA
    O["<b>Políticas de oferta</b><br/>capital, trabajo,<br/>tecnología"] --> DA
    DA --> OB["<b>OBJETIVOS</b><br/>crecimiento · precios estables<br/>empleo · cuentas equilibradas"]
    style F fill:#FFA726,color:#fff
    style M fill:#FFA726,color:#fff
    style C fill:#4DB6AC,color:#fff
    style O fill:#4DB6AC,color:#fff
    style OB fill:#7C5CFF,color:#fff
```

## Conexiones

- [[Microeconomía y Macroeconomía]] — la división de aguas que se planteó en U1; acá se desarrolla el lado macro
- [[Producto Bruto Interno]] — el indicador con el que se mide el primero de los objetivos
- [[Política Fiscal]] — el primer juego de instrumentos: gasto público e impuestos
- [[Política Monetaria]] — el segundo: cantidad de dinero y tasa de interés
- [[Inflación]] — un objetivo con nota propia, porque se mide y se ataca de forma específica
- [[Balanza de Pagos y Mercado de Divisas]] — donde se resuelven a la vez dos objetivos: sector externo y tipo de cambio

## En el parcial

Es la pregunta de apertura típica. **Enumerar los seis objetivos con el indicador de cada uno y,
dado un instrumento suelto (por ejemplo "coeficiente de caja" o "arancel a la importación"),
decir a qué política pertenece.** El error clásico es mezclar las dos listas: "baja inflación" es
un **objetivo**, "tasa de interés" es un **instrumento**. Si en la respuesta ponés la producción
potencial como objetivo, perdiste el punto: el material la lista entre las variables-instrumento.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

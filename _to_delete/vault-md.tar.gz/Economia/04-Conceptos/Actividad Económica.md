---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos]
---

# Actividad Económica

> La interacción entre **unidades productoras** y **unidades consumidoras**, mediada por el
> intercambio.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

```mermaid
flowchart LR
    I["<b>INSUMOS</b><br/>Factores de producción<br/>K · L · RN"] --> P["<b>PRODUCCIÓN</b>"]
    P --> S["<b>PRODUCTO</b><br/>Bienes y servicios"]
    PR["PRODUCTORES"] <-->|INTERCAMBIO| CO["CONSUMIDORES"]
    style I fill:#4DB6AC,color:#fff
    style P fill:#7C5CFF,color:#fff
    style S fill:#FFA726,color:#fff
```

El esquema del teórico tiene dos lecturas superpuestas:

1. **La transformación**: los factores de producción entran como insumos, la producción los
   transforma, y salen bienes y servicios.
2. **El circuito**: productores y consumidores se encuentran en el intercambio. No es una
   flecha en un solo sentido — los consumidores son a la vez los dueños de los factores
   (aportan su trabajo, su capital) y los destinatarios del producto.

Esa segunda lectura es el germen del **flujo circular del ingreso** que se formaliza en la U4
de Macroeconomía.

## Conexiones

- [[Factores de Producción]] — son los insumos que entran al circuito
- [[Función de Producción]] — la formalización matemática de la caja "PRODUCCIÓN" de este esquema
- [[Sistemas de Organización Económica]] — definen cómo se coordina el intercambio: por precios o por autoridad
- [[Problema Económico de Toda Sociedad]] — el "para quién producir" se resuelve del lado de los consumidores

## En el parcial

Reproducir el esquema insumos → producción → producto e identificar los factores. Es de las
pocas cosas de la U1 que se piden dibujadas.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados]
---

# Maximización de Beneficios

> **$IMg = CMg$.** Es la regla que vale para *cualquier* estructura de mercado —competencia
> perfecta, monopolio, oligopolio— y lo que cambia entre una y otra no es la regla, es de dónde
> sale el precio.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## El planteo

El objetivo de toda empresa es maximizar su beneficio:

$$B(Q) = IT(Q) - CT(Q)$$

Se maximiza donde la derivada se anula:

$$\frac{dB}{dQ} = \frac{dIT}{dQ} - \frac{dCT}{dQ} = 0 \quad \Longrightarrow \quad IMg = CMg$$

Es decir: el beneficio es máximo cuando el ingreso marginal (lo que suma vender una unidad más)
iguala al costo marginal (lo que suma producirla).

## Los tres ingresos

| Concepto | Definición | Fórmula |
|---|---|---|
| **Ingreso total ($IT$)** | La cantidad total pagada por los compradores y recibida por los vendedores | $IT = P \times Q$ |
| **Ingreso medio ($IMe$)** | Ingresos totales divididos la cantidad vendida | $IMe = \dfrac{IT}{Q}$ |
| **Ingreso marginal ($IMg$)** | El cambio en los ingresos totales que ocasiona vender una unidad adicional | $IMg = \dfrac{\Delta IT}{\Delta Q}$ |

## El principio marginal, en la versión que se usa

No hace falta derivar nada para aplicarlo: alcanza con comparar.

| Si… | Conviene… | Porque |
|---|---|---|
| $IMg > CMg$ | **Aumentar** la producción | Cada unidad extra suma más de lo que cuesta |
| $IMg < CMg$ | **Reducir** la producción | Cada unidad extra cuesta más de lo que suma |
| $IMg = CMg$ | Quedarse ahí | Es el máximo |

## La misma condición vista con curvas totales

> "La maximización de beneficio desde un análisis de Ingresos Totales y Costos Totales ocurre en el punto en el que la **diferencia** entre las curvas de $IT$ y $CT$ es máxima, y esto ocurre cuando la pendiente de ambas curvas son iguales, es decir, cuando $IMg = CMg$."

Y ahí está el puente entre los dos gráficos: la pendiente de $IT$ **es** el $IMg$; la pendiente
de $CT$ **es** el $CMg$. Máxima distancia vertical entre dos curvas = tangentes paralelas.

```mermaid
flowchart TD
    A["<b>B(Q) = IT(Q) &minus; CT(Q)</b>"] --> B["Gráfico de TOTALES<br/>máxima distancia vertical<br/>entre IT y CT"]
    A --> C["Gráfico de MARGINALES<br/>cruce de las curvas"]
    B --> D["Pendiente de IT<br/>= pendiente de CT"]
    C --> E["<b>IMg = CMg</b>"]
    D --> E
    E --> F["Competencia perfecta:<br/>IMg = P, entonces P = CMg"]
    E --> G["Monopolio:<br/>P &gt; IMg = CMg"]
    style A fill:#4DB6AC,color:#fff
    style E fill:#7C5CFF,color:#fff
    style F fill:#FFA726,color:#fff
    style G fill:#FFA726,color:#fff
```

## La nota que vale oro

> "La condición que maximiza beneficios es **independiente del número de integrantes del mercado**."

O sea: $IMg = CMg$ vale igual para el productor agrícola atomizado y para el monopolista. Lo que
cambia entre estructuras es **cuánto vale el $IMg$**: en [[Competencia Perfecta]] el $IMg$ es el
precio de mercado (y por eso la regla se escribe $P = CMg$), mientras que en [[Monopolio]] el
$IMg$ es menor que el precio (y por eso $P > IMg = CMg$).

## Conexiones

- [[Costo Marginal]] — es la mitad de la condición, y viene entero de la teoría de costos de U2
- [[Relación entre Costo Marginal y Costo Medio]] — para saber si en el $Q$ óptimo hay beneficio o pérdida hay que mirar el costo medio
- [[Competencia Perfecta]] — mismo principio con $IMg = P$: la regla se reduce a $P = CMg$
- [[Monopolio]] — mismo principio, pero el precio se lee en la curva de demanda y queda por encima del $CMg$
- [[Equilibrio de Mercado]] — la condición $P = CMg$ de la empresa es una de las dos mitades del equilibrio
- [[Punto de Equilibrio]] — el mismo cruce de $IT$ y $CT$, pero buscando dónde el beneficio es **cero** en lugar de máximo

## En el parcial

**Escribir $B(Q) = IT - CT$, derivar y llegar a $IMg = CMg$, y después explicar el mismo
resultado en el gráfico de totales** (máxima diferencia vertical = pendientes iguales). Después
aplicarlo: si te dan una tabla de $Q$, $IT$ y $CT$, calcular $IMg$ y $CMg$ columna por columna y
señalar la fila donde se cruzan. El error clásico es buscar el $Q$ donde el $CMg$ es **mínimo**
o donde el $IT$ es **máximo**: ninguno de los dos es el óptimo — el óptimo es donde se cruzan
marginal con marginal.

---
Fuente: `SEGUNDO PARCIAL — Google Docs, sección Unidad 3`, con `Resumen temas coloquio` y el manuscrito `MERCADOS` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

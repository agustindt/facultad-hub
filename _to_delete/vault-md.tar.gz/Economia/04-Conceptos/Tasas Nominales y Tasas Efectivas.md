---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, tasas]
---

# Tasas Nominales y Tasas Efectivas

> La TNA es la tasa **de pizarrón**; la TEA es la que realmente terminás pagando o ganando.
> Se separan porque el **período de capitalización no coincide con el período de referencia de
> la tasa**.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## El problema que resuelven

El apunte lo enuncia en una línea, y es la línea entera del tema:

> "Periodo de capitalización ≠ periodo de referencia de la tasa."

Si el banco te informa una tasa anual pero capitaliza mensualmente, esos intereses mensuales
generan intereses (ver [[Interés Simple e Interés Compuesto]]). La tasa anunciada se queda
corta: hace falta otra que incluya ese efecto.

## Las tres tasas

| Tasa | Qué es | Incluye… | **Unidad** |
|---|---|---|---|
| **TNA** — Tasa Nominal Anual | "la tasa de interés de referencia que un banco o entidad financiera te informa anualmente (ej. 'Plazo fijo al 40 % TNA'). Es una tasa 'de pizarrón'" | Nada más que sí misma; **no** la capitalización | % anual |
| **TEA** — Tasa Efectiva Anual | "la tasa que realmente terminas pagando o ganando en un año, una vez que se considera el efecto del interés compuesto (la capitalización)" | La capitalización | % anual |
| **Tasa real** | "Muestra la relación entre la tasa de interés y la inflación proyectada. Te dice si realmente estás ganando o perdiendo poder adquisitivo" | La inflación (ver [[Inflación e Interés]]) | % anual |

## La fórmula

$$TEA = \left(1 + \frac{TNA}{n}\right)^{n} - 1$$

- **TNA** — tasa nominal anual, en **tanto por uno** (0,40 y no 40 %)
- **n** — cantidad de **períodos de capitalización dentro del año** (12 si capitaliza
  mensualmente, 4 si trimestralmente, 365 si diariamente)
- **TEA** — tasa efectiva anual, resultado en **tanto por uno**; para leerla como porcentaje,
  multiplicá por 100

El cociente $TNA/n$ es la **tasa efectiva del período de capitalización**: es la que
realmente se aplica cada mes o cada trimestre. La segunda fuente escribe la misma fórmula
llamando $m$ a los períodos de capitalización.

## Capitalización continua

> "Si la frecuencia de capitalización aumenta, el monto compuesto resultante también aumenta. Cuando 'n' aumenta en forma indefinida (tiende a infinito), el monto compuesto tiende a un valor límite."

O sea: cuanto más seguido capitaliza, más te cobran (o más ganás) para una misma TNA — pero
**no crece sin techo**, converge a un límite.

## Faltante

El apunte nombra la capitalización continua pero **no escribe la fórmula del límite** ni la
tasa continua equivalente. Tampoco da un ejemplo numérico de pasaje TNA → TEA, ni la fórmula
inversa (TEA → TNA), ni la tasa efectiva de un período distinto del anual (mensual,
trimestral).

## Conexiones

- [[Interés Simple e Interés Compuesto]] — la brecha TNA/TEA existe únicamente porque hay capitalización compuesta
- [[Costo Financiero Total]] — el paso siguiente: la TEA todavía no incluye gastos ni impuestos
- [[Inflación e Interés]] — la tasa real es la tercera pata; TEA descontada de inflación
- [[Valor del Dinero en el Tiempo]] — la tasa es el precio del tiempo, y acá se ve que ese precio depende de cómo lo cortes
- [[Fuentes de Financiamiento]] — comparar alternativas de financiamiento exige llevarlas todas a la misma tasa

## En el parcial

**Explicar por qué TNA ≠ TEA en una frase (el período de capitalización no es el de la tasa) y
calcular la TEA a partir de una TNA y una frecuencia de capitalización.** Fijate en dos cosas:
que la TNA entre a la fórmula en tanto por uno, y que $n$ sea la cantidad de capitalizaciones
**por año**, no la cantidad de años.

Y la trampa conceptual: **para comparar dos préstamos no alcanza con la TEA** — hay que ir al
[[Costo Financiero Total]], que suma gastos e impuestos.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, costos]
---

# Costeo Variable

> También llamado **costeo directo** o **marginal**. Sólo inventaria los costos variables: *"los
> costos variables representan los costos de **producir**, mientras que los fijos los costos de
> **permanecer o estar**"*. Los CIF fijos se van derecho al resultado del período — al revés que
> en [[Costeo por Absorción]].

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## La definición y su lógica

> "COSTEO VARIABLE O COSTEO DIRECTO separa los costos fijos de los variables. (…) Se considera que **la producción que no se vende es una variación de los bienes de la empresa**, por lo que el estudio se debe sólo a la producción **vendida**. Es un Costeo marginal o variable: **una unidad más**."

Esa última frase es la bisagra con la U2: "una unidad más" es literalmente la pregunta del
[[Costo Marginal]]. El costeo variable responde *cuánto cuesta producir una unidad adicional* —
y la respuesta es **sólo los variables**, porque los fijos se pagan igual: "(como el alquiler de
planta o sueldos del personal fijo) **no se asignan a los productos**, sino que se reconocen como
gasto del período".

## Los dos conceptos de gestión que sólo aparecen acá

**Contribución marginal:** "la diferencia entre las ventas totales y los costos variables totales.
Representa el dinero que queda disponible para **cubrir los costos fijos y generar una utilidad**".

$$CM = \text{Ventas totales} - \text{Costos variables totales}$$

**Punto de equilibrio:** "el nivel de ventas (en unidades o en dinero) en el que la empresa **no
gana ni pierde** dinero, es decir, sus ingresos totales son iguales a sus costos totales".

```mermaid
flowchart LR
    V["<b>VENTAS</b>"] --> CM["<b>CONTRIBUCIÓN<br/>MARGINAL</b>"]
    CV["- Costos variables<br/>totales"] --> CM
    CM --> CF["cubre primero<br/>los COSTOS FIJOS"]
    CF --> PE["si alcanza justo:<br/><b>PUNTO DE EQUILIBRIO</b>"]
    CF --> U["si sobra:<br/><b>UTILIDAD</b>"]
    style CM fill:#7C5CFF,color:#fff
    style CF fill:#FFA726,color:#fff
    style PE fill:#4DB6AC,color:#fff
    style U fill:#4DB6AC,color:#fff
```

El orden importa: la contribución marginal **primero tapa los fijos**, y recién lo que sobra es
ganancia. Por eso este método hace visible el punto de equilibrio y el de absorción no.

## Absorción vs. variable — la tabla que hay que saber

Textual del apunte:

> "En el costeo por absorción, **todos los costos son inventariables**, mientras que en costeo variable **sólo se tiene en cuenta los costos de fabricación variables** a la hora de calcular el CMV, siendo los CF considerados como **costos del período**."

| | **Costeo por absorción** | **Costeo variable** |
|---|---|---|
| Otro nombre | Costeo total / completo | Costeo directo o marginal |
| Costos **variables** de fabricación | Inventariables | Inventariables |
| Costos **fijos** de fabricación (CIF fijos) | **Inventariables**: entran al producto | **Gasto del período**: van al resultado del mes |
| Administración, ventas, financiación | Gasto del período | Gasto del período |
| Qué hay dentro del CMV | Costos de fabricación fijos **y** variables | Sólo los costos de fabricación **variables** |
| Conceptos de gestión que aporta | — | Contribución marginal y punto de equilibrio |
| Lógica de fondo | Todo lo fabricado costó, y ese costo viaja con el producto | Los fijos son "costos de estar", no de producir |

**Lo único que cambia de casillero es la fila del medio.** Todo lo demás es idéntico.

## Faltante

No hay **ejemplo numérico**: ni un estado de resultados armado por los dos métodos, ni la
comparación cuando producción ≠ ventas. Tampoco aparece la **fórmula** del punto de equilibrio,
sólo su definición verbal — para calcularlo hay que ir a [[Punto de Equilibrio]]. Y no se dice si
este costeo es admisible para los estados contables o si es sólo de uso interno.

## Conexiones

- [[Costeo por Absorción]] — el método espejo: mismo trato a los variables, trato opuesto a los CIF fijos. Es **la** comparación del bloque
- [[Costo Marginal]] — "una unidad más" es la pregunta de U2, respondida con criterio contable
- [[Costos Fijos Variables y Totales]] — este método **necesita** los costos ya partidos en fijos y variables
- [[Punto de Equilibrio]] — el concepto que este costeo hace visible, y donde está la fórmula que acá falta
- [[Contabilidad de Costos]] — el análisis de cuentas (fijas, variables o mixtas) es el paso previo

## En el parcial

**Calcular la contribución marginal (ventas totales – costos variables totales) y explicar para qué
sirve: cubrir los costos fijos y, recién después, generar utilidad.** Y la pregunta gemela de la
nota de absorción: **qué hace cada método con los CIF fijos**. El error clásico es definir la
contribución marginal como "ganancia": es lo que queda **antes** de tapar los fijos. Segundo error:
creer que "costeo directo" significa "sólo costos directos" — significa sólo **variables**.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, precios]
---

# Inflación

> **Aumento generalizado y sostenido del nivel de precios de una economía.** Las dos palabras
> hacen el trabajo: *generalizado* (no es un producto el que sube) y *sostenido* (no es un salto de
> un mes).

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## La definición y sus dos filtros

| Filtro | Qué excluye |
|---|---|
| **Generalizado** | Que suba un producto —o unos pocos— no es inflación |
| **Sostenido / persistente** | Un salto puntual de precios tampoco lo es |

La consecuencia inmediata, que es el efecto que hay que nombrar primero: **el dinero pierde poder
adquisitivo**.

## Cómo se mide: el IPC

> "El índice de precios al consumidor (IPC) mide el costo de una canasta fija de bienes generalmente adquiridos por el consumidor medio."

Y la inflación es la variación de ese índice:

> "La inflación, medida por el IPC, es la tasa de variación porcentual que experimenta este índice en el periodo de tiempo considerado."

$$\pi = \frac{IPC_t - IPC_{t-1}}{IPC_{t-1}} \times 100$$

Cada término: $IPC_t$ es el costo de la canasta hoy, $IPC_{t-1}$ el de la misma canasta —**la
misma**, por eso es fija— en el período anterior. La resta es cuánto se encareció; dividir por el
valor anterior la vuelve porcentaje comparable.

El material agrega el detalle metodológico: "Tradicionalmente, el IPC se ha calculado aplicando un
índice de **Laspeyres** convencional."

## Efectos

| Efecto | En qué se traduce |
|---|---|
| Pérdida del poder adquisitivo | Con el mismo dinero se compra menos |
| Distorsión de precios | Los precios relativos dejan de informar bien |
| Afecta el ahorro y la inversión | Las decisiones de largo plazo se vuelven difíciles |

## De dónde sale la inflación, según el resto de la unidad

Esta nota no vive sola: la unidad la explica desde el lado de la demanda, en tres lugares
distintos que conviene tener juntos.

| Origen | Qué dice el material |
|---|---|
| Política monetaria expansiva | "Los precios no deberían subir siempre que las empresas sean capaces de producir todo lo que se demanda… Si esto no ocurre, hay inflación" |
| Política fiscal expansiva | Al aumentar el gasto público y bajar los impuestos, "se tiende al déficit o incluso puede provocar inflación" |
| Desempleo bajo | "Un nivel bajo de desempleo se asocia con una demanda agregada alta, que a su vez ejerce presión al alza en los salarios y los precios de toda la economía" |

El hilo común: **demanda agregada por encima de lo que la economía puede producir**. Ese techo es
el de [[Producción Potencial y Brecha]].

## Faltante

El material **no** desarrolla:

- la clasificación por intensidad (moderada, galopante, hiperinflación);
- la distinción entre inflación de demanda y de costos como categorías con nombre —el mecanismo de
  costos aparece descrito en la oferta agregada, pero nunca se lo llama así—;
- la fórmula del índice de Laspeyres: el procedimiento de cálculo estaba en una imagen del apunte;
- indexación, expectativas de inflación y cualquier dato de la economía argentina.

## Conexiones

- [[PBI Nominal y PBI Real]] — la inflación es exactamente lo que separa a los dos, y por eso el crecimiento se mide en términos reales
- [[Desempleo y Curva de Phillips]] — la disyuntiva de corto plazo entre inflación y desempleo
- [[Política Monetaria]] — combatirla es el objetivo declarado del Banco Central
- [[Política Fiscal]] — una política expansiva puede provocarla; una restrictiva se aplica para frenarla
- [[Producción Potencial y Brecha]] — el potencial se define, precisamente, como el máximo compatible con precios estables
- [[Inflación e Interés]] — en U6 se ve cómo la inflación corrige las tasas de interés en los proyectos

## En el parcial

**Definir inflación con los dos filtros (generalizado y sostenido), decir con qué se mide y
calcular la tasa a partir de dos valores del IPC.** Después, el enganche: explicar por qué un
aumento del PBI nominal mayor que la inflación es crecimiento y uno menor es caída. El error
clásico es llamar inflación a la suba de un solo bien; el segundo, confundir el **nivel** del
índice con la **variación** del índice —la inflación es siempre la variación.

---
Fuente: `MACROECONOMIA — manuscrito iPad, nov 2025`, con aportes de `UNIDAD 4 — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos]
---

# Relación entre Costo Marginal y Costo Medio

> **La curva de costo marginal corta a la de costo medio en su mínimo.** Siempre. No es una
> casualidad del dibujo: es una necesidad matemática.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## La regla

Textual, y es de las frases más citables de la unidad:

> "La curva de costos marginales ha de cortar la curva de costos medios **en su mínimo**."

Y el mecanismo:

> "Si la producción de una unidad adicional hace **disminuir** el costo medio, el costo marginal será **inferior** al costo medio.
>
> Si la producción de una unidad adicional hace que **aumenten** los costos medios, el costo de esa unidad adicional (costo marginal) será **mayor** que el costo medio."

| Si… | Entonces el costo medio… |
|---|---|
| $CMg < CTMe$ | **baja** |
| $CMg > CTMe$ | **sube** |
| $CMg = CTMe$ | está en su **mínimo** |

```mermaid
flowchart LR
    A["CMg &lt; CMe"] -->|"el marginal tira<br/>el promedio hacia abajo"| B["CMe DESCENDENTE"]
    C["CMg = CMe"] --> D["<b>MÍNIMO del CMe</b>"]
    E["CMg &gt; CMe"] -->|"el marginal tira<br/>el promedio hacia arriba"| F["CMe ASCENDENTE"]
    style D fill:#7C5CFF,color:#fff
    style B fill:#4DB6AC,color:#fff
    style F fill:#FFA726,color:#fff
```

## Por qué, en una frase

**El marginal siempre arrastra al medio hacia sí.** Si lo que agregás vale menos que el
promedio actual, el promedio baja; si vale más, sube. El promedio deja de bajar y empieza a
subir exactamente en el instante en que el marginal lo cruza. Por eso el cruce **es** el
mínimo.

La analogía del promedio de notas funciona perfecto: si tu promedio es 7 y sacás un 9, sube; si
sacás un 5, baja; y si sacás exactamente 7, se queda quieto — que es el punto de inflexión.

<svg viewBox="0 0 440 195" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="169" y2="169" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="172" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="117.3" y2="117.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="120.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="65.7" y2="65.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="68.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">40</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">60</text><line x1="34" x2="34" y1="14" y2="169" stroke="var(--background-modifier-border,#8886)"/><line x1="202.6" x2="202.6" y1="14" y2="169" stroke="#4DB6AC" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="202.6" cy="143.2" r="3.4" fill="#4DB6AC"/><text x="202.6" y="180" text-anchor="middle" font-size="8" fill="#4DB6AC" font-weight="600">CMg=CVMe</text><line x1="255.9" x2="255.9" y1="14" y2="169" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="255.9" cy="121" r="3.4" fill="#7C5CFF"/><text x="255.9" y="180" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600">CMg=CTMe</text><path d="M68.8 27.1 L73.8 38.1 L78.7 47.4 L83.7 55.2 L88.7 61.9 L93.7 67.8 L98.6 73 L103.6 77.6 L108.6 81.8 L113.5 85.5 L118.5 88.9 L123.5 91.9 L128.5 94.7 L133.4 97.3 L138.4 99.6 L143.4 101.8 L148.3 103.8 L153.3 105.6 L158.3 107.3 L163.3 108.8 L168.2 110.3 L173.2 111.6 L178.2 112.8 L183.1 113.9 L188.1 114.9 L193.1 115.8 L198.1 116.6 L203 117.4 L208 118.1 L213 118.7 L217.9 119.2 L222.9 119.6 L227.9 120 L232.9 120.3 L237.8 120.6 L242.8 120.8 L247.8 120.9 L252.7 121 L257.7 121 L262.7 120.9 L267.7 120.8 L272.6 120.7 L277.6 120.4 L282.6 120.2 L287.5 119.8 L292.5 119.5 L297.5 119 L302.5 118.6 L307.4 118 L312.4 117.5 L317.4 116.8 L322.3 116.2 L327.3 115.4 L332.3 114.7 L337.3 113.9 L342.2 113 L347.2 112.1 L352.2 111.1 L357.1 110.1 L362.1 109.1 L367.1 108 L372.1 106.8 L377 105.6 L382 104.4" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="107.4" font-size="9" fill="#7C5CFF" font-weight="600">CTMe</text><path d="M34 120.3 L39 121.7 L43.9 123 L48.9 124.2 L53.9 125.4 L58.9 126.6 L63.8 127.7 L68.8 128.8 L73.8 129.8 L78.7 130.8 L83.7 131.8 L88.7 132.7 L93.7 133.6 L98.6 134.5 L103.6 135.3 L108.6 136.1 L113.5 136.8 L118.5 137.5 L123.5 138.1 L128.5 138.8 L133.4 139.3 L138.4 139.9 L143.4 140.3 L148.3 140.8 L153.3 141.2 L158.3 141.6 L163.3 141.9 L168.2 142.2 L173.2 142.5 L178.2 142.7 L183.1 142.9 L188.1 143 L193.1 143.1 L198.1 143.1 L203 143.2 L208 143.1 L213 143.1 L217.9 143 L222.9 142.8 L227.9 142.7 L232.9 142.4 L237.8 142.2 L242.8 141.9 L247.8 141.5 L252.7 141.1 L257.7 140.7 L262.7 140.3 L267.7 139.8 L272.6 139.2 L277.6 138.7 L282.6 138 L287.5 137.4 L292.5 136.7 L297.5 135.9 L302.5 135.2 L307.4 134.3 L312.4 133.5 L317.4 132.6 L322.3 131.7 L327.3 130.7 L332.3 129.7 L337.3 128.6 L342.2 127.5 L347.2 126.4 L352.2 125.2 L357.1 124 L362.1 122.7 L367.1 121.5 L372.1 120.1 L377 118.7 L382 117.3" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="120.3" font-size="9" fill="#4DB6AC" font-weight="600">CVMe</text><path d="M34 123.3 L39 125.8 L43.9 128.2 L48.9 130.5 L53.9 132.7 L58.9 134.8 L63.8 136.7 L68.8 138.6 L73.8 140.3 L78.7 141.9 L83.7 143.4 L88.7 144.7 L93.7 146 L98.6 147.1 L103.6 148.1 L108.6 149 L113.5 149.7 L118.5 150.4 L123.5 150.9 L128.5 151.3 L133.4 151.6 L138.4 151.7 L143.4 151.8 L148.3 151.7 L153.3 151.5 L158.3 151.2 L163.3 150.8 L168.2 150.2 L173.2 149.6 L178.2 148.8 L183.1 147.9 L188.1 146.8 L193.1 145.7 L198.1 144.4 L203 143 L208 141.5 L213 139.9 L217.9 138.2 L222.9 136.3 L227.9 134.4 L232.9 132.3 L237.8 130 L242.8 127.7 L247.8 125.3 L252.7 122.7 L257.7 120 L262.7 117.2 L267.7 114.2 L272.6 111.2 L277.6 108 L282.6 104.7 L287.5 101.3 L292.5 97.8 L297.5 94.2 L302.5 90.4 L307.4 86.5 L312.4 82.5 L317.4 78.4 L322.3 74.2 L327.3 69.8 L332.3 65.3 L337.3 60.7 L342.2 56 L347.2 51.2 L352.2 46.2 L357.1 41.1 L362.1 36 L367.1 30.6 L372.1 25.2 L377 19.7" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="381.0" y="22.7" font-size="9" fill="#FFA726" font-weight="600">CMg</text><text x="208.0" y="192" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*El CMg corta al CVMe y al CTMe exactamente en sus mínimos. Y el del CTMe queda a la derecha, porque el CFMe sigue empujando hacia abajo un rato más.*


## Es la misma regla que en producción

Ya la viste en [[Producto Total Medio y Marginal]], pero dada vuelta porque ahí se trata de un
máximo y acá de un mínimo:

| | Se cruzan en | Porque |
|---|---|---|
| $PMg$ y $PMe$ | **Máximo** del PMe (óptimo técnico) | La curva media tiene forma de ∩ |
| $CMg$ y $CTMe$ | **Mínimo** del CTMe | La curva media tiene forma de U |

Es una única propiedad matemática de la relación entre una función y su promedio, aplicada dos
veces.

## Ojo con el orden de los cortes

El CMg corta **primero** al CVMe (en su mínimo) y **después** al CTMe (en el suyo). El mínimo
del CTMe está más a la derecha porque el costo fijo medio, que sigue cayendo, empuja al CTMe
hacia abajo un rato más.

## Conexiones

- [[Costo Marginal]] — es una de las dos curvas de la relación
- [[Costos Medios]] — es la otra, y su mínimo es el punto de corte
- [[Producto Total Medio y Marginal]] — la misma relación marginal–medio, del lado de la producción
- [[Escala Mínima Eficiente]] — en el largo plazo, el corte de CMgL con CMeL define la escala eficiente mínima
- [[Máximo Técnico y Óptimo Técnico]] — el óptimo técnico es el análogo exacto de este punto en producción

## En el parcial

Es de las preguntas más probables de toda la unidad, sola o como parte de un gráfico.
**Enunciar la regla, justificarla con el mecanismo de arrastre y dibujar el corte en el
mínimo.** El error clásico es dibujar el CMg cortando al CTMe en cualquier lado.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

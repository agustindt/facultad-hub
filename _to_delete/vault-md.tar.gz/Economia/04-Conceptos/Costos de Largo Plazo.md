---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos, largo-plazo]
---

# Costos de Largo Plazo

> En el largo plazo **no hay factores fijos**: la empresa elige el tamaño de planta. La curva de
> costos de largo plazo es la **envolvente** de todas las curvas de corto plazo.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Textual:

> "A largo plazo, la empresa tiene tiempo suficiente, dados unos precios concretos de los factores, para ajustar la cantidad empleada de la **totalidad** de los factores de producción, de modo que **no existen factores fijos**. En cada nivel de producción, la empresa elegirá el método menos costoso."

De ahí:

- **CTL** — curva de costo total de largo plazo: *"es la **envolvente** de las curvas de costos totales a corto plazo, en el mínimo nivel de costo para cada nivel de producción"*.
- **CMeL** — costo medio de largo plazo: *"muestra el costo medio **mínimo** de producción cuando todos los factores productivos son totalmente variables"*.
- **CMgL** — costo marginal de largo plazo: *"el costo adicional necesario para obtener una unidad más de producción cuando todos los factores son totalmente variables"*.

## Qué significa "envolvente"

Cada **tamaño de planta** tiene su propia curva de costo medio de corto plazo (CMe1, CMe2,
CMe3…). Para producir una cantidad dada, alguna de esas plantas es la más barata. La CMeL toma,
para cada nivel de producción, **el mínimo de todas**.

> "Cada curva de costos medios de corto plazo **toca dicha curva en un punto y permanece por encima de ella en todos los demás**."

```mermaid
flowchart TD
    Q["Quiero producir Q unidades"] --> P1["Planta chica<br/>CMe1"]
    Q --> P2["Planta mediana<br/>CMe2"]
    Q --> P3["Planta grande<br/>CMe3"]
    P1 --> M["Elijo la planta<br/>de <b>menor costo medio</b><br/>para ese Q"]
    P2 --> M
    P3 --> M
    M --> E["<b>CMeL</b><br/>envolvente de los mínimos"]
    style Q fill:#4DB6AC,color:#fff
    style M fill:#FFA726,color:#fff
    style E fill:#7C5CFF,color:#fff
```

Y de ahí la consecuencia que se toma:

> "Debido a que en el largo plazo la empresa tiene **más flexibilidad**, los costos medios de corto plazo están **por encima** de los costos medios de largo plazo."

Nunca al revés. Tener más opciones no puede empeorar el resultado: en el peor caso, la empresa
elige en el largo plazo la misma planta que tenía.

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">17</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">35</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">52</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><line x1="232.9" x2="232.9" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="232.9" cy="125.5" r="3.4" fill="#7C5CFF"/><text x="232.9" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600">mínimo</text><path d="M34 101.9 L39 103 L43.9 103.9 L48.9 104.8 L53.9 105.5 L58.9 106.1 L63.8 106.6 L68.8 107 L73.8 107.2 L78.7 107.4 L83.7 107.5 L88.7 107.4 L93.7 107.2 L98.6 107 L103.6 106.6 L108.6 106.1 L113.5 105.5 L118.5 104.8 L123.5 103.9 L128.5 103 L133.4 101.9 L138.4 100.8 L143.4 99.5 L148.3 98.1 L153.3 96.6 L158.3 95 L163.3 93.3 L168.2 91.5 L173.2 89.6 L178.2 87.5 L183.1 85.4 L188.1 83.1 L193.1 80.7 L198.1 78.3 L203 75.7 L208 73 L213 70.1 L217.9 67.2 L222.9 64.2 L227.9 61 L232.9 57.8 L237.8 54.4 L242.8 50.9 L247.8 47.3 L252.7 43.6 L257.7 39.8 L262.7 35.9 L267.7 31.9 L272.6 27.7 L277.6 23.5 L282.6 19.1 L287.5 14.7" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 95.4 L39 97.6 L43.9 99.6 L48.9 101.6 L53.9 103.4 L58.9 105.1 L63.8 106.7 L68.8 108.2 L73.8 109.6 L78.7 110.8 L83.7 112 L88.7 113 L93.7 114 L98.6 114.8 L103.6 115.5 L108.6 116.1 L113.5 116.6 L118.5 117 L123.5 117.3 L128.5 117.5 L133.4 117.5 L138.4 117.5 L143.4 117.3 L148.3 117 L153.3 116.6 L158.3 116.1 L163.3 115.5 L168.2 114.8 L173.2 114 L178.2 113 L183.1 112 L188.1 110.8 L193.1 109.6 L198.1 108.2 L203 106.7 L208 105.1 L213 103.4 L217.9 101.6 L222.9 99.6 L227.9 97.6 L232.9 95.4 L237.8 93.2 L242.8 90.8 L247.8 88.3 L252.7 85.7 L257.7 83 L262.7 80.2 L267.7 77.3 L272.6 74.2 L277.6 71.1 L282.6 67.8 L287.5 64.4 L292.5 61 L297.5 57.4 L302.5 53.7 L307.4 49.9 L312.4 46 L317.4 41.9 L322.3 37.8 L327.3 33.5 L332.3 29.2 L337.3 24.7 L342.2 20.1 L347.2 15.4" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 73.8 L39 77.1 L43.9 80.2 L48.9 83.3 L53.9 86.2 L58.9 89 L63.8 91.7 L68.8 94.3 L73.8 96.8 L78.7 99.2 L83.7 101.4 L88.7 103.6 L93.7 105.6 L98.6 107.6 L103.6 109.4 L108.6 111.1 L113.5 112.7 L118.5 114.2 L123.5 115.6 L128.5 116.9 L133.4 118 L138.4 119.1 L143.4 120 L148.3 120.8 L153.3 121.5 L158.3 122.2 L163.3 122.6 L168.2 123 L173.2 123.3 L178.2 123.5 L183.1 123.5 L188.1 123.5 L193.1 123.3 L198.1 123 L203 122.6 L208 122.2 L213 121.5 L217.9 120.8 L222.9 120 L227.9 119.1 L232.9 118 L237.8 116.9 L242.8 115.6 L247.8 114.2 L252.7 112.7 L257.7 111.1 L262.7 109.4 L267.7 107.6 L272.6 105.6 L277.6 103.6 L282.6 101.4 L287.5 99.2 L292.5 96.8 L297.5 94.3 L302.5 91.7 L307.4 89 L312.4 86.2 L317.4 83.3 L322.3 80.2 L327.3 77.1 L332.3 73.8 L337.3 70.5 L342.2 67 L347.2 63.4 L352.2 59.7 L357.1 55.9 L362.1 52 L367.1 47.9 L372.1 43.8 L377 39.6 L382 35.2" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 37.2 L39 41.6 L43.9 45.8 L48.9 50 L53.9 54 L58.9 57.9 L63.8 61.7 L68.8 65.4 L73.8 69 L78.7 72.5 L83.7 75.8 L88.7 79.1 L93.7 82.3 L98.6 85.3 L103.6 88.2 L108.6 91 L113.5 93.7 L118.5 96.3 L123.5 98.8 L128.5 101.2 L133.4 103.5 L138.4 105.6 L143.4 107.6 L148.3 109.6 L153.3 111.4 L158.3 113.1 L163.3 114.7 L168.2 116.2 L173.2 117.6 L178.2 118.9 L183.1 120 L188.1 121.1 L193.1 122 L198.1 122.8 L203 123.6 L208 124.2 L213 124.7 L217.9 125 L222.9 125.3 L227.9 125.5 L232.9 125.5 L237.8 125.5 L242.8 125.3 L247.8 125 L252.7 124.7 L257.7 124.2 L262.7 123.6 L267.7 122.8 L272.6 122 L277.6 121.1 L282.6 120 L287.5 118.9 L292.5 117.6 L297.5 116.2 L302.5 114.7 L307.4 113.1 L312.4 111.4 L317.4 109.6 L322.3 107.6 L327.3 105.6 L332.3 103.5 L337.3 101.2 L342.2 98.8 L347.2 96.3 L352.2 93.7 L357.1 91 L362.1 88.2 L367.1 85.3 L372.1 82.3 L377 79.1 L382 75.8" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M63.8 16.6 L68.8 21.4 L73.8 26.1 L78.7 30.7 L83.7 35.2 L88.7 39.6 L93.7 43.8 L98.6 47.9 L103.6 52 L108.6 55.9 L113.5 59.7 L118.5 63.4 L123.5 67 L128.5 70.5 L133.4 73.8 L138.4 77.1 L143.4 80.2 L148.3 83.3 L153.3 86.2 L158.3 89 L163.3 91.7 L168.2 94.3 L173.2 96.8 L178.2 99.2 L183.1 101.4 L188.1 103.6 L193.1 105.6 L198.1 107.6 L203 109.4 L208 111.1 L213 112.7 L217.9 114.2 L222.9 115.6 L227.9 116.9 L232.9 118 L237.8 119.1 L242.8 120 L247.8 120.8 L252.7 121.5 L257.7 122.2 L262.7 122.6 L267.7 123 L272.6 123.3 L277.6 123.5 L282.6 123.5 L287.5 123.5 L292.5 123.3 L297.5 123 L302.5 122.6 L307.4 122.2 L312.4 121.5 L317.4 120.8 L322.3 120 L327.3 119.1 L332.3 118 L337.3 116.9 L342.2 115.6 L347.2 114.2 L352.2 112.7 L357.1 111.1 L362.1 109.4 L367.1 107.6 L372.1 105.6 L377 103.6 L382 101.4" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M118.5 15.4 L123.5 20.1 L128.5 24.7 L133.4 29.2 L138.4 33.5 L143.4 37.8 L148.3 41.9 L153.3 46 L158.3 49.9 L163.3 53.7 L168.2 57.4 L173.2 61 L178.2 64.4 L183.1 67.8 L188.1 71.1 L193.1 74.2 L198.1 77.3 L203 80.2 L208 83 L213 85.7 L217.9 88.3 L222.9 90.8 L227.9 93.2 L232.9 95.4 L237.8 97.6 L242.8 99.6 L247.8 101.6 L252.7 103.4 L257.7 105.1 L262.7 106.7 L267.7 108.2 L272.6 109.6 L277.6 110.8 L282.6 112 L287.5 113 L292.5 114 L297.5 114.8 L302.5 115.5 L307.4 116.1 L312.4 116.6 L317.4 117 L322.3 117.3 L327.3 117.5 L332.3 117.5 L337.3 117.5 L342.2 117.3 L347.2 117 L352.2 116.6 L357.1 116.1 L362.1 115.5 L367.1 114.8 L372.1 114 L377 113 L382 112" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 101.9 L39 103 L43.9 103.9 L48.9 104.8 L53.9 105.5 L58.9 106.1 L63.8 106.7 L68.8 108.2 L73.8 109.6 L78.7 110.8 L83.7 112 L88.7 113 L93.7 114 L98.6 114.8 L103.6 115.5 L108.6 116.1 L113.5 116.6 L118.5 117 L123.5 117.3 L128.5 117.5 L133.4 118 L138.4 119.1 L143.4 120 L148.3 120.8 L153.3 121.5 L158.3 122.2 L163.3 122.6 L168.2 123 L173.2 123.3 L178.2 123.5 L183.1 123.5 L188.1 123.5 L193.1 123.3 L198.1 123 L203 123.6 L208 124.2 L213 124.7 L217.9 125 L222.9 125.3 L227.9 125.5 L232.9 125.5 L237.8 125.5 L242.8 125.3 L247.8 125 L252.7 124.7 L257.7 124.2 L262.7 123.6 L267.7 123 L272.6 123.3 L277.6 123.5 L282.6 123.5 L287.5 123.5 L292.5 123.3 L297.5 123 L302.5 122.6 L307.4 122.2 L312.4 121.5 L317.4 120.8 L322.3 120 L327.3 119.1 L332.3 118 L337.3 117.5 L342.2 117.3 L347.2 117 L352.2 116.6 L357.1 116.1 L362.1 115.5 L367.1 114.8 L372.1 114 L377 113 L382 112" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="115.0" font-size="9" fill="#7C5CFF" font-weight="600">CMeL</text><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*Cada curva punteada es un tamaño de planta. La CMeL toma el mínimo de todas: la toca en un punto y queda por encima en el resto.*


## CMgL y CMeL

> "La curva de CMgL **corta en su mínimo** la curva de CMeL […] cuando la curva CMgL se encuentra por debajo de CMeL, esta es descendente, mientras que si se encuentra por encima, la curva CMeL es ascendente."

Es exactamente la misma
[[Relación entre Costo Marginal y Costo Medio|relación marginal–medio]] del corto plazo.
Cambia el plazo, no la matemática.

## Conexiones

- [[Corto Plazo y Largo Plazo]] — la definición del largo plazo es lo que hace posible la envolvente
- [[Costos Medios]] — la CMeL se construye tomando el mínimo de todas las curvas de corto plazo
- [[Relación entre Costo Marginal y Costo Medio]] — la misma regla vale entre CMgL y CMeL
- [[Economías y Deseconomías de Escala]] — explican por qué la CMeL tiene forma de U
- [[Sendero de Expansión]] — es de donde salen los pares (cantidad, costo mínimo) que forman esta curva
- [[Escala Mínima Eficiente]] — el mínimo de la CMeL

## En el parcial

Definición de envolvente, **por qué las curvas de corto plazo están siempre por encima**, y el
dibujo con las tres CMe de corto plazo tocando la CMeL en un punto cada una. Es un gráfico que
se pide.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

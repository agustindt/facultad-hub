---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados, competencia]
---

# Competencia Perfecta

> **La empresa es precio-aceptante: enfrenta una demanda horizontal y su única decisión es
> cuánto producir.** Como $P = IMe = IMg$, la regla de maximización se simplifica a
> $P = CMg$. Es el modelo más eficiente y sirve de referencia teórica para todo lo demás.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Los cuatro supuestos

| Supuesto | Qué significa |
|---|---|
| **Precio-aceptante** | La empresa no puede influir en el precio (mercado atomizado: muchos oferentes y demandantes) |
| **Bien homogéneo** | Todos venden exactamente el mismo producto |
| **Transparencia informativa** | Todos conocen precios y condiciones |
| **Libre entrada y salida** | No hay barreras para entrar ni para irse |

Consecuencia inmediata: la curva de demanda que enfrenta **cada empresa** es **horizontal**
(perfectamente elástica). Puede vender la cantidad que decida al precio de mercado, porque su
peso individual no es significativo. Ojo con no confundir esa demanda horizontal de la *empresa*
con la demanda de pendiente negativa de la *industria*.

## La regla de producción

Como la empresa vende toda unidad al mismo precio:

$$P = IMe = IMg$$

Y aplicando el principio general de [[Maximización de Beneficios]] ($IMg = CMg$):

$$P = CMg$$

Si alguna empresa decide cobrar un precio superior al del mercado, no vendería nada: otra
empresa se llevaría a los consumidores. Y cada empresa puede vender tanto o tan poco como se lo
permitan sus costos, al precio determinado en el mercado.

## Cierre y salida — la distinción que más se pregunta

| | **Cierre** | **Salida** |
|---|---|---|
| Plazo | Corto plazo | Largo plazo |
| Qué es | No producir nada durante un período específico, por las condiciones actuales del mercado | Abandonar definitivamente el mercado |
| Condición | $P < CVMe$ (los ingresos no cubren ni los costos variables) | $P < CTMe$ (los ingresos no cubren los costos totales) |
| Costos que igual paga | **Sí paga los costos fijos**: se vuelven costo hundido | No paga ningún costo |

Un **costo hundido** es un costo en el que ya se incurrió y no se puede recuperar. Por eso al
decidir el cierre de corto plazo el costo fijo **no cuenta**: lo pagás produzcas o no.

## Las curvas de oferta de la empresa

| Plazo | La curva de oferta es… |
|---|---|
| **Corto plazo** | El tramo de la curva de $CMg$ que está **por encima del $CVMe$** |
| **Largo plazo** | El tramo de la curva de $CMg$ que está **por encima del $CTMe$** |

El punto donde $P = CTMe$ mínimo es el **límite para operar**: ahí el beneficio es cero.

## ¿Se debe cerrar si el beneficio es cero?

**No.** Y el argumento es de los más citables de la unidad: los $CT$ del economista incluyen
todos los **costos de oportunidad** de la empresa (el tiempo y el dinero que los propietarios
invierten en el negocio). Si el beneficio económico es cero, los ingresos totales **ya
compensaron** esos costos de oportunidad.

> En los libros contables se registran los costos **explícitos** (los que requieren desembolso), pero no los **implícitos**. Por eso, en el equilibrio de cero beneficios, el beneficio económico es cero pero la utilidad contable es positiva.

```mermaid
flowchart TD
    P["<b>Precio de mercado</b>"] --> C1{"¿P vs. costos medios?"}
    C1 -->|"P &gt; CTMe"| G["Beneficios<br/>extraordinarios"]
    C1 -->|"P = CTMe"| Z["<b>Beneficio ECONÓMICO = 0</b><br/>límite para operar<br/>(la contable es positiva)"]
    C1 -->|"CVMe &lt; P &lt; CTMe"| L["Pérdidas, pero conviene<br/>seguir produciendo<br/>en el corto plazo"]
    C1 -->|"P &lt; CVMe"| X["<b>CIERRE</b><br/>el costo fijo queda hundido"]
    G --> E["Entran empresas nuevas<br/>&rarr; la oferta se desplaza<br/>&rarr; el precio baja"]
    E --> Z
    style P fill:#4DB6AC,color:#fff
    style Z fill:#7C5CFF,color:#fff
    style X fill:#FFA726,color:#fff
```

## Las lecciones del modelo

- **Sólo el innovador obtiene beneficios superiores a los normales**, y por un tiempo: hasta que actúa la imitación.
- A corto plazo, un aumento de la demanda sube el precio y genera beneficios; una caída de la demanda baja el precio y genera pérdidas.
- Los beneficios extraordinarios **atraen entrada** de nuevas firmas, lo que desplaza la oferta de mercado y baja el precio. El proceso de entrada y salida concluye cuando el precio iguala al costo total promedio: **el número de empresas se ajusta hasta restablecer el equilibrio de cero beneficios**.

## Conexiones

- [[Maximización de Beneficios]] — acá la regla general $IMg = CMg$ se vuelve $P = CMg$ porque $IMg = P$
- [[Costo Marginal]] — la curva de $CMg$ es literalmente la curva de oferta de la empresa competitiva
- [[Costos Medios]] — el $CVMe$ marca el cierre y el $CTMe$ marca la salida y el beneficio cero
- [[Costo Económico]] — sin la distinción entre costo explícito e implícito no se entiende el beneficio cero
- [[Monopolio]] — el modelo opuesto: sirve de contraste para medir la pérdida de eficiencia
- [[Fallas del Mercado]] — la competencia perfecta es la que asigna eficientemente los recursos; una falla es cualquier desvío de eso

## En el parcial

**Distinguir cierre de salida, con la condición de cada uno y el plazo.** Cierre: corto plazo,
$P < CVMe$, el costo fijo queda hundido y se paga igual. Salida: largo plazo, $P < CTMe$, no se
paga nada. Y saber contestar *"¿conviene cerrar con beneficio cero?"* con el argumento del costo
de oportunidad — es una pregunta conceptual habitual y la respuesta correcta es **no**. Tercera
consigna probable: **decir cuál es la curva de oferta de la empresa** y en qué se diferencia la
de corto plazo (sobre el $CVMe$) de la de largo plazo (sobre el $CTMe$).

---
Fuente: `SEGUNDO PARCIAL — Google Docs, sección Unidad 3`, con `ECONOMIA FINAL — camila arenel (feb 2025)` y el manuscrito `MERCADOS` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

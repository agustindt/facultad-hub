---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, costos]
---

# Costeo Basado en Actividades

> La premisa que da vuelta todo: **los productos no consumen costos, consumen actividades; las
> actividades consumen recursos, y son los recursos los que generan los costos.** El producto paga
> por lo que efectivamente hizo consumir, no por una base de prorrateo única.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## La premisa, textual

> "En el COSTEO BASADO EN ACTIVIDADES, los productos no consumen costos, sino **las actividades consumen recursos** y es la disponibilidad y uso de esos recursos lo que generan costos. Es decir, la imputación al producto o servicio será **en función de las actividades** que haya producido o consumido."

En ABC **el objeto de costo es la actividad**: "un evento, una tarea o una unidad de trabajo que
tiene un propósito especificado. De una manera más informal, **las actividades son verbos**: algo
que hace una empresa". *Programar producción. Recibir materiales. Mantener equipos.* Si podés
ponerlo en infinitivo, es una actividad.

```mermaid
flowchart LR
    R["<b>RECURSOS</b><br/>generan los costos"] --> A["<b>ACTIVIDADES</b><br/>los verbos:<br/>recibir, programar,<br/>mantener"]
    A --> P["<b>PRODUCTOS</b><br/>y servicios"]
    CD["<b>Conductor de costo</b><br/>lo que causa el costo<br/>de la actividad"] -.->|"mide cuánto<br/>consume cada uno"| A
    CD -.-> P
    style R fill:#4DB6AC,color:#fff
    style A fill:#7C5CFF,color:#fff
    style P fill:#FFA726,color:#fff
```

## El conductor de costo

> "Un **conductor de costo** causa (o conduce) los costos de una actividad. Es un suceso que afecta al costo de una actividad por tener efecto directo con el consumo de recursos."

Es el **causante** de los costos —o factor de variabilidad— y sirve **para asignar** los costos de
la actividad a los productos.

| Tipo de conductor | Qué mide |
|---|---|
| **De transacción** | La **frecuencia** con que se desarrolla una actividad |
| **De duración** | El **tiempo** requerido para desarrollarla |
| **De intensidad** o imputación directa | La **imputación de los recursos utilizados** |

Y un principio de diseño: hay que buscar un "**intercambio adecuado entre precisión y costo**". Más
conductores = más precisión = más caro de mantener.

## Los cinco pasos del sistema ABC

1. **Se identifican las actividades** de todas las funciones de la cadena de valor: se descompone
   la organización en una estructura de actividades.
2. **Se identifican conductores de costos** asociados a cada actividad.
3. **Se calculan los costos de las actividades individuales** (costo por unidad de conductor).
4. **Se asignan los costos a los objetos de costos** —productos y servicios— con base en la mezcla
   de actividades necesarias para producir cada uno.
5. **Se asignan costos a los productos** multiplicando el costo unitario del conductor por el
   volumen de unidades del conductor consumidas por el producto.

Los pasos 3 y 5 juntos son toda la mecánica de cálculo:

$$\text{Costo asignado} = \frac{\text{Costo de la actividad}}{\text{Unidades del conductor}} \times \text{Unidades consumidas por el producto}$$

## El precio de la precisión

> "El sistema ABC proporciona información de costos **mucho más precisa**, pero su implementación es **más compleja y costosa** que los sistemas tradicionales."

Ése es el trade-off que se pregunta: ABC no es "mejor" sin más. En
[[Costeo por Órdenes y por Procesos]] el CIF se reparte con una base única; en ABC, por tantos
conductores como actividades relevantes haya.

## Faltante

**No hay ejemplo numérico** de una asignación ABC completa, ni una comparación resuelta contra el
prorrateo tradicional. Tampoco se desarrolla el concepto de **cadena de valor**, que el paso 1 usa
sin definir.

## Conexiones

- [[Contabilidad de Costos]] — otra respuesta a la misma pregunta: cómo repartir los costos indirectos
- [[Costeo por Órdenes y por Procesos]] — los sistemas tradicionales, que prorratean el CIF con una base única
- [[Costeo por Absorción]] — ABC no discute **qué** costos son inventariables sino **cómo** se asignan
- [[Costeo Variable]] — el otro camino frente al CIF: en vez de repartirlo mejor, sacarlo del producto
- [[Teoría de las Restricciones]] — el otro enfoque que el programa pone al lado del ABC, y que el material no cubre

## En el parcial

**Enunciar la premisa completa —los productos no consumen costos, consumen actividades; las
actividades consumen recursos— y definir conductor de costo con sus tres tipos** (transacción,
duración, intensidad). El error clásico es definir la actividad como "un departamento" o "un centro
de costo": es un **verbo**, algo que la empresa **hace**. Si piden comparar con el costeo
tradicional, la respuesta es el trade-off: más preciso, más complejo y más costoso.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, proyectos]
---

# Tasa de Descuento

> Es **el costo de oportunidad del capital**: el rendimiento mínimo que le exigís a un
> proyecto para que valga la pena hacerlo. Es la tasa con la que se actualiza el flujo de
> fondos, y es el patrón contra el que se mide todo.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Tres nombres para la misma cosa

El apunte la define encadenando igualdades, y ésa es la definición que hay que saber:

> "Tasa de descuento $d$ = costo de oportunidad del capital = TMRA Tasa Mínima de Rendimiento Aceptable (por ej. la rentabilidad económica de la empresa)."

| Nombre | Desde qué ángulo lo mira |
|---|---|
| **Tasa de descuento (d)** | Operativo: es la $i$ que va en el denominador al actualizar |
| **Costo de oportunidad del capital** | Económico: lo que se resigna por no usar la plata en la mejor alternativa |
| **TMRA** — Tasa Mínima de Rendimiento Aceptable | Decisorio: el piso que el proyecto tiene que superar |

El ejemplo que da de TMRA es "la rentabilidad económica de la empresa": si tu empresa ya rinde
tanto, un proyecto que rinda menos te empeora.

## Dónde entra

$$VP = \frac{VF}{(1+d)^n}$$

- **d** — tasa de descuento, en **tanto por uno por período**
- **n** — cantidad de **períodos**
- **VF**, **VP** — en **pesos**

Es la misma fórmula de [[Factores de Equivalencia]]; lo que cambia es de dónde sale la tasa.
Acá no la fija un banco: **la fija quien decide**, según su costo de oportunidad.

## El criterio de inflación: NEUTRA

Dato corto pero preguntable. Textual:

> "Criterio para la tasa de inflación en el Flujo de Fondos: NEUTRA."

## Cómo se usa contra cada indicador

| Indicador | Qué papel juega $d$ |
|---|---|
| [[Valor Actual Neto]] | Es la tasa con la que se actualiza. Si $VAN > 0$, "el proyecto ofrece una rentabilidad mayor que la tasa de descuento adoptada" |
| [[Tasa Interna de Retorno]] | Es la tasa **exigida** con la que se compara la TIR: conviene si la exigida es menor que la TIR |
| Beneficio del Primer Año | El criterio es $BPA > d$; si no, conviene postergar la inversión |

Fijate el patrón: los tres indicadores **no dicen nada solos**. Dicen algo contra $d$. Por eso
elegir mal la tasa de descuento arruina la evaluación entera aunque las cuentas estén bien.

## Faltante

El apunte **no explica cómo se calcula la TMRA**: no menciona costo promedio ponderado del
capital, ni prima por riesgo, ni cómo se ajusta la tasa según el riesgo del proyecto. Sólo da
el ejemplo de "la rentabilidad económica de la empresa".

## Conexiones

- [[Costo de Oportunidad]] — la tasa de descuento es el costo de oportunidad del capital, en número
- [[Valor Actual Neto]] — es la tasa con la que se actualizan los flujos del VAN
- [[Tasa Interna de Retorno]] — la TIR se compara contra esta tasa para decidir
- [[Flujo de Fondos]] — el flujo se arma a valores corrientes y se actualiza con $d$
- [[Inflación e Interés]] — de ahí sale el criterio de inflación neutra
- [[Ratios e Indicadores de Performance]] — la rentabilidad económica de la empresa, que es el ejemplo de TMRA, sale de ahí

## En el parcial

**Definir la tasa de descuento por sus tres nombres (tasa de descuento = costo de oportunidad
del capital = TMRA) y explicar por qué el VAN de un proyecto depende de ella.** Es una
pregunta corta de teoría que aparece pegada al VAN.

El error conceptual que se busca: creer que $d$ es "la tasa del banco". No: es la tasa que
**exige el decisor**, su costo de oportunidad. Y ojo con la consecuencia práctica: **si $d$
sube, el VAN baja** — actualizás más fuerte los flujos futuros.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

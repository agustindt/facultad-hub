---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, impuestos]
---

# Impuestos: Ganancias e IVA

> **Nota casi vacía a propósito.** El programa pide "impuesto a las ganancias" (tema 11) y el
> material lo menciona apenas de costado: nunca define el impuesto, ni su base, ni su alícuota.
> Del IVA no dice **una sola palabra**.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Todo lo que el material sí dice

Son cuatro menciones sueltas, y conviene tenerlas ubicadas porque son los ganchos por donde el
tema entra a la unidad:

| Dónde aparece | Qué dice, textual |
|---|---|
| Actividades empresariales → Operaciones | "Pago de los impuestos" figura como una de las operaciones de la empresa |
| Contabilidad general | Mide la Δ patrimonial para los accionistas (protección) y para el **Gobierno (base tributaria)** |
| Gastos del período (costeo) | La lista incluye las áreas "**Financieros e impositivos**", con base de distribución % costo de producción o % facturación |
| EBITDA | "*Earnings Before Interest, **Taxes**, Depreciation and Amortization*": la utilidad **sin incorporar** los gastos por intereses, impuestos ni amortizaciones |

De ahí salen dos afirmaciones defendibles y ninguna más:

1. **El impuesto es un gasto del período, no un costo del producto.** Va en el bloque de
   gastos impositivos, junto a los financieros — nunca se inventaría dentro del producto. Ver
   [[Costeo por Absorción]] para la distinción costo inventariable / gasto del período.
2. **El EBITDA se calcula antes del impuesto.** Por eso sirve para "medir la rentabilidad
   operacional" y comparar empresas con cargas fiscales distintas — ver
   [[Ratios e Indicadores de Performance]].

## Faltante

Esto es lo que hay que ir a buscar, listado para no olvidarse:

**Impuesto a las ganancias** — no hay nada sobre: sujetos alcanzados, hecho imponible, las
categorías de ganancias, la diferencia entre ganancia contable y ganancia impositiva (ajustes),
alícuotas vigentes, anticipos, ni cómo se expone en el estado de resultados.

**IVA** — el material **no lo menciona en ninguna línea**. Falta absolutamente todo: qué grava,
débito y crédito fiscal, el mecanismo de saldo a favor / a pagar, alícuotas, la condición de los
sujetos (responsable inscripto, monotributo, exento) y el hecho de que para el responsable
inscripto el IVA **no es un costo** sino un pasivo/crédito.

**Otros tributos** — nada sobre ingresos brutos, impuesto al cheque, tasas municipales ni cargas
sociales, que en un ejercicio de costos aparecen sí o sí.

## Conexiones

- [[Estados Contables Básicos]] — el impuesto a las ganancias es uno de los últimos renglones antes de la utilidad neta, y la utilidad neta es la que alimenta el estado de evolución del patrimonio
- [[Ratios e Indicadores de Performance]] — ROA y ROE se calculan sobre utilidad **neta** (después de impuestos); el EBITDA, **antes**
- [[Contabilidad de Costos]] — los impuestos entran como gasto del período, no como costo del producto
- [[Sistemas de Información Contable]] — la contabilidad general es obligatoria en parte porque le sirve al Gobierno como base tributaria
- [[Política Fiscal]] — el otro lado del mismo peso: acá el impuesto es un egreso de la empresa, allá es el instrumento del Estado
- [[La Empresa y sus Actividades]] — "pago de los impuestos" figura explícitamente entre las operaciones

## En el parcial

Con este material sólo se puede responder lo conceptual: **ubicar el impuesto en el circuito** —
es un **gasto del período** (nunca un costo inventariable del producto), se paga como parte de
las **operaciones**, y el **EBITDA se mide antes de intereses, impuestos y amortizaciones**
justamente para dejarlo afuera. Si el parcial pide liquidar Ganancias o calcular un IVA
débito-crédito, **con esto no se puede**: hay que conseguir el teórico antes. Anotá esta nota
como la primera pregunta para la clase.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, factores]
---

# Mercado de Trabajo

> **La empresa contrata mientras el valor que genera el nuevo trabajador sea mayor que el
> salario que le tiene que pagar.** Toda la teoría del mercado de factores cabe en esa frase: es
> el mismo principio marginal de siempre, aplicado a los insumos en vez de al producto.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## El marco: los mercados de factores

Los recursos principales son la **mano de obra, el capital y el terreno**. Los mercados de
factores son los más relevantes para determinar **cómo y para quién producir** (los de bienes y
servicios determinan **qué** producir).

Su demanda es **derivada**: se genera por la demanda del bien que requiere de ese factor para ser
producido. Nadie demanda trabajo por el trabajo en sí — lo demanda porque hay quien quiere
comprar el producto.

**Valor (ingreso) del producto marginal de un factor:** el ingreso adicional que obtendría una
empresa competitiva utilizando una unidad adicional del factor, manteniendo constantes los
demás. Se calcula multiplicando el producto marginal por el precio del producto. Y la regla
general de contratación: será rentable contratar unidades adicionales **sólo hasta que** el
ingreso adicional que consiga ese factor extra sea mayor o igual al costo marginal que implica
($IPMg = CMg_F$ en el límite).

## El factor mano de obra

**Ingreso producto marginal del trabajo ($IPMg_L$):** el ingreso adicional que resulta de agregar
una unidad más de trabajo, manteniendo constantes los demás factores. Su precio de mercado es el
**salario**.

$$w = PMg_L \times P_{\text{producto}} = IPMg_L$$

| Zona del gráfico | Qué pasa | Qué conviene |
|---|---|---|
| A la **izquierda** del óptimo | El valor que aporta cada nuevo trabajador es **superior** a su salario | Seguir contratando |
| A la **derecha** | El salario es **mayor** que el valor de la producción que genera | Reducir el empleo |
| En el óptimo | $w = IPMg_L$ | Quedarse ahí |

**La curva de demanda de trabajo ES la curva del valor del producto marginal**, porque indica
cuánto trabajo demanda la empresa a cualquier nivel de salario. Tiene pendiente negativa **debido
al producto marginal decreciente** — o sea, la [[Ley de Rendimientos Decrecientes]] es la que le
da la forma.

## Qué desplaza cada curva

| Curva | Qué la desplaza |
|---|---|
| **Demanda de trabajo** | **Precio del bien producido:** si sube, sube el valor del producto marginal y sube la demanda de trabajo. **Avance tecnológico:** normalmente sube el $PMg_L$ y desplaza la demanda a la derecha, aunque también puede reducirla (ejemplo del material: robots industriales baratos) |
| **Oferta de trabajo** | **Preferencias** (si más gente elige trabajar, se desplaza a la derecha), **migración** (fuerte inmigración aumenta la oferta) y **cambio en las oportunidades** (si otro mercado ofrece mejores condiciones, la oferta local se corre a la izquierda) |

La curva de oferta de trabajo refleja cómo responden los trabajadores a la disyuntiva entre
**ocio y trabajo** ante cambios en el costo de oportunidad: un salario más alto induce a ofrecer
más horas, y por eso tiene pendiente positiva.

## El equilibrio y el salario mínimo

Como la demanda refleja el valor del producto marginal, **en equilibrio los trabajadores reciben
el valor de su contribución marginal** a la producción. Por eso todo lo que mueva la oferta o la
demanda modifica el salario de equilibrio y el valor del producto marginal **en la misma
cantidad**: siempre tienen que ser iguales.

> **Nota del material:** una fijación de salario mínimo genera un **exceso de oferta**, es decir un excedente — **aumenta el desempleo**. Si se mejoran los salarios, disminuye la cantidad de empleados.

Es el caso "precio mínimo" de [[Equilibrio de Mercado]] aplicado al trabajo.

```mermaid
flowchart TD
    A["Demanda de un BIEN"] --> B["<b>DEMANDA DERIVADA</b><br/>de trabajo"]
    B --> C["Curva de demanda de trabajo<br/>= valor del producto marginal<br/>pendiente negativa por el PMg decreciente"]
    D["Oferta de trabajo<br/>disyuntiva ocio &ndash; trabajo<br/>pendiente positiva"] --> E["<b>SALARIO DE EQUILIBRIO</b><br/>w = IPMgL"]
    C --> E
    E --> F["El trabajador recibe el valor de su<br/>contribución marginal"]
    G["Salario MÍNIMO<br/>por encima del equilibrio"] --> H["<b>Exceso de oferta<br/>= desempleo</b>"]
    style B fill:#4DB6AC,color:#fff
    style D fill:#4DB6AC,color:#fff
    style E fill:#7C5CFF,color:#fff
    style H fill:#FFA726,color:#fff
```

## Los otros dos factores, en breve

| Factor | Cómo se llama su retribución | Rasgo propio |
|---|---|---|
| **Recursos naturales / tierra** | **Renta** — refleja el valor de su productividad | La cantidad disponible es aproximadamente constante: **oferta inelástica**. El precio lo determina **exclusivamente la demanda**. La *renta económica* es el rendimiento de un factor por encima de su costo de oportunidad |
| **Capital** | **Rendimiento o interés** | La demanda viene de las empresas con proyectos de inversión y la oferta de las economías domésticas; su confrontación determina la **tasa de interés de equilibrio**, que difiere según el riesgo, las garantías y el período de vigencia |

## ⚠️ Faltante

Dos temas del programa que **el material no cubre**:

- **Sindicatos.** No aparecen mencionados en ninguna de las cuatro fuentes. No hay nada sobre negociación colectiva ni sobre su efecto en el salario de equilibrio.
- **Mercado de capitales, rendimientos y riesgo.** Sólo hay una enumeración de activos financieros (dinero y plazos fijos, bonos y letras de renta fija, acciones de renta variable) y de los tres factores que hacen diferir las tasas. No hay tratamiento de la relación rendimiento-riesgo.

## Conexiones

- [[Producto Total Medio y Marginal]] — el $IPMg_L$ es el producto marginal del trabajo multiplicado por el precio del producto
- [[Ley de Rendimientos Decrecientes]] — es la razón de que la curva de demanda de trabajo tenga pendiente negativa
- [[Factores de Producción]] — trabajo, capital y tierra son los recursos cuyos mercados se analizan acá
- [[Equilibrio de Mercado]] — el salario mínimo es el caso "precio mínimo" de aquella tabla, con desempleo como excedente
- [[Clasificación de Mercados]] — los mercados de factores son la otra mitad del esquema, junto a los de bienes y servicios
- [[Desempleo y Curva de Phillips]] — el desempleo que acá aparece como exceso de oferta se retoma del lado macro

## En el parcial

**Escribir la condición de contratación óptima ($w = PMg_L \times P$) y explicar por qué la
curva de demanda de trabajo tiene pendiente negativa** — por el producto marginal decreciente, no
por "gustos" ni por el salario. Segundo ejercicio típico: **dado un cambio (sube el precio del
bien, aparece una nueva tecnología, hay una ola migratoria), decir qué curva se mueve y qué pasa
con el salario y el empleo de equilibrio.** Y saber justificar el efecto del salario mínimo:
exceso de oferta de trabajo, o sea desempleo.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `Resumen temas coloquio` y `SEGUNDO PARCIAL — Google Docs` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

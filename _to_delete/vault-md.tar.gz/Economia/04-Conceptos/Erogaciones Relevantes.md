---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos, costos]
---

# Erogaciones Relevantes

> En un proyecto de cambio **no se costea la empresa: se costea la diferencia**. Sólo entra en
> el flujo lo que cambia entre la situación *sin proyecto* y la situación *con proyecto*.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## La definición

Textual:

> "Erogaciones en inversiones y costos de operación **incrementales**, que marcan una diferencia entre las situaciones antes y después del cambio, o sea, **sin proyecto y con proyecto**."

```mermaid
flowchart LR
    A["Situación<br/><b>SIN PROYECTO</b>"] --> C["<b>DIFERENCIA</b><br/>erogaciones relevantes<br/>= lo único que va al flujo"]
    B["Situación<br/><b>CON PROYECTO</b>"] --> C
    style A fill:#4DB6AC,color:#fff
    style B fill:#FFA726,color:#fff
    style C fill:#7C5CFF,color:#fff
```

El apunte lo ubica en la **ingeniería de proyecto**, y aclara el nivel al que se hace: costos en
proyectos de cambio, **a nivel factibilidad**.

## Las cinco categorías

| Costo relevante | Qué capta |
|---|---|
| **Inversiones** | Lo que hay que desembolsar para hacer el cambio |
| **Desafectación de activos** | Los activos que el cambio deja fuera de uso |
| **Cambios en capital de trabajo** | Lo que el nuevo nivel de operación exige inmovilizar |
| **Cambios en costos de operación** | El diferencial de operar de la manera nueva |
| **Efectos impositivos** | Lo que el cambio mueve en la carga impositiva |

Las dos que más se olvidan son la **desafectación de activos** y los **efectos impositivos**:
son las que no aparecen como una factura nueva, pero cambian el flujo igual.

## Dónde se aplica

Los casos típicos de proyectos de cambio, con lo que cada uno mueve:

- **Nuevo producto**: incorporación de equipos, cambios de layout.
- **Cambios de tecnología**: reemplazo de equipos, reingeniería.
- **Ampliación de capacidad**: incorporación o reemplazo de equipos, ampliación de
  infraestructura.
- **Internalización**.
- **Outsourcing (tercerización)**.

## Conexiones

- [[Tipos de Proyectos]] — el criterio incremental vale para los proyectos de cambio, no para los nuevos
- [[Flujo de Fondos]] — las erogaciones relevantes son exactamente lo que se vuelca en el cash flow del proyecto
- [[Reemplazo de Equipos]] — el caso de U6 donde el razonamiento incremental se ve más limpio
- [[Ciclo del Capital Circulante]] — explica por qué un cambio en el nivel de operación exige más capital de trabajo
- [[Impuestos: Ganancias e IVA]] — los efectos impositivos entran como un costo relevante más
- [[Comparación de Alternativas]] — comparar con y sin proyecto es un caso de comparación de alternativas

## En el parcial

Dado un caso de proyecto de cambio, **decidir qué costos entran al flujo y cuáles no**,
justificando con el criterio *con proyecto vs. sin proyecto*. Y **listar las cinco categorías**.
El error clásico es meter costos que la empresa iba a tener igual sin hacer el proyecto: si no
cambia entre las dos situaciones, **no es relevante**, por más que aparezca en la contabilidad.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

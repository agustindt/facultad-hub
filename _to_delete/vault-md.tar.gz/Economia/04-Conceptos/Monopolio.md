---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados, competencia]
---

# Monopolio

> **Una sola empresa vendiendo un producto sin sustitutos cercanos.** Y de ahí sale todo lo
> demás: si es la única, la curva de demanda del mercado **es** su curva de demanda, y para
> vender más tiene que bajar el precio.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Qué es y por qué aparece

> "Una empresa que es la única que vende un producto que no tiene sustitutos cercanos."

Es el caso extremo de la competencia imperfecta. Las causas que explican su aparición son tres:

| Causa | Detalle |
|---|---|
| **Propiedad exclusiva de ciertos recursos** | Poco común |
| **Monopolio natural** | Existencia de costos decrecientes o economías de escala: una sola empresa produce a un costo menor que un gran número de productores (por ejemplo, la distribución de servicios) |
| **Regulaciones del gobierno** | Concesión a una sola empresa del derecho de fabricar un producto o prestar un servicio: patentes, derechos de propiedad intelectual |

## El rasgo que lo distingue: la elasticidad de la demanda que enfrenta

| | Demanda que enfrenta **la empresa** | Consecuencia |
|---|---|---|
| **Monopolio** | La demanda de todo el mercado, con pendiente negativa | Es **creador** de precios |
| **Empresa competitiva** | Horizontal, con elasticidad precio infinita | Es **tomadora** de precios |

Cuidado con no confundir la elasticidad de la demanda que enfrenta **la firma** con la que
enfrenta **la industria**: en competencia perfecta son distintas, en monopolio son la misma cosa.

## El ingreso marginal: los dos efectos

Cuando el monopolista vende una unidad más, pasan dos cosas opuestas sobre $IT = P \times Q$:

- **Efecto-producto:** se vende más producto, $Q$ es mayor → el ingreso total **aumenta**.
- **Efecto-precio:** para colocar esa unidad hay que bajar el precio, $P$ es menor → el ingreso total **disminuye**.

> "Al vender una unidad más, se obtiene un ingreso adicional, pero también se deja de percibir una parte del ingreso que las unidades anteriores proporcionaban."

Por eso el $IMg$ del monopolista queda **por debajo** del precio. En la empresa competitiva no
hay efecto-precio (vende todo lo que quiera al precio de mercado), y por eso ahí $IMg = P$.
Además: **el monopolista nunca operará voluntariamente donde el $IMg$ sea inferior a cero.**

## El equilibrio, en tres puntos

$$IMg = CMg \qquad \text{y} \qquad P_m > IMg = CMg$$

1. **Punto A** — el cruce $IMg = CMg$ determina la **cantidad** $Q_m$ que maximiza el beneficio.
2. **Punto B** — subiendo desde $Q_m$ **hasta la curva de demanda** se lee el **precio** $P_m$ al que los consumidores pagarán esa cantidad.
3. Con esa combinación, el monopolista obtiene beneficios positivos **si el precio es superior al $CTMe$**.

Como no hay entrada de empresas aunque haya beneficios extraordinarios, **el equilibrio de corto
plazo es también el de largo plazo**.

```mermaid
flowchart TD
    A["<b>PASO 1</b><br/>Cruce IMg = CMg<br/>&rarr; da la CANTIDAD Qm"] --> B["<b>PASO 2</b><br/>Subir desde Qm hasta la<br/>CURVA DE DEMANDA<br/>&rarr; da el PRECIO Pm"]
    B --> C["<b>PASO 3</b><br/>Comparar Pm con CTMe<br/>&rarr; da el BENEFICIO"]
    D["Error clásico:<br/>leer el precio sobre el CMg<br/>en lugar de sobre la demanda"] -.->|"NO"| B
    style A fill:#4DB6AC,color:#fff
    style B fill:#7C5CFF,color:#fff
    style C fill:#FFA726,color:#fff
```

## ¿Puede quebrar un monopolio? Sí

La regla $IMg = CMg$ sólo asegura que, **si obtiene beneficios, serán máximos, y si obtiene
pérdidas, serán mínimas**. Quien decide el resultado es el costo medio:

| Posición de la curva | Resultado |
|---|---|
| $CTMe$ **por debajo** de la demanda | El monopolio disfruta de beneficios |
| $CTMe$ **por encima** de la demanda | Sufre pérdidas |
| Demanda **por debajo** del $CVMe$ para toda cantidad posible | Debe **cerrar** la planta |

## El monopolio no tiene curva de oferta

La curva de oferta indica qué cantidad ofrecen las empresas a cualquier precio dado, y eso tiene
sentido para tomadores de precios. Pero el monopolio es **creador** de precios: asigna el precio
al mismo tiempo que elige la cantidad. Con una demanda fija, su "oferta" es **un único punto**:
la combinación precio-producto para la que $IMg = CMg$.

## El costo social

Comparado con la competencia perfecta, el monopolista **produce menos y cobra más**
($Q_m < Q_c$, $P_m > P_{cp}$, con $P > CMg$). Produce una cantidad **inferior a la socialmente
eficiente**: la demanda refleja el valor que el consumidor le atribuye al bien y el $CMg$ refleja
el costo de producirlo, así que

> el costo social o **pérdida de eficiencia** del monopolio es la suma de las diferencias entre el precio que los consumidores están dispuestos a pagar y el costo marginal, para todas las unidades entre el nivel de producción monopolístico y el competitivo.

## Conexiones

- [[Maximización de Beneficios]] — la regla es la misma; lo que cambia es que acá $P > IMg$
- [[Competencia Perfecta]] — el punto de comparación obligado: menos cantidad y más precio
- [[Economías y Deseconomías de Escala]] — el monopolio natural nace de costos decrecientes, o sea de economías de escala
- [[Discriminación de Precios]] — es la jugada siguiente del monopolista para aumentar todavía más su beneficio
- [[Concentración y Defensa de la Competencia]] — el índice de Lerner mide exactamente el hueco entre $P$ y $CMg$ que abre el monopolio
- [[Fallas del Mercado]] — el monopolio es el caso extremo de la falla "competencia imperfecta"

## En el parcial

**Dibujar el equilibrio del monopolista y marcar los tres puntos en orden:** dónde $IMg = CMg$
(cantidad), de dónde sale el precio (subiendo hasta la **curva de demanda**, no hasta el $CMg$) y
el área del beneficio comparando $P_m$ con el $CTMe$. El error que se lleva más puntos es leer el
precio sobre el $CMg$. Segunda consigna probable: **explicar por qué el $IMg$ está por debajo del
precio** con el efecto-producto y el efecto-precio, y **por qué el monopolio no tiene curva de
oferta**.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `SEGUNDO PARCIAL — Google Docs` y `Resumen temas coloquio` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

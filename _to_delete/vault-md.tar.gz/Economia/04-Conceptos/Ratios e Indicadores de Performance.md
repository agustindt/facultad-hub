---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, finanzas]
---

# Ratios e Indicadores de Performance

> Un ratio es un **cociente entre dos partidas de los estados contables**. Los económicos miden si
> la empresa **gana**; los financieros, si la empresa **puede pagar**. Son preguntas
> independientes: se puede ganar plata y no poder pagar.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Qué son

> "Indicadores cuantitativos obtenidos mediante la relación entre diferentes partidas de los estados financieros de una empresa. Se utilizan para analizar y comparar su rendimiento, liquidez, solvencia, eficiencia operativa, rentabilidad y otros aspectos financieros a lo largo del tiempo o frente a otras empresas."

Se dividen en **económicos, financieros y de valoración de mercado**, y se presentan "en
porcentaje, días o montos, según corresponda".

## Ratios económicos: miden la capacidad de generar resultados

$$\text{Margen Bruto} = \frac{\text{Ventas} - CMV}{\text{Ventas}} \qquad \text{Margen Operativo} = \frac{\text{Utilidad Neta}}{\text{Ventas}}$$

$$ROA = \frac{\text{Utilidad Neta}}{\text{Activos}} \qquad ROE = \frac{\text{Utilidad Neta}}{PN}$$

**Ojo con dos detalles del apunte.** El margen bruto está escrito sin paréntesis
("Ventas – CMV / Ventas"): el numerador es toda la resta. Y el "margen operativo" está definido
con **utilidad neta**, no con utilidad operativa — es lo que trae el material, pero no es la
definición habitual.

### ROA vs. ROE

| | **ROA** | **ROE** |
|---|---|---|
| Nombre largo | Rentabilidad económica / de los activos | Rentabilidad del patrimonio / sobre el capital |
| Denominador | Activos | Patrimonio Neto |
| Qué mide | "Capacidad que tienen los activos de generar renta **independientemente de la estructura financiera**" | "Capacidad que tienen los **recursos propios** de generar beneficio" |
| A quién le importa | El negocio en sí | Los **accionistas** |

La frase que resume la diferencia es "independientemente de la estructura financiera": el **ROA**
dice si el negocio es bueno; el **ROE**, si te conviene como dueño — y eso depende de cómo esté
financiado, ver [[Estructura Financiera de la Empresa]].

### EBITDA

*Earnings Before Interest, Taxes, Depreciation and Amortization* (el apunte lo escribe "EBDITA").
Es "la utilidad **sin incorporar** los gastos por intereses, impuestos, ni amortizaciones, para
evaluar lo que la empresa está ganando o perdiendo **en el núcleo de su negocio**"; también "puede
ser utilizado para determinar el precio de compra o venta de una organización".

La lógica de qué saca: intereses (dependen de cómo te financiaste), impuestos (dependen del fisco)
y amortizaciones (son una ficción contable, ver [[Depreciación]]).

## Ratios financieros: miden la situación financiera

| | **Liquidez** | **Solvencia** |
|---|---|---|
| Definición | Capacidad de "cancelar sus obligaciones **en el corto plazo**" | Capacidad de "atender el pago de los compromisos adquiridos **en el largo plazo**" |
| Cómo se miden | Disponibilidad de efectivo para obligaciones a menos de un año desde el cierre del ejercicio | En forma **agregada** (activos totales vs. pasivos totales) o **desagregada** (por corriente y no corriente) |

**La única variable que las separa es el plazo.** Misma pregunta —¿puede pagar?— a un año o a
más de un año.

## Faltante

- **No hay ni una fórmula de ratio financiero**: liquidez y solvencia están definidas en palabras,
  pero no aparecen la liquidez corriente, la prueba ácida ni ningún índice de endeudamiento.
- **Los ratios de valoración de mercado** se nombran en la clasificación y no se desarrollan.
- **El "tablero de comando financiero"** (tema 18 del programa) **no aparece en ninguna línea**.

## Conexiones

- [[Estados Contables Básicos]] — sin balance no hay ratio: todos son cocientes entre sus partidas
- [[Estructura Financiera de la Empresa]] — la solvencia mide si esa estructura aguanta; el ROA se define por ignorarla
- [[Depreciación]] — el EBITDA existe para sacar del medio las amortizaciones
- [[Ciclo del Capital Circulante]] — CO y CE son los ratios de eficiencia operativa, en días
- [[Maximización de Beneficios]] — el ROE es la traducción contable de aquel objetivo teórico
- [[Impuestos: Ganancias e IVA]] — ROA y ROE van sobre utilidad neta; el EBITDA, antes de impuestos

## En el parcial

**Calcular ROA y ROE con datos de un balance y explicar la diferencia en una frase**: el ROA mide el
rendimiento del activo *independientemente de la estructura financiera*, el ROE lo que rinde la
plata de los accionistas. El error clásico es intercambiar los denominadores. Segunda consigna
probable: **distinguir liquidez de solvencia** — misma pregunta, distinto plazo.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

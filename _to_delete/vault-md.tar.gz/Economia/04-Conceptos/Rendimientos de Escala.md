---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion, largo-plazo]
---

# Rendimientos de Escala

> La respuesta del producto total cuando **todos** los factores se incrementan
> proporcionalmente. Es el fenómeno de **largo plazo**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

> "**Escala** significa el tamaño de la empresa medido por su producción. Los rendimientos de escala reflejan la respuesta del producto total cuando **todos los factores se incrementan proporcionalmente**."

La pregunta que contestan: *¿cuánto varía el producto cuando se varía la cantidad utilizada de
los factores en la misma proporción?*

| Tipo | Qué pasa | Regla práctica | En las isocuantas |
|---|---|---|---|
| **Constantes** | La producción crece proporcionalmente: $X_1 = X_0$ | Duplicar los factores **duplica** la producción | Son **equidistantes** |
| **Crecientes** | Crece **más** que proporcionalmente: $X_1 > X_0$ | Duplicar los factores aumenta **más del doble** | Están **cada vez más cerca** |
| **Decrecientes** | Crece **menos** que proporcionalmente: $X_1 < X_0$ | Duplicar los factores **no llega a duplicar** | Se **alejan** |

> 📌 Ese último dato —cómo se ven en el mapa de [[Isocuanta|isocuantas]]— es un guiño de examen:
> te pueden dar un gráfico con isocuantas y pedirte identificar el tipo de rendimientos
> **sin ninguna cuenta**. Isocuantas que se juntan = rendimientos crecientes.

## La confusión que hay que evitar

**No son la [[Ley de Rendimientos Decrecientes]].** Se parecen en el nombre y son cosas
distintas:

| | Rendimientos decrecientes | Rendimientos decrecientes **de escala** |
|---|---|---|
| **Plazo** | Corto | Largo |
| **Qué varía** | **Un** factor; el resto **fijo** | **Todos** los factores, en la misma proporción |
| **Qué mide** | Producto **marginal** de ese factor | Producto **total** ante un cambio de escala |
| **Concepto asociado** | Etapas de la producción | [[Economías y Deseconomías de Escala]] |

Se puede tener rendimientos decrecientes en el corto plazo y crecientes de escala en el largo
al mismo tiempo, sin ninguna contradicción: son preguntas distintas.

## Del lado de los costos

Los rendimientos de escala son la causa de las
[[Economías y Deseconomías de Escala]]:

- Rendimientos **crecientes** de escala → el costo medio de largo plazo **baja** → economías de escala.
- Rendimientos **decrecientes** de escala → el CMeL **sube** → deseconomías de escala.
- Rendimientos **constantes** → el CMeL no cambia.

## Conexiones

- [[Corto Plazo y Largo Plazo]] — los rendimientos de escala solo existen en el largo plazo
- [[Ley de Rendimientos Decrecientes]] — el fenómeno de corto plazo con el que se confunde
- [[Economías y Deseconomías de Escala]] — es su traducción directa al lenguaje de los costos
- [[Isocuanta]] — el espaciado entre isocuantas revela el tipo de rendimientos
- [[Función de Producción]] — describen cómo responde la función a un cambio proporcional de todos sus argumentos

## En el parcial

Los tres tipos con su definición y la regla del "duplicar". Y **la diferencia con los
rendimientos decrecientes de corto plazo** — es la comparación que más se toma.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

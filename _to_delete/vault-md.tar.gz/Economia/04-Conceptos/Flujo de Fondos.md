---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, proyectos]
---

# Flujo de Fondos

> Es la tabla donde se ordenan ingresos y egresos **por momento**. Sin flujo de fondos no hay
> VAN, no hay TIR y no hay comparación de alternativas: todos los indicadores de la unidad se
> calculan sobre él.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Qué es

Las dos definiciones del apunte, que miran la misma herramienta desde el proyecto y desde la
caja:

> "Es una técnica que permite ordenar y estudiar un hecho económico para establecer anticipadamente los recursos necesarios y evaluar sus posibles resultados."

> "Es un registro detallado de todos los movimientos de dinero (entradas y salidas de efectivo) que tiene una empresa o persona durante un período determinado."

Y cómo se estructura:

> "El flujo de caja se estructura en varias **columnas que representan momentos**, los cuales reflejan los movimientos de caja ocurridos durante un periodo, y los desembolsos que deben ser realizados para que los eventos del periodo siguiente puedan ocurrir."

Esa palabra —**momentos**— es la que conecta con [[Valor del Dinero en el Tiempo]]: cada
columna está fechada, y por eso los números de columnas distintas no se pueden sumar sin
actualizar.

## Los cuatro elementos

| Elemento | Qué entra | **Unidad** |
|---|---|---|
| **Saldo Inicial (SI)** | "El dinero disponible al comenzar el período" | pesos |
| **Ingresos** | "Todas las entradas de efectivo (ventas cobradas, préstamos recibidos, etc.)" | pesos del período |
| **Egresos** | "Todas las salidas de efectivo (pago a proveedores, sueldos, deudas, compras, etc.)" | pesos del período |
| **Saldo Final (SF)** | "El dinero que queda al final del período" | pesos |

```mermaid
flowchart LR
    SI["<b>SALDO INICIAL</b><br/>plata al empezar"] --> OP{"+ Ingresos<br/>− Egresos"}
    OP --> SF["<b>SALDO FINAL</b><br/>plata al cerrar"]
    SF -.->|"es el saldo inicial<br/>del período siguiente"| SI
    SF --> IND["<b>INDICADORES</b><br/>VAN · TIR · PRC · RBC"]
    style SI fill:#4DB6AC,color:#fff
    style OP fill:#FFA726,color:#fff
    style IND fill:#7C5CFF,color:#fff
```

## Para qué se usa

El apunte lista tres usos y conviene distinguirlos porque son tres materias distintas:

1. **Gestionar liquidez** — "Controlar el efectivo disponible para asegurarse de poder pagar
   las obligaciones diarias." Es el uso de corto plazo, el del
   [[Ciclo del Capital Circulante]].
2. **Evaluar proyectos de inversión** — "Proyectar si una inversión generará más ingresos que
   egresos a lo largo del tiempo." Es el uso que da pie al [[Valor Actual Neto]].
3. **Planeamiento financiero** — "Permite anticipar futuros déficits (falta de dinero) o
   superávits (sobrante de dinero) para tomar decisiones, cómo invertir los excedentes de
   dinero o solicitar un préstamo si se prevé la falta de efectivo."

## Cómo se proyecta

> "Se realiza una proyección de ingresos y egresos, **a valores corrientes**. Luego, se pueden realizar análisis calculando distintas medidas de rentabilidad, que tienen en cuenta el valor del dinero en el tiempo y sirven de base para la comparación de alternativas."

Sumale el criterio de inflación que fija el apunte para el flujo: **NEUTRA** (ver
[[Inflación e Interés]] y [[Tasa de Descuento]]).

## Faltante

El apunte **no muestra una planilla modelo** de flujo de fondos, ni trata cómo entran los
impuestos, el IVA o la depreciación en el flujo (la depreciación aparece sólo de pasada en la
decisión de fabricar o comprar). Tampoco define **valor residual** ni el período de análisis,
que son temas del programa.

## Conexiones

- [[Valor Actual Neto]] — se calcula actualizando cada columna del flujo
- [[Tasa Interna de Retorno]] — es la tasa que anula ese mismo flujo actualizado
- [[Valor del Dinero en el Tiempo]] — las columnas son momentos, y por eso hay que actualizar antes de sumar
- [[Ciclo del Capital Circulante]] — el uso de corto plazo del flujo es controlar liquidez
- [[Erogaciones Relevantes]] — qué entra y qué no entra al flujo de un proyecto
- [[Estados Contables Básicos]] — el flujo de fondos es caja, no devengado: no es lo mismo que el resultado contable

## En el parcial

**Armar un flujo de fondos con las cuatro filas (SI, ingresos, egresos, SF) y usarlo como
insumo del VAN.** Si te dan un enunciado con ventas, costos e inversión inicial, lo primero es
ordenarlo por momento: la inversión va en el momento 0 con signo negativo.

Dos cosas que se cobran: el flujo es **caja, no devengado** (va lo cobrado y lo pagado, no lo
facturado), y el **saldo final de un período es el saldo inicial del siguiente** — si no
encadena, hay un error de arrastre.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

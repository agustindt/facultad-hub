---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, contabilidad]
---

# Depreciación

> Hay **dos depreciaciones distintas**: la *funcional* es una pérdida real de capacidad de
> producir; la *contable* es un reparto sistemático del costo del bien a lo largo de su vida útil.
> La segunda es, textual, **"una necesaria ficción contable"**.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Las dos depreciaciones

| | **Funcional** | **Contable** |
|---|---|---|
| Qué es | "Disminución del **valor económico** de un bien de capital por pérdida de capacidad para producir" | "Reconocimiento **racional y sistemático** del costo de los bienes, distribuido durante su vida útil estimada" |
| Para qué | Describe un hecho físico o tecnológico | "Obtener los recursos necesarios para la reposición de los bienes, de manera que se conserve la capacidad operativa o productiva" |

Las **tres causas** de la funcional, que se piden enumeradas:

1. **Desgaste físico** — por el uso del activo en el proceso económico.
2. **Envejecimiento** — desgaste gradual **independiente del funcionamiento** del bien.
3. **Obsolescencia tecnológica** — por mejoras técnicas o nuevos procedimientos.

Aplica a construcciones, instalaciones, equipos y rodados. **Los terrenos no se deprecian** —
esa frase suelta es candidata segura a verdadero/falso.

## Depreciación vs. amortización

Mismo proceso, distinto objeto:

| | **Depreciación** | **Amortización** |
|---|---|---|
| Se aplica a | Activos **fijos** tangibles: máquinas, edificios, rodados | Activos **intangibles** y diferidos: "los que tienen valor, pero que no se puede tocar" (una patente, una marca, gastos pagados por anticipado) |
| Método habitual | Varios, ver abajo | "Normalmente se utiliza el método de **línea recta**" |

## Los métodos contables

| Método | Cómo reparte |
|---|---|
| **Línea recta** | "Distribuye la base de amortización en **partes iguales** a cada año de su vida útil" |
| **Saldo de declinación** | Acelerado: "se aplica un porcentaje constante sobre el valor **no depreciado** del activo" |
| **Servicio prestado** (agotamiento) | "Utiliza unidades ligadas a algún aspecto de **producción, independiente del tiempo**" |
| **Métodos específicos** | El apunte los nombra y no los desarrolla |

Lo que los separa es **contra qué se reparte el costo**: línea recta contra el *tiempo* en partes
iguales, saldo de declinación contra el tiempo pero cargando más al principio, servicio prestado
contra el *uso*.

En el balance, la compra del activo fijo se refleja **positivamente** y la pérdida de valor queda
en una **cuenta negativa acumulada**, período tras período. El bien no se achica: la diferencia
entre las dos cuentas es el **valor de libros**.

## Por qué existe

Es consecuencia directa del criterio de lo devengado, que obliga a capitalizar los activos de
larga vida y depreciarlos durante su vida útil. Y de ahí la frase clave:

> "El concepto de 'depreciación' es una necesaria ficción contable; pero **esta idea de depreciación no existe si se usa el método de lo percibido**."

Bajo lo percibido, comprar una máquina es una salida de plata y se acabó — ver
[[Sistemas de Información Contable]].

## Faltante

**El material no trae las fórmulas** de los métodos: los tres títulos están seguidos de imágenes
que no se transcribieron. Tampoco hay tablas de vida útil ni un ejercicio resuelto. Si el parcial
pide calcular una cuota, esto no alcanza.

## Conexiones

- [[Sistemas de Información Contable]] — la depreciación existe únicamente porque los estados contables usan el criterio de lo devengado
- [[Estados Contables Básicos]] — es lo que hace bajar el activo no corriente vía la cuenta regularizadora
- [[Valuación de Activos]] — el mismo problema de valuación, del lado de los activos circulantes
- [[Costos Fijos Variables y Totales]] — la amortización del equipo es el ejemplo canónico de costo **fijo**
- [[Ratios e Indicadores de Performance]] — el EBITDA se calcula **antes** de amortizaciones, para sacar del medio esta ficción
- [[Costeo por Absorción]] — la depreciación de planta es un CIF fijo, y qué se hace con ella separa absorción de variable

## En el parcial

**Distinguir depreciación funcional de contable en una frase cada una y enumerar las tres causas
de la funcional.** Después, dado un bien, decidir si corresponde depreciación o amortización (¿se
toca o no se toca?) y elegir método por el criterio de reparto: si el enunciado habla de **horas
de uso o unidades producidas**, es servicio prestado. Los dos errores que se repiten: decir que
los **terrenos** se deprecian, y usar "amortización" para una máquina.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

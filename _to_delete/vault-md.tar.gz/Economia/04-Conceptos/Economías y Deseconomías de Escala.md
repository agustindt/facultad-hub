---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos, largo-plazo]
---

# Economías y Deseconomías de Escala

> **Economía de escala**: el costo medio de largo plazo **disminuye** al aumentar la producción.
> **Deseconomía**: aumenta. Es lo que le da forma de U a la CMeL.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

> "Al hablar de **Economía de escala**, se hace referencia a la propiedad según la cual el costo medio a largo plazo **disminuye** conforme se incrementa la producción."

Y la advertencia que la cátedra pone justo al lado, que es la clave conceptual:

> "no debe olvidarse que al hablar de Economía de escala nos estamos refiriendo a la **función de producción** de la empresa."

Es decir: **las economías de escala no son un fenómeno de costos, son un fenómeno de
producción visto en los costos.** Su causa está en los [[Rendimientos de Escala]].

## La tabla que resume todo

| Si aumentar Q requiere un incremento de factores… | Rendimientos | Efecto en CMeL | Nombre |
|---|---|---|---|
| **menos** que proporcional | Crecientes | **Baja** (a mayor Q, menor CMeL) | **Economía de escala** |
| **más** que proporcional | Decrecientes | **Sube** (a mayor Q, mayor CMeL) | **Deseconomía de escala** |
| de la **misma** proporción | Constantes | **No cambia** (a mayor Q, igual CMeL) | Rendimientos constantes |

Textual de la diapositiva, punto por punto:

> "Si un aumento en las cantidades producidas requiere un incremento **menos que proporcional** en los factores de producción, producirá una **disminución en los costos medios** y se dice que existen rendimientos crecientes o **economía de escala** (a mayor Q, menor CMeL);
>
> Si un aumento […] requiere un incremento **más que proporcional** […] producirá un **aumento en los costos medios** y existen rendimientos decrecientes o **deseconomías de escala** (a mayor Q, mayor CMeL);
>
> Si un aumento […] requiere un incremento **de la misma proporción** […] **no producirá cambios** en los costos medios (a mayor Q, igual CMeL)."

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><rect x="34" y="14" width="198.9" height="145" fill="#4DB6AC" opacity=".10"/><text x="133.4" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Economías de escala</text><rect x="232.9" y="14" width="149.1" height="145" fill="#FFA726" opacity=".10"/><text x="307.4" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Deseconomías</text><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">17</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">35</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">52</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><line x1="232.9" x2="232.9" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="232.9" cy="125.5" r="3.4" fill="#7C5CFF"/><text x="232.9" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600">escala mín. eficiente</text><path d="M34 101.9 L39 103 L43.9 103.9 L48.9 104.8 L53.9 105.5 L58.9 106.1 L63.8 106.7 L68.8 108.2 L73.8 109.6 L78.7 110.8 L83.7 112 L88.7 113 L93.7 114 L98.6 114.8 L103.6 115.5 L108.6 116.1 L113.5 116.6 L118.5 117 L123.5 117.3 L128.5 117.5 L133.4 118 L138.4 119.1 L143.4 120 L148.3 120.8 L153.3 121.5 L158.3 122.2 L163.3 122.6 L168.2 123 L173.2 123.3 L178.2 123.5 L183.1 123.5 L188.1 123.5 L193.1 123.3 L198.1 123 L203 123.6 L208 124.2 L213 124.7 L217.9 125 L222.9 125.3 L227.9 125.5 L232.9 125.5 L237.8 125.5 L242.8 125.3 L247.8 125 L252.7 124.7 L257.7 124.2 L262.7 123.6 L267.7 123 L272.6 123.3 L277.6 123.5 L282.6 123.5 L287.5 123.5 L292.5 123.3 L297.5 123 L302.5 122.6 L307.4 122.2 L312.4 121.5 L317.4 120.8 L322.3 120 L327.3 119.1 L332.3 118 L337.3 117.5 L342.2 117.3 L347.2 117 L352.2 116.6 L357.1 116.1 L362.1 115.5 L367.1 114.8 L372.1 114 L377 113 L382 112" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="115.0" font-size="9" fill="#7C5CFF" font-weight="600">CMeL</text><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*A la izquierda del mínimo, economías de escala; a la derecha, deseconomías.*


## Por qué existen (lo que la diapositiva no dice)

La diapositiva da la mecánica pero no las causas, y en la defensa oral o en una pregunta de
desarrollo conviene tenerlas:

- **Economías de escala**: especialización del trabajo, indivisibilidad de ciertos equipos (una
  máquina grande cuesta menos del doble que dos chicas), poder de negociación con proveedores,
  reparto de costos fijos como I+D o marketing entre más unidades.
- **Deseconomías de escala**: complejidad de coordinación, capas de burocracia, pérdida de
  control y de comunicación, dificultad para monitorear.

Lo primero es tecnológico; lo segundo es **organizativo**. Por eso las deseconomías aparecen
recién a escalas grandes.

## Conexiones

- [[Rendimientos de Escala]] — son su causa directa: economías de escala ⟺ rendimientos crecientes
- [[Costos de Largo Plazo]] — explican la forma de U de la CMeL
- [[Escala Mínima Eficiente]] — es justo el punto donde terminan las economías y empiezan las deseconomías
- [[Corto Plazo y Largo Plazo]] — son un fenómeno exclusivamente de largo plazo
- [[Costos Medios]] — la U de corto plazo tiene otra causa (rendimientos decrecientes), no confundir

## En el parcial

La tabla de los tres casos con la relación proporcional ↔ rendimientos ↔ CMeL. Y **la
aclaración de que la causa está en la función de producción**, que es el matiz que la cátedra
subrayó.

⚠️ **No confundir** la U de la CMeL (economías/deseconomías de escala, largo plazo) con la U
del CTMe de corto plazo (rendimientos decrecientes de un factor). Se ven igual y tienen causas
distintas.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

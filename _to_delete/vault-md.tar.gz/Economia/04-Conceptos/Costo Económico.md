---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos]
---

# Costo Económico

> El costo que considera el **costo de oportunidad de todos los recursos** utilizados: lo que
> podrían obtener en su mejor uso alternativo. Incluye costos **explícitos e implícitos**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Textual:

> "EL COSTO viene determinado por el valor de los factores utilizados por la empresa para producir el bien. Costo: **sacrificio de recurso productivo**.
>
> El costo económico considera el **costo de oportunidad de todos los recursos utilizados**, esto es, lo que todos los recursos podrían obtener en su mejor uso alternativo (incluye tanto los costos **explícitos** como los **implícitos**)."

| | **Costos explícitos** | **Costos implícitos** |
|---|---|---|
| Qué son | Pagos efectivos a terceros | Costo de oportunidad de recursos **propios** |
| Ejemplos | Sueldos, alquiler, insumos, energía | El sueldo que el dueño dejó de ganar en otro empleo; el alquiler del local propio; el interés del capital propio invertido |
| ¿Los ve el contador? | Sí | **No** |
| ¿Están en el costo económico? | Sí | **Sí** |

## Por qué esta distinción importa

Es [[Costo de Oportunidad]] de la U1, aplicado a la empresa. Y tiene una consecuencia fuerte:

> **una empresa puede tener beneficio contable positivo y beneficio económico negativo.**

Si el dueño gana \$100.000 al año con su negocio, pero podría ganar \$150.000 en relación de
dependencia y además tiene inmovilizado un capital que rentaría \$40.000, el contador dice que
gana \$100.000 y la economía dice que **pierde \$90.000**: está sacrificando \$190.000 de
alternativas para obtener \$100.000.

El criterio económico dice que ese negocio **no conviene**, aunque los libros den ganancia.

## Dónde reaparece

Es la base de toda la evaluación de proyectos de las unidades VI y VII: el VAN y la TIR
comparan un proyecto contra su mejor alternativa, y la tasa de descuento **es** un costo de
oportunidad del capital.

## Conexiones

- [[Costo de Oportunidad]] — el costo económico es ese mismo concepto llevado a la empresa
- [[Costos Fijos Variables y Totales]] — la clasificación operativa que se usa para las cuentas del corto plazo
- [[Función de Producción]] — el beneficio $B(Q) = I(Q) - C(Q)$ se calcula con el costo económico, no el contable
- [[Escasez]] — los recursos tienen usos alternativos justamente porque son escasos

## En el parcial

Definición **con explícitos e implícitos** y un ejemplo de costo implícito. La diferencia entre
beneficio contable y beneficio económico es una pregunta conceptual muy tomada.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

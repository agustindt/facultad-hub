---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos]
---

# Costo Marginal

> El costo adicional ligado a la producción de **una unidad adicional** de un bien.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

$$CMg = \frac{\Delta CT}{\Delta Q}$$

Textual:

> "EL COSTO MARGINAL (CMg) es el costo adicional ligado a la producción de una unidad adicional de un bien."

## El costo fijo no aparece

Como $CT = CF + CV$ y el $CF$ no cambia con $Q$, resulta que:

$$CMg = \frac{\Delta CT}{\Delta Q} = \frac{\Delta CV}{\Delta Q}$$

**El costo marginal solo depende de los costos variables.** Es un punto conceptual que se
pregunta: producir una unidad más no aumenta el alquiler.

## Forma de la curva

> "La curva de CMg tiene un tramo **decreciente**, alcanza un **mínimo** y, posteriormente, tiene un tramo **creciente**. Esta evolución del costo marginal se explica por la existencia de rendimientos crecientes en una primera fase, mientras que en una segunda fase, los rendimientos marginales son decrecientes."

Es la [[Ley de Rendimientos Decrecientes]] leída desde los costos: si cada unidad adicional de
factor rinde **menos**, cada unidad adicional de producto cuesta **más**.

Formalmente, con precio del factor constante: $CMg = w / PMg_L$. El CMg es la inversa del
producto marginal.

> El mínimo del CMg cae debajo del **máximo del PMg** — que es el punto de inflexión del
> producto total. Alinear los gráficos verticalmente hace evidente esa correspondencia.

<svg viewBox="0 0 440 175" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="149" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="152" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="104" y2="104" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="107" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="59" y2="59" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="62" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">40</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">60</text><line x1="34" x2="34" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)"/><line x1="142.8" x2="142.8" y1="14" y2="149" stroke="#FFA726" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="142.8" cy="134" r="3.4" fill="#FFA726"/><text x="142.8" y="160" text-anchor="middle" font-size="8" fill="#FFA726" font-weight="600">mínimo</text><path d="M34 109.2 L39 111.4 L43.9 113.5 L48.9 115.5 L53.9 117.4 L58.9 119.2 L63.8 120.9 L68.8 122.5 L73.8 124 L78.7 125.4 L83.7 126.7 L88.7 127.9 L93.7 128.9 L98.6 129.9 L103.6 130.8 L108.6 131.5 L113.5 132.2 L118.5 132.8 L123.5 133.2 L128.5 133.6 L133.4 133.8 L138.4 134 L143.4 134 L148.3 133.9 L153.3 133.8 L158.3 133.5 L163.3 133.1 L168.2 132.6 L173.2 132.1 L178.2 131.4 L183.1 130.6 L188.1 129.7 L193.1 128.7 L198.1 127.6 L203 126.4 L208 125.1 L213 123.7 L217.9 122.2 L222.9 120.5 L227.9 118.8 L232.9 117 L237.8 115.1 L242.8 113 L247.8 110.9 L252.7 108.7 L257.7 106.3 L262.7 103.9 L267.7 101.3 L272.6 98.7 L277.6 95.9 L282.6 93 L287.5 90.1 L292.5 87 L297.5 83.8 L302.5 80.5 L307.4 77.2 L312.4 73.7 L317.4 70.1 L322.3 66.4 L327.3 62.6 L332.3 58.7 L337.3 54.7 L342.2 50.6 L347.2 46.4 L352.2 42.1 L357.1 37.6 L362.1 33.1 L367.1 28.5 L372.1 23.8 L377 18.9" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="381.0" y="21.9" font-size="9" fill="#FFA726" font-weight="600">CMg</text><text x="208.0" y="172" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*Tramo decreciente, mínimo, tramo creciente: la ley de rendimientos decrecientes vista desde los costos.*


## La explicación intuitiva de la cátedra

> "A niveles bajos de producción, cada factor variable adicional (por ejemplo un trabajador), eleva la producción más que el PMe hasta ese momento (PMg > PMe). Cuando el CMg de la producción es decreciente, se está produciendo en la zona de rendimientos crecientes de producción. A partir de un punto, cada trabajador adicional produce menos que la PMe hasta ese momento (PMg < PMe). **Para producir una unidad más se necesitan cantidades mayores de trabajo adicional.** En esta zona el CMg de la producción es creciente."

## Conexiones

- [[Costos Fijos Variables y Totales]] — se calcula sobre el costo total, pero el fijo se cancela
- [[Relación entre Costo Marginal y Costo Medio]] — la regla del corte en el mínimo, que es su consecuencia más tomada
- [[Ley de Rendimientos Decrecientes]] — es la causa del tramo creciente del CMg
- [[Producto Total Medio y Marginal]] — el CMg es el espejo del producto marginal
- [[Costos Medios]] — el CMg determina si los medios suben o bajan

## En el parcial

Fórmula, cálculo en tabla (ojo: es una **variación**, va **entre** filas) y la explicación de la
forma de U por rendimientos. Que el CF no afecte al CMg es una pregunta conceptual frecuente.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion, largo-plazo]
---

# Isocuanta

> Curva que muestra **todas las combinaciones de factores** que permiten producir el **mismo
> nivel de producción**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Con dos factores, $q = F(L, K)$: la isocuanta une los puntos $(L, K)$ que dan el mismo $q_0$.
*Iso* = igual, *cuanta* = cantidad.

Textual:

> "CURVA ISOCUANTA: Muestra las distintas combinaciones de factores para producir el mismo nivel de producción."
>
> "Las ISOCUANTAS se pueden definir también como el **lugar geométrico de todas las tecnologías técnicamente eficientes** que permiten obtener un determinado nivel de producto."

Esa segunda definición es la buena: cada punto de la isocuanta es una **tecnología distinta**
—más intensiva en capital o más intensiva en trabajo— y **todas son técnicamente eficientes**.
Ninguna desperdicia recursos.

## Propiedades

- **Pendiente negativa.** Si usás menos capital, necesitás más trabajo para producir lo mismo.
- **Convexas** respecto al origen. Esa curvatura significa que la
  [[Tasa Marginal de Sustitución Técnica]] es **decreciente**: cuanto menos capital te queda,
  más trabajo hace falta para reemplazar cada unidad adicional.
- **Las de más arriba y a la derecha** corresponden a mayores niveles de producción
  ($q_1 = 55 < q_2 = 75 < q_3 = 90$ en el gráfico del teórico).
- **No se cortan** entre sí.

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">10</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">30</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><path d="M48.9 22.4 L53.9 43.7 L58.9 59.3 L63.8 71.1 L68.8 80.5 L73.8 88 L78.7 94.2 L83.7 99.4 L88.7 103.9 L93.7 107.7 L98.6 111 L103.6 114 L108.6 116.5 L113.5 118.8 L118.5 120.9 L123.5 122.8 L128.5 124.5 L133.4 126 L138.4 127.4 L143.4 128.7 L148.3 129.9 L153.3 131 L158.3 132 L163.3 133 L168.2 133.9 L173.2 134.7 L178.2 135.5 L183.1 136.2 L188.1 136.9 L193.1 137.5 L198.1 138.1 L203 138.7 L208 139.2 L213 139.8 L217.9 140.2 L222.9 140.7 L227.9 141.1 L232.9 141.6 L237.8 142 L242.8 142.4 L247.8 142.7 L252.7 143.1 L257.7 143.4 L262.7 143.7 L267.7 144 L272.6 144.3 L277.6 144.6 L282.6 144.9 L287.5 145.2 L292.5 145.4 L297.5 145.7 L302.5 145.9 L307.4 146.1 L312.4 146.3 L317.4 146.6 L322.3 146.8 L327.3 147 L332.3 147.2 L337.3 147.3 L342.2 147.5 L347.2 147.7 L352.2 147.9 L357.1 148 L362.1 148.2 L367.1 148.3 L372.1 148.5 L377 148.6 L382 148.8" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M83.7 18 L88.7 28.5 L93.7 37.6 L98.6 45.5 L103.6 52.4 L108.6 58.5 L113.5 64 L118.5 68.9 L123.5 73.3 L128.5 77.3 L133.4 80.9 L138.4 84.3 L143.4 87.3 L148.3 90.1 L153.3 92.7 L158.3 95.2 L163.3 97.4 L168.2 99.5 L173.2 101.5 L178.2 103.3 L183.1 105 L188.1 106.6 L193.1 108.1 L198.1 109.6 L203 110.9 L208 112.2 L213 113.4 L217.9 114.6 L222.9 115.7 L227.9 116.7 L232.9 117.7 L237.8 118.7 L242.8 119.6 L247.8 120.5 L252.7 121.3 L257.7 122.1 L262.7 122.9 L267.7 123.6 L272.6 124.3 L277.6 125 L282.6 125.6 L287.5 126.2 L292.5 126.8 L297.5 127.4 L302.5 128 L307.4 128.5 L312.4 129 L317.4 129.5 L322.3 130 L327.3 130.5 L332.3 131 L337.3 131.4 L342.2 131.8 L347.2 132.2 L352.2 132.7 L357.1 133 L362.1 133.4 L367.1 133.8 L372.1 134.1 L377 134.5 L382 134.8" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="137.8" font-size="9" fill="#4DB6AC" font-weight="600">q</text><path d="M133.4 16.7 L138.4 22.8 L143.4 28.4 L148.3 33.5 L153.3 38.3 L158.3 42.7 L163.3 46.8 L168.2 50.6 L173.2 54.1 L178.2 57.5 L183.1 60.6 L188.1 63.5 L193.1 66.3 L198.1 68.9 L203 71.4 L208 73.8 L213 76 L217.9 78.1 L222.9 80.1 L227.9 82 L232.9 83.8 L237.8 85.5 L242.8 87.2 L247.8 88.8 L252.7 90.3 L257.7 91.7 L262.7 93.1 L267.7 94.5 L272.6 95.7 L277.6 97 L282.6 98.2 L287.5 99.3 L292.5 100.4 L297.5 101.4 L302.5 102.5 L307.4 103.4 L312.4 104.4 L317.4 105.3 L322.3 106.2 L327.3 107.1 L332.3 107.9 L337.3 108.7 L342.2 109.5 L347.2 110.2 L352.2 111 L357.1 111.7 L362.1 112.4 L367.1 113.1 L372.1 113.7 L377 114.3 L382 115" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L) — eje vertical: Capital (K)</text></svg>

*Pendiente negativa y convexas. Las de más arriba y a la derecha son mayores niveles de producción.*


## Función de producción ≠ isocuanta

La cátedra le dedicó una diapositiva entera a esta diferencia, así que va tal cual:

> "Una **función de producción** muestra la relación entre la cantidad de **un factor variable** y la cantidad de producto obtenida. Una **isocuanta** identifica **todas las diferentes combinaciones** de insumos de los factores que pueden ser usados para producir un particular nivel de producto total."

Dicho de otro modo: la función de producción se mueve **a lo largo de un eje** (varía un
factor, cambia el producto); la isocuanta se mueve **sobre una curva de nivel** (varían los dos
factores, el producto queda igual). Es la misma superficie mirada de frente o desde arriba.

## Y acá aparece la pregunta económica

> "Cualquiera de las combinaciones en la curva isocuanta es apropiada para obtener la cantidad $q_0$, todas son **técnicamente eficientes**, sin embargo, la empresa buscará encontrar la combinación que le permita producir $q_0$ **al menor costo**."

Ese salto —de "todas sirven" a "una es la mejor"— es el corazón de la unidad, y necesita
información que la isocuanta **no tiene**: los precios de los factores. Eso lo aporta el
[[Isocosto]], y el cruce de los dos da la [[Eficiencia Económica en Tecnología]].

## Conexiones

- [[Función de Producción]] — la isocuanta es una curva de nivel de esa función, y la cátedra insiste en la diferencia
- [[Tasa Marginal de Sustitución Técnica]] — es la pendiente de la isocuanta en cada punto
- [[Isocosto]] — su complemento: mismo costo en vez de mismo producto
- [[Eficiencia Económica en Tecnología]] — surge de la tangencia entre isocuanta e isocosto
- [[Rendimientos de Escala]] — el espaciado entre isocuantas dice de qué tipo son
- [[Frontera de Posibilidades de Producción]] — la análoga a nivel de toda una economía

## En el parcial

Definición, propiedades (pendiente negativa y convexidad) y **la diferencia con la función de
producción**. Si te dan un mapa de isocuantas, saber leer el tipo de rendimientos de escala por
el espaciado.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

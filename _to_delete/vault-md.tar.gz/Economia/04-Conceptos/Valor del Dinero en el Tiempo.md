---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, finanzas]
---

# Valor del Dinero en el Tiempo

> **Un peso hoy vale más que un peso mañana**, y el precio de esa diferencia es la tasa de
> interés. Por eso una suma de dinero sin fecha es un dato incompleto.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## La idea que abre toda la unidad

Textual del apunte:

> "Cuando se habla de una suma de dinero, se debe especificar la fecha, de lo contrario la información es incompleta → El dinero cambia de valor a través del tiempo."

De ahí sale la regla operativa que vas a usar en **todos** los ejercicios de la unidad:
montos ubicados en momentos distintos **no se suman**. Primero se los lleva a una misma
fecha con los [[Factores de Equivalencia]], recién ahí se comparan.

## Por qué pasa: las tres razones

| Razón | Qué dice el apunte |
|---|---|
| **Inflación** | "En la economía con inflación, el dinero pierde poder adquisitivo con el tiempo. Con \$1000 hoy compras más que con \$1000 en un año." |
| **Costo de oportunidad** | "Podrías invertir el dinero que tienes hoy (en un plazo fijo, un fondo común de inversión, etc.) y generar una ganancia, por lo que en un año tendrías más de \$1000." |
| **Riesgo** | "Tener el dinero hoy es seguro. Esperar a recibirlo en el futuro siempre implica un riesgo (que no te paguen, que la inversión falle, etc.)." |

```mermaid
flowchart LR
    A["<b>1000 pesos HOY</b>"] --> B["Inflación:<br/>pierde poder adquisitivo"]
    A --> C["Costo de oportunidad:<br/>podría estar invertido"]
    A --> D["Riesgo:<br/>que no te paguen"]
    B --> E["<b>1000 pesos EN UN AÑO<br/>valen menos</b>"]
    C --> E
    D --> E
    E --> F["El precio de esa diferencia:<br/><b>LA TASA DE INTERÉS</b>"]
    style A fill:#4DB6AC,color:#fff
    style E fill:#FFA726,color:#fff
    style F fill:#7C5CFF,color:#fff
```

## Interés y tasa de interés no son lo mismo

Es la primera distinción que se pregunta, y se confunde seguido porque el apunte usa las dos
palabras casi pegadas:

| Concepto | Qué es | **Unidad** |
|---|---|---|
| **Interés** | "el costo de usar dinero durante cierto tiempo"; la cantidad que pagás por usar dinero ajeno o que ganás por prestar el tuyo | **pesos** (\$) |
| **Tasa de interés** | "el porcentaje que se paga por el alquiler del dinero" | **porcentaje por período** (% / período) |

Y la frase que cierra la idea:

> "El capital tiene un costo de oportunidad en el tiempo y su remuneración es el interés."

O sea: la tasa de interés **es** el [[Costo de Oportunidad]] del capital puesto en número.
Ese mismo número, cuando lo usás para evaluar un proyecto, se llama
[[Tasa de Descuento]].

## Conexiones

- [[Factores de Equivalencia]] — son la maquinaria para mover un monto de una fecha a otra
- [[Interés Simple e Interés Compuesto]] — las dos formas de calcular ese interés
- [[Costo de Oportunidad]] — la tasa de interés es el costo de oportunidad del capital, medido
- [[Inflación e Interés]] — la inflación es una de las tres razones, y la que corroe la tasa
- [[Tasa de Descuento]] — el mismo costo de oportunidad, ya del lado de evaluar un proyecto
- [[Consumo Ahorro e Inversión]] — la tasa es lo que define postergar consumo hoy por consumo mañana

## En el parcial

Es la pregunta de arranque y la que habilita todo lo demás. **Tenés que poder justificar en
tres renglones por qué \$1000 hoy no son \$1000 dentro de un año, nombrando las tres causas
(inflación, costo de oportunidad y riesgo) y diciendo cuál es el precio de esa diferencia (la
tasa de interés).**

El error que hace perder puntos en los prácticos no es conceptual: es **sumar montos de
períodos distintos** dentro de un flujo de fondos sin actualizarlos. Si un enunciado te da
plata en el momento 0 y plata en el momento 3, no hay nada que sumar hasta que los lleves a la
misma fecha.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

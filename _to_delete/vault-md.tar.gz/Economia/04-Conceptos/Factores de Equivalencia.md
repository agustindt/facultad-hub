---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, equivalencia]
---

# Factores de Equivalencia

> Son las fórmulas que mueven un monto de una fecha a otra. **Capitalizar** es ir hacia
> adelante agregando interés; **actualizar** es ir hacia atrás descontándolo.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Las dos operaciones

Textual, y son las dos definiciones que hay que poder recitar:

> "La **CAPITALIZACIÓN** es la operación que nos permite agregar a un valor presente, un cierto valor para obtener un valor futuro → significa avanzar en el tiempo, agregando el interés obtenido."

> "La **ACTUALIZACIÓN** es determinar qué cantidad de dinero significa hoy, una suma de dinero futuro → ¿Qué suma de dinero debo depositar hoy para obtener en un tiempo determinado un monto específico?"

```mermaid
flowchart LR
    VP["<b>VALOR PRESENTE</b><br/>momento 0"] -->|"CAPITALIZAR<br/>agregar interés<br/>por 1 + i elevado a n"| VF["<b>VALOR FUTURO</b><br/>momento n"]
    VF -->|"ACTUALIZAR<br/>descontar interés<br/>dividir por 1 + i elevado a n"| VP
    style VP fill:#4DB6AC,color:#fff
    style VF fill:#FFA726,color:#fff
```

## Pago único

Las definiciones del apunte:

> "El **VALOR FUTURO** de un monto, es el referido monto más todos los intereses compuestos acumulados, a una cierta tasa."

> "El **VALOR PRESENTE** de un monto es el capital futuro menos todo el interés compuesto descontado a la fecha presente, a una cierta tasa."

La fórmula que da el apunte es la de actualización:

$$VP = \frac{VF}{(1+i)^n}$$

- **VP** — valor presente, en **pesos** de hoy
- **VF** — valor futuro, en **pesos** del momento $n$
- **i** — tasa de interés efectiva del período, en **tanto por uno** (0,05 y no 5 %)
- **n** — cantidad de **períodos** entre la fecha del VF y hoy

Y despejando queda la de capitalización, $VF = VP \times (1+i)^n$. Es una sola fórmula leída
en los dos sentidos: por eso se llaman *factores de equivalencia* y no dos temas distintos.

| Te dan… | Buscás… | Operación | Cuenta |
|---|---|---|---|
| Un monto de hoy | Cuánto será en $n$ períodos | Capitalizar | Multiplicar por $(1+i)^n$ |
| Un monto futuro | Cuánto vale hoy | Actualizar | Dividir por $(1+i)^n$ |
| Una serie de cuotas iguales | Su valor hoy | Actualizar serie | Ver [[Anualidades y Perpetuidades]] |
| Un valor presente | La cuota igual equivalente | FRC | Ver abajo |

## Factor de Recuperación de Capital (FRC)

> "Se utiliza para encontrar el valor de una serie uniforme de pagos iguales (A) que inician en el periodo 1 y que se extienden hasta (n) periodos, a partir de un valor presente (P) y dado una tasa de interés (i), donde el interés se calcula sobre saldos. Nos permite obtener el costo anual uniforme equivalente A, durante 'n' períodos, de una inversión P cuando la tasa de interés es 'i'."

Es el factor que convierte una inversión inicial en **cuota uniforme**, y es exactamente la
maquinaria que después usa el **costo anual equivalente** en
[[Reemplazo de Equipos]] y la cuota del sistema francés en
[[Sistemas de Amortización de Deuda]].

## Faltante

El apunte **no escribe la fórmula del FRC**, ni presenta la tabla de factores con la notación
estándar (P/F, F/P, P/A, A/P), ni da ejemplos numéricos de ninguno. Tampoco trata series
gradientes.

## Conexiones

- [[Valor del Dinero en el Tiempo]] — los factores son la herramienta concreta de esa idea
- [[Interés Simple e Interés Compuesto]] — todos los factores suponen interés compuesto
- [[Anualidades y Perpetuidades]] — el caso de serie uniforme en lugar de pago único
- [[Valor Actual Neto]] — el VAN es aplicar el factor de actualización a cada flujo y sumar
- [[Reemplazo de Equipos]] — el FRC es lo que produce el costo anual equivalente
- [[Tasa de Descuento]] — la $i$ que entra en el factor no es cualquiera: es el costo de oportunidad del capital

## En el parcial

**Dado un monto y una fecha, llevarlo a otra fecha: capitalizar o actualizar según
corresponda, y justificar cuál usaste.** Es la operación base de todos los ejercicios de la
unidad, así que se pregunta adentro de otras consignas más que sola.

Chequeo rápido antes de entregar: si actualizaste, el resultado tiene que ser **menor** que el
monto original; si capitalizaste, **mayor**. Si te da al revés, invertiste el factor. Y $i$ y
$n$ siempre en el mismo período.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

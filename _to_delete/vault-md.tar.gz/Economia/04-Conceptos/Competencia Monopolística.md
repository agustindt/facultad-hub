---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados, competencia]
---

# Competencia Monopolística

> **Muchas empresas ofreciendo productos similares pero no idénticos.** La diferenciación le da
> a cada una un poquito de poder sobre su precio; la libre entrada se lo termina sacando. El
> resultado de largo plazo: beneficio cero pero produciendo por debajo de la escala eficiente.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Definición

> "Un mercado en el cual muchas empresas ofrecen productos **similares, pero no idénticos**. Ninguna empresa posee una gran cuota de mercado y es clave la **diferenciación del producto**."

Ejemplos del material: libros, ropa, juegos, restaurantes, electrodomésticos, cosméticos,
cafeterías, perfumes.

## El híbrido: qué toma de cada modelo

| Rasgo | Se parece a… |
|---|---|
| Muchos productores, ninguno con gran cuota | Competencia perfecta |
| Libertad de entrada y salida del mercado | Competencia perfecta |
| Producto **diferenciado** (marca, publicidad) | Monopolio |
| Cada empresa fija un precio **superior al costo marginal** | Monopolio |

De ahí el nombre: es competencia (muchos, libre entrada) con un pedacito de monopolio (cada
marca es única).

## Corto plazo vs. largo plazo

| | **Corto plazo** | **Largo plazo** |
|---|---|---|
| Regla de producción | $IMg = CMg$ | $IMg = CMg$ |
| Beneficios | Extraordinarios si $P > CTMe$ | **Cero**: $P = CTMe$ |
| Qué está pasando | Nada ajusta todavía | Entran y salen empresas hasta que el beneficio desaparece |

El mecanismo de ajuste, textual y con una dirección que se presta a error:

> "Si las empresas obtienen beneficios, nuevas ingresan al mercado y las curvas de demanda de las que permanecen se desplazan hacia la **izquierda**. Si las empresas tienen pérdidas, algunas salen y las curvas de demanda de las que permanecen se desplazan hacia la **derecha**."

Tiene lógica: cuando entra un competidor nuevo, te **roba** clientes, así que **tu** demanda se
achica (se corre a la izquierda). Es al revés de lo que uno diría por inercia.

```mermaid
flowchart TD
    A["<b>CORTO PLAZO</b><br/>hay beneficios<br/>P &gt; CTMe"] --> B["Entran empresas nuevas"]
    B --> C["La demanda de cada empresa<br/>se desplaza a la IZQUIERDA"]
    C --> D["<b>LARGO PLAZO</b><br/>P = CTMe<br/>beneficio CERO"]
    E["Hay pérdidas"] --> F["Salen empresas"]
    F --> G["La demanda de las que quedan<br/>se desplaza a la DERECHA"]
    G --> D
    D --> H["<b>EXCESO DE CAPACIDAD</b><br/>se produce en el tramo<br/>descendente del CTMe"]
    style A fill:#4DB6AC,color:#fff
    style E fill:#FFA726,color:#fff
    style D fill:#7C5CFF,color:#fff
    style H fill:#7C5CFF,color:#fff
```

## Las dos ineficiencias del resultado final

1. **Exceso de capacidad.** Cada empresa opera en el **segmento descendente** de la curva de costo total promedio, o sea produce a **menos de su escala eficiente**. Podría aumentar la cantidad producida y reducir su costo total medio — pero no le conviene, porque para vender más tendría que bajar el precio.
2. **Margen sobre el costo marginal.** Cada empresa establece un precio **superior al $CMg$**. Ese margen es el que paga la diferenciación.

Y una consecuencia de la diferenciación que el material señala explícitamente: **lleva al uso de
la publicidad y las marcas**.

## Conexiones

- [[Clasificación de Mercados]] — es la tercera fila de la tabla: muchas empresas, barreras bajas, producto diferenciado
- [[Competencia Perfecta]] — comparte muchos oferentes y libre entrada, pero el producto no es homogéneo
- [[Monopolio]] — comparte el precio por encima del $CMg$, pero acá el poder de mercado es mínimo y desaparece con la entrada
- [[Escala Mínima Eficiente]] — el exceso de capacidad es exactamente producir por debajo de la escala eficiente
- [[Costos Medios]] — el resultado de largo plazo se lee sobre la curva de $CTMe$: $P = CTMe$ en su tramo descendente
- [[Elasticidad Ingreso y Cruzada]] — los productos diferenciados son sustitutos imperfectos entre sí

## En el parcial

**Comparar competencia monopolística con competencia perfecta en los dos puntos que las
separan:** el producto es diferenciado (no homogéneo) y en el largo plazo, aunque el beneficio
también sea cero, se produce con **exceso de capacidad** y con $P > CMg$. El error clásico es
decir que la entrada de nuevas empresas desplaza la demanda de las existentes **a la derecha**:
es a la **izquierda**, porque los nuevos se llevan clientes. Y tener listos dos ejemplos
(restaurantes, ropa).

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `SEGUNDO PARCIAL — Google Docs` y `Resumen temas coloquio` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

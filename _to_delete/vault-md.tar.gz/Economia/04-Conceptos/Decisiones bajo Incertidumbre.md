---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, decisiones]
---

# Decisiones bajo Incertidumbre

> Hay incertidumbre cuando **no se conocen ni se pueden asignar probabilidades** a los estados
> de la naturaleza. Sin probabilidades no hay valor esperado: se decide mirando los extremos de
> cada fila, y el criterio que elijas depende de tu actitud frente al riesgo.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## La definición que separa las aguas

Textual:

> "En aquellos casos en que **no se conocen o no es posible asignar probabilidades** a los eventos, decimos que es una decisión con **Incertidumbre** y se aplican métodos con información limitada (criterios de Maximax, Maximin, Hurwics, Savage, etc.)."

| | [[Decisiones bajo Riesgo]] | **Incertidumbre** |
|---|---|---|
| Probabilidades de los estados | **Conocidas o asignables** | **No se conocen ni se pueden asignar** |
| Herramienta central | Valor esperado $\sum V_i P_i$ | Máximos y mínimos de cada fila |
| Métodos | Probabilísticos | "métodos con información limitada" |

Punto clave: **la [[Matriz de Pagos]] es la misma**. Lo único que falta acá es la fila de
probabilidades.

## Los criterios, uno por uno

| Criterio | Postura | Qué hace | Fórmula |
|---|---|---|---|
| **Maximin** | **Pesimista** / prudencia máxima | "de cada opción selectiva elige el resultado **mínimo** y luego selecciona la opción que lleva al **máximo** el resultado mínimo": el mejor de los peores | $\max_i [\min_\theta p(a_i,\theta)]$ |
| **Maximax** | **Optimista** | "investiga el resultado **máximo** de cada opción y luego elige la que lleve al **máximo** el resultado máximo": el mejor de los mejores | $\max_i [\max_\theta p(a_i,\theta)]$ |
| **Minimín** | Optimista, **para pérdidas** | "Investiga el costo mínimo de cada opción y luego elige la que lleva al mínimo el costo mínimo" | $\min_i [\min_\theta p(a_i,\theta)]$ |
| **Minimax (Savage)** | Minimizar el **arrepentimiento** | Trabaja sobre pérdidas de oportunidad: "el costo máximo de cada opción y luego selecciona la opción que lleve al mínimo el costo máximo" | $\min_i [\max_\theta R(a_i,\theta)]$ |
| **Laplace** | **Neutral** | "los niveles deben asumirse como **equiprobables** al no haber razón suficiente para atribuir mayor o menor probabilidad a alguno de ellos" | $P(\theta = \theta_i) = 1/n$ |
| **Hurwicz** | **Mezcla** optimismo y pesimismo | "Coeficiente de optimismo. Combinación lineal entre el maximin y el maximax" | $\max_i \left( \alpha [\max_\theta p(a_i,\theta)] + (1-\alpha)[\min_\theta p(a_i,\theta)] \right)$ |

Notación: $a_i$ es cada alternativa (fila), $\theta$ cada estado de la naturaleza (columna) y
$p(a_i,\theta)$ el pago de ese cruce, en **pesos** (o en la medida que use la matriz).
$\alpha$ es el **coeficiente de optimismo**, un número **entre 0 y 1** (sin unidad): con
$\alpha = 1$ Hurwicz colapsa en maximax, con $\alpha = 0$ en maximin.

*(El apunte lo escribe "Hurwics"; es el mismo criterio.)*

## Savage: la pérdida de oportunidad

Es el único que no trabaja con la matriz original sino con una matriz nueva, así que va aparte:

> "Se basa en el cálculo de las pérdidas en que se incurre por **no haber seleccionado la alternativa correcta** (pérdida de oportunidad)."

$$R(a_i,\theta) = \max_\theta \text{pago} - \text{pago}(a_i,\theta)$$

- **$R(a_i,\theta)$** — el arrepentimiento: cuánto perdiste por no haber elegido lo mejor
  **dado que ocurrió** ese estado, en **pesos**; nunca es negativo
- **$\max_\theta \text{pago}$** — el mejor pago de esa **columna**, en pesos

Y la regla final: "La alternativa a elegir es la que tenga el mínimo costo de oportunidad entre
los máximos costos de oportunidad calculados, o sea la alternativa cuya **pena máxima es la
menor**."

O sea, dos pasos: **(1)** armás la matriz de arrepentimientos restando cada pago del mejor de
su columna; **(2)** de cada fila tomás el máximo y elegís la fila con el mínimo de esos
máximos.

```mermaid
flowchart TD
    M["<b>MATRIZ DE PAGOS</b><br/>sin probabilidades"] --> P{"¿Qué postura<br/>tomás?"}
    P -->|"Pesimista"| MN["<b>MAXIMIN</b><br/>el mejor de los peores"]
    P -->|"Optimista"| MX["<b>MAXIMAX</b><br/>el mejor de los mejores"]
    P -->|"Intermedia"| H["<b>HURWICZ</b><br/>combinación lineal<br/>con alfa de optimismo"]
    P -->|"Neutral"| L["<b>LAPLACE</b><br/>todos equiprobables:<br/>P = 1 sobre n"]
    P -->|"Evitar arrepentirse"| S["<b>SAVAGE</b><br/>matriz de pérdidas<br/>de oportunidad"]
    style M fill:#4DB6AC,color:#fff
    style P fill:#FFA726,color:#fff
    style MN fill:#7C5CFF,color:#fff
    style MX fill:#7C5CFF,color:#fff
    style H fill:#7C5CFF,color:#fff
    style L fill:#7C5CFF,color:#fff
    style S fill:#7C5CFF,color:#fff
```

## Faltante

El apunte da las fórmulas de todos los criterios pero **no resuelve ninguna matriz numérica de
ejemplo**, que es exactamente el formato en que se toma el tema. Tampoco fija cómo elegir
$\alpha$ en Hurwicz, ni discute que **distintos criterios pueden recomendar alternativas
distintas** sobre la misma matriz.

## Conexiones

- [[Decisiones bajo Riesgo]] — el otro mundo: misma matriz, pero con probabilidades y valor esperado
- [[Matriz de Pagos]] — es el insumo de todos estos criterios, sin fila de probabilidades
- [[Toma de Decisiones]] — el marco general de decisión en la organización
- [[Incertidumbre Ambiental]] — la incertidumbre del entorno organizacional es la fuente de estos estados de la naturaleza
- [[Análisis de Sensibilidad y Escenarios]] — cuando no hay probabilidades, los escenarios extremos son la alternativa práctica
- [[Comparación de Alternativas]] — estos criterios entran cuando la alternativa elegida depende de un futuro que no controlás

## En el parcial

**Dada una matriz de pagos sin probabilidades, aplicar los cinco criterios y decir cuál elige
cada uno, justificando la postura detrás de cada elección** (pesimista, optimista, neutral,
intermedia, arrepentimiento). Savage es el que más se equivoca porque requiere construir la
matriz de pérdidas de oportunidad primero.

La pregunta teórica casi segura: **la diferencia entre riesgo e incertidumbre.** Respuesta en
una línea: *con riesgo se conocen o se pueden asignar probabilidades a los estados de la
naturaleza; con incertidumbre no.* Todo lo demás se deduce de ahí.

Dos errores: aplicar Laplace y decir que es un criterio "sin probabilidades" — Laplace
**inventa** probabilidades iguales, es su forma de resolver el problema; y calcular el
arrepentimiento de Savage restando por **filas**: se resta contra el mejor pago de cada
**columna**, que es el estado que efectivamente ocurrió.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

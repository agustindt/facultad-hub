---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion]
---

# Máximo Técnico y Óptimo Técnico

> Los dos puntos con nombre propio de la curva de producción. **Máximo técnico**: el máximo del
> producto **total**. **Óptimo técnico**: el máximo del producto **medio**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

| | Dónde está | Condición | Qué significa |
|---|---|---|---|
| **Óptimo técnico** | Máximo de la curva de **PMe** | $PMg = PMe$ | Cada unidad de factor variable rinde lo máximo posible en promedio |
| **Máximo técnico** | Máximo de la curva de **PT** | $PMg = 0$ | No se puede producir más con ese factor fijo |

Textual: *"El máximo de la curva del producto se denomina **MÁXIMO TÉCNICO**"* y *"El máximo de
la curva del producto medio se denomina **ÓPTIMO TÉCNICO**"*.

## El orden importa: primero el óptimo, después el máximo

```mermaid
flowchart LR
    A["Inicio<br/>PMg sube"] --> B["<b>ÓPTIMO TÉCNICO</b><br/>máx. PMe<br/>PMg = PMe"]
    B --> C["Zona económica<br/>PMg &lt; PMe, PMg &gt; 0"]
    C --> D["<b>MÁXIMO TÉCNICO</b><br/>máx. PT<br/>PMg = 0"]
    D --> E["Absurdo<br/>PMg &lt; 0"]
    style B fill:#4DB6AC,color:#fff
    style D fill:#FFA726,color:#fff
    style E fill:#7C5CFF,color:#fff
```

El óptimo técnico llega **antes** que el máximo técnico. Entre los dos está la
[[Etapas de la Producción|etapa 2]], que es la única región donde tiene sentido producir.

<svg viewBox="0 0 440 180" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="154" y2="154" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="157" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">-8</text><line x1="34" x2="382" y1="107.3" y2="107.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="110.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">6</text><line x1="34" x2="382" y1="60.7" y2="60.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="63.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">34</text><line x1="34" x2="34" y1="14" y2="154" stroke="var(--background-modifier-border,#8886)"/><line x1="251.5" x2="251.5" y1="14" y2="154" stroke="#4DB6AC" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="251.5" cy="52.3" r="3.4" fill="#4DB6AC"/><text x="251.5" y="165" text-anchor="middle" font-size="8" fill="#4DB6AC" font-weight="600">PMg=PMe</text><line x1="324" x2="324" y1="14" y2="154" stroke="#FFA726" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="324" cy="127.3" r="3.4" fill="#FFA726"/><text x="324" y="165" text-anchor="middle" font-size="8" fill="#FFA726" font-weight="600">PMg=0</text><path d="M39 123.9 L43.9 120.6 L48.9 117.4 L53.9 114.2 L58.9 111.2 L63.8 108.2 L68.8 105.3 L73.8 102.4 L78.7 99.7 L83.7 97 L88.7 94.4 L93.7 91.8 L98.6 89.4 L103.6 87 L108.6 84.7 L113.5 82.5 L118.5 80.4 L123.5 78.3 L128.5 76.3 L133.4 74.4 L138.4 72.6 L143.4 70.9 L148.3 69.2 L153.3 67.6 L158.3 66.1 L163.3 64.7 L168.2 63.3 L173.2 62.1 L178.2 60.9 L183.1 59.7 L188.1 58.7 L193.1 57.7 L198.1 56.9 L203 56.1 L208 55.3 L213 54.7 L217.9 54.1 L222.9 53.6 L227.9 53.2 L232.9 52.9 L237.8 52.6 L242.8 52.5 L247.8 52.4 L252.7 52.3 L257.7 52.4 L262.7 52.5 L267.7 52.7 L272.6 53 L277.6 53.4 L282.6 53.9 L287.5 54.4 L292.5 55 L297.5 55.7 L302.5 56.5 L307.4 57.3 L312.4 58.2 L317.4 59.2 L322.3 60.3 L327.3 61.4 L332.3 62.7 L337.3 64 L342.2 65.4 L347.2 66.9 L352.2 68.4 L357.1 70 L362.1 71.7 L367.1 73.5 L372.1 75.4 L377 77.3 L382 79.3" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="82.3" font-size="9" fill="#4DB6AC" font-weight="600">PMe</text><path d="M34 127.3 L39 120.6 L43.9 114.1 L48.9 107.8 L53.9 101.8 L58.9 96 L63.8 90.4 L68.8 85.1 L73.8 80 L78.7 75.1 L83.7 70.5 L88.7 66.1 L93.7 62 L98.6 58.1 L103.6 54.4 L108.6 50.9 L113.5 47.7 L118.5 44.7 L123.5 42 L128.5 39.5 L133.4 37.2 L138.4 35.2 L143.4 33.4 L148.3 31.8 L153.3 30.5 L158.3 29.4 L163.3 28.5 L168.2 27.9 L173.2 27.5 L178.2 27.3 L183.1 27.4 L188.1 27.7 L193.1 28.3 L198.1 29.1 L203 30.1 L208 31.3 L213 32.8 L217.9 34.5 L222.9 36.5 L227.9 38.7 L232.9 41.1 L237.8 43.8 L242.8 46.7 L247.8 49.8 L252.7 53.2 L257.7 56.8 L262.7 60.6 L267.7 64.7 L272.6 69 L277.6 73.6 L282.6 78.4 L287.5 83.4 L292.5 88.6 L297.5 94.1 L302.5 99.8 L307.4 105.8 L312.4 112 L317.4 118.4 L322.3 125.1 L327.3 132 L332.3 139.1 L337.3 146.5" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="341.3" y="149.5" font-size="9" fill="#FFA726" font-weight="600">PMg</text><text x="208.0" y="177" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L)</text></svg>

*El óptimo técnico (PMg = PMe) llega antes que el máximo técnico (PMg = 0).*


## El nombre engaña

"Máximo" suena mejor que "óptimo", pero es al revés: **el máximo técnico no es el mejor punto
para producir.** Es donde el producto total es más alto, sí, pero para llegar ahí ya estuviste
agregando unidades de factor que rendían cada vez menos. Si el factor variable cuesta algo —y
cuesta—, conviene parar antes.

Dónde exactamente parar no lo decide la técnica: lo deciden los **precios**, y eso es
[[Eficiencia Económica en Tecnología]]. La técnica sola solamente te dice que el punto está
**entre** el óptimo y el máximo técnico.

## Conexiones

- [[Producto Total Medio y Marginal]] — son los máximos de dos de esas tres curvas
- [[Etapas de la Producción]] — el óptimo y el máximo técnico son justamente las fronteras entre las tres etapas
- [[Ley de Rendimientos Decrecientes]] — es lo que hace que existan esos máximos
- [[Eficiencia Económica en Tecnología]] — la técnica acota la zona; los precios eligen el punto
- [[Costos Medios]] — el óptimo técnico se corresponde con el mínimo del costo variable medio

## En el parcial

Ubicarlos en una tabla o un gráfico **y no confundirlos**. Regla mnemotécnica: el **óptimo**
tiene que ver con el **promedio** (PMe), el **máximo** con el **total** (PT). Y el óptimo viene
primero.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion]
---

# Producto Total, Medio y Marginal

> Las tres curvas del corto plazo: cuánto se produce en total, cuánto por unidad de factor, y
> cuánto agrega la unidad siguiente.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Las tres definiciones

| | Qué mide | Fórmula |
|---|---|---|
| **Producto total (PT)** | La producción obtenida con una cantidad dada del factor variable | $PT = f(L)$ |
| **Producto marginal (PMg)** | Lo que agrega **una unidad más** del factor variable | $PMg_L = \dfrac{\Delta PT}{\Delta L}$ |
| **Producto medio (PMe)** | Producción **por unidad** del factor variable | $PMe_L = \dfrac{PT}{L}$ |

Textual:

> "EL PRODUCTO MARGINAL (PMg) mide la variación que tiene lugar en el producto total (PT) cuando se utiliza una unidad más del factor variable."
>
> "EL PRODUCTO MEDIO (PMe) se define como el cociente entre el producto total y el número de unidades físicas del factor de producción variable utilizado."

$$PMg = \frac{\text{Variación del producto total}}{\text{Variación de una unidad del factor variable}} = \frac{\Delta Q}{\Delta L}$$

$$PMe = \frac{\text{Producto total}}{\text{Unidades del factor productivo variable}} = \frac{Q}{L}$$

## Cómo se comportan

El producto total *"inicialmente aumenta a un ritmo creciente y luego lo hace de forma
decreciente hasta alcanzar un máximo, a partir del cual decrece"*.

Las tres curvas se dibujan **alineadas verticalmente** (PT arriba, PMe y PMg abajo, mismo eje
horizontal) porque los puntos notables de una caen justo debajo de los de la otra:

| En la curva de arriba (PT) | Cae exactamente debajo en |
|---|---|
| Punto de inflexión del PT | **Máximo del PMg** |
| Punto donde una recta desde el origen es tangente al PT | **Máximo del PMe** = [[Máximo Técnico y Óptimo Técnico]] |
| **Máximo del PT** = [[Máximo Técnico y Óptimo Técnico]] | $PMg = 0$ |
| Tramo decreciente del PT | $PMg < 0$ |

<svg viewBox="0 0 440 170" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="144" y2="144" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="147" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="100.7" y2="100.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="103.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">70</text><line x1="34" x2="382" y1="57.3" y2="57.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="60.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">140</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">210</text><line x1="34" x2="34" y1="14" y2="144" stroke="var(--background-modifier-border,#8886)"/><line x1="251.5" x2="251.5" y1="14" y2="144" stroke="#4DB6AC" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="251.5" cy="39.5" r="3.4" fill="#4DB6AC"/><text x="251.5" y="155" text-anchor="middle" font-size="8" fill="#4DB6AC" font-weight="600">óptimo</text><line x1="324" x2="324" y1="14" y2="144" stroke="#FFA726" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="324" cy="20.2" r="3.4" fill="#FFA726"/><text x="324" y="155" text-anchor="middle" font-size="8" fill="#FFA726" font-weight="600">máximo</text><path d="M34 144 L39 143.9 L43.9 143.6 L48.9 143.1 L53.9 142.3 L58.9 141.4 L63.8 140.3 L68.8 139.1 L73.8 137.7 L78.7 136.1 L83.7 134.3 L88.7 132.5 L93.7 130.4 L98.6 128.3 L103.6 126 L108.6 123.7 L113.5 121.2 L118.5 118.6 L123.5 115.9 L128.5 113.2 L133.4 110.3 L138.4 107.4 L143.4 104.5 L148.3 101.4 L153.3 98.4 L158.3 95.3 L163.3 92.1 L168.2 89 L173.2 85.8 L178.2 82.6 L183.1 79.4 L188.1 76.3 L193.1 73.1 L198.1 70 L203 66.8 L208 63.8 L213 60.7 L217.9 57.8 L222.9 54.8 L227.9 52 L232.9 49.2 L237.8 46.5 L242.8 43.9 L247.8 41.4 L252.7 38.9 L257.7 36.6 L262.7 34.5 L267.7 32.4 L272.6 30.5 L277.6 28.7 L282.6 27 L287.5 25.6 L292.5 24.3 L297.5 23.1 L302.5 22.1 L307.4 21.4 L312.4 20.8 L317.4 20.4 L322.3 20.2 L327.3 20.2 L332.3 20.5 L337.3 21 L342.2 21.7 L347.2 22.7 L352.2 23.9 L357.1 25.4 L362.1 27.2 L367.1 29.2 L372.1 31.5 L377 34.1 L382 37" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="40.0" font-size="9" fill="#7C5CFF" font-weight="600">PT</text><text x="208.0" y="167" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L) →  Producto total</text></svg>

<svg viewBox="0 0 440 180" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="154" y2="154" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="157" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">-8</text><line x1="34" x2="382" y1="107.3" y2="107.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="110.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">6</text><line x1="34" x2="382" y1="60.7" y2="60.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="63.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">34</text><line x1="34" x2="34" y1="14" y2="154" stroke="var(--background-modifier-border,#8886)"/><line x1="251.5" x2="251.5" y1="14" y2="154" stroke="#4DB6AC" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="251.5" cy="52.3" r="3.4" fill="#4DB6AC"/><text x="251.5" y="165" text-anchor="middle" font-size="8" fill="#4DB6AC" font-weight="600">PMg=PMe</text><line x1="324" x2="324" y1="14" y2="154" stroke="#FFA726" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="324" cy="127.3" r="3.4" fill="#FFA726"/><text x="324" y="165" text-anchor="middle" font-size="8" fill="#FFA726" font-weight="600">PMg=0</text><path d="M39 123.9 L43.9 120.6 L48.9 117.4 L53.9 114.2 L58.9 111.2 L63.8 108.2 L68.8 105.3 L73.8 102.4 L78.7 99.7 L83.7 97 L88.7 94.4 L93.7 91.8 L98.6 89.4 L103.6 87 L108.6 84.7 L113.5 82.5 L118.5 80.4 L123.5 78.3 L128.5 76.3 L133.4 74.4 L138.4 72.6 L143.4 70.9 L148.3 69.2 L153.3 67.6 L158.3 66.1 L163.3 64.7 L168.2 63.3 L173.2 62.1 L178.2 60.9 L183.1 59.7 L188.1 58.7 L193.1 57.7 L198.1 56.9 L203 56.1 L208 55.3 L213 54.7 L217.9 54.1 L222.9 53.6 L227.9 53.2 L232.9 52.9 L237.8 52.6 L242.8 52.5 L247.8 52.4 L252.7 52.3 L257.7 52.4 L262.7 52.5 L267.7 52.7 L272.6 53 L277.6 53.4 L282.6 53.9 L287.5 54.4 L292.5 55 L297.5 55.7 L302.5 56.5 L307.4 57.3 L312.4 58.2 L317.4 59.2 L322.3 60.3 L327.3 61.4 L332.3 62.7 L337.3 64 L342.2 65.4 L347.2 66.9 L352.2 68.4 L357.1 70 L362.1 71.7 L367.1 73.5 L372.1 75.4 L377 77.3 L382 79.3" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="82.3" font-size="9" fill="#4DB6AC" font-weight="600">PMe</text><path d="M34 127.3 L39 120.6 L43.9 114.1 L48.9 107.8 L53.9 101.8 L58.9 96 L63.8 90.4 L68.8 85.1 L73.8 80 L78.7 75.1 L83.7 70.5 L88.7 66.1 L93.7 62 L98.6 58.1 L103.6 54.4 L108.6 50.9 L113.5 47.7 L118.5 44.7 L123.5 42 L128.5 39.5 L133.4 37.2 L138.4 35.2 L143.4 33.4 L148.3 31.8 L153.3 30.5 L158.3 29.4 L163.3 28.5 L168.2 27.9 L173.2 27.5 L178.2 27.3 L183.1 27.4 L188.1 27.7 L193.1 28.3 L198.1 29.1 L203 30.1 L208 31.3 L213 32.8 L217.9 34.5 L222.9 36.5 L227.9 38.7 L232.9 41.1 L237.8 43.8 L242.8 46.7 L247.8 49.8 L252.7 53.2 L257.7 56.8 L262.7 60.6 L267.7 64.7 L272.6 69 L277.6 73.6 L282.6 78.4 L287.5 83.4 L292.5 88.6 L297.5 94.1 L302.5 99.8 L307.4 105.8 L312.4 112 L317.4 118.4 L322.3 125.1 L327.3 132 L332.3 139.1 L337.3 146.5" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="341.3" y="149.5" font-size="9" fill="#FFA726" font-weight="600">PMg</text><text x="208.0" y="177" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L)</text></svg>

*Las tres curvas, alineadas: el máximo del PT cae donde el PMg cruza el cero, y el máximo del PMe donde lo cruza el PMg.*


## La relación marginal–medio (vale para todo)

Esta regla aparece dos veces en la unidad — acá y en
[[Relación entre Costo Marginal y Costo Medio]] — y es la misma matemática:

- Si $PMg > PMe$ → el medio **sube** (la unidad nueva rinde más que el promedio y lo tira para arriba).
- Si $PMg < PMe$ → el medio **baja**.
- Si $PMg = PMe$ → el medio está en su **máximo**.

La analogía que la fija: si a un curso con promedio 7 entra un alumno con 9, el promedio sube;
si entra uno con 5, baja. El "marginal" arrastra al "medio" hacia sí.

## Conexiones

- [[Función de Producción]] — las tres curvas se derivan de ella
- [[Máximo Técnico y Óptimo Técnico]] — son los máximos del PT y del PMe respectivamente
- [[Ley de Rendimientos Decrecientes]] — explica por qué el PMg termina cayendo
- [[Etapas de la Producción]] — las tres etapas se delimitan comparando PMg con PMe
- [[Relación entre Costo Marginal y Costo Medio]] — la misma relación marginal–medio, del lado de los costos
- [[Costos Medios]] — el PMe con forma de ∩ es el reflejo del CVMe con forma de U

## En el parcial

**Completar la tabla.** Te dan $L$ y $PT$, y hay que calcular $PMg$ y $PMe$, marcar máximo y
óptimo técnico y delimitar las etapas. Verificación rápida: el PMg se calcula **entre** filas
(es una variación) y el PMe **en** cada fila (es un cociente). Confundirlos es el error de
arrastre típico.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, decisiones]
---

# Decisiones bajo Riesgo

> Hay riesgo cuando **se conocen o se pueden asignar probabilidades** a los estados de la
> naturaleza. Con probabilidades en la mano se puede calcular un valor esperado — y ésa es
> toda la diferencia con [[Decisiones bajo Incertidumbre]].

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## La definición que separa las aguas

Textual, y el apunte la repite tres veces porque es **la** distinción del bloque:

> "En aquellos casos en que **se conocen o es posible asignar probabilidades** a los eventos, decimos que es una decisión con **Riesgo** y es posible utilizar métodos probabilísticos (valor esperado, árboles de decisión, simulación de Montecarlo, etc.)."

| | **Riesgo** | **Incertidumbre** |
|---|---|---|
| ¿Hay probabilidades? | **Sí**, conocidas o asignables | **No** |
| Tipo de método | Probabilísticos | "métodos con información limitada" |
| Criterios | Valor esperado, árboles de decisión, Montecarlo, regla de Bayes, aversión al riesgo | Maximin, Maximax, Minimín, Savage, Laplace, Hurwicz |

Ambos parten de la misma [[Matriz de Pagos]]; lo que cambia es si las columnas llevan un $P_i$
o no.

## Valor esperado

Es el método base: "el valor de cada proyecto representa la 'esperanza' o el 'valor medio' de
los valores que puede adoptar el proyecto", pesados por la probabilidad de cada escenario.

$$VE(\text{decisión}) = \sum_i V_i \times P_i$$

- **$V_i$** — "la utilidad de la decisión en el estado de naturaleza $i$", en **pesos** (o en
  la medida de performance que use la matriz)
- **$P_i$** — "la probabilidad de ocurrencia del estado de la naturaleza $i$", en **tanto por
  uno**, y las $P_i$ de una fila suman 1
- **VE** — valor esperado de esa decisión, en **pesos**

## Los criterios de decisión con riesgo

| Criterio | Qué hace |
|---|---|
| **Regla de Bayes** | "Con las mejores estimaciones de probabilidades elegir la alternativa de **mayor valor esperado**" |
| **Aversión al riesgo** | "Elegir la alternativa que no supere un % techo de riesgo de pérdidas o elegir la alternativa de **menor probabilidad de pérdida**" |
| **Varianza** | "refleja la dispersión de las observaciones en torno a la media. El grado de Riesgo de cada proyecto se ve reflejado en la magnitud de la varianza" |
| **Equivalente cierto** | "la suma de dinero para la cual el decisor es **indiferente** entre recibirla o ejecutar un proyecto […] Cuánto está dispuesto a pagar (o dejar de ganar), para no enfrentar un juego" |

La pareja **valor esperado + varianza** es la que hay que tener junta: el valor esperado dice
cuánto rinde en promedio, la varianza **cuánto riesgo tiene**. Dos proyectos con el mismo VE
pueden ser cosas muy distintas.

## Árboles de decisión

Sirven cuando hay **decisiones en secuencia** y se conocen las probabilidades de los eventos.
Tres componentes: **nodo cuadrado** ("punto en el que se debe tomar una decisión"), **nodo
circular** ("punto en el que ocurre un evento incierto") y **ramas** ("describen las distintas
secuencias de acontecimientos"), cada una con su probabilidad si sale de un círculo.

El mecanismo de resolución es lo que más se pregunta:

> "La secuencia temporal se desarrolla de **izquierda a derecha**. El árbol se procesa de **derecha a izquierda**. Los nodos de estados de la naturaleza se reducen reemplazándolos por un valor equivalente al correspondiente **valor esperado**. Los nodos de decisión se reducen comparando los valores de utilidad y **escogiendo el mayor**."

```mermaid
flowchart LR
    D1["<b>NODO CUADRADO</b><br/>acá decidís"] -->|"alternativa a1"| C1(["<b>NODO CIRCULAR</b><br/>acá decide el azar"])
    D1 -->|"alternativa a2"| C2(["<b>NODO CIRCULAR</b><br/>acá decide el azar"])
    C1 -->|"estado 1 · P1"| R1["Resultado"]
    C1 -->|"estado 2 · P2"| R2["Resultado"]
    C2 -->|"estado 1 · P1"| R3["Resultado"]
    C2 -->|"estado 2 · P2"| R4["Resultado"]
    style D1 fill:#7C5CFF,color:#fff
    style C1 fill:#FFA726,color:#fff
    style C2 fill:#FFA726,color:#fff
    style R1 fill:#4DB6AC,color:#fff
    style R2 fill:#4DB6AC,color:#fff
    style R3 fill:#4DB6AC,color:#fff
    style R4 fill:#4DB6AC,color:#fff
```

*Se arma de izquierda a derecha, se resuelve de derecha a izquierda: círculos por valor
esperado, cuadrados por el mayor.*

## Simulación de Montecarlo

> "consiste en determinar repetidamente el valor del VAN del proyecto, mediante la asignación aleatoria de un valor a cada variable pertinente del flujo […] donde la probabilidad de elegir entre todos los resultados posibles está en estricta relación con sus respectivas **distribuciones de probabilidades**."

Cómo funciona: se le asigna a cada variable no controlable una distribución (normal,
triangular, uniforme, beta, lognormal, gamma, exponencial, pareto), el programa sortea un valor
por variable en cada corrida y, "al pedirle que ejecute, por ejemplo, **mil iteraciones**",
devuelve una distribución de VAN e **"indica el porcentaje de escenarios en que el VAN es igual
o superior a cero"**. Software que nombra el apunte: Crystal Ball, Parisimet, SimulAr,
EasyPlanEx.

## Escenarios y sensibilidad

> "Los riesgos se analizan previendo situaciones futuras diferentes a las estimadas en el escenario base."

| Análisis | Qué mueve | Qué busca |
|---|---|---|
| **Multidimensional (escenarios)** | Varias variables a la vez: "se modifican las variables que más sensibilizan el resultado de la evaluación **en rangos extremos**" | Cómo queda el proyecto en un escenario optimista o pesimista |
| **Unidimensional (sensibilidad)** | Una variable por vez | "encuentra el valor **máximo o mínimo** de una variable para que el proyecto sea aceptable" |

## El límite honesto del método

> "El riesgo y la incertidumbre referidas a las consecuencias en estudio **no se eliminan por el uso de probabilidades**. Es valioso expresar el grado de confianza en las estimaciones a través del uso de distribuciones de probabilidad."

Las que nombra: **normal** (curva de Gauss) y **beta** (optimista, pesimista y más frecuente).

## Faltante

El apunte **no da la fórmula de la varianza**, ni ejemplos numéricos de valor esperado, ni un
árbol resuelto. Tampoco desarrolla cómo se estiman las probabilidades ni el teorema de Bayes
más allá de nombrar "la regla de Bayes" como criterio de elección.

## Conexiones

- [[Decisiones bajo Incertidumbre]] — el otro mundo: misma matriz, sin probabilidades
- [[Matriz de Pagos]] — el insumo del que salen los valores esperados
- [[Valor Actual Neto]] — es lo que se simula en Montecarlo y lo que suele ir en las celdas de la matriz
- [[Análisis de Sensibilidad y Escenarios]] — el análisis unidimensional y el multidimensional del proyecto
- [[Toma de Decisiones]] — el marco general de decisión al que esto le aporta el aparato cuantitativo
- [[Proyecto de Inversión]] — el riesgo del proyecto es lo que la varianza mide

## En el parcial

**Definir riesgo por la existencia de probabilidades, calcular el valor esperado de cada
alternativa de una matriz de pagos con $VE = \sum V_i \times P_i$ y elegir la de mayor VE
(regla de Bayes).** Si el ejercicio menciona decisiones en secuencia, va árbol: se procesa de
derecha a izquierda, círculos por valor esperado y cuadrados por el mayor.

Dos errores: verificá que **las probabilidades de una fila sumen 1** antes de calcular nada; y
no confundas valor esperado con varianza — el VE dice cuánto rinde, **la varianza es la que
mide el riesgo**. Dos proyectos con igual VE se separan por varianza.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos]
---

# Costos Medios

> Los costos **por unidad de producción**. Tres: fijo medio, variable medio y total medio.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Las tres fórmulas

$$CFMe = \frac{CF}{Q} \qquad CVMe = \frac{CV}{Q} \qquad CTMe = \frac{CT}{Q} = CFMe + CVMe$$

> "El **costo total medio** (CTMe), es el costo total (CT = CF + CV) dividido por el número de unidades producidas: CTMe = CT/Q = CFMe + CVMe. **Nos dice lo que cuesta en promedio cada unidad de producto.**"

Esa última igualdad, $CTMe = CFMe + CVMe$, es la mejor verificación cuando completás una tabla:
si no cierra, hay un error de arrastre.

## Las formas de las curvas

| Curva | Forma | Por qué |
|---|---|---|
| **CFMe** | Decreciente **siempre**, se acerca a cero sin tocarlo | El mismo monto fijo se reparte entre más unidades |
| **CVMe** | **U** | Rendimientos crecientes primero, decrecientes después |
| **CTMe** | **U**, por encima del CVMe | Es la suma de las dos anteriores |

Textual:

> "Las curvas CTMe y CVMe tienen **forma de "U"**, lo que se explica por la existencia de rendimientos crecientes en una primera fase y decrecientes en una segunda fase."

> 📌 A medida que $Q$ crece, la **distancia vertical entre CTMe y CVMe** —que es el CFMe— se
> achica. Las dos curvas se van juntando sin llegar a tocarse. Es un detalle que se pide
> dibujar bien.

<svg viewBox="0 0 440 190" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="164" y2="164" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="167" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="114" y2="114" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="117" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="64" y2="64" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="67" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">40</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">60</text><line x1="34" x2="34" y1="14" y2="164" stroke="var(--background-modifier-border,#8886)"/><line x1="202.6" x2="202.6" y1="14" y2="164" stroke="#4DB6AC" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="202.6" cy="139" r="3.4" fill="#4DB6AC"/><text x="202.6" y="175" text-anchor="middle" font-size="8" fill="#4DB6AC" font-weight="600">mín CVMe</text><line x1="255.9" x2="255.9" y1="14" y2="164" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="255.9" cy="117.5" r="3.4" fill="#7C5CFF"/><text x="255.9" y="175" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600">mín CTMe</text><path d="M68.8 26.7 L73.8 37.4 L78.7 46.3 L83.7 53.9 L88.7 60.4 L93.7 66.1 L98.6 71.1 L103.6 75.6 L108.6 79.6 L113.5 83.2 L118.5 86.4 L123.5 89.4 L128.5 92.1 L133.4 94.6 L138.4 96.9 L143.4 98.9 L148.3 100.9 L153.3 102.6 L158.3 104.3 L163.3 105.8 L168.2 107.2 L173.2 108.4 L178.2 109.6 L183.1 110.7 L188.1 111.6 L193.1 112.5 L198.1 113.3 L203 114.1 L208 114.7 L213 115.3 L217.9 115.8 L222.9 116.2 L227.9 116.6 L232.9 116.9 L237.8 117.1 L242.8 117.3 L247.8 117.4 L252.7 117.5 L257.7 117.5 L262.7 117.5 L267.7 117.4 L272.6 117.2 L277.6 117 L282.6 116.7 L287.5 116.4 L292.5 116.1 L297.5 115.7 L302.5 115.2 L307.4 114.7 L312.4 114.1 L317.4 113.5 L322.3 112.9 L327.3 112.2 L332.3 111.4 L337.3 110.6 L342.2 109.8 L347.2 108.9 L352.2 108 L357.1 107 L362.1 106 L367.1 104.9 L372.1 103.8 L377 102.7 L382 101.5" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="104.5" font-size="9" fill="#7C5CFF" font-weight="600">CTMe</text><path d="M34 116.9 L39 118.2 L43.9 119.4 L48.9 120.6 L53.9 121.8 L58.9 122.9 L63.8 124 L68.8 125.1 L73.8 126.1 L78.7 127.1 L83.7 128 L88.7 128.9 L93.7 129.8 L98.6 130.6 L103.6 131.4 L108.6 132.1 L113.5 132.8 L118.5 133.5 L123.5 134.1 L128.5 134.7 L133.4 135.3 L138.4 135.8 L143.4 136.3 L148.3 136.7 L153.3 137.1 L158.3 137.5 L163.3 137.8 L168.2 138.1 L173.2 138.3 L178.2 138.5 L183.1 138.7 L188.1 138.8 L193.1 138.9 L198.1 139 L203 139 L208 139 L213 138.9 L217.9 138.8 L222.9 138.7 L227.9 138.5 L232.9 138.3 L237.8 138 L242.8 137.7 L247.8 137.4 L252.7 137 L257.7 136.6 L262.7 136.2 L267.7 135.7 L272.6 135.2 L277.6 134.6 L282.6 134 L287.5 133.4 L292.5 132.7 L297.5 132 L302.5 131.3 L307.4 130.5 L312.4 129.6 L317.4 128.8 L322.3 127.9 L327.3 126.9 L332.3 125.9 L337.3 124.9 L342.2 123.9 L347.2 122.8 L352.2 121.6 L357.1 120.4 L362.1 119.2 L367.1 118 L372.1 116.7 L377 115.4 L382 114" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="117.0" font-size="9" fill="#4DB6AC" font-weight="600">CVMe</text><path d="M53.9 17.7 L58.9 38.1 L63.8 53.5 L68.8 65.6 L73.8 75.3 L78.7 83.2 L83.7 89.8 L88.7 95.5 L93.7 100.3 L98.6 104.5 L103.6 108.2 L108.6 111.4 L113.5 114.3 L118.5 116.9 L123.5 119.3 L128.5 121.4 L133.4 123.3 L138.4 125.1 L143.4 126.7 L148.3 128.2 L153.3 129.5 L158.3 130.8 L163.3 132 L168.2 133.1 L173.2 134.1 L178.2 135.1 L183.1 136 L188.1 136.8 L193.1 137.6 L198.1 138.3 L203 139.1 L208 139.7 L213 140.4 L217.9 141 L222.9 141.5 L227.9 142.1 L232.9 142.6 L237.8 143.1 L242.8 143.6 L247.8 144 L252.7 144.5 L257.7 144.9 L262.7 145.3 L267.7 145.7 L272.6 146 L277.6 146.4 L282.6 146.7 L287.5 147 L292.5 147.3 L297.5 147.6 L302.5 147.9 L307.4 148.2 L312.4 148.5 L317.4 148.8 L322.3 149 L327.3 149.3 L332.3 149.5 L337.3 149.7 L342.2 149.9 L347.2 150.2 L352.2 150.4 L357.1 150.6 L362.1 150.8 L367.1 151 L372.1 151.1 L377 151.3 L382 151.5" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="154.5" font-size="9" fill="#FFA726" font-weight="600">CFMe</text><text x="208.0" y="187" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*El CFMe cae siempre; el CVMe y el CTMe tienen forma de U. La distancia entre CTMe y CVMe es el CFMe, y por eso se van juntando.*


## La conexión con la producción — esto es lo que se pregunta

La forma de U no es casualidad: es el reflejo especular de la ∩ del producto medio.

> "Lo contrario de lo que ocurre con la curva de producto medio (primero asciende hasta un máximo y luego desciende). Esto se encuentra relacionado puesto que la evolución de los costos está condicionada por las características de producción: **cuando aumente la productividad de algún factor los costos medios se reducirán, mientras que si la productividad empieza a reducirse, lógicamente, los costos medios se incrementarán**."

| Producción | Costos |
|---|---|
| PMe **sube** | CVMe **baja** |
| PMe en su **máximo** ([[Máximo Técnico y Óptimo Técnico]]) | CVMe en su **mínimo** |
| PMe **baja** | CVMe **sube** |

Formalmente: $CVMe = w / PMe_L$. Si el precio del factor es constante, el costo variable medio
es literalmente la inversa del producto medio.

## Conexiones

- [[Costos Fijos Variables y Totales]] — los costos medios son estos divididos por Q
- [[Costo Marginal]] — corta a las curvas medias exactamente en su mínimo
- [[Relación entre Costo Marginal y Costo Medio]] — la regla que explica por qué ese corte ocurre en el mínimo
- [[Producto Total Medio y Marginal]] — el CVMe es el espejo del producto medio
- [[Máximo Técnico y Óptimo Técnico]] — el mínimo del CVMe se corresponde con el óptimo técnico
- [[Economías y Deseconomías de Escala]] — la versión de largo plazo de esta forma de U

## En el parcial

Completar la tabla y dibujar las tres curvas con las formas correctas. Verificación:
$CTMe = CFMe + CVMe$ en cada fila. Y saber explicar la U **por la productividad**, no
"porque sí".

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, dinero]
---

# El Dinero y los Intermediarios Financieros

> El banco toma depósitos a una tasa y presta a otra más alta: esa diferencia es el **spread**. Y
> como sólo tiene que guardar una fracción de lo que recibe, el sistema bancario **multiplica** el
> dinero que existe.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Las dos tasas y el spread

| Tasa | Quién la cobra / paga | Sobre qué |
|---|---|---|
| **Activa** | La cobra el banco | El dinero que te presta |
| **Pasiva** | La paga el banco | Tus depósitos |

$$Spread = Tasa\ activa - Tasa\ pasiva$$

El material lo define además en términos generales como "la diferencia entre el precio de compra y
el de venta de un activo financiero". Regla mnemotécnica: el banco es **activo** cuando presta
(pone la plata a trabajar) y **pasivo** cuando la recibe.

## Quién manda

> "Banco Central de la República Argentina: es el organismo rector del sistema financiero de la República Argentina, encargado de la política monetaria del país."

Dos atribuciones que aparecen en el resto de la unidad: fija el **coeficiente de caja** y compra o
vende divisas para morigerar las fluctuaciones del tipo de cambio.

## El multiplicador monetario

> "El efecto multiplicador del dinero es un proceso por el cual los bancos multiplican el dinero partiendo de una cantidad dada. Esto se debe a que los bancos sólo están obligados a mantener en sus reservas un nivel mínimo de dinero, el **coeficiente de caja**, determinado por cada Banco Central."

El ejemplo del material, que conviene reproducir tal cual en el parcial porque explica todo:

| Ronda | Depósito | Reserva (10 %) | Préstamo |
|---|---|---|---|
| 1 — Juan deposita | 1000 | 100 | 900, a María |
| 2 — María deposita los 900 | 900 | 90 | 810, a Fulano |
| 3 — y así sucesivamente | 810 | 81 | … |

Con un coeficiente de caja $c$ y un depósito inicial $D_0$, cada ronda presta la fracción que el
banco no está obligado a guardar:

$$D_n = D_0 \cdot (1 - c)^n$$

Con $D_0 = 1000$ y $c = 0{,}10$ salen los $900$ y los $810$ del ejemplo. La serie es **infinita y
decreciente**, y por eso el total que genera es finito. La interpretación es lo que importa: el
dinero no se imprime, se **crea por el crédito**, y cuanto más bajo es el coeficiente de caja más
presta el banco en cada ronda — que es exactamente por qué bajarlo es una medida **expansiva** en
[[Política Monetaria]].

```mermaid
flowchart LR
    D["Depósito inicial<br/>1000"] --> B1["Banco guarda 10%<br/>reserva 100"]
    B1 --> P1["Presta 900"]
    P1 --> B2["Se deposita<br/>guarda 90"]
    B2 --> P2["Presta 810"]
    P2 --> N["<b>Serie infinita<br/>y decreciente</b><br/>el dinero se multiplica"]
    style D fill:#4DB6AC,color:#fff
    style N fill:#7C5CFF,color:#fff
    style B1 fill:#FFA726,color:#fff
    style B2 fill:#FFA726,color:#fff
```

## Faltante

Este es el tema del programa peor cubierto después de la matriz insumo-producto. Los apuntes de
2025 **no traen**:

- la **definición de dinero** ni sus funciones (medio de cambio, unidad de cuenta, depósito de valor);
- los agregados monetarios (M1, M2, base monetaria) ni la distinción entre dinero legal y bancario;
- una **enumeración de los tipos de intermediarios financieros**: sólo nombran al BCRA y hablan
  genéricamente de "los bancos";
- la **fórmula cerrada del multiplicador monetario** en función del coeficiente de caja. Sólo está
  el proceso y el ejemplo numérico; la expresión de arriba es la formalización de esas rondas, no
  una fórmula que el material escriba.

## Conexiones

- [[Política Monetaria]] — el coeficiente de caja y la tasa de interés son sus instrumentos, y actúan sobre este mecanismo
- [[Flujo Circular del Ingreso]] — los intermediarios son el puente entre el ahorro que sale y la inversión que entra
- [[Inflación]] — más dinero en circulación sin más producción termina en precios
- [[Fuentes de Financiamiento]] — la tasa activa es, del lado de la empresa, el costo del financiamiento bancario
- [[Interés Simple e Interés Compuesto]] — la mecánica de las tasas se desarrolla en Ingeniería Económica
- [[Balanza de Pagos y Mercado de Divisas]] — el BCRA usa las reservas para intervenir en el mercado cambiario

## En el parcial

**Explicar el efecto multiplicador con el ejemplo de los 1000 pesos y el coeficiente de caja del
10 %: qué guarda el banco, qué presta y qué pasa cuando ese préstamo se vuelve a depositar.** Y la
pregunta corta segura: definir tasa activa, tasa pasiva y spread, y decir cuál es mayor. El error
clásico es invertir activa y pasiva; el segundo, creer que el coeficiente de caja lo fija el banco
comercial — lo determina el Banco Central.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes del `MACROECONOMIA — manuscrito iPad, nov 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

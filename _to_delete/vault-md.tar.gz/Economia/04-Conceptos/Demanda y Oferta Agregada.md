---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, equilibrio-macro]
---

# Demanda y Oferta Agregada

> Las mismas curvas de U3, pero para **toda la economía a la vez**: en el eje vertical el nivel
> general de precios, en el horizontal el PBI real. Donde se cruzan queda el equilibrio
> macroeconómico.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Demanda agregada

> "La demanda agregada (DA) es la cantidad total de bienes y servicios que los distintos sectores de la economía están dispuestos a comprar o gastar durante un período determinado."

$$DA = C + I + G + (X - M)$$

| Componente | Quién gasta |
|---|---|
| $C$ | Consumo privado de las familias |
| $I$ | Inversión de las empresas |
| $G$ | Gasto público |
| $X - M$ | Exportaciones netas: lo que compra el resto del mundo menos lo que le compramos |

Tiene **pendiente negativa**, "porque cuando bajan los precios aumenta la cantidad demandada de
bienes y servicios": cada punto de la curva indica, para un nivel de precios dado, el nivel de
gasto total o producción demandada.

Qué la mueve: la política monetaria (tasas de interés y cantidad de dinero), la política fiscal
(impuestos y gasto público) y otras fuerzas como las expectativas, la confianza y el comercio
exterior. Ahí está el enganche de toda la segunda mitad de la unidad: **las dos políticas actúan
sobre la DA**.

## Oferta agregada

> "Es la cantidad total de bienes y servicios que las empresas de un país están dispuestas a producir y vender en un determinado período, dados los precios, la capacidad productiva, los costos y las condiciones del mercado."

Viene determinada por el $PBI_{pm}$ y las importaciones $M$.

El mecanismo que explica su forma es el **mark-up**: cuando una empresa fija precios lo hace con
un margen porcentual sobre sus costos unitarios, y a nivel macro importa el margen promedio, que
depende del grado de competencia — a mayor competencia, menor margen. Como los márgenes cambian
lentamente, el margen promedio es estable en el corto plazo, pero el nivel de precios puede
moverse si cambian los costos. Y cuando el nivel general de precios aumenta a corto plazo, los
costos suben de forma generalizada por cuatro vías:

1. Aumento de los precios de los insumos o materias primas.
2. Necesidad de contratar más trabajadores.
3. Aumento de los precios de los factores productivos (trabajo, capital, tierra).
4. Incremento de los salarios nominales, sobre todo por la negociación entre empresas y trabajadores.

| | Corto plazo | Largo plazo |
|---|---|---|
| De qué depende | El nivel de precios al que las empresas están dispuestas a producir para cada nivel de producción o capacidad | El nivel de empleo, la tecnología y la capacidad productiva del país |
| Forma | Con pendiente | **Vertical** |
| Consecuencia | Más precios pueden traer más producción | Los aumentos de precios no incrementan la producción, sólo el nivel de precios |

## El equilibrio macroeconómico

> "Un EQUILIBRIO MACROECONÓMICO es una combinación de la cantidad y el precio globales con los que ni los compradores ni los vendedores desean alterar sus compras, ventas o precios. La intersección de las curvas de oferta y demanda agregadas determina el PIB real del equilibrio y el nivel general de precios."

```mermaid
flowchart LR
    PM["<b>Política monetaria</b><br/>tasas y cantidad de dinero"] --> DA["<b>DEMANDA AGREGADA</b><br/>C + I + G + (X &minus; M)<br/>pendiente negativa"]
    PF["<b>Política fiscal</b><br/>impuestos y gasto público"] --> DA
    EX["Expectativas, confianza<br/>y comercio exterior"] --> DA
    OA["<b>OFERTA AGREGADA</b><br/>PBI pm + M<br/>mark-up sobre costos"] --> EQ["<b>EQUILIBRIO MACRO</b><br/>PBI real de equilibrio<br/>+ nivel general de precios"]
    DA --> EQ
    style PM fill:#FFA726,color:#fff
    style PF fill:#FFA726,color:#fff
    style EX fill:#4DB6AC,color:#fff
    style OA fill:#4DB6AC,color:#fff
    style EQ fill:#7C5CFF,color:#fff
```

Una aclaración que evita un lío de fórmulas: una de las fuentes pone las exportaciones en la
demanda y las importaciones en la oferta. Igualando $OA = DA$ queda
$PBI_{pm} + M = C + I + G + X$, y despejando, $PBI_{pm} = C + I + G + (X - M)$. Es la misma
identidad de [[Métodos de Cálculo del PBI]], escrita de otra manera.

## Conexiones

- [[Métodos de Cálculo del PBI]] — la fórmula del gasto y la de la demanda agregada son la misma
- [[Política Fiscal]] — actúa sobre la DA por gasto público e impuestos
- [[Política Monetaria]] — actúa sobre la DA por tasa de interés y cantidad de dinero
- [[Producción Potencial y Brecha]] — la OA de largo plazo es vertical en la capacidad productiva del país
- [[Inflación]] — el nivel general de precios de equilibrio sale de este cruce
- [[Equilibrio de Mercado]] — el mismo razonamiento de oferta y demanda de U3, subido a escala agregada

## En el parcial

**Dibujar las dos curvas con los ejes bien rotulados (nivel general de precios en la vertical, PBI
real en la horizontal), marcar el equilibrio y explicar por qué la DA tiene pendiente negativa.**
Después, mover una: una política fiscal expansiva desplaza la DA y hay que decir qué pasa con
producción y precios. La pregunta trampa es la OA de largo plazo: si es vertical, un desplazamiento
de la DA **sólo sube los precios**, no la producción. El otro error clásico es escribir los ejes
como si fuera un mercado de U3 (precio y cantidad de un bien).

---
Fuente: `SEGUNDO PARCIAL — sección Macroeconomía`, con aportes de `UNIDAD 4 — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, indicadores]
---

# Valor Actual Neto

> El VAN mide **en pesos de hoy cuánto aumenta tu riqueza** por hacer la inversión, después de
> recuperar todo lo puesto y de pagarle a todos lo que exigían. Criterio: **si VAN > 0, se
> hace.**

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Qué mide

> "mide monetariamente, expresado en el momento presente, en cuánto varía la riqueza por hacer la inversión. Es decir, cuánto se gana **por sobre** lo que quiere ganar, después de recuperada la inversión."

Y la definición larga, que conviene citar porque enumera todo lo que ya está descontado adentro:

> "Es un monto de dinero que resulta si se lleva a cabo el proyecto, después de recuperar las inversiones realizadas, devolver el capital prestado más sus intereses (capital para financiar inversiones) y devolver el capital propio de los accionistas más los dividendos mínimos exigidos por estos."

Leelo despacio: el VAN **no es la ganancia del proyecto**. Es lo que sobra **después** de que
todos cobraron lo que exigían, incluidos los accionistas. Por eso $VAN = 0$ no es un mal
negocio: es un negocio que rinde exactamente lo exigido.

## La fórmula

> **Atención:** el apunte **no escribe** la fórmula del VAN. La de abajo es la traducción
> directa de lo que sí dice — aplicar a cada flujo el factor de actualización de
> [[Factores de Equivalencia]] y sumar. Verificala contra el teórico oficial.

$$VAN = \sum_{t=0}^{n} \frac{FF_t}{(1+d)^t}$$

- **$FF_t$** — flujo de fondos neto del momento $t$, en **pesos** de ese momento; el del
  momento 0 es la inversión inicial y va **negativo**
- **d** — [[Tasa de Descuento]], en **tanto por uno por período**
- **n** — cantidad de **períodos** del horizonte de análisis
- **VAN** — resultado en **pesos de hoy**

## Criterio de decisión

> "Si el VAN resulta positivo, el proyecto ofrece una rentabilidad mayor que la tasa de descuento adoptada."

| VAN | Qué significa | Decisión |
|---|---|---|
| $VAN > 0$ | Rinde **más** que la tasa de descuento; "equivale al aumento de riqueza por la inversión" | Se hace |
| $VAN = 0$ | Rinde **exactamente** lo exigido. Es el VAN de la alternativa nula | Indiferente |
| $VAN < 0$ | Rinde **menos** que lo exigido | No se hace |

## La alternativa nula

> "Siempre existe una alternativa para comparar que es la **alternativa nula**, es decir, el flujo de fondo sin proyecto. […] El VAN de la alternativa nula = 0."

No hacer nada **también es una opción**, y su VAN vale cero: un proyecto con VAN negativo
pierde contra no hacer nada.

## Ventaja, desventaja y el supuesto que se olvida

| | Qué dice el apunte |
|---|---|
| **Ventaja** | "refleja la incorporación de valor" |
| **Desventaja** | "no mide la tasa de rentabilidad del proyecto" — para eso está la [[Tasa Interna de Retorno]] |
| **Supuesto** | "Asume como supuesto la reinversión de los flujos de caja intermedios hasta el final de la vida del proyecto **a la tasa de descuento**. Al asumir interés compuesto se está asumiendo implícitamente que el interés se reinvierte periodo a período" |

## VAN o TIR: cuándo se separan

El apunte da la regla y es de las frases más preguntables de la unidad:

> "Entre dos proyectos **excluyentes**, el mayor VAN maximiza la ganancia. Pero si considero que tengo un **monto fijo de capital** a invertir, los proyectos de mayor TIR maximizan la ganancia."

Es decir: **pueden recomendar cosas distintas**, y cuál gana depende de si lo que te limita es
elegir uno solo (VAN) o repartir un presupuesto fijo (TIR). Ver
[[Tasa Interna de Retorno]].

## Faltante

El apunte no da **ningún ejemplo numérico** de cálculo de VAN, ni trata el valor residual ni la
definición del horizonte de análisis, que son temas del programa.

## Conexiones

- [[Tasa Interna de Retorno]] — es la tasa que hace este VAN igual a cero; se leen juntas siempre
- [[Tasa de Descuento]] — es la $d$ del denominador, y sin ella el VAN no significa nada
- [[Flujo de Fondos]] — es el insumo: el VAN actualiza y suma sus columnas
- [[Comparación de Alternativas]] — el VAN es uno de los dos métodos que sí consideran el valor tiempo
- [[Factores de Equivalencia]] — el VAN es aplicar el factor de actualización a cada flujo
- [[Proyecto de Inversión]] — es el indicador central para aceptar o rechazar un proyecto

## En el parcial

**Calcular el VAN de un flujo dado y concluir con la frase completa: "VAN > 0 ⇒ el proyecto
rinde más que la tasa de descuento adoptada ⇒ se acepta".** Media respuesta es sólo el número;
la otra media es qué significa contra $d$.

Tres errores caros: (1) olvidar que la **inversión inicial va en el momento 0 con signo
negativo**; (2) decir que $VAN = 0$ significa que el proyecto no gana nada — gana exactamente
lo exigido, y empata con la alternativa nula; (3) presentar el VAN como si midiera la
rentabilidad: **no la mide**, ésa es su desventaja declarada.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

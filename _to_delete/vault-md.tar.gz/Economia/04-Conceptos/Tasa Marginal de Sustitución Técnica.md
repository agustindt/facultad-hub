---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion, largo-plazo]
---

# Tasa Marginal de Sustitución Técnica

> La cantidad de un insumo que la empresa está dispuesta a **ceder** a cambio de una unidad
> adicional de otro, **sin perder producción**. Es la pendiente de la [[Isocuanta]].

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

$$TMST(L,K) = -\frac{dK}{dL} = -\frac{\text{Variación de la cantidad de capital } \Delta K}{\text{Variación de la cantidad de trabajo } \Delta L} \qquad \text{para igual } Q$$

Textual:

> "LA TASA MARGINAL DE SUSTITUCIÓN TÉCNICA: Es la cantidad de un insumo que una firma está dispuesta ceder a cambio de una unidad adicional de otro insumo, **sin que se produzcan pérdidas en la producción**. Se mide por la pendiente de la isocuanta en el punto que representa esa combinación."

El signo menos está para que la tasa quede **positiva**: como la isocuanta tiene pendiente
negativa, $\Delta K / \Delta L$ es negativo, y el menos lo da vuelta.

## Es decreciente, y eso es lo que se pregunta

Con los datos del gráfico del teórico, moviéndose sobre la misma isocuanta:

| Paso (trabajo) | Capital cedido | TMST |
|---|---|---|
| 1 → 2 | 2 | **2** |
| 2 → 3 | 1 | **1** |
| 3 → 4 | 2/3 | **2/3** |
| 4 → 5 | 1/3 | **1/3** |

Cada unidad adicional de trabajo permite ceder **menos** capital que la anterior. Por eso la
isocuanta es **convexa**: TMST decreciente ⟺ curva convexa. Son la misma afirmación.

## Por qué decrece

Porque los factores **no son perfectamente sustituibles**. Cuando tenés mucho capital y poco
trabajo, el capital está subutilizado y podés cederlo barato a cambio de un trabajador. Cuando
ya casi no te queda capital, cada máquina que sacás es crítica y hace falta muchísimo trabajo
para compensarla.

## La relación con los productos marginales

La TMST es el cociente de los productos marginales:

$$TMST = \frac{PMg_L}{PMg_K}$$

Y de acá sale, en un paso, la condición de minimización de costos: en el óptimo la TMST se
iguala a la relación de precios $w/r$. Ver [[Eficiencia Económica en Tecnología]].

## Conexiones

- [[Isocuanta]] — la TMST es literalmente su pendiente, y su carácter decreciente es la convexidad
- [[Producto Total Medio y Marginal]] — la TMST es el cociente entre los productos marginales de los dos factores
- [[Eficiencia Económica en Tecnología]] — el óptimo iguala la TMST con la relación de precios de los factores
- [[Costo de Oportunidad]] — es el mismo razonamiento de "a cuánto de A renuncio por una unidad de B", entre factores
- [[Isocosto]] — la relación $w/r$ es la pendiente del isocosto, con la que la TMST se compara

## En el parcial

Definición, fórmula con el signo menos explicado, y **por qué es decreciente**. Puede venir
como cálculo sobre una tabla de isocuanta.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

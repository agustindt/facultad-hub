---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, fallas]
---

# Bienes Públicos

> **Ni excluibles ni rivales: no se puede dejar afuera a quien no paga, y que lo use uno no le
> quita nada a los demás.** Por eso el mercado no los provee y proveerlos es una de las
> principales tareas del Estado.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Las dos propiedades que clasifican cualquier bien

Todo el tema se ordena con dos preguntas, y conviene tenerlas escritas exactas:

- **Rivalidad:** el consumo de un bien o servicio por parte de una persona implica que **nadie más** puede consumirlo.
- **Exclusión:** la capacidad de **excluir del consumo** a los que no pagan por él.

| Tipo de bien | ¿Excluible? | ¿Rival? | Ejemplos del material |
|---|---|---|---|
| **Bienes privados** | Sí | Sí | Comprar un alimento en el mercado. Los ofertan empresas privadas |
| **Recursos comunes** | **No** | Sí | Pesca en el mar |
| **Bienes públicos** | **No** | **No** | Defensa nacional, vacunación, enseñanza, espacios públicos, carreteras |

## Qué tiene de especial el bien público

> "Son mercancías en las que **el costo de extender el servicio a una persona adicional es cero** y de cuyo disfrute no se puede excluir a nadie, independientemente de quien pague, y su consumo por parte de un individuo no reduce la cantidad disponible para otro."

Y el problema práctico que eso genera: **si existe una disposición a pagar, no se encuentra
revelada.** El mercado necesita que la gente muestre cuánto valora las cosas comprándolas; con un
bien público nadie tiene motivo para mostrarlo, porque lo va a disfrutar igual.

De ahí las dos conclusiones que cierran el tema:

1. Los bienes públicos pueden considerarse un **caso extremo de externalidad positiva**, porque benefician de manera indivisible a toda una comunidad, quieran o no comprarlos los individuos.
2. **El mercado no puede proveer los bienes públicos.** Por lo tanto, su provisión es una de las principales tareas del Estado.

```mermaid
flowchart TD
    A["<b>¿SE PUEDE EXCLUIR<br/>A QUIEN NO PAGA?</b>"] -->|"sí"| B["¿Es rival?"]
    A -->|"no"| C["¿Es rival?"]
    B -->|"sí"| D["<b>BIEN PRIVADO</b><br/>lo provee el mercado"]
    C -->|"sí"| E["<b>RECURSO COMÚN</b><br/>pesca en el mar"]
    C -->|"no"| F["<b>BIEN PÚBLICO</b><br/>defensa, vacunación,<br/>carreteras"]
    F --> G["Costo de una persona<br/>adicional = CERO"]
    F --> H["La disposición a pagar<br/>NO se revela"]
    G --> I["<b>Lo provee el ESTADO</b>"]
    H --> I
    style A fill:#7C5CFF,color:#fff
    style D fill:#4DB6AC,color:#fff
    style E fill:#FFA726,color:#fff
    style F fill:#7C5CFF,color:#fff
    style I fill:#7C5CFF,color:#fff
```

## ⚠️ Faltante

El material desarrolla **tres** de las cuatro combinaciones posibles de rivalidad y exclusión.
**Falta el cuarto casillero: los bienes excluibles pero no rivales.** No aparece con ningún
nombre ni con ejemplos en ninguna de las cuatro fuentes. Si en clase se pide la matriz 2×2
completa, ese casillero hay que buscarlo aparte.

## Conexiones

- [[Externalidades]] — el material define al bien público como caso extremo de externalidad positiva
- [[Fallas del Mercado]] — la imposibilidad de proveerlos por el mercado es una falla, y de las que más se citan
- [[Rol del Estado y Desarrollo Sustentable]] — la provisión de bienes públicos es una de las principales tareas del Estado
- [[Excedente del Consumidor]] — la disposición a pagar existe pero no se revela: por eso no hay demanda de mercado que medir
- [[Competencia Perfecta]] — el modelo eficiente supone bienes privados; con bienes públicos el mecanismo de precios directamente no arranca

## En el parcial

**Definir rivalidad y exclusión y clasificar bienes concretos en las tres categorías.** Te dan
una lista (una hamburguesa, el alumbrado público, un banco de peces, una vacuna) y hay que
ubicar cada uno. La clave es hacerse las dos preguntas por separado y en orden: primero *¿puedo
dejar afuera al que no paga?*, después *¿si lo consume uno, se acaba para otro?* El error clásico
es llamar "bien público" a cualquier cosa que provee el Estado: lo que define al bien público son
las **dos propiedades**, no quién lo paga. Saber también la frase de por qué el mercado no puede
proveerlos.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, coincidente con `SEGUNDO PARCIAL — Google Docs`, `Resumen temas coloquio` y el manuscrito `MERCADOS` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

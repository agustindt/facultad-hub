---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, indicadores]
---

# Tasa Interna de Retorno

> La TIR es **la tasa que hace el VAN igual a cero**. Como está en porcentaje y no en pesos,
> es la que responde lo que el [[Valor Actual Neto]] no responde: cuánto rinde el proyecto.
> Criterio: **conviene invertir si la tasa exigida es menor que la TIR.**

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Definición

Las dos frases del apunte:

> "es aquella tasa de interés que hace igual a cero el valor actual neto. Es conveniente realizar la inversión cuando la tasa exigida es menor que la TIR."

> "Es aquella tasa, que, utilizada como tasa de descuento, hace que el VAN sea cero. Es decir, hace que se igualen los egresos actualizados a los ingresos actualizados. En estas condiciones, la TIR representa **la rentabilidad del proyecto**."

## La fórmula

> **Atención:** igual que con el VAN, el apunte **no escribe** la ecuación. Ésta es la
> traducción literal de "la tasa que hace el VAN igual a cero". Verificala contra el teórico
> oficial.

$$\sum_{t=0}^{n} \frac{FF_t}{(1 + TIR)^t} = 0$$

- **$FF_t$** — flujo de fondos neto del momento $t$, en **pesos**; el del momento 0 es la
  inversión y va negativo
- **n** — cantidad de **períodos**
- **TIR** — la incógnita: una **tasa por período**, en tanto por uno (por 100, porcentaje)

Fijate que acá la tasa es **el resultado**, no el dato. En el VAN la tasa entra; en la TIR
sale.

## Criterio de decisión

| Comparación | Qué significa | Decisión |
|---|---|---|
| $d < TIR$ | El proyecto rinde más que lo exigido | **Se hace** |
| $d = TIR$ | Rinde exactamente lo exigido — es el punto donde $VAN = 0$ | Indiferente |
| $d > TIR$ | Rinde menos que lo exigido | No se hace |

Donde $d$ es la [[Tasa de Descuento]], o sea la tasa exigida / TMRA. Es el mismo criterio que
el del VAN dicho en otro idioma: $d < TIR$ y $VAN > 0$ son la misma cosa.

## VAN y TIR: dónde se separan

Ahí está la pregunta fina de la unidad. Textual:

> "El VAN y la TIR se utilizan para seleccionar proyectos, según los casos. Entre dos proyectos **excluyentes**, el **mayor VAN** maximiza la ganancia. Pero si considero que tengo un **monto fijo de capital** a invertir, los proyectos de **mayor TIR** maximizan la ganancia."

| | [[Valor Actual Neto]] | Tasa Interna de Retorno |
|---|---|---|
| **Unidad del resultado** | Pesos de hoy | Porcentaje por período |
| **Qué responde** | Cuánta riqueza agrega | Cuánto rinde |
| **La tasa de descuento es…** | Un dato de entrada | El resultado |
| **Criterio** | $VAN > 0$ | $TIR >$ tasa exigida |
| **Gana cuando la restricción es…** | Elegir **uno** entre proyectos excluyentes | Repartir un **monto fijo de capital** |
| **Debilidad declarada** | "no mide la tasa de rentabilidad del proyecto" | El apunte no le señala una |

```mermaid
flowchart TD
    P["<b>Proyecto con su<br/>flujo de fondos</b>"] --> Q{"¿Qué te limita?"}
    Q -->|"Elegir uno solo entre<br/>proyectos excluyentes"| V["Ordenar por <b>MAYOR VAN</b><br/>maximiza la ganancia"]
    Q -->|"Repartir un monto<br/>fijo de capital"| T["Ordenar por <b>MAYOR TIR</b><br/>maximiza la ganancia"]
    V --> D["<b>DECISIÓN</b>"]
    T --> D
    style P fill:#4DB6AC,color:#fff
    style Q fill:#FFA726,color:#fff
    style D fill:#7C5CFF,color:#fff
```

## Faltante

El apunte **no explica cómo se calcula la TIR** (ni por interpolación ni por iteración), no da
ejemplos numéricos, y **no menciona el problema de las TIR múltiples** en flujos con más de un
cambio de signo. Tampoco trata la TIR modificada.

## Conexiones

- [[Valor Actual Neto]] — la TIR es exactamente la tasa que lo anula; se estudian y se responden juntas
- [[Tasa de Descuento]] — es la tasa exigida contra la que se compara la TIR
- [[Flujo de Fondos]] — es el insumo del que sale la ecuación
- [[Comparación de Alternativas]] — junto con el VAN, son los dos métodos que consideran el valor tiempo
- [[Proyecto de Inversión]] — la TIR es lo que se informa como "rentabilidad del proyecto"
- [[Maximización de Beneficios]] — la lógica de elegir el mayor rendimiento marginal del capital es la misma

## En el parcial

**Definir la TIR como la tasa que hace VAN = 0, enunciar el criterio (conviene si la tasa
exigida es menor que la TIR) y saber decir en qué caso VAN y TIR ordenan distinto:** proyectos
excluyentes → mayor VAN; monto fijo de capital a repartir → mayor TIR. Esa última frase es
casi textual del apunte, memorizala así.

El error clásico es comparar la TIR contra cero ("TIR positiva, se hace"). **La TIR no se
compara contra cero: se compara contra la tasa exigida.** Una TIR del 8 % con una TMRA del
15 % es un proyecto que se rechaza.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

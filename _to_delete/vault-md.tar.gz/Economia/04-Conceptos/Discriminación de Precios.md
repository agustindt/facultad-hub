---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados, competencia]
---

# Discriminación de Precios

> **Cobrar precios distintos a clientes distintos por el mismo bien, sin que la diferencia
> responda a distintos costos de producción.** Es lo que hace el monopolista para quedarse con
> el excedente que, con precio único, se llevaba el comprador.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## La definición, con su condición escondida

> "Cuando un monopolista cobra precios diferentes a diversos clientes (**no de acuerdo con los diferentes costos de producción**), se dice que hay DISCRIMINACIÓN DE PRECIOS."

Esa aclaración entre paréntesis es la que se pregunta: si cobrás más caro porque **te cuesta**
más producir o entregar, eso no es discriminación de precios. Discriminar es cobrar distinto por
**lo mismo**, según cuánto valore el bien cada comprador.

## Por qué le conviene al monopolista

Con un precio único, el monopolista pierde en los dos extremos:

| Si pone el precio… | Qué pierde |
|---|---|
| **Alto** | Las ventas de los potenciales compradores que **menos valoran** el bien |
| **Bajo** | Los ingresos adicionales de los que **estaban dispuestos a pagar más** |

Discriminando resuelve las dos pérdidas a la vez: le vende más caro a quien más lo valora y más
barato a quien menos lo valora o tiene menos recursos. **Si el monopolista pudiera discriminar
precio, conseguiría aumentar su beneficio.**

El objetivo, textual: *"maximizar los beneficios capturando una mayor proporción del
[[Excedente del Consumidor|excedente del consumidor]]"*.

## Los tres grados

| Grado | Criterio | Ejemplo del material |
|---|---|---|
| **Primer grado** | Un precio distinto para **cada cliente** | Es un caso teórico |
| **Segundo grado** | Según la **cantidad comprada** | Tarifas eléctricas |
| **Tercer grado** | Según el **grupo de consumidores** | Estudiantes, jubilados |

```mermaid
flowchart TD
    A["<b>MONOPOLISTA</b><br/>enfrenta compradores con<br/>distinta disposición a pagar"] --> B["Segmenta en subgrupos<br/>según cuánto valoran el bien"]
    B --> C["Precio ALTO<br/>a quien más lo valora"]
    B --> D["Precio BAJO<br/>a quien menos lo valora<br/>o tiene menos recursos"]
    C --> E["<b>Mayor beneficio</b><br/>captura excedente<br/>del consumidor"]
    D --> E
    style A fill:#7C5CFF,color:#fff
    style C fill:#FFA726,color:#fff
    style D fill:#4DB6AC,color:#fff
    style E fill:#7C5CFF,color:#fff
```

## Los tres ejemplos del material

- **Agua:** "Precio 1" para consumo familiar y "Precio 2" para consumo de lujo (riego, piscina).
- **Boletos de transporte:** hay mayor disposición a pagar por viajes de negocios que por viajes de placer.
- **Descuentos por volumen:** son un buen sistema de discriminación *"ya que la disposición de un cliente a pagar por una unidad adicional disminuye conforme compra más unidades"*.

Fijate que el tercer ejemplo cierra el círculo con el arranque de la unidad: los descuentos por
volumen funcionan **porque la utilidad marginal es decreciente**.

## Conexiones

- [[Monopolio]] — la discriminación es una estrategia del monopolista: presupone poder de mercado
- [[Excedente del Consumidor]] — es exactamente lo que la discriminación busca capturar
- [[Elasticidad Precio de la Demanda]] — segmentar tiene sentido porque cada grupo responde distinto al precio
- [[Ley de la Utilidad Marginal Decreciente]] — el descuento por volumen funciona porque la disposición a pagar por la unidad siguiente cae
- [[Concentración y Defensa de la Competencia]] — es una de las conductas que las autoridades de competencia miran de cerca

## En el parcial

**Definir discriminación de precios incluyendo la condición "no por diferencias de costos", y
clasificar tres casos concretos en primero, segundo o tercer grado.** Un ejercicio típico te da
ejemplos sueltos (tarifa de estudiante, descuento por comprar 10 unidades, regateo uno a uno) y
hay que asignar el grado. Y saber explicar en una frase **por qué le conviene al monopolista**:
con precio único pierde las ventas de los que valoran poco *y* los ingresos extra de los que
valoran mucho.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con la clasificación en tres grados de `SEGUNDO PARCIAL — Google Docs` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, costos]
---

# Costeo por Absorción

> **El inventario "absorbe" TODOS los costos de manufactura**, fijos y variables. Los costos
> indirectos **fijos** de fábrica entran al producto y se quedan en el activo hasta que el producto
> se vende. Ésa es la única diferencia real con el [[Costeo Variable]], y es toda la diferencia.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## La definición

> "Es un método de costeo donde **todos los Costos del Producto (fijos y variables) se incluyen como costos inventariables**. Es decir, el inventario 'absorbe' todos los costos de manufactura."

Se considera **costo del producto**: el costo de **material**, el de **mano de obra** y los
**costos indirectos de fábrica, tanto fijos como variables**. Del otro lado, "todos los costos que
no son de manufactura —comercialización, administración, financiación, desarrollo, etc.— resultan
**no inventariables** y se registran como **Gastos del Período**".

**Fijate dónde cae la línea.** No es entre fijo y variable: es entre **fabricación y no
fabricación**. Un CIF fijo de planta es inventariable; todo lo de comercialización, administración,
financiación y desarrollo no lo es, sea fijo o variable.

```mermaid
flowchart TD
    MAT["Material"] --> INV["<b>INVENTARIO</b><br/>costo del producto<br/>queda en el ACTIVO"]
    MO["Mano de obra"] --> INV
    CIFV["CIF variables"] --> INV
    CIFF["<b>CIF FIJOS</b><br/>acá está la clave"] --> INV
    INV -->|"cuando se vende"| CMV["<b>CMV</b><br/>en el Estado de Resultados"]
    NOFAB["Comercialización · Administración<br/>Financiación · Desarrollo"] --> GP["<b>GASTOS DEL PERÍODO</b><br/>bajan directo al resultado"]
    style INV fill:#7C5CFF,color:#fff
    style CIFF fill:#FFA726,color:#fff
    style CMV fill:#4DB6AC,color:#fff
    style GP fill:#4DB6AC,color:#fff
```

## Cómo termina en el estado de resultados

> "El Costo del producto fabricado y vendido se convierte en el Estado de Resultado en gastos con la forma de '**costo de mercadería vendida / servicios prestados**'."

El costo se queda quieto en el activo y **sólo baja al resultado en el momento de la venta**:
mientras no se venda, es un bien, no una pérdida — ver [[Estados Contables Básicos]]. Para acumular
los CIF y los gastos del período se usan **centros de costos**, cada uno con su base de distribución
(hs máquina, hs MOD, costo de MP, % de facturación); ver [[Contabilidad de Costos]].

## Absorción vs. variable — la tabla que hay que saber

Textual del apunte:

> "En el costeo por absorción, **todos los costos son inventariables**, mientras que en costeo variable **sólo se tiene en cuenta los costos de fabricación variables** a la hora de calcular el CMV, siendo los CF considerados como **costos del período**."

| | **Costeo por absorción** | **Costeo variable** |
|---|---|---|
| Otro nombre | Costeo total / completo | Costeo directo o marginal |
| Costos **variables** de fabricación | Inventariables | Inventariables |
| Costos **fijos** de fabricación (CIF fijos) | **Inventariables**: entran al producto | **Gasto del período**: van al resultado del mes |
| Administración, ventas, financiación | Gasto del período | Gasto del período |
| Qué hay dentro del CMV | Costos de fabricación fijos **y** variables | Sólo los costos de fabricación **variables** |
| Conceptos de gestión que aporta | — | Contribución marginal y punto de equilibrio |
| Lógica de fondo | Todo lo fabricado costó, y ese costo viaja con el producto | Los fijos son "costos de estar", no de producir |

## Faltante

**El material no trae ningún ejemplo numérico** que compare los dos métodos. En particular, no
muestra el caso que el tema pide: qué pasa con el resultado cuando la **producción es distinta de
las ventas**. La diferencia queda enunciada pero **no cuantificada**.

## Conexiones

- [[Costeo Variable]] — el método espejo: mismo trato a los variables, trato opuesto a los CIF fijos. Es **la** comparación del bloque
- [[Contabilidad de Costos]] — acá se decide qué es costo del producto y qué es gasto del período
- [[Costos Fijos Variables y Totales]] — la clasificación de U2 es la que este método deliberadamente **no** usa
- [[Estados Contables Básicos]] — lo inventariado queda en el activo; lo vendido pasa al resultado como CMV
- [[Valuación de Activos]] — para inventariar un costo hay que valuarlo, y el método cambia el número
- [[Costeo por Órdenes y por Procesos]] — cómo se acumulan esos costos entre productos

## En el parcial

Es la comparación más evaluable de la unidad. **Decir en una frase qué hace cada método con los
costos indirectos FIJOS de fabricación: absorción los inventaria, variable los manda a resultado
del período.** Todo lo demás lo tratan igual. Si te dan una lista de costos, clasificá cada uno en
inventariable / gasto del período **según el método**: la trampa es que la misma erogación cambia
de casillero, pero **sólo si es un costo fijo de fabricación**. El error clásico es creer que el
costeo variable saca del producto *todos* los costos fijos, incluidos los de administración: ésos
ya eran gasto del período en los dos métodos.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

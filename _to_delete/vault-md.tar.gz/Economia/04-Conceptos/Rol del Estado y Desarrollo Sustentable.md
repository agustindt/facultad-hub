---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, estado]
---

# Rol del Estado y Desarrollo Sustentable

> **El Estado interviene por dos razones: promover la eficiencia y promover la igualdad.** Con
> tres instrumentos —impuestos, gastos y regulación— y, en el cierre de la unidad, con un
> objetivo que el material le asigna directamente a la ingeniería: el desarrollo sustentable.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Las dos razones de la intervención

> "**Rol del Estado: promover la eficiencia y la igualdad.** Estos son las dos grandes razones por las cuales el gobierno debe intervenir en la economía, para cambiar la manera en que las personas asignarían los recursos."

| Razón | De dónde viene |
|---|---|
| **Eficiencia** | De las [[Fallas del Mercado]]: poder de mercado, información imperfecta y externalidades hacen que el mercado no asigne bien por sí solo |
| **Igualdad** | El mercado eficiente puede dejar una distribución del ingreso muy desigual — y eficiencia no es lo mismo que equidad |

**Estado de bienestar:** alude a la responsabilidad del Estado por el bienestar de la población
(Europa de posguerra). Es el conjunto de servicios sociales —pensiones, desempleo, salud,
educación— que garantizan a los ciudadanos un nivel de subsistencia. Supone que el Estado
**modifica las fuerzas del mercado** para proteger a los individuos de ciertas contingencias y
garantizarles un nivel mínimo de vida.

## Los tres instrumentos

| Instrumento | Qué es |
|---|---|
| **Impuestos** | Se establecen sobre los ingresos y sobre los bienes y servicios. **Reducen el ingreso y el gasto privado** (política fiscal) |
| **Gastos** | Compras de bienes y servicios del sector público, sueldos de funcionarios, seguridad social y otras transferencias (política fiscal) |
| **Regulación** | Control de la actividad económica que lleva a individuos y empresas a realizar determinadas actividades o a abstenerse. Son normas destinadas a controlar las decisiones de las empresas sobre **precios, ventas o producción** |

Los dos primeros están explícitamente etiquetados como **política fiscal** en el material: es el
puente directo con la macroeconomía. La fijación de precios máximos y mínimos, con todas sus
consecuencias, está en [[Equilibrio de Mercado]].

## Cómo se mide la igualdad de la que habla el rol del Estado

**Principio de Pareto o ley 80-20:** es la *observación* (no ley) de que la mayoría de las cosas
en la vida no se distribuyen de manera uniforme — el 80 % de la riqueza y los ingresos son
producidos por el 20 % de la población, y el 20 % más rico acapara el 80 % de los recursos.

**Curva de Lorenz:** muestra cómo se distribuye el ingreso, reflejando la relación entre los
grupos de la población y sus respectivas participaciones en el ingreso nacional. Si todas las
familias tuvieran la misma riqueza, sería una **recta diagonal**; cuanto más alejada de esa
diagonal, mayor la desigualdad.

**Coeficiente de Gini:** medida de desigualdad derivada de la curva de Lorenz. Es el área entre
la curva y la recta diagonal, dividida por el área total bajo la diagonal.

| Valor de $G$ | Lectura |
|---|---|
| $G = 0$ | Sin desigualdad: la curva de Lorenz **es** la diagonal |
| Menor a 0,33 | Escasa desigualdad |
| Entre 0,33 y 0,67 | Desigualdad moderada |
| Mayor a 0,67 | Alta desigualdad |
| $G = 1$ | Desigualdad completa: una persona tiene todos los ingresos |

## El cierre de la unidad: desarrollo sustentable

> "**OBJETIVO DEMANDADO POR LA SOCIEDAD A LA INGENIERÍA: DESARROLLO SUSTENTABLE.**"

> "**Desarrollo sostenible:** es el obtenido de la satisfacción de las necesidades de las generaciones presentes, sin comprometer la capacidad de las generaciones futuras para satisfacer sus propias necesidades."

Sobre sustentable vs. sostenible, el material es prudente y conviene copiarle la prudencia: *"hoy
en día se utilizan como sinónimos, aunque podría decirse que el concepto de desarrollo
sustentable es más limitado"*.

| | **Economía ambiental** | **Economía ecológica** |
|---|---|---|
| Qué es | Una **rama de la economía** | **No** es una rama de las ciencias económicas: es un campo de estudio **multidisciplinario** |
| Qué analiza | Las externalidades negativas y positivas relacionadas con la optimización en la explotación de los recursos naturales, los medios para la gestión de la calidad ambiental y los instrumentos de política económica para el desarrollo sustentable | La sostenibilidad de las interacciones entre el sistema económico y el macrosistema natural |

```mermaid
flowchart TD
    A["<b>FALLAS DEL MERCADO</b>"] --> B["<b>ROL DEL ESTADO</b>"]
    C["Desigualdad en la<br/>distribución del ingreso<br/>Lorenz y Gini"] --> B
    B --> D["EFICIENCIA"]
    B --> E["IGUALDAD"]
    D --> F["Instrumentos:<br/>IMPUESTOS &middot; GASTOS &middot; REGULACIÓN"]
    E --> F
    F --> G["<b>DESARROLLO SUSTENTABLE</b><br/>objetivo que la sociedad<br/>le demanda a la ingeniería"]
    style A fill:#FFA726,color:#fff
    style C fill:#FFA726,color:#fff
    style B fill:#7C5CFF,color:#fff
    style F fill:#4DB6AC,color:#fff
    style G fill:#7C5CFF,color:#fff
```

## Conexiones

- [[Fallas del Mercado]] — son la justificación técnica de la intervención: sin falla, no hay razón de eficiencia para intervenir
- [[Bienes Públicos]] — su provisión es una de las principales tareas del Estado, porque el mercado no puede proveerlos
- [[Externalidades]] — la economía ambiental es, por definición del material, el estudio de externalidades
- [[Equilibrio de Mercado]] — ahí están los precios máximos y mínimos, la forma más directa de intervención sobre un mercado
- [[Política Fiscal]] — impuestos y gastos aparecen etiquetados como política fiscal: es la continuación macro de este tema
- [[Concentración y Defensa de la Competencia]] — la regulación y las leyes antimonopolio son el instrumento aplicado al poder de mercado

## En el parcial

**Enunciar las dos razones del rol del Estado (eficiencia e igualdad) y los tres instrumentos
(impuestos, gastos, regulación), y definir desarrollo sustentable con la frase de las
generaciones futuras.** Esa definición es citable casi textual y es la más probable de todo el
cierre de la unidad. Segunda consigna: **diferenciar economía ambiental de economía ecológica** —
una es rama de la economía, la otra es un campo multidisciplinario. Y saber leer un coeficiente
de Gini con los tres tramos (menos de 0,33 / 0,33 a 0,67 / más de 0,67).

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `Resumen temas coloquio` y `SEGUNDO PARCIAL — Google Docs` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

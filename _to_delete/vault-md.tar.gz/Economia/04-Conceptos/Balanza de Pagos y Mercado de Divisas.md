---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, sector-externo]
---

# Balanza de Pagos y Mercado de Divisas

> La balanza de pagos es el **registro sistemático de todas las transacciones entre residentes y no
> residentes** en un período. Su saldo no es un número abstracto: es exactamente la variación de
> las reservas del Banco Central.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Por qué hay comercio internacional

> "El COMERCIO INTERNACIONAL consiste en el intercambio de bienes, servicios y capitales entre los diferentes países."

Las razones que da el material son cuatro: diferencias en las dotaciones de recursos productivos,
distintas capacidades tecnológicas, **ventajas comparativas** en los costos de producción y
diferencias en los gustos o preferencias de los consumidores.

La ventaja comparativa está definida con la herramienta de U1: un país tiene ventaja comparativa en
un bien "cuando puede producirlo con **menor costo de oportunidad** que otros países". Y el
resultado: cuando cada uno se especializa donde tiene ventaja comparativa, todos se benefician,
porque la economía mundial produce y consume más con la misma cantidad de recursos.

| Forma de relacionarse | Qué busca | Ejemplos del material |
|---|---|---|
| Globalizadora | Abarcar a todos los países y fomentar el libre comercio | GATT, OMC |
| Regional | Iniciativas del bilateralismo comercial | Uniones aduaneras (arancel externo común), áreas de libre comercio (arancel propio ante terceros), unión económica (unión monetaria) |

Y del otro lado, el **proteccionismo**: políticas y procedimientos "que adoptan los gobiernos con
el fin de obstaculizar las transacciones económicas con el extranjero". Se justifica por tres
motivos —defensa nacional y sustitución de importaciones, industrias nacientes, combatir el déficit
del sector externo— y se ejecuta con tres instrumentos: aranceles o cuotas a la importación,
barreras no arancelarias y subvenciones a la exportación.

## La balanza de pagos y sus cuentas

Se contabilizan los **ingresos** (entradas de moneda extranjera) y los **pagos** (salidas de moneda
extranjera); el saldo es la diferencia entre unos y otros.

| Cuenta | Qué registra |
|---|---|
| **Corriente** | Los flujos de bienes, servicios, ingreso primario e ingreso secundario entre residentes y no residentes |
| **De capital** | Las compras y ventas de activos y pasivos, como acciones, bonos y tierras |
| **Financiera** | La compra y venta de activos y pasivos financieros por los residentes de un país al resto del mundo |

Hay déficit "cuando las importaciones son mayores que las exportaciones".

## Reservas: el termómetro

> "LAS RESERVAS son las posesiones que un país tiene de divisas y otros activos que pueden utilizarse para satisfacer las demandas de divisas y que sitúan al país como acreedor frente al exterior."

$$Saldo\ de\ la\ balanza\ de\ pagos = Variación\ de\ reservas$$

El Banco Central **reduce** sus reservas cuando la balanza de pagos tiene déficit y las
**incrementa** cuando presenta superávit. Por eso mirar la variación neta de reservas alcanza para
saber si la balanza está en déficit o superávit globalmente considerada.

```mermaid
flowchart LR
    X["Exportaciones y otros<br/>ENTRADAS de divisas"] --> B["<b>BALANZA DE PAGOS</b><br/>corriente + capital + financiera"]
    M["Importaciones y otros<br/>SALIDAS de divisas"] --> B
    B -->|"superávit"| SU["&uarr; Reservas del Banco Central"]
    B -->|"déficit"| DE["&darr; Reservas del Banco Central"]
    style X fill:#4DB6AC,color:#fff
    style M fill:#FFA726,color:#fff
    style B fill:#7C5CFF,color:#fff
```

## Tipo de cambio

> "Expresa el precio en unidades monetarias nacionales de una unidad de una moneda extranjera."

Leelo despacio, porque la dirección importa: el que se cotiza es el **bien extranjero**, la divisa.
Sobre su formación, el material dice dos cosas y las dos entran en la respuesta: "la cotización se
fija según la oferta y la demanda, pero el Banco Central interviene activamente comprando o
vendiendo divisas con el fin de morigerar las fluctuaciones". Es un precio de mercado con un
jugador grande adentro — el mismo BCRA que maneja la [[Política Monetaria]] y que tiene la
estabilidad del tipo de cambio entre sus objetivos.

## Faltante

El material trata el tipo de cambio pero **no el mercado de divisas como mercado**. No hay:

- regímenes cambiarios (fijo, flotante, flotación administrada) ni sus diferencias;
- devaluación, revaluación, apreciación y depreciación como conceptos definidos;
- gráfico de oferta y demanda de divisas ni efecto de la intervención sobre él;
- tipo de cambio real, ni la definición de "mercado común" dentro de las formas de integración
  regional que sí enumera.

## Conexiones

- [[Costo de Oportunidad]] — la ventaja comparativa se define exactamente con este concepto de U1
- [[Flujo Circular del Ingreso]] — exportaciones e importaciones son el par entrada/salida del resto del mundo
- [[Métodos de Cálculo del PBI]] — el término $(X - M)$ del método del gasto es el saldo comercial
- [[Política Monetaria]] — el Banco Central persigue la estabilidad del tipo de cambio y usa las reservas para intervenir
- [[El Dinero y los Intermediarios Financieros]] — el BCRA es el organismo que compra y vende divisas
- [[Objeto de la Macroeconomía]] — balanza de pagos y tipo de cambio son dos de los seis objetivos macro

## En el parcial

**Enumerar las tres cuentas de la balanza de pagos con lo que registra cada una, y explicar la
relación entre su saldo y las reservas del Banco Central: déficit significa reservas que caen.**
La otra consigna probable es de comercio: definir ventaja comparativa vía costo de oportunidad y
nombrar los tres instrumentos de protección. El error clásico es meter las importaciones de bienes
en la cuenta de capital: bienes y servicios van en la **cuenta corriente**; en la de capital van
acciones, bonos y tierras.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, costos]
---

# Contabilidad de Costos

> Todo el bloque de costos se apoya en **una sola distinción**: los **costos** se identifican con
> el producto, los **gastos** con el período. Si esa línea te queda clara, los sistemas de costeo
> se entienden como variantes de dónde ponerla.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Costo vs. Gasto — la distinción madre

| | **COSTO** | **GASTO** |
|---|---|---|
| Se identifica con | El **producto** elaborado o el servicio prestado | **Intervalos de tiempo**, no con los productos |
| Qué es | "El valor monetario de los recursos asignados a la elaboración de un producto o a la prestación de un servicio" | Erogaciones de las funciones de **distribución, administración y financiamiento** |
| Se compone de | Materia prima directa, mano de obra directa y cargos indirectos | Administración, ventas, RRHH, I+D, financieros e impositivos |

Ahí está la trampa del lenguaje corriente: en la calle son sinónimos; acá son categorías
**excluyentes**, y de qué lado caiga una erogación depende si se inventaría o si baja directo al
resultado del período.

## Qué es y para qué sirve

> "Es un sistema que le permite a las empresas identificar los costos de las tareas ejecutadas. Provee de información que sirva para la toma de decisión, la planificación y la evaluación del desempeño."

Sus **tres objetivos**, textuales: (a) proveer información para la **asignación de valor monetario**
a productos o servicios; (b) proveer información de **uso interno** para planeación, control y toma
de decisiones; (c) **visualizar desviaciones** para tomar medidas correctivas. Es opcional y
alimenta a la contabilidad financiera y a la administrativa; ver
[[Sistemas de Información Contable]].

## Los elementos del costo y sus bases de distribución

| Concepto | Qué incluye | Bases de distribución |
|---|---|---|
| **Costos primos** | Materia prima directa + mano de obra directa | Son directos: se identifican con el producto sin prorratear |
| **CIF** (costo indirecto de fabricación) | MOI, suministros, instalaciones y equipos | Hs máquina, hs MOD, costo de MP, MOD, etc. |
| **Gastos del período** | Administración, ventas, RRHH, I+D, financieros e impositivos | % costo de producción, % facturación, etc. |

Para acumular los CIF y los gastos del período "se hace uso del concepto de **CENTROS DE COSTOS**".

## El mapa de los sistemas de costeo

```mermaid
flowchart TD
    CC["<b>CONTABILIDAD DE COSTOS</b>"] --> Q1["¿Qué costos entran<br/>al producto?"]
    CC --> Q2["¿Cómo se reparten<br/>entre productos?"]
    Q1 --> ABS["<b>Costeo por absorción</b><br/>todos, fijos y variables"]
    Q1 --> VAR["<b>Costeo variable</b><br/>sólo los variables"]
    Q2 --> ORD["<b>Por órdenes</b><br/>productos distintos entre sí"]
    Q2 --> PRO["<b>Por procesos</b><br/>grandes cantidades homogéneas"]
    Q2 --> ABC["<b>ABC</b><br/>por actividades consumidas"]
    style CC fill:#7C5CFF,color:#fff
    style Q1 fill:#4DB6AC,color:#fff
    style Q2 fill:#FFA726,color:#fff
```

Son **dos preguntas independientes**: qué se inventaría ([[Costeo por Absorción]] vs.
[[Costeo Variable]]) y cómo se acumula ([[Costeo por Órdenes y por Procesos]] o
[[Costeo Basado en Actividades]]). Una empresa contesta las dos.

## Métodos para estimar costos

| Método | Cómo funciona |
|---|---|
| **Estadísticos** | "Método matemático formal para ajustar funciones de costos a observaciones de datos históricos", $C = f(Q)$, con correcciones **por escala** (tamaño) y **por índices de precios** (actualización) |
| **De ingeniería** | Analiza la relación entre insumos y productos "en **términos físicos**"; muy completa y detallada, "aunque puede consumir mucho tiempo" |
| **De análisis de cuentas** | Clasifica las cuentas de costos como **variables, fijas o mixtas** respecto del nivel de actividad |

$$C = \sum_i x_i \, h_i$$

donde $x_i$ es la cantidad del recurso $i$ y $h_i$ su precio unitario. Su aplicación cambia con el
tipo de producción: en **producción continua**, costo estándar; en **producción por proyecto**,
análisis de precios por ítem.

## Conexiones

- [[Sistemas de Información Contable]] — la de costos es la rama opcional, e informa a las otras dos
- [[Costeo por Absorción]] — la respuesta tradicional a qué costos son inventariables: todos
- [[Costeo Variable]] — la alternativa: sólo los variables; comparar ambos es el eje del bloque
- [[Costeo por Órdenes y por Procesos]] — los dos sistemas de acumulación entre productos
- [[Costeo Basado en Actividades]] — el que rompe con prorratear el CIF por una base única
- [[Costo Económico]] — el costo del contador no incluye los implícitos que sí incluye el del economista

## En el parcial

**Clasificar una lista de erogaciones en costo vs. gasto y, dentro de los costos, en primos vs.
CIF.** El criterio es uno solo: si se identifica con el **producto** es costo; si se identifica con
el **período** es gasto. Sueldo del operario de línea = costo (MOD); del jefe de planta = costo
indirecto (MOI); del vendedor = **gasto**. El error clásico es mandar todos los sueldos al mismo
casillero. Y saber enumerar los tres objetivos.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

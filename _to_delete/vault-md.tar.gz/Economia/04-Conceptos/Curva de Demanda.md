---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, demanda]
---

# Curva de Demanda

> **Muestra la cantidad demandada de un bien a cada precio.** Baja porque baja la utilidad
> marginal, y hay que saber cuándo te movés *sobre* la curva y cuándo la curva *se desplaza*.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## De dónde sale

No es un supuesto: es el resultado de repetir el [[Equilibrio del Consumidor]] para cada precio.

> "Podemos ver la curva de demanda del consumidor como la suma de las decisiones óptimas que se originan de su restricción presupuestaria y sus curvas de indiferencia."

**Demanda individual:** la cantidad de un bien que un consumidor está dispuesto a comprar a
distintos precios en un tiempo determinado. Su curva tiene **pendiente negativa**: a mayor
precio, menor cantidad a consumir, y viceversa.

## La función de demanda y sus cuatro determinantes

$$Q_a = f(P_a,\ P_b,\ Y,\ G)$$

| Símbolo | Qué es |
|---|---|
| $P_a$ | Precio del bien $a$ |
| $P_b$ | Precio de los otros bienes |
| $Y$ | Ingreso |
| $G$ | Gustos (preferencias subjetivas) |

## Ley de la demanda: moverse vs. desplazarse

Ésta es **la** distinción operativa del tema.

> "Si todo lo demás permanece constante, la cantidad demandada de un bien disminuye cuando aumenta el precio de ese bien."

| Qué cambia | Qué pasa con la curva |
|---|---|
| El **precio del propio bien** ($P_a$) | Te movés **sobre** la curva — cambia la *cantidad demandada* |
| Ingreso, precio de otros bienes, gustos | La curva **se desplaza** a derecha o izquierda — cambia la *demanda* |

```mermaid
flowchart TD
    P["Cambia el PRECIO<br/>del propio bien"] --> M["<b>Movimiento SOBRE la curva</b><br/>ley de la demanda"]
    O["Cambia el INGRESO,<br/>el precio de otros bienes<br/>o los gustos"] --> D["<b>DESPLAZAMIENTO de la curva</b><br/>a derecha o a izquierda"]
    M --> R["Cambia la<br/>cantidad demandada"]
    D --> S["Cambia la<br/>demanda"]
    style P fill:#4DB6AC,color:#fff
    style O fill:#FFA726,color:#fff
    style M fill:#7C5CFF,color:#fff
    style D fill:#7C5CFF,color:#fff
```

## De la demanda individual a la demanda de mercado

> "La demanda de un mercado es la suma de las cantidades demandadas por los compradores a cada precio. Por lo tanto, la curva de demanda del mercado se halla **sumando horizontalmente** las curvas individuales."

Horizontalmente, no verticalmente: a cada precio se suman **cantidades**. Esa curva de mercado
es la que después se cruza con la oferta en el [[Equilibrio de Mercado]], y es también la que
enfrenta entero el monopolista.

## Conexiones

- [[Equilibrio del Consumidor]] — la curva de demanda es la colección de óptimos del consumidor a distintos precios
- [[Ley de la Utilidad Marginal Decreciente]] — es la razón de fondo de la pendiente negativa
- [[Elasticidad Precio de la Demanda]] — mide *cuánto* responde la cantidad al precio a lo largo de esta curva
- [[Elasticidad Ingreso y Cruzada]] — miden el efecto de los otros dos determinantes, $Y$ y $P_b$, que desplazan la curva
- [[Equilibrio de Mercado]] — la demanda de mercado es una de las dos curvas que se cruzan
- [[Monopolio]] — el monopolista enfrenta directamente la curva de demanda del mercado, y por eso tiene poder sobre el precio

## En el parcial

**Dada una lista de cambios, decir en cada caso si hay movimiento sobre la curva o
desplazamiento de la curva, y hacia dónde.** Es la pregunta más repetida del tema y se pierde
por confundir *cantidad demandada* con *demanda*: sólo el precio del propio bien mueve **sobre**
la curva; todo lo demás la desplaza. Saber además escribir $Q_a = f(P_a, P_b, Y, G)$ nombrando
las cuatro variables, y explicar por qué la demanda de mercado se obtiene sumando
**horizontalmente** las individuales.

---
Fuente: `Resumen temas coloquio — sección demanda/mercados`, con el manuscrito `MERCADOS` (nov 2025) y `ECONOMIA FINAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

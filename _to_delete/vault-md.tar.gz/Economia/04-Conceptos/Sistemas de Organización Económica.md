---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos]
---

# Sistemas de Organización Económica

> Las tres formas en que una sociedad puede contestar qué, cómo y para quién producir: por
> **autoridad**, por **mercado**, o una mezcla de ambas.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

| Sistema | Quién decide | Cómo se lo llama | Régimen de propiedad |
|---|---|---|---|
| **De autoridad** | El Estado | Economía **dirigida** | Derecho **público** |
| **De mercado** | Los precios libres | Economía **de mercado** | Propiedad **privada** |
| **Mixto** | El mercado, con el Estado interviniendo en ciertos momentos | Economía mixta | Ambos |

Textual de la cátedra:

> "**SISTEMA DE AUTORIDAD** — El Estado es quien decide → economía dirigida, derecho público.
> **SISTEMA DE MERCADO** — Sistema de actividades y precios libres → economía de mercado, propiedad privada.
> **SISTEMA MIXTO** — Se deja actuar al mercado y el Estado interviene en ciertos momentos."

## Lo que hay que entender, no memorizar

La diferencia real está en **qué mecanismo transmite la información** sobre qué hace falta:

- En el sistema de **mercado**, esa información viaja en los **precios**. Si un bien escasea,
  su precio sube, y eso por sí solo le avisa a los productores que conviene producir más y a
  los consumidores que conviene consumir menos. Nadie coordina: el precio coordina.
- En el sistema de **autoridad**, la información tiene que ser recolectada y procesada por una
  planificación central, que decide cantidades y destinatarios.

Ningún país real es puro. **Todas las economías contemporáneas son mixtas**; lo que varía es
dónde se pone el límite de la intervención — que es justamente el tema de las fallas de mercado
y el rol del Estado de la U3.

## Conexiones

- [[Problema Económico de Toda Sociedad]] — estos sistemas son las tres respuestas posibles a las tres preguntas
- [[Escasez]] — sin escasez no habría nada que asignar y ningún sistema haría falta
- [[Actividad Económica]] — en el sistema de mercado, el circuito productores ↔ consumidores se coordina por precios
- [[Microeconomía y Macroeconomía]] — el rol del Estado es materia macro; la formación de precios, materia micro

## En el parcial

Los tres sistemas con su nombre y su régimen de propiedad. Puede venir como pregunta de
opción múltiple o para asociar columnas.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

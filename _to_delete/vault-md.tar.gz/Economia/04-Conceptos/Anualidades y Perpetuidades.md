---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, equivalencia]
---

# Anualidades y Perpetuidades

> Una **anualidad** es una serie de montos iguales y periódicos durante un plazo determinado.
> Una **perpetuidad** es la misma serie pero sin fin — y por eso su valor presente colapsa a
> una división.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Anualidad

Las dos definiciones del apunte:

> "Son pagos o retiros de dinero periódicos y que se suceden durante un periodo específico de tiempo. El VP y VF de una anualidad se compone de una serie de montos iguales y periódicos que se depositan y retiran y no de un único monto. Cantidad constante que se entrega periódicamente."

> "Son una serie de flujos de dinero iguales (ej. cuotas, salarios, alquileres) que ocurren durante un período de tiempo determinado."

La diferencia con [[Factores de Equivalencia]] es exactamente ésa: allá había **un** monto en
**una** fecha; acá hay **muchos montos iguales** en fechas sucesivas.

$$VP = A \times \frac{(1+i)^n - 1}{i \times (1+i)^n}$$

- **A** — el pago periódico, constante, en **pesos por período**
- **i** — tasa de interés efectiva del período, en **tanto por uno**
- **n** — cantidad de **períodos** en que se paga o cobra $A$
- **VP** — valor presente de toda la serie, en **pesos** de hoy

Para qué sirve, según el apunte: "calcular el VP (cuánto dinero necesitas tener invertido hoy)
para poder retirar una cantidad fija A durante n períodos a una tasa i".

## Perpetuidad

> "Son anualidades que no tienen fin."

$$VP = \frac{A}{i} \qquad \text{(la primera fuente lo escribe } P = C/i \text{)}$$

- **A** o **C** — el pago periódico, en **pesos por período**
- **i** — tasa de interés del período, en **tanto por uno**
- **P** o **VP** — valor presente de la serie infinita, en **pesos**

Que una serie infinita tenga valor presente **finito** no es un truco: cada cuota vale menos
que la anterior una vez actualizada, y la suma converge.

## La comparación

| | Anualidad | Perpetuidad |
|---|---|---|
| Duración | $n$ períodos, definidos | Infinita |
| Monto de cada pago | Constante ($A$) | Constante ($A$) |
| Valor presente | $A \cdot \dfrac{(1+i)^n-1}{i(1+i)^n}$ | $\dfrac{A}{i}$ |
| Ejemplos que da el apunte | Cuotas, salarios, alquileres | — |

## El otro sentido: del VP a la cuota

Si en vez del VP buscás la cuota, la operación es el **Factor de Recuperación de Capital
(FRC)**, que el apunte trata dentro de [[Factores de Equivalencia]]: convierte una inversión
$P$ en el **costo anual uniforme equivalente** $A$. Ese mismo mecanismo reaparece en
[[Reemplazo de Equipos]] cuando se comparan equipos con distinta vida útil, y en el sistema
francés de [[Sistemas de Amortización de Deuda]].

## Faltante

El apunte **no da la fórmula del valor futuro de una anualidad**, ni la del FRC, ni distingue
entre anualidad **vencida** y **adelantada** (si el pago va al final o al principio de cada
período) — que es una distinción que cambia el resultado. Tampoco hay ejemplos numéricos.

## Conexiones

- [[Factores de Equivalencia]] — la anualidad es el caso de serie uniforme; ahí está el FRC
- [[Sistemas de Amortización de Deuda]] — la cuota del sistema francés es literalmente una anualidad
- [[Reemplazo de Equipos]] — el costo anual equivalente compara equipos como si fueran anualidades
- [[Valor Actual Neto]] — si los flujos del proyecto son constantes, el VAN se calcula con la fórmula de anualidad
- [[Interés Simple e Interés Compuesto]] — la serie se descuenta a interés compuesto

## En el parcial

**Calcular el valor presente de una serie de cuotas iguales y el de una perpetuidad, y decir
qué cambia entre las dos.** La perpetuidad es regalada ($A/i$) y por eso mismo aparece:
verificá que $i$ esté en tanto por uno y en el mismo período que el pago.

Dos errores que se repiten: usar la fórmula de pago único para una serie de cuotas (hay que
actualizar **cada** cuota, no el total), y mezclar cuota mensual con tasa anual sin convertir.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

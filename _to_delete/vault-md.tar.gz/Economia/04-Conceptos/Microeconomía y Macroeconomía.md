---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos]
---

# Microeconomía y Macroeconomía

> Los dos enfoques con que se estudia la economía: el de las **decisiones individuales** de
> hogares y empresas, y el de los **fenómenos agregados** que afectan a toda la economía.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

| | **Microeconomía** | **Macroeconomía** |
|---|---|---|
| **Qué estudia** | Decisiones de hogares y empresas | Fenómenos que afectan a toda la economía |
| **Variables típicas** | Precios, costos, producción, demanda | PBI, inflación, desempleo, política fiscal |
| **Pregunta de ejemplo** | ¿Qué producir? ¿A qué precio vender? | ¿Cómo reducir el desempleo? |

## Cómo se reparte la materia

Esto es útil para orientarte en el programa: **la mitad de Economía es micro y la otra
macro**, y las dos mitades casi no se tocan entre sí.

| Unidad | Enfoque |
|---|---|
| U1 — Introducción | Marco general |
| **U2 — Producción y Costos** | **Micro** |
| **U3 — Demanda y Mercados** | **Micro** |
| U4 — Macroeconomía | **Macro** |
| U5 — Economía de empresas | Micro aplicada (contabilidad y finanzas) |
| U6 — Ingeniería Económica | Micro aplicada (decisiones de inversión) |
| U7 — Proyectos de inversión | Micro aplicada |

O sea: lo que viene inmediatamente —[[U2-Teoria-de-la-Produccion-y-de-los-Costos]]— es
microeconomía pura, y todo lo que sigue después de macro vuelve a ser micro aplicada a la
empresa. Macro es **una sola unidad**.

## El matiz que conviene tener

No son dos economías distintas: son dos niveles de agregación del mismo objeto. Los fenómenos
macro son el resultado de millones de decisiones micro, pero no se explican sumándolas
directamente — de ahí que se estudien con herramientas propias.

## Conexiones

- [[Problema Económico de Toda Sociedad]] — las tres preguntas se pueden mirar desde los dos niveles
- [[Función de Producción]] — herramienta microeconómica por excelencia: describe a una empresa
- [[Sistemas de Organización Económica]] — el rol del Estado en la economía es un tema macro
- [[Escasez]] — es el punto de partida de los dos enfoques

## En el parcial

Diferenciar los dos enfoques **con un ejemplo de cada uno**. El ejemplo es lo que se califica:
la definición sola la escribe cualquiera.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

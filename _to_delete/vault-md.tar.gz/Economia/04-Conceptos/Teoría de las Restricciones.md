---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, costos, faltante]
---

# Teoría de las Restricciones

> **Nota abierta a propósito.** El programa la pide como último tema de la unidad ("Enfoque de la
> teoría de las restricciones") y **el material disponible no la trata en ninguna línea**. Acá no
> hay contenido porque no hay fuente, no porque el tema sea menor.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Qué pide el programa

Es el **tema 29**, el que cierra la unidad, y aparece justo después de "estimación de costos" y
"métodos estadísticos y de ingeniería". Por su ubicación en el programa está planteado como un
**enfoque de gestión de costos**, en la misma serie que el [[Costeo Basado en Actividades]].

Eso es lo único que se puede afirmar sin inventar: **su lugar en el temario**. No su contenido.

## Faltante

Se revisaron los dos apuntes de la unidad —`UNIDAD 5 final` y la sección de contabilidad de costos
de `SEGUNDO PARCIAL`— buscando el tema por todas sus entradas posibles: *restricción*, *cuello de
botella*, *throughput*, *TOC*, *Goldratt*. **Cero resultados en ambos.**

Lo que falta, entonces, es todo:

- La definición del enfoque y su premisa.
- El concepto de **restricción** o cuello de botella y cómo se identifica.
- Los pasos del método.
- Las medidas de desempeño propias del enfoque y en qué se diferencian de las del costeo
  tradicional.
- El autor de referencia y la bibliografía.
- Cualquier ejemplo o ejercicio.

**No completar esto de memoria ni con material de otra cátedra.** Es el hueco más grande de la
unidad y hay que llevarlo como pregunta al teórico.

## Conexiones

- [[Contabilidad de Costos]] — el bloque de la unidad al que este tema pertenece según el programa
- [[Costeo Basado en Actividades]] — el enfoque que el programa nombra inmediatamente antes; los dos se presentan como alternativas a la lógica de costeo tradicional
- [[Costeo Variable]] — el otro método que razona en términos de "una unidad más" y de qué costos son relevantes para decidir
- [[U5-Economia-de-Empresas]] — la nota de unidad lleva la lista completa de temas del programa sin material

## En el parcial

**No se puede armar una consigna de repaso sin material: cualquier cosa que escriba acá sería
inventada.** Lo único accionable hoy es preguntarlo. Consigna real: *llevar este tema a la
primera clase de la unidad y anotar si entra en el parcial del 29/10; si entra, conseguir el
teórico o la bibliografía antes de estudiar el resto del bloque de costos.* Hasta entonces, esta
nota queda como marcador de un hueco conocido, que es exactamente lo que tiene que ser.

---
Fuente: revisados `UNIDAD 5 final` (Valentina, feb 2025) y `SEGUNDO PARCIAL` — apuntes de compañeros (2025), **sin resultados para este tema**. **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

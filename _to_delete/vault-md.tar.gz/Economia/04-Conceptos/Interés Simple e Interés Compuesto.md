---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, finanzas]
---

# Interés Simple e Interés Compuesto

> La diferencia está en **sobre qué base se calcula el interés de cada período**: el simple
> siempre sobre el capital inicial, el compuesto sobre el capital inicial más todo lo que ya
> se acumuló.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Las dos definiciones, textuales

**Interés simple:**

> "se computa un monto de interés por cada periodo, tomando siempre como base el mismo capital."

> "Se calcula siempre sobre el capital inicial que se prestó o invirtió. Los intereses generados en cada período no se suman al capital para calcular los intereses del siguiente período."

**Interés compuesto:**

> "el monto del interés en cada periodo se computa sobre el principal más todo el interés acumulado en periodos anteriores."

> "Los intereses que se generan en un período se suman al capital ('se capitalizan'). En el siguiente período, calcularán intereses sobre el capital inicial más los intereses ya acumulados. Esto genera un efecto de 'bola de nieve'."

## La comparación

| | Interés simple | Interés compuesto |
|---|---|---|
| Base de cálculo de cada período | Siempre el **capital inicial** | Capital inicial **+ intereses acumulados** |
| Qué pasa con el interés del período | No se suma al capital | Se **capitaliza** |
| Monto de interés de cada período | El mismo todos los períodos | Creciente ("bola de nieve") |
| Es el supuesto de… | — | Todos los [[Factores de Equivalencia]] de la unidad |

**Lo que hay que retener:** de acá en adelante, en toda la unidad (valor presente, valor
futuro, [[Anualidades y Perpetuidades]], [[Valor Actual Neto]]) el interés que se usa es
**compuesto**. El apunte lo dice explícito al hablar del VAN: "Al asumir interés compuesto se
está asumiendo implícitamente que el interés se reinvierte periodo a período."

## Las fórmulas

Interés simple, tal como lo escribe el apunte:

$$\text{Capital Final} = \text{Capital Inicial} \times (1 + \text{tasa de interés} + \text{número de períodos})$$

- **Capital Inicial** — el monto prestado o invertido, en **pesos**
- **tasa de interés** — en **tanto por uno por período** (0,40 y no 40 %)
- **número de períodos** — cantidad de **períodos**, en la misma unidad que la tasa
- **Capital Final** — en **pesos**

> **Ojo con esta fórmula.** El apunte la transcribe con un `+` entre la tasa y el número de
> períodos. Tal como está escrita no reproduce la definición de interés simple que el propio
> apunte da dos renglones antes ("un monto de interés por cada período, tomando siempre como
> base el mismo capital"). **Chequeala contra el teórico oficial antes de usarla en el
> parcial** — no la corrijo acá porque el apunte no da otra versión.

Para el interés compuesto el apunte no escribe la fórmula de capitalización, pero sí da la de
actualización a interés compuesto (ver [[Factores de Equivalencia]]), y despejándola queda:

$$VF = VP \times (1+i)^n$$

- **VP** — valor presente / capital inicial, en **pesos**
- **VF** — valor futuro / capital final, en **pesos**
- **i** — tasa de interés efectiva **del período de capitalización**, en tanto por uno
- **n** — cantidad de **períodos de capitalización** (no de años: ver [[Tasas Nominales y Tasas Efectivas]])

Que $i$ y $n$ estén referidos al **mismo** período es donde se cae la mitad de los ejercicios.

## Faltante

El apunte **no da ningún ejemplo numérico** de interés simple ni compuesto, ni un cuadro
comparativo de cómo evoluciona un capital bajo cada régimen. Tampoco define interés adelantado
ni vencido.

## Conexiones

- [[Valor del Dinero en el Tiempo]] — el interés es la medida de ese valor tiempo
- [[Tasas Nominales y Tasas Efectivas]] — la capitalización dentro del año es interés compuesto puro
- [[Factores de Equivalencia]] — todos se construyen sobre interés compuesto
- [[Sistemas de Amortización de Deuda]] — en los tres sistemas los intereses se aplican sobre el saldo adeudado
- [[Valor Actual Neto]] — el supuesto de reinversión período a período viene de acá

## En el parcial

**Definir los dos regímenes marcando la única diferencia que importa (la base de cálculo) y
decir cuál se usa en el resto de la unidad — el compuesto, siempre.** Si te dan una tasa
mensual y un plazo en años, convertí antes de reemplazar: $i$ y $n$ tienen que estar en el
mismo período. El error clásico es meter una TNA del 40 % con $n$ en meses.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

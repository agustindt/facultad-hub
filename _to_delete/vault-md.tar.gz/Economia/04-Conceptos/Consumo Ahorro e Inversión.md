---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
autor: Keynes
estado: pendiente
tags: [Economia, U4, keynes]
---

# Consumo Ahorro e Inversión

> Todo ingreso se consume o se ahorra: $Y = C + S$. De esa partición sale la **propensión marginal
> a consumir**, y de la propensión marginal a consumir sale el **multiplicador**, que es el corazón
> del modelo keynesiano.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## La función consumo y el gráfico de 45°

> "Existe una relación empírica estable entre el consumo y el ingreso."

$$Y = C + S \qquad \Longleftrightarrow \qquad S = Y - C$$

La recta de 45° es el lugar donde $C = Y$. Todo lo demás se lee como distancia vertical a esa recta:

| Posición de la función consumo | Qué pasa |
|---|---|
| Sobre la recta de 45° | El consumo es exactamente igual al ingreso: la familia no ahorra (punto de nivelación) |
| Por debajo de la recta | Ahorro **positivo** |
| Por encima de la recta | La familia **desahorra**: gasta más de lo que gana |

Y la cantidad de ahorro o desahorro "se mide por la distancia vertical entre la función de consumo
y la recta de 45°".

## Las cuatro propensiones

Ésta es la tabla que hay que tener escrita antes de entrar al parcial.

| | Marginal (¿qué hago con el peso **siguiente**?) | Media (¿qué proporción del **total**?) |
|---|---|---|
| Consumo | $PMC = \dfrac{\Delta C}{\Delta Y}$ | $PMeC = \dfrac{C}{Y}$ |
| Ahorro | $PMS = \dfrac{\Delta S}{\Delta Y}$ | $PMeS = \dfrac{S}{Y}$ |
| Suman | $PMC + PMS = 1$ | $PMeC + PMeS = 1$ |

**PMC**: "es la cantidad adicional que consumen los individuos cuando reciben un peso adicional de
ingreso disponible". La hipótesis keynesiana básica es que un aumento del ingreso genera un aumento
del consumo, **aunque menor**:

$$0 < PMC < 1$$

Interpretación literal: de cada peso extra, algo se consume (por eso es mayor que cero) pero no
todo (por eso es menor que uno) — y lo que sobra es, por definición, ahorro. Que las dos sumen 1
no es una coincidencia: es la misma ecuación $Y = C + S$ dividida por $\Delta Y$.

**PMeC**: Keynes sostenía que era decreciente, es decir que el porcentaje del ingreso dedicado al
consumo debería bajar cuando el ingreso sube. Los estudios empíricos lo matizaron: sólo es
decreciente **a corto plazo**, mientras que a largo plazo se mantiene aproximadamente constante,
por la aparición de nuevos bienes y servicios de consumo.

## Inversión: bruta, neta y depreciación

$$Inversión\ Bruta = Inversión\ Neta + Depreciación$$

La depreciación (o amortización) es la parte del gasto en capital destinada a **reponer** el
capital desgastado en el período; la inversión neta es la que **crea capital nuevo**. Por eso
$Neto = Bruto - Depreciaciones$ vale para todos los agregados de la unidad.

## El modelo keynesiano: la cruz y el multiplicador

> "Explica cómo se determina la producción a corto plazo. En este contexto predomina la demanda agregada sobre la oferta."

Supuestos, que son dos y hay que decirlos: **precios y salarios fijos**, y **recursos
desempleados**. Sin ellos el modelo no se sostiene, porque el aumento de demanda iría a precios y
no a producción.

La dinámica del multiplicador de la inversión, paso por paso:

```mermaid
flowchart TD
    A["Aumenta la demanda:<br/>se decide invertir más"] --> B["Las empresas aumentan<br/>producción y empleo"]
    B --> C["Las familias tienen<br/>un ingreso mayor"]
    C --> D["Con ese ingreso mayor<br/>aumentan su consumo"]
    D --> B
    D --> E["<b>El aumento total de la producción<br/>es MAYOR que el impulso inicial</b>"]
    style A fill:#4DB6AC,color:#fff
    style E fill:#7C5CFF,color:#fff
```

Quien recibe el dinero de la inversión original gasta ese dinero multiplicado por la PMC; quien
recibe ese gasto vuelve a gastar la misma proporción, y así:

$$\Delta I \rightarrow \Delta I \cdot PMC \rightarrow \Delta I \cdot PMC^2 \rightarrow \ldots$$

Es "una cadena de gasto de consumo secundario que, si bien es interminable, es decreciente y acaba
generando una cantidad finita de gasto". El multiplicador es el número que resume esa cadena:

$$k = \frac{\Delta Y}{\Delta I} \qquad \Longleftrightarrow \qquad \Delta Y = k \cdot \Delta I$$

> "El multiplicador es el número por el cual debe multiplicarse la variación de la inversión para averiguar el cambio resultante de la producción total."

## Faltante

Dos cosas que el material **no** da y que conviene no improvisar:

- La **fórmula cerrada del multiplicador** en función de la PMC. El material sólo lo define como
  cociente $\Delta Y / \Delta I$ y describe la cadena; nunca escribe la expresión que la resume.
- Las **expresiones analíticas de las cuatro propensiones** venían en imágenes del apunte que no
  llegaron al texto. Las de la tabla son la traducción directa de las definiciones en palabras,
  que sí son textuales.

## Conexiones

- [[Ingreso Nacional e Ingreso Disponible]] — el ingreso disponible es la variable que acá se parte en C y S
- [[Demanda y Oferta Agregada]] — consumo e inversión son dos de los cuatro componentes de la DA
- [[Flujo Circular del Ingreso]] — el ahorro es una salida del circuito y la inversión una entrada
- [[Política Fiscal]] — actúa sobre la renta disponible y, por la PMC, sobre el consumo
- [[Depreciación]] — lo que separa inversión bruta de neta es lo que en U5 se calcula como amortización
- [[Producción Potencial y Brecha]] — el supuesto de "recursos desempleados" es lo que permite que la producción reaccione

## En el parcial

**Calcular la PMC a partir de dos pares (ingreso, consumo) y usarla para explicar el efecto
multiplicador de un aumento de la inversión.** Tenés que poder decir las tres cosas: que
$0 < PMC < 1$, que $PMC + PMS = 1$ y que el aumento final del ingreso es un **múltiplo** del
impulso inicial. Y saber enunciar los dos supuestos del modelo. Los errores clásicos: confundir
propensión marginal con media (una usa variaciones, la otra totales) y dibujar la función consumo
cortando la recta de 45° sin marcar el punto de nivelación.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

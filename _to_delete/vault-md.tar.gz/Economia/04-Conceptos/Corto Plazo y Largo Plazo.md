---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion]
---

# Corto Plazo y Largo Plazo

> La distinción **no es temporal**: se establece únicamente según existan o no **factores
> fijos** de producción.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

| | **Corto plazo** | **Largo plazo** |
|---|---|---|
| **Definición** | Al menos un factor es **fijo** | **Todos** los factores son variables |
| **Qué se puede ajustar** | Los factores variables (trabajo, materiales) | Todo, incluido el capital |
| **Qué se estudia** | Cómo evoluciona la producción cuando **un** factor varía y el resto queda fijo | Cómo evoluciona cuando **todos** varían en la misma proporción |
| **Concepto asociado** | Productividad de un factor variable → [[Ley de Rendimientos Decrecientes]] | [[Rendimientos de Escala]] |
| **Costos** | Se distinguen [[Costos Fijos Variables y Totales]] | **Todos** los costos son variables |

Textual, y conviene citarlo así porque es una definición que se toma:

> "En Economía, la distinción entre corto y largo plazo se establece **según existan o no factores fijos de producción**."

## Por qué esto importa tanto

Es la bisagra de toda la unidad. **Cada concepto pertenece a un plazo, y mezclarlos es el error
más caro del parcial:**

```mermaid
flowchart TD
    D{"¿Hay algún<br/>factor fijo?"}
    D -->|Sí| CP["<b>CORTO PLAZO</b>"]
    D -->|No| LP["<b>LARGO PLAZO</b>"]
    CP --> A["Producto total, medio y marginal<br/>Ley de rendimientos decrecientes<br/>Las 3 etapas<br/>CF, CV, CT · CMg"]
    LP --> B["Rendimientos de escala<br/>Isocuantas e isocostos<br/>Sendero de expansión<br/>CMeL envolvente · Economías de escala"]
    style CP fill:#FFA726,color:#fff
    style LP fill:#4DB6AC,color:#fff
    style D fill:#7C5CFF,color:#fff
```

**Rendimientos decrecientes** (corto plazo, un factor) y **rendimientos decrecientes de escala**
(largo plazo, todos los factores) se llaman casi igual y son fenómenos distintos. Es la
confusión número uno de la unidad.

## El matiz que muestra que entendiste

Cuánto dura "el corto plazo" **depende de la industria**. Para un puesto de choripanes, ampliar
la capacidad puede ser cuestión de días: el largo plazo llega rápido. Para una central nuclear,
el capital tarda una década en ajustarse. Por eso la definición se hace por factores fijos y no
por meses.

## Conexiones

- [[Función de Producción]] — puede ser de corto o de largo plazo según qué factores se dejen variar
- [[Ley de Rendimientos Decrecientes]] — es un fenómeno **exclusivamente** de corto plazo
- [[Rendimientos de Escala]] — es su equivalente de largo plazo, y no hay que confundirlos
- [[Costos Fijos Variables y Totales]] — la clasificación de costos solo tiene sentido en el corto plazo
- [[Costos de Largo Plazo]] — en el largo plazo desaparecen los costos fijos y aparece la curva envolvente

## En el parcial

Definición **por factores fijos, no por tiempo**. Y saber ubicar cada concepto en su plazo.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos]
---

# Ciclo de Vida del Proyecto

> Un proyecto no se estudia de una sola vez: se estudia **tres veces, cada vez más caro y más
> preciso**. Perfil, prefactibilidad y factibilidad. La lógica es gastar poco en descartar y
> gastar mucho sólo en lo que sobrevivió.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## Las tres etapas de estudio

| Etapa | De dónde sale la información | Qué precisión tiene | Para qué sirve |
|---|---|---|---|
| **Perfil** | Información ya existente, juicio común y experiencia. Sin investigaciones de terreno | Estimaciones **muy globales** de inversiones, costos e ingresos | Detectar si hay alguna razón que justifique **abandonar la idea** |
| **Prefactibilidad** | Principalmente **fuentes secundarias** | Define "con cierta aproximación" las variables principales | Acotar mercado, alternativas técnicas de producción y capacidad financiera de los inversionistas |
| **Factibilidad** | Mayoritariamente **fuentes primarias** | Antecedentes precisos; las variables cualitativas son mínimas | El cálculo de las variables financieras y económicas tiene que ser demostrativo |

## El perfil no calcula rentabilidad

Es la frase que más se presta a pregunta conceptual, y va textual:

> "En el estudio de perfil, más que calcular la rentabilidad del proyecto, se busca determinar si existe alguna razón que justifique el **abandono de una idea antes de que se destinen recursos**."

O sea: el perfil no responde "¿cuánto gano?", responde "¿tiene sentido seguir gastando plata en
estudiar esto?". La rentabilidad recién se calcula bien en factibilidad, que es el nivel al que
se hace el análisis beneficio-costo con [[Valor Actual Neto]] y [[Tasa Interna de Retorno]].

El perfil incluye además **análisis de alternativas** y **cronograma**.

De perfil a factibilidad todo se mueve en la misma dirección: la información pasa de existente
a secundaria y de secundaria a primaria, y lo cualitativo se reduce hasta ser mínimo.

## Faltante

En el apunte, el esquema titulado "ETAPAS EN EL CICLO DE VIDA DEL PROYECTO" **está en blanco**
(era una imagen que no se conserva). Por eso acá sólo figuran las tres etapas de **preinversión**
que el texto sí describe. **No hay material sobre las etapas posteriores** (ejecución, puesta en
marcha, operación, cierre) ni sobre cómo se numeran o nombran en la cátedra. Verificar cuando se
publique el teórico.

## Conexiones

- [[Estudios de Factibilidad]] — desarrolla las dos últimas etapas y las seis viabilidades que hay que aprobar
- [[Proyecto de Inversión]] — formulación y evaluación se recorren dentro de cada una de estas etapas
- [[Erogaciones Relevantes]] — los costos de proyectos de cambio se calculan recién a nivel factibilidad
- [[Valor Actual Neto]] — el número que el perfil todavía no calcula y la factibilidad sí
- [[Flujo de Fondos]] — se arma con datos globales en el perfil y con datos primarios en factibilidad

## En el parcial

**Ordenar las tres etapas y decir qué fuente de información usa cada una** (existente/experiencia
→ secundarias → primarias). Y saber responder por qué el perfil no calcula rentabilidad: su
función es descartar ideas antes de destinar recursos. El error clásico es tratar prefactibilidad
y factibilidad como sinónimos: se distinguen por el tipo de fuente y por cuánta variable
cualitativa queda.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

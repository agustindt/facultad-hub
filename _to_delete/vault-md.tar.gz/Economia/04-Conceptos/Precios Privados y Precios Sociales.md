---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos, evaluacion]
---

# Precios Privados y Precios Sociales

> El precio de mercado dice **cuánto se paga**; el precio social, **cuánto recurso se sacrifica
> realmente**. Los separan los impuestos, los subsidios y las externalidades — y para evaluar
> socialmente hay que corregirlos.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## La distinción

> "Precios privados (mercado) ≠ Precios sociales (sacrificio de recursos)."

Los **precios privados** salen de los mercados donde el proyecto vende o se abastece. A veces
reflejan el verdadero valor para la economía y a veces no: depende de las **distorsiones** y las
**externalidades** que existan.

La razón de fondo por la que hay que corregirlos:

> "El Estado con los impuestos y subsidios **no crea ni consume riqueza, la redistribuye**."

Para la empresa un impuesto es un costo; para la sociedad es una transferencia interna. De ahí
que la evaluación social trabaje **sin impuestos ni subsidios**.

## Las dos formas de escribir la corrección

$$\text{Precios privados (mercado)} + \text{Correcciones (imp. o subs.)} = \text{Precios sociales}$$

$$P_{social} = P_{mercado} \times FPC$$

El **FPC (Factor de Precio de Cuenta)** convierte valores en precios de mercado a precios
sociales: intenta "limpiar" los efectos distorsivos del mercado y de las externalidades para
reflejar fielmente el valor social. El único valor que da el apunte:

| Ítem | FPC |
|---|---|
| Edificios, máquinas | $0{,}70$ |

Los precios sociales también se llaman **precios de cuenta** o **precios sombra**: son tres
nombres para lo mismo y en el parcial pueden aparecer con cualquiera de ellos.

## Las externalidades

> "Costos **no asumidos** y/o beneficios **no capturados** por los promotores del proyecto."
>
> "Cuando las elecciones de consumo de una persona o de producción de una empresa entran en la función de utilidad o de producción de otra entidad **sin permiso ni compensación**."

Entran acá el **impacto ambiental** y los **efectos indirectos** del proyecto. Son justamente lo
que el precio de mercado no captura, y por eso la corrección social no se agota en sacar los
impuestos.

## Quién decide el valor social

El cálculo de precios sociales depende de muchas variables, cuya ponderación "se deberá
establecer de acuerdo con los objetivos y las prioridades que la sociedad determine por medio
del Estado como garante del bien común". Los objetivos que nombra el apunte son dos:
**eficiencia y distribución**.

## Conexiones

- [[Evaluación Privada y Evaluación Social]] — esta corrección de precios es exactamente lo que separa una de la otra
- [[Externalidades]] — el concepto de la U3, acá aplicado a la valuación de un proyecto
- [[Impuestos: Ganancias e IVA]] — los impuestos son la distorsión que el FPC tiene que limpiar
- [[Rol del Estado y Desarrollo Sustentable]] — es el Estado el que fija las prioridades con las que se ponderan los precios sociales
- [[Fallas del Mercado]] — las distorsiones que hacen que el precio de mercado no refleje el valor para la economía

## En el parcial

**Escribir la conversión en las dos formas** (privados + correcciones = sociales, y sociales =
mercado × FPC) y **decir qué hace el FPC**. Si te dan una inversión en máquinas a precios de
mercado, aplicar $FPC = 0{,}70$. Y justificar por qué la evaluación social saca impuestos y
subsidios: el Estado redistribuye, no crea ni consume riqueza. El error clásico es tratar el
impuesto como un costo social.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

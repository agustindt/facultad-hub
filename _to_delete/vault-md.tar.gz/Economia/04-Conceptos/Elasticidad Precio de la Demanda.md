---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, demanda]
---

# Elasticidad Precio de la Demanda

> **Cuánto responde la cantidad demandada a un cambio del precio del mismo bien.** Y lo que
> importa de verdad: si la demanda es elástica, subir el precio te **baja** el ingreso total.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Definición y fórmula

La **elasticidad de la demanda** en general es "una medida de la capacidad de respuesta de la
cantidad demandada ante un cambio en uno de sus determinantes". La elasticidad **precio** toma
como determinante el precio del propio bien:

$$\varepsilon_{Q_x,P_x} = \frac{\dfrac{\Delta Q}{Q_i}}{\dfrac{\Delta P_x}{P_{ix}}}$$

Es decir: cambio porcentual en la cantidad demandada dividido el cambio porcentual en el precio.

**Ejemplo del material:** el precio del kilo de helado sube 10 % y la cantidad comprada cae
20 %. Aplicando la fórmula, el cociente entre 20 % y 10 % da **2**, o sea demanda elástica.

## Clasificación

| Caso | Qué pasa | Valor |
|---|---|---|
| **Inelástica** | Escasa respuesta de la cantidad ante un gran cambio del precio | Menor que 1 |
| **Elástica** | Gran respuesta de la cantidad ante un pequeño cambio del precio | Mayor que 1 |

## Lo que se evalúa: el efecto sobre el ingreso total

El ingreso total es "la cantidad total pagada por los compradores y recibida como ingreso por
los vendedores", igual al área de la caja bajo la curva de demanda:

$$IT = P \times Q$$

Y acá está la conclusión que no es obvia: **no siempre incrementar los precios es sinónimo de
incrementar los ingresos.**

| Si la demanda es… | y el precio **aumenta**… | el ingreso total… |
|---|---|---|
| Inelástica ($\varepsilon < 1$) | ↑ | **Aumenta** |
| Elástica ($\varepsilon > 1$) | ↑ | **Disminuye** |

```mermaid
flowchart LR
    S["<b>SUBE EL PRECIO</b>"] --> I["Demanda INELÁSTICA<br/>&epsilon; &lt; 1<br/>la cantidad casi no cae"]
    S --> E["Demanda ELÁSTICA<br/>&epsilon; &gt; 1<br/>la cantidad se derrumba"]
    I --> IA["<b>Ingreso total SUBE</b>"]
    E --> EB["<b>Ingreso total BAJA</b>"]
    style I fill:#4DB6AC,color:#fff
    style E fill:#FFA726,color:#fff
    style IA fill:#7C5CFF,color:#fff
    style EB fill:#7C5CFF,color:#fff
```

## La trampa de la demanda lineal

Aunque la **pendiente** de una demanda lineal sea constante, la **elasticidad no lo es**. El
material lo explica así: la pendiente es la razón de cambio entre dos variables, mientras que la
elasticidad es la razón de cambios **porcentuales** entre esas dos variables.

- En puntos con **precio bajo y cantidad alta** → la demanda es **inelástica**.
- En puntos con **precio alto y cantidad baja** → la demanda es **elástica**.

Por eso no se puede decir "esta demanda es elástica": hay que decir **en qué punto**.

## Conexiones

- [[Curva de Demanda]] — la elasticidad se mide a lo largo de esta curva, y cambia punto a punto
- [[Elasticidad Ingreso y Cruzada]] — las otras dos elasticidades, con el mismo formato de cociente de variaciones porcentuales
- [[Monopolio]] — el rasgo que distingue al monopolista de la empresa competitiva es justamente la elasticidad precio de la demanda que enfrenta
- [[Competencia Perfecta]] — la empresa competitiva enfrenta una demanda de elasticidad precio infinita (horizontal)
- [[Discriminación de Precios]] — cobrar distinto a cada grupo funciona porque cada grupo tiene distinta disposición a pagar
- [[Excedente del Consumidor]] — el área $P \times Q$ bajo la demanda es la que se reparte entre ingreso del vendedor y excedente

## En el parcial

**Calcular la elasticidad en un punto con la fórmula de variaciones porcentuales, clasificarla
en elástica o inelástica, y decir qué le pasa al ingreso total si el precio sube.** Es un
ejercicio de dos renglones que se pierde por la segunda parte: elástica + suba de precio =
ingreso total **baja**. Segunda pregunta muy probable: *"¿la elasticidad es la pendiente?"* — no;
en una demanda lineal la pendiente es constante y la elasticidad varía, alta arriba y baja abajo.

---
Fuente: `Resumen temas coloquio — sección demanda/mercados`, con `ECONOMIA FINAL — camila arenel (feb 2025)` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

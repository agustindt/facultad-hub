---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos]
---

# Frontera de Posibilidades de Producción

> Curva que muestra la **cantidad máxima** de unos bienes que puede producir una economía con
> los recursos y la tecnología de que dispone, dadas las cantidades de los otros bienes que
> también produce.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

También llamada **curva de transformación**. Es la [[Escasez]] dibujada: todo lo que está sobre
la curva se puede producir usando **todos** los recursos; todo lo que está afuera, no.

Definición textual:

> "La curva de transformación o frontera de posibilidades de producción (FPP) muestra la cantidad máxima posible de unos bienes o servicios que puede producir una determinada economía con los recursos y la tecnología de que dispone, y dadas las cantidades de otros bienes y servicios que también produce."

## Las tres regiones — esto es lo que se pregunta

```mermaid
quadrantChart
    title Lectura de un punto en la FPP
    x-axis "Usa pocos recursos" --> "Usa todos los recursos"
    y-axis "Dentro de lo posible" --> "Fuera de lo posible"
    quadrant-1 "INALCANZABLE con la tecnología actual"
    quadrant-2 "INALCANZABLE"
    quadrant-3 "INEFICIENTE: hay recursos ociosos"
    quadrant-4 "EFICIENTE: sobre la curva"
```

| Posición | Nombre | Qué significa |
|---|---|---|
| **Sobre** la curva | **Eficiente** | Se alcanza la máxima cantidad posible con los recursos dados |
| **Dentro** de la curva | **Ineficiente** | Hay recursos ociosos o mal asignados |
| **Fuera** de la curva | **Inalcanzable** | No se puede con la tecnología actual |

## El test para detectar ineficiencia

La cátedra da un criterio operativo, y es elegante:

> "La ineficiencia se detecta cuando hay **costo de oportunidad cero**, pudiendo aumentar la producción de P1 sin disminuir la producción de P2 o viceversa."

O sea: **si podés producir más de algo sin resignar nada, estás adentro de la curva.** Sobre la
curva, cualquier aumento de un bien exige resignar el otro — el costo de oportunidad es
estrictamente positivo.

## Por qué es cóncava

Por el [[Costo de Oportunidad]] **creciente**: los recursos no son igualmente aptos para todos
los usos. Ver el cálculo con la tabla A–E en esa nota.

<svg viewBox="0 0 440 175" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="149" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="152" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="104" y2="104" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="107" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">7</text><line x1="34" x2="382" y1="59" y2="59" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="62" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">13</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="34" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)"/><line x1="113.1" x2="113.1" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="113.1" cy="35.1" r="3.4" fill="var(--background-modifier-border,#8886)"/><text x="113.1" y="160" text-anchor="middle" font-size="8" fill="var(--background-modifier-border,#8886)" font-weight="600">B</text><line x1="192.2" x2="192.2" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="192.2" cy="57.9" r="3.4" fill="var(--background-modifier-border,#8886)"/><text x="192.2" y="160" text-anchor="middle" font-size="8" fill="var(--background-modifier-border,#8886)" font-weight="600">C</text><line x1="271.3" x2="271.3" y1="14" y2="149" stroke="var(--background-modifier-border,#8886)" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="271.3" cy="95.8" r="3.4" fill="var(--background-modifier-border,#8886)"/><text x="271.3" y="160" text-anchor="middle" font-size="8" fill="var(--background-modifier-border,#8886)" font-weight="600">D</text><path d="M34 27.5 L39 27.5 L43.9 27.6 L48.9 27.8 L53.9 28 L58.9 28.3 L63.8 28.6 L68.8 29 L73.8 29.4 L78.7 29.9 L83.7 30.5 L88.7 31.1 L93.7 31.8 L98.6 32.6 L103.6 33.4 L108.6 34.3 L113.5 35.2 L118.5 36.2 L123.5 37.2 L128.5 38.3 L133.4 39.5 L138.4 40.7 L143.4 42 L148.3 43.4 L153.3 44.8 L158.3 46.3 L163.3 47.8 L168.2 49.4 L173.2 51 L178.2 52.7 L183.1 54.5 L188.1 56.3 L193.1 58.2 L198.1 60.2 L203 62.2 L208 64.3 L213 66.4 L217.9 68.6 L222.9 70.8 L227.9 73.1 L232.9 75.5 L237.8 77.9 L242.8 80.4 L247.8 83 L252.7 85.6 L257.7 88.3 L262.7 91 L267.7 93.8 L272.6 96.6 L277.6 99.5 L282.6 102.5 L287.5 105.5 L292.5 108.6 L297.5 111.8 L302.5 115 L307.4 118.3 L312.4 121.6 L317.4 125 L322.3 128.4 L327.3 131.9 L332.3 135.5 L337.3 139.1 L342.2 142.8 L347.2 146.6" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="351.2" y="149.6" font-size="9" fill="#7C5CFF" font-weight="600">FPP</text><text x="208.0" y="172" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Bienes de consumo — eje vertical: bienes de capital</text></svg>

*Los puntos son la tabla B, C y D del teórico. La curvatura es el costo de oportunidad creciente.*


## Qué la desplaza

Un desplazamiento **hacia afuera** de la FPP es **crecimiento económico** — aumento de la
capacidad productiva. Las cuatro causas que da la cátedra:

1. **Mejora técnica** — nuevos y mejores métodos de producción.
2. **Aumento del volumen de capital** — más ahorro e inversión.
3. **Aumento de la fuerza de trabajo**.
4. **Descubrimiento de nuevos recursos naturales**.

> 📌 **Matiz que suele preguntarse:** si la mejora afecta a **un solo bien**, la frontera no se
> desplaza pareja: se estira **en la dirección del eje de ese bien**. Textual: *"Una mejora o
> perfeccionamiento en la producción de uno de los bienes implica un desplazamiento de la
> frontera en la dirección marcada por el eje en el que se representa el bien."*

Un punto que estaba **dentro** de la curva pasando a estar **sobre** ella **no** es
crecimiento: es dejar de desperdiciar recursos.

## Conexiones

- [[Escasez]] — la FPP es la escasez hecha gráfico: la curva es el límite
- [[Costo de Oportunidad]] — la pendiente de la FPP en cada punto es el costo de oportunidad, y por eso la curva es cóncava
- [[Factores de Producción]] — los "recursos dados" que fijan la posición de la curva son K, L y RN
- [[Problema Económico de Toda Sociedad]] — elegir un punto de la FPP es contestar "qué producir"
- [[Isocuanta]] — su equivalente a nivel empresa: combinaciones técnicamente eficientes en vez de combinaciones de productos

## En el parcial

Identificar las tres regiones en un gráfico, calcular costo de oportunidad entre dos puntos,
explicar la concavidad y nombrar las cuatro causas del desplazamiento. **La trampa:** que te
den un punto interior y te pregunten si "crecer hasta la curva" es crecimiento económico. No lo
es.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos, largo-plazo]
---

# Escala Mínima Eficiente

> La **cantidad de producción más pequeña** en la cual el costo medio de largo plazo alcanza su
> **nivel más bajo**. Es el equilibrio del productor respecto al **tamaño de planta**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Textual:

> "**Escala eficiente mínima**: cantidad de producción más pequeña en la cual el CMeL alcanza su nivel más bajo."
>
> "$Q_2$: Equilibrio del productor respecto al **Tamaño**: Min CMeL"

Es el punto donde terminan las [[Economías y Deseconomías de Escala|economías de escala]] y
empiezan las deseconomías: el fondo de la U de la CMeL.

```mermaid
flowchart LR
    A["Q &lt; Q2<br/><b>Economías de escala</b><br/>CMeL bajando"] --> B["<b>Q2 · ESCALA MÍNIMA EFICIENTE</b><br/>mínimo de la CMeL"]
    B --> C["Q &gt; Q2<br/><b>Deseconomías de escala</b><br/>CMeL subiendo"]
    style A fill:#4DB6AC,color:#fff
    style B fill:#7C5CFF,color:#fff
    style C fill:#FFA726,color:#fff
```

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><rect x="34" y="14" width="198.9" height="145" fill="#4DB6AC" opacity=".10"/><text x="133.4" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Economías de escala</text><rect x="232.9" y="14" width="149.1" height="145" fill="#FFA726" opacity=".10"/><text x="307.4" y="24" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Deseconomías</text><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">17</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">35</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">52</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><line x1="232.9" x2="232.9" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="232.9" cy="125.5" r="3.4" fill="#7C5CFF"/><text x="232.9" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600">escala mín. eficiente</text><path d="M34 101.9 L39 103 L43.9 103.9 L48.9 104.8 L53.9 105.5 L58.9 106.1 L63.8 106.7 L68.8 108.2 L73.8 109.6 L78.7 110.8 L83.7 112 L88.7 113 L93.7 114 L98.6 114.8 L103.6 115.5 L108.6 116.1 L113.5 116.6 L118.5 117 L123.5 117.3 L128.5 117.5 L133.4 118 L138.4 119.1 L143.4 120 L148.3 120.8 L153.3 121.5 L158.3 122.2 L163.3 122.6 L168.2 123 L173.2 123.3 L178.2 123.5 L183.1 123.5 L188.1 123.5 L193.1 123.3 L198.1 123 L203 123.6 L208 124.2 L213 124.7 L217.9 125 L222.9 125.3 L227.9 125.5 L232.9 125.5 L237.8 125.5 L242.8 125.3 L247.8 125 L252.7 124.7 L257.7 124.2 L262.7 123.6 L267.7 123 L272.6 123.3 L277.6 123.5 L282.6 123.5 L287.5 123.5 L292.5 123.3 L297.5 123 L302.5 122.6 L307.4 122.2 L312.4 121.5 L317.4 120.8 L322.3 120 L327.3 119.1 L332.3 118 L337.3 117.5 L342.2 117.3 L347.2 117 L352.2 116.6 L357.1 116.1 L362.1 115.5 L367.1 114.8 L372.1 114 L377 113 L382 112" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="115.0" font-size="9" fill="#7C5CFF" font-weight="600">CMeL</text><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*La escala mínima eficiente es el fondo de la U: donde terminan las economías y empiezan las deseconomías.*


## El detalle del gráfico del teórico

La diapositiva muestra dos puntos, y la diferencia entre ellos es lo que se pregunta:

> "El punto **B** da el producto $Q_1$ al **menor costo por unidad**. La escala de **menor costo medio** es $Q_2$."

- **B** contesta: *dado que quiero producir $Q_1$, ¿cuál es la planta más barata?* Es un punto
  de la envolvente.
- **$Q_2$** contesta: *¿cuál es la cantidad que minimiza el costo por unidad de todas?* Es el
  mínimo de la envolvente.

Producir $Q_1$ es eficiente **para ese nivel de producción**, pero cuesta más por unidad que
producir $Q_2$. Son dos preguntas distintas y el examen las mezcla a propósito.

## Los tres equilibrios del productor

Vale ordenarlos porque la cátedra usa esa expresión tres veces en la unidad, con tres sentidos:

| Equilibrio respecto a… | Qué se elige | Dónde |
|---|---|---|
| La **tecnología** | La combinación de factores | [[Eficiencia Económica en Tecnología]] — tangencia isocuanta/isocosto |
| La **tasa de producción** | Cuánto producir con una planta dada | Corto plazo (se completa en la U3, con los ingresos) |
| El **tamaño de planta** | Qué planta construir | **Escala mínima eficiente** — mínimo de la CMeL |

## Por qué importa fuera del examen

La escala mínima eficiente explica por qué algunas industrias están concentradas en pocas
empresas grandes y otras no. Si la escala mínima eficiente es enorme respecto del tamaño del
mercado —siderurgia, telecomunicaciones—, solo entran pocos jugadores. Si es chica
—panaderías, software—, conviven muchos. Es la puerta de entrada a la clasificación de
mercados de la U3.

## Conexiones

- [[Costos de Largo Plazo]] — es el punto mínimo de la curva CMeL
- [[Economías y Deseconomías de Escala]] — marca exactamente la frontera entre unas y otras
- [[Relación entre Costo Marginal y Costo Medio]] — en ese mínimo la CMgL corta a la CMeL
- [[Eficiencia Económica en Tecnología]] — el otro equilibrio del productor, con el que se confunde
- [[Rendimientos de Escala]] — a la izquierda son crecientes, a la derecha decrecientes

## En el parcial

Definición textual y ubicación en el gráfico de la CMeL. **La trampa** es la diferencia entre
"el menor costo para producir $Q_1$" y "la escala de menor costo medio": la diapositiva las
pone juntas justamente para que se distingan.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

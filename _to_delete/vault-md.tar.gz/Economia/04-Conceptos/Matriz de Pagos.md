---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, decisiones]
---

# Matriz de Pagos

> Una tabla de **alternativas de decisión contra estados de la naturaleza**, con una medida de
> performance en cada cruce. Es el insumo común de todos los criterios de decisión: con riesgo
> y con incertidumbre se arma exactamente la misma matriz.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Qué es

Textual:

> "Es una lista de posibles **estados de la naturaleza** (futuro incierto) versus las diferentes **alternativas de decisión**. Dentro del cuerpo de la tabla, es decir, para el cruce de cada estado de la naturaleza y cada decisión, figura cualquier medida de perfomance relevante para el problema de decisión (VAN o términos monetarios de utilidad, o de costo, o términos de tiempo, etc.)."

Las tres piezas, y hay que poder nombrarlas separadas:

| Pieza | Qué es | Quién la controla |
|---|---|---|
| **Alternativas de decisión** ($a_i$) | Las filas: lo que podés elegir hacer | **Vos** |
| **Estados de la naturaleza** ($\theta$) | Las columnas: los futuros posibles | **Nadie** — es el futuro incierto |
| **Pagos** ($p(a_i, \theta)$) | El cuerpo de la tabla: el resultado de cada cruce | Se deduce de los dos anteriores |

## La forma de la tabla

Con la notación que usa el apunte:

| | Estado $\theta_1$ | Estado $\theta_2$ | … | Estado $\theta_j$ |
|---|---|---|---|---|
| **Alternativa $a_1$** | $p(a_1,\theta_1)$ | $p(a_1,\theta_2)$ | … | $p(a_1,\theta_j)$ |
| **Alternativa $a_2$** | $p(a_2,\theta_1)$ | $p(a_2,\theta_2)$ | … | $p(a_2,\theta_j)$ |
| **Alternativa $a_i$** | $p(a_i,\theta_1)$ | $p(a_i,\theta_2)$ | … | $p(a_i,\theta_j)$ |

La medida que va en cada celda **la elegís vos según el problema**: puede ser VAN, utilidad,
costo o tiempo. Eso importa para el criterio, porque no es lo mismo maximizar utilidades que
minimizar costos — de ahí que existan un *maximax* y un *minimín* (ver
[[Decisiones bajo Incertidumbre]]).

## Por qué es la bisagra de la unidad

La matriz es idéntica en los dos mundos; lo que cambia es **si le podés poner probabilidades a
las columnas o no**:

```mermaid
flowchart TD
    MP["<b>MATRIZ DE PAGOS</b><br/>alternativas x estados de la naturaleza"] --> Q{"¿Se conocen o se pueden<br/>asignar probabilidades<br/>a los estados?"}
    Q -->|"SÍ"| R["<b>DECISIÓN CON RIESGO</b><br/>valor esperado, árboles,<br/>Montecarlo"]
    Q -->|"NO"| I["<b>DECISIÓN CON INCERTIDUMBRE</b><br/>Maximin, Maximax, Laplace,<br/>Hurwicz, Savage"]
    style MP fill:#4DB6AC,color:#fff
    style Q fill:#FFA726,color:#fff
    style R fill:#7C5CFF,color:#fff
    style I fill:#7C5CFF,color:#fff
```

En riesgo, cada columna lleva su $P_i$ y se calcula un valor esperado por fila. En
incertidumbre no hay $P_i$, y los criterios trabajan sólo con los máximos y mínimos de cada
fila.

## Faltante

El apunte **no trae ninguna matriz de pagos numérica de ejemplo**, que es justamente el formato
en el que se practica el tema. Tampoco desarrolla cómo se construye la lista de estados de la
naturaleza ni cómo se los define de forma exhaustiva y excluyente.

## Conexiones

- [[Decisiones bajo Riesgo]] — cuando a las columnas se les puede poner probabilidad
- [[Decisiones bajo Incertidumbre]] — cuando no, y hay que decidir con los extremos de cada fila
- [[Valor Actual Neto]] — es una de las medidas de performance que el apunte nombra para el cuerpo de la tabla
- [[Comparación de Alternativas]] — la matriz es el paso siguiente cuando el futuro no es único
- [[Toma de Decisiones]] — el marco general del que esto es la herramienta cuantitativa
- [[Análisis de Sensibilidad y Escenarios]] — los escenarios son, en el fondo, los estados de la naturaleza

## En el parcial

**Dibujar la matriz identificando bien los tres elementos: filas = alternativas que controlás,
columnas = estados de la naturaleza que no controlás, celdas = la medida de performance.** Y
decir cuál es la pregunta que separa el camino siguiente: *¿se le pueden asignar
probabilidades a los estados?*

El error clásico es **poner en las columnas cosas que el decisor controla**. Si podés elegirlo,
es una alternativa (fila), no un estado de la naturaleza (columna).

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

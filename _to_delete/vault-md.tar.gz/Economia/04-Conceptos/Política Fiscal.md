---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, politicas]
---

# Política Fiscal

> Son las decisiones del Gobierno sobre **gasto público e impuestos**. Dos palancas, dos
> direcciones: expansiva para estimular la demanda agregada, restrictiva para frenarla.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Qué es y por dónde actúa

> "Se refiere a las decisiones del Gobierno sobre el nivel de gasto público y los impuestos. Incide sobre los ingresos y el consumo de los individuos y ofrece incentivos a la inversión y otras decisiones económicas."

| Palanca | Qué incluye | Por dónde pega |
|---|---|---|
| Gasto público | Compras de bienes y servicios del Estado (infraestructura, bienes públicos) y **transferencias** (subsidios, jubilaciones) | Demanda agregada directa; también reduce el margen de desigualdad en la distribución del ingreso |
| Impuestos | Lo que el Estado recauda de personas y empresas | Reduce los ingresos, influye en el gasto y el ahorro privados y, al incidir sobre los precios de bienes y factores, sobre los incentivos para trabajar |

Si se incrementan los impuestos pasan tres cosas a la vez: se incrementan las recaudaciones del
Estado, se influye sobre los ingresos de personas y empresas (y por lo tanto sobre consumo e
inversión) y el Estado tendrá más recursos para gastar. Por su impacto sobre ahorro, inversión e
incentivos, "suele utilizarse para incidir en el crecimiento económico".

## El resultado fiscal

$$T = G \quad \Longrightarrow \quad \text{equilibrio fiscal}$$

$$D\acute{e}ficit\ p\acute{u}blico = G - T$$

| Situación | Cómo se llama | Por qué |
|---|---|---|
| $G > T$ | **Déficit** | El gasto es mayor que los ingresos |
| $G = T$ | **Equilibrio fiscal** | Los impuestos alcanzan exactamente para el gasto |
| $G < T$ | **Superávit** | Se ingresa más de lo que se gasta |

Y una distinción que se pregunta sola:

| Resultado | Qué incluye | Para qué sirve |
|---|---|---|
| Primario | Sólo los ingresos y gastos propios del Estado; **no** el pago de intereses de la deuda | "Recoge los pagos y cobros sobre los que el Gobierno tiene control" |
| Total (o financiero) | Suma los intereses generados por la deuda contraída | Es el resultado completo |

El déficit fiscal se mide **en relación al PIB** de cada país: es un porcentaje, no un monto suelto.

## Las dos direcciones

| | Expansiva | Restrictiva |
|---|---|---|
| Objetivo | Estimular la demanda agregada | Frenar la demanda agregada |
| Cuándo se aplica | Economías en recesión que necesitan un impulso | Economías en expansión que hay que frenar por la excesiva inflación |
| Gasto público | **Aumentar**, para subir la producción y reducir el desempleo | **Reducir**, para bajar demanda agregada y producción |
| Impuestos | **Bajar**, para aumentar la renta disponible de las personas | **Subir**, para que la renta y el consumo bajen |
| Resultado fiscal | Se tiende al déficit | Se tiende al superávit, o se reduce el déficit |
| El costo | Puede provocar inflación | Aumenta el desempleo |

```mermaid
flowchart LR
    E["<b>EXPANSIVA</b><br/>&uarr; gasto público<br/>&darr; impuestos"] --> DA1["&uarr; Demanda agregada"]
    DA1 --> R1["&uarr; producción y empleo<br/>pero déficit y riesgo de inflación"]
    R["<b>RESTRICTIVA</b><br/>&darr; gasto público<br/>&uarr; impuestos"] --> DA2["&darr; Demanda agregada"]
    DA2 --> R2["&darr; inflación<br/>pero &uarr; desempleo y superávit"]
    style E fill:#4DB6AC,color:#fff
    style R fill:#FFA726,color:#fff
    style R1 fill:#7C5CFF,color:#fff
    style R2 fill:#7C5CFF,color:#fff
```

Leelo como un trade-off, no como una receta: **ninguna de las dos es gratis**. La expansiva compra
empleo con déficit e inflación; la restrictiva compra estabilidad de precios con desempleo. Es la
misma disyuntiva que formaliza la [[Desempleo y Curva de Phillips]].

## Conexiones

- [[Política Monetaria]] — la otra política de demanda; conviene estudiarlas en paralelo porque comparten objetivos y no instrumentos
- [[Demanda y Oferta Agregada]] — es el canal por el que la política fiscal llega a la producción y a los precios
- [[Desempleo y Curva de Phillips]] — explica por qué la política restrictiva paga con desempleo
- [[Inflación]] — el riesgo de la política expansiva y el motivo de la restrictiva
- [[Flujo Circular del Ingreso]] — impuestos (salida) y gasto público (entrada) son el par del sector público
- [[Ingreso Nacional e Ingreso Disponible]] — los impuestos directos son lo que separa el ingreso personal del disponible

## En el parcial

**Te describen un escenario —recesión con desempleo alto, o expansión con inflación— y hay que
elegir la política, nombrar las dos palancas con su dirección y decir qué le pasa al resultado
fiscal.** La respuesta completa incluye el costo: la expansiva tiende al déficit, la restrictiva al
desempleo. Los dos errores clásicos: decir que la política expansiva "mejora las cuentas públicas"
(es al revés) y confundir resultado primario con total — el primario **excluye** los intereses de
la deuda.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes del `MACROECONOMIA — manuscrito iPad, nov 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

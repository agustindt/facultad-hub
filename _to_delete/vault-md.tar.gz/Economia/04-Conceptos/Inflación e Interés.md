---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, tasas]
---

# Inflación e Interés

> La tasa que importa no es la que te pagan, es la que te pagan **después de descontar la
> inflación**. Si la inflación le gana a la tasa, el prestamista pierde plata en términos
> reales.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## El ejemplo del apunte

Es el único ejemplo numérico del tema y vale la pena tenerlo de memoria porque resuelve la
idea entera:

> "Si la inflación es de 3 %, y la tasa de interés de un préstamo, 2 %, el rendimiento que obtiene el prestamista es inferior a cero. En ese caso, decimos que la tasa de interés real —la tasa nominal menos la tasa de inflación— es negativa."

Con 2 % de interés contra 3 % de inflación, quien prestó recupera más pesos pero **menos poder
adquisitivo**: la tasa real es negativa.

## Las dos formas en que el apunte escribe la tasa real

Ojo acá, porque **las dos fuentes no dicen exactamente lo mismo** y conviene saber las dos.

Forma aproximada (resta simple), la que usa la primera fuente:

$$TRI = i - TIA$$

Forma exacta (cociente), la que usa la segunda fuente:

$$\text{Tasa Real} = \frac{1 + \text{Tasa Nominal}}{1 + \text{Tasa de Inflación}} - 1$$

- **TIA** — Tasa de Inflación Anual, en **tanto por uno** por año
- **i** / **Tasa Nominal** — tasa de interés nominal del período, en **tanto por uno**
- **TRI** / **Tasa Real** — tasa real de interés, en **tanto por uno**; puede ser **negativa**

| Signo de la tasa real | Qué significa |
|---|---|
| **Positiva** | "tasa de interés le gana a la inflación": ganás poder adquisitivo |
| **Negativa** | "inflación es más alta que la tasa de interés": perdés poder adquisitivo aunque tengas más pesos |

## La tasa de política monetaria

El apunte engancha el tema con macro, así que entra:

> "Los bancos centrales modifican esa tasa llamada 'tasa de política monetaria'. Una tasa de política monetaria más alta estimula el ahorro; una tasa más baja promueve el consumo y reduce el costo de la inversión empresarial."

Y el patrón de referencia es la **tasa de interés neutral**: "la tasa de interés a largo plazo
que es congruente con una inflación estable".

| Si la tasa está… | La política monetaria es… |
|---|---|
| **Por debajo** de la tasa neutral | **Expansiva** |
| **Por encima** de la tasa neutral | **Contractiva** |

## Y en el flujo de fondos: criterio NEUTRA

Dato operativo que se pregunta y se olvida: el apunte fija como criterio para la inflación
dentro del [[Flujo de Fondos]] que sea **NEUTRA**. Es decir, se proyecta sin arrastrar el
efecto inflacionario a la [[Tasa de Descuento]].

## Conexiones

- [[Tasas Nominales y Tasas Efectivas]] — la tasa real es la tercera tasa de esa terna, después de TNA y TEA
- [[Inflación]] — el fenómeno macro que está detrás de todo esto
- [[Política Monetaria]] — la tasa de política monetaria es el instrumento que fija el banco central
- [[Tasa de Descuento]] — el criterio de inflación neutra manda sobre cómo se arma la tasa del proyecto
- [[Valor del Dinero en el Tiempo]] — la inflación es una de las tres razones por las que el dinero cambia de valor
- [[El Dinero y los Intermediarios Financieros]] — el canal por el que la tasa de política llega a los préstamos

## En el parcial

**Reproducir el ejemplo del 3 % de inflación contra 2 % de interés y concluir que la tasa real
es negativa**, explicando qué significa eso para el prestamista (más pesos, menos poder
adquisitivo). Y saber decir si una política monetaria es expansiva o contractiva comparando la
tasa fijada contra la tasa neutral.

Dos cosas que se cobran caro: **la tasa real puede ser negativa** (no es un error de cuenta), y
si te piden precisión usá la fórmula del cociente, no la resta — la resta es la aproximación.

## Faltante

El apunte no aclara **cuál de las dos formas de calcular la tasa real es la que pide la
cátedra**, ni desarrolla la relación de Fisher más allá de esas dos expresiones. Tampoco dice
cómo se ajusta un flujo de fondos por inflación cuando el criterio no es neutro.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

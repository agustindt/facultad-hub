---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados, competencia]
---

# Concentración y Defensa de la Competencia

> **Dos índices para ponerle número al poder de mercado: Lerner mide cuánto se despega el precio
> del costo marginal; Herfindahl mide cuán repartidas están las ventas.** Y a partir de esos
> números, el Estado decide si interviene.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Qué se está midiendo

> "Es importante determinar el **grado de poder de mercado** de una empresa, entendiendo por él al grado en que una única empresa o un número reducido de ellas controla las decisiones sobre precios y producción en una industria."

La columna "influencia sobre el precio" de la tabla de [[Clasificación de Mercados]] es
cualitativa. Estos dos índices la vuelven cuantitativa, y lo hacen desde ángulos distintos: uno
mira **el precio**, el otro mira **el reparto del mercado**.

## Índice de Lerner — mira el margen sobre el costo

Permite determinar en qué medida el monopolista puede imponer un precio superior al que se
fijaría en competencia perfecta. Recoge la diferencia entre el precio de mercado y el costo
marginal, respecto del precio de mercado:

$$L = \frac{P - CMg}{P}$$

| Situación | Valor del índice |
|---|---|
| **Competencia perfecta** ($P = CMg$) | **Nulo** |
| Cuanto mayor sea la diferencia entre $P$ y $CMg$ | Mayor el poder de monopolio |

**Desventaja:** la dificultad de medir el costo marginal. Es la limitación que hay que nombrar
si te lo preguntan.

## Índice de Herfindahl (HHI) — mira la concentración

Mide la concentración económica **sumando las cuotas de mercado al cuadrado** de las empresas de
la industria:

$$HHI = \sum_{i=1}^{n} s_i^{\,2}$$

Toma valores en el rango de **1 a 10.000**: 1 es el nivel en el que no hay concentración y
10.000 el nivel de monopolio.

| Valor del HHI | Lectura |
|---|---|
| Menor a **1.500** | Mercado **no concentrado** |
| Entre **1.500 y 2.500** | Mercado **moderadamente concentrado** |
| Mayor a **2.500** | Mercado **altamente concentrado** |

Elevar al cuadrado no es un detalle: es lo que hace que una empresa grande pese muchísimo más
que varias chicas. Diez empresas con 10 % cada una dan 1.000 (no concentrado); una con 100 % da
10.000.

```mermaid
flowchart TD
    A["<b>¿CUÁNTO PODER DE MERCADO HAY?</b>"] --> B["ÍNDICE DE LERNER<br/>mira el PRECIO<br/>(P &minus; CMg) / P"]
    A --> C["ÍNDICE HERFINDAHL<br/>mira el REPARTO<br/>suma de cuotas al cuadrado"]
    B --> D["Cero en competencia perfecta<br/>problema: medir el CMg"]
    C --> E["1 a 10.000<br/>&gt; 2.500 = altamente concentrado"]
    D --> F["<b>DEFENSA DE LA COMPETENCIA</b><br/>leyes antimonopolio"]
    E --> F
    style A fill:#7C5CFF,color:#fff
    style B fill:#4DB6AC,color:#fff
    style C fill:#4DB6AC,color:#fff
    style F fill:#FFA726,color:#fff
```

## Qué puede hacer el gobierno frente a la ineficiencia

El material lista cuatro opciones, y la cuarta es la que sorprende:

1. Emplear las **leyes antimonopolio** para tratar de que la industria sea más competitiva.
2. **Regular los precios** que asigna el monopolio.
3. Convertir al monopolio en una **empresa administrada por el gobierno**.
4. **No hacer nada**, si se considera que la falla del mercado es pequeña en comparación con las imperfecciones inevitables de las distintas políticas.

Y el encuadre general: *"la política de competencia actúa como un mecanismo de potenciación y
vigilancia del adecuado funcionamiento de los mercados"*.

## ⚠️ Faltante

El material trata la defensa de la competencia sólo en términos genéricos ("leyes
antimonopolio", "autoridades a cargo de diseñar políticas"). **No hay nada sobre el régimen
normativo argentino de defensa de la competencia**: ni ley, ni autoridad de aplicación, ni
control de fusiones y concentraciones. Si el programa lo pide con ese nivel de detalle, hay que
completarlo con el teórico de la cátedra.

## Conexiones

- [[Monopolio]] — el índice de Lerner mide exactamente el hueco entre $P$ y $CMg$ que abre el monopolista
- [[Oligopolio]] — es la estructura donde más se aplican las leyes antimonopolio, por el riesgo de colusión
- [[Clasificación de Mercados]] — los índices cuantifican la columna "influencia sobre el precio" de esa tabla
- [[Competencia Perfecta]] — es el punto de referencia: ahí el índice de Lerner vale cero
- [[Rol del Estado y Desarrollo Sustentable]] — la regulación es uno de los tres instrumentos del Estado, y acá se ve aplicada
- [[Fallas del Mercado]] — el poder de mercado es la primera falla de la tipología

## En el parcial

**Calcular un HHI a partir de una lista de cuotas de mercado y clasificar el mercado en las tres
categorías** (menos de 1.500 / 1.500 a 2.500 / más de 2.500). Es el ejercicio numérico más
probable de todo el bloque de mercados y es un regalo si te acordás de **elevar al cuadrado
antes de sumar**. Aparte: **escribir el índice de Lerner, decir cuánto vale en competencia
perfecta (cero) y cuál es su desventaja** (medir el $CMg$). El error clásico es sumar las cuotas
sin elevarlas al cuadrado y dar 100.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `Resumen temas coloquio` y `SEGUNDO PARCIAL — Google Docs` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

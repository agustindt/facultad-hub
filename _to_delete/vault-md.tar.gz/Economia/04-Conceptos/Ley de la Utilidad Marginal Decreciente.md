---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, consumidor]
---

# Ley de la Utilidad Marginal Decreciente

> **Cuanto más tenés de un bien, menos te suma la unidad siguiente.** Es una sola frase, pero
> es la que hace que la curva de demanda baje.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## El enunciado

Textual del material:

> "A medida que aumenta la cantidad consumida de un bien, el incremento de utilidad total que proporciona la última unidad es cada vez menor. El hecho de que la utilidad marginal disminuya conforme aumenta la cantidad consumida de un bien es lo que se conoce como la **ley de la utilidad marginal decreciente**."

En símbolos: la $UMg$ es positiva pero **decreciente** en $Q$. La [[Utilidad Total y Marginal|utilidad total]]
sigue subiendo mientras la marginal sea positiva; lo que cae es el **ritmo** al que sube.

## Ojo con esta confusión — es la trampa del tema

| Afirmación | ¿Correcta? |
|---|---|
| La utilidad **marginal** decrece | Sí — es la ley |
| La utilidad **total** decrece | No — sigue creciendo, sólo que cada vez menos |
| El incremento de la utilidad total que aporta la última unidad es cada vez menor | Sí — es otra forma de decir lo mismo |

Uno de los apuntes de origen (el manuscrito) enuncia la ley diciendo que decrece "el incremento
de la utilidad **marginal**". Eso es un error de copia: lo que decrece es la utilidad marginal
misma, o equivalentemente el incremento de la utilidad **total**.

## Por qué importa tanto

Sin esta ley no hay teoría del consumidor. Es la que hace que:

1. **La demanda tenga pendiente negativa.** Si cada unidad extra vale menos, sólo la comprás si el precio también baja. De ahí sale la [[Curva de Demanda]].
2. **El agua sea barata y los diamantes caros.** La disposición a pagar se engancha a la $UMg$, y la $UMg$ depende de cuántas unidades ya tenés.
3. **El [[Equilibrio del Consumidor]] sea un punto y no un rincón.** Si la $UMg$ fuera constante, convendría gastar todo el ingreso en un solo bien.

## La hermana melliza del lado de la producción

```mermaid
flowchart LR
    A["<b>CONSUMIDOR</b><br/>consumo una unidad más<br/>del mismo bien"] --> B["Utilidad marginal<br/>DECRECIENTE"]
    C["<b>EMPRESA</b><br/>agrego una unidad más<br/>de un factor variable"] --> D["Producto marginal<br/>DECRECIENTE"]
    B --> E["<b>Demanda con<br/>pendiente negativa</b>"]
    D --> F["<b>Costo marginal<br/>creciente</b>"]
    style B fill:#4DB6AC,color:#fff
    style D fill:#FFA726,color:#fff
    style E fill:#7C5CFF,color:#fff
    style F fill:#7C5CFF,color:#fff
```

Son dos leyes distintas con la misma forma: agregar más de lo mismo rinde cada vez menos. Una
explica por qué la **demanda** baja; la otra, por qué la **oferta** sube.

## Conexiones

- [[Utilidad Total y Marginal]] — la ley es una propiedad de la $UMg$: no se entiende sin las definiciones
- [[Curva de Demanda]] — la pendiente negativa de la demanda es la consecuencia directa de esta ley
- [[Equilibrio del Consumidor]] — sólo hay un óptimo interior porque las utilidades marginales decrecen
- [[Ley de Rendimientos Decrecientes]] — la misma estructura lógica del lado de la producción
- [[Excedente del Consumidor]] — si todas las unidades valieran lo mismo, no habría excedente que medir

## En el parcial

**Enunciar la ley y usarla para justificar la pendiente negativa de la demanda** en dos pasos:
(1) cada unidad adicional aporta menos utilidad; (2) por lo tanto sólo se compra si el precio
baja. Es de las preguntas conceptuales cortas más probables. El error clásico es decir que "la
utilidad total disminuye": no disminuye, **crece cada vez menos**.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, cotejado con el manuscrito `MERCADOS` (nov 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, contabilidad-nacional]
---

# Ingreso Nacional e Ingreso Disponible

> Del total que produce el país hasta lo que a una familia le queda para gastar hay una cadena de
> restas: **Ingreso Nacional → Ingreso Personal → Ingreso Disponible**. Cada flecha saca algo
> concreto.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Producto o ingreso, interno o nacional

Cuatro definiciones que se cruzan de a dos y se confunden siempre:

| | Producto (lo que se produce) | Ingreso (lo que se retribuye) |
|---|---|---|
| **Interno** (territorio) | Producto de la actividad que se desarrolla dentro de un país, sin importar si quien la hace es del país o foráneo | Retribución por los factores de producción que se utilizan dentro de las fronteras |
| **Nacional** (residentes) | Producto de la actividad que desarrollan habitantes de un país, residan dentro o fuera de las fronteras | Retribución por los factores que reciben los residentes de un país, residan dentro o fuera |

El puente entre las dos filas es siempre el mismo:

$$Nacional = Interno + Saldo\ de\ remesas$$

## El Ingreso Nacional

> "Es la suma de las remuneraciones pagadas a los factores de producción nacionales (sueldos, salarios, alquileres, intereses y beneficios) durante un periodo de tiempo."

$$YN = YNN_{cf} = PNN_{cf}$$

Y ojo con esta sutileza, que es material de pregunta teórica: el Producto Nacional Neto a costo de
factores es **numéricamente equivalente** al Ingreso Nacional Neto a costo de factores, pero
**conceptualmente distinto**. Uno mide producción, el otro retribución.

## La cadena de conversiones

Textual del material, y es lo que se toma como ejercicio:

$$YIN_{cf} + Depreciación = YIB_{cf}$$
$$YIN_{cf} + Depreciación + Imp.Ind.Netos = YIB_{pm}$$
$$YIN_{cf} \pm Saldo\ de\ remesas = YNN_{cf}$$
$$YIB_{pm} - Imp.Ind.Netos \pm Saldo\ de\ remesas - Depreciación = YNN_{cf} = YN$$

```mermaid
flowchart LR
    A["<b>YIB pm</b><br/>interno, bruto,<br/>a precios de mercado"] -->|"&minus; imp. indirectos netos"| B["YIB cf"]
    B -->|"&minus; depreciación"| C["YIN cf"]
    C -->|"&plusmn; saldo de remesas"| D["<b>YNN cf = YN</b><br/>Ingreso Nacional"]
    D -->|"&minus; lo que no llega a las personas<br/>+ transferencias del Estado"| E["<b>YP</b><br/>Ingreso Personal"]
    E -->|"&minus; impuestos directos"| F["<b>YD</b><br/>Ingreso Disponible"]
    style A fill:#4DB6AC,color:#fff
    style D fill:#FFA726,color:#fff
    style F fill:#7C5CFF,color:#fff
```

## Del Ingreso Nacional al bolsillo

**Ingreso Personal (YP)**: "es igual a la parte del ingreso nacional que efectivamente reciben las
personas".

$$YP = YN - (BeE + C_{ss} + BndSA + ImpBS) + (Becas + Subsidios + Jubilaciones\ y\ pensiones + Planes\ de\ desempleo)$$

| Se resta | Por qué |
|---|---|
| Beneficios de las empresas del Estado (BeE) | No llegan a las personas |
| Beneficios no distribuidos de las SA (BndSA) | Se quedan en la empresa |
| Contribuciones a la seguridad social (Css) | No se cobran como ingreso |
| Impuestos sobre los beneficios de sociedades (ImpBS) | Los capta el Estado |

| Se suma | Por qué |
|---|---|
| Becas, subsidios, jubilaciones, pensiones, planes de desempleo | Son ingresos que las familias reciben del Estado **sin** haber aportado un factor de producción |

**Ingreso Disponible (YD)**: "la parte del ingreso personal efectivamente disponible para el gasto
o el ahorro".

$$YD = YP - Impuestos\ directos$$

Y ese YD es exactamente la variable con la que arranca [[Consumo Ahorro e Inversión]]: se consume
o se ahorra, no hay tercera opción.

## Directos vs. indirectos, para no equivocarse en la resta

| | Qué grava | Ejemplo | Dónde entra |
|---|---|---|---|
| Impuesto directo | Las fuentes de riqueza, la propiedad o la renta | Impuesto a las ganancias, al patrimonio | Se resta para pasar de YP a YD |
| Impuesto indirecto | El consumo; recae sobre el costo del producto | IVA | Separa precios de mercado de costo de factores |

$$P_{mercado} = C_{factores} + Imp.Indirectos - Subsidios$$

## Conexiones

- [[Producto Bruto Interno]] — el otro lado de la misma identidad: producción e ingreso son la misma cosa
- [[Métodos de Cálculo del PBI]] — el método del ingreso desemboca directamente en el YN
- [[Consumo Ahorro e Inversión]] — el ingreso disponible es lo que se reparte entre C y S
- [[Política Fiscal]] — impuestos y transferencias son las dos manos del Estado sobre esta cadena
- [[Impuestos: Ganancias e IVA]] — los mismos dos impuestos, vistos desde la empresa en U5
- [[Flujo Circular del Ingreso]] — impuestos y transferencias como salida y entrada del circuito

## En el parcial

**Ejercicio de conversión: te dan el YIBpm más depreciación, impuestos indirectos netos y saldo de
remesas, y piden llegar al YN o al YD.** Hacelo en pasos separados y escribí al lado de cada uno
qué eje estás moviendo (precios, plazo del capital, residencia). Después, la parte conceptual:
explicar por qué PNNcf e YNNcf son iguales en número y distintos en concepto. El error clásico es
restar impuestos directos donde iban indirectos —y ahí se cae todo el ejercicio— o sumar las
transferencias en el paso equivocado de la cadena.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

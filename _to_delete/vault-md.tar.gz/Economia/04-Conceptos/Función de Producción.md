---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion]
---

# Función de Producción

> Especifica la **cantidad máxima** de un bien que puede producirse con una cantidad dada de
> factores, para un estado dado del conocimiento tecnológico.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Con dos factores:

$$q = F(L, K)$$

Textual de la cátedra:

> "LA FUNCIÓN DE PRODUCCIÓN: Especifica la cantidad máxima de un bien que puede producirse con una cantidad dada de factores o insumos, y se define para un estado dado del conocimiento tecnológico."

Dos palabras hacen todo el trabajo en esa definición:

- **Máxima** — la función describe lo que se obtiene produciendo **bien**, sin desperdicio. Ya
  supone eficiencia técnica. Una empresa mal gestionada produce *menos* que su función de
  producción; nunca más.
- **Dado el estado de la tecnología** — la función se define para una tecnología fija. Un
  cambio tecnológico **no** es un movimiento a lo largo de la función: es una función nueva.

## Tecnología

> "TECNOLOGÍA: Es un conjunto de técnicas disponibles en un momento dado, para la combinación de factores de producción. Se relaciona con la forma o el modo en que se combinan los recursos y con los métodos que se emplean en la producción y la proporción en que se usan los distintos factores."

Es el parámetro que la función toma como dado. Por eso, en el gráfico de la
[[Frontera de Posibilidades de Producción]], una mejora técnica desplaza la curva: cambió la
función.

## La empresa

> "La empresa es la unidad económica de producción encargada de la transformación de los factores de producción (trabajo, capital y recursos naturales), para obtener bienes y servicios que se venden en los mercados."

El esquema completo que arma la cátedra, con sus funciones:

| Elemento | Función | Qué dice |
|---|---|---|
| Producción | $Q = f(x_1, \dots, x_n)$ | El producto depende de los factores usados |
| Costo | $C = h(c_{x_1}, \dots, c_{x_n})$ | El costo depende del precio de esos factores |
| Costo en función del producto | $C = f(Q)$ | Combinando las dos anteriores |
| Ingreso | $I = V(Q)$ | El ingreso depende de lo vendido |
| **Beneficio** | $B(Q) = I(Q) - C(Q)$ | **El objetivo de la empresa** |

Toda la unidad construye la pieza $C = f(Q)$ de ese sistema. La pieza $I(Q)$ es la U3, y
recién ahí se puede maximizar $B(Q)$.

## Conexiones

- [[Factores de Producción]] — son las variables de la función: K, L y RN
- [[Corto Plazo y Largo Plazo]] — la función es distinta según puedan variar todos los factores o no
- [[Producto Total Medio y Marginal]] — las tres curvas se derivan de esta función
- [[Isocuanta]] — es la misma función vista "de arriba": las combinaciones que dan igual producto
- [[Rendimientos de Escala]] — describe cómo responde esta función si se mueven todos los factores a la vez

## En el parcial

Definición **con las dos palabras clave**: cantidad *máxima* y tecnología *dada*. Y saber
distinguirla de la [[Isocuanta]] — la cátedra le dedicó una diapositiva a esa diferencia.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion, largo-plazo]
---

# Eficiencia Económica en Tecnología

> El punto donde la [[Isocuanta]] es **tangente** al [[Isocosto]]: la combinación de factores
> que produce una cantidad dada **al menor costo posible**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Textual:

> "**EN EL PUNTO DE EFICIENCIA ECONÓMICA** existe una combinación de factores para la cual **la recta de isocosto es tangente a la curva de isocuanta**."

Y el punto se lee en los dos sentidos, que son equivalentes:

> "Para una recta de isocosto dada, se tiene la **máxima cantidad de producción alcanzable**.
> Para una determinada cantidad de producción, se **minimiza el costo**."

```mermaid
flowchart TD
    I["<b>ISOCUANTA</b><br/>qué es técnicamente posible<br/>(tecnología)"] --> T
    C["<b>ISOCOSTO</b><br/>qué cuesta cada combinación<br/>(precios)"] --> T
    T["<b>TANGENCIA</b><br/>eficiencia económica"] --> R["TMST = w / r"]
    R --> F["PMg-L / w = PMg-K / r"]
    style I fill:#4DB6AC,color:#fff
    style C fill:#FFA726,color:#fff
    style T fill:#7C5CFF,color:#fff
    style F fill:#7C5CFF,color:#fff
```

## La condición, y lo que significa

$$\frac{w}{r} = \frac{PMg_L}{PMg_K} \qquad \Longleftrightarrow \qquad \frac{PMg_L}{w} = \frac{PMg_K}{r}$$

Textual de la cátedra:

> "La condición para minimizar los costos se alcanza cuando la razón entre los precios de los factores se iguala a la razón de los productos marginales de los factores […] cuyo significado económico es que **el producto marginal obtenido por el último peso tiene que ser el mismo, cualquiera sea el factor productivo**."

Esa segunda forma es la que hay que saber explicar. Cada término es *"cuánto producto me da el
último peso gastado en este factor"*. Si un peso en trabajo rinde más que un peso en capital,
conviene mover plata hacia el trabajo: producís lo mismo gastando menos. Y así hasta que
rinden igual — ahí no queda nada por ganar, y estás en el óptimo.

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">10</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">30</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><line x1="142" x2="142" y1="14" y2="159" stroke="#7C5CFF" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="142" cy="86.5" r="3.4" fill="#7C5CFF"/><text x="142" y="170" text-anchor="middle" font-size="8" fill="#7C5CFF" font-weight="600">óptimo</text><path d="M83.7 18 L88.7 28.5 L93.7 37.6 L98.6 45.5 L103.6 52.4 L108.6 58.5 L113.5 64 L118.5 68.9 L123.5 73.3 L128.5 77.3 L133.4 80.9 L138.4 84.3 L143.4 87.3 L148.3 90.1 L153.3 92.7 L158.3 95.2 L163.3 97.4 L168.2 99.5 L173.2 101.5 L178.2 103.3 L183.1 105 L188.1 106.6 L193.1 108.1 L198.1 109.6 L203 110.9 L208 112.2 L213 113.4 L217.9 114.6 L222.9 115.7 L227.9 116.7 L232.9 117.7 L237.8 118.7 L242.8 119.6 L247.8 120.5 L252.7 121.3 L257.7 122.1 L262.7 122.9 L267.7 123.6 L272.6 124.3 L277.6 125 L282.6 125.6 L287.5 126.2 L292.5 126.8 L297.5 127.4 L302.5 128 L307.4 128.5 L312.4 129 L317.4 129.5 L322.3 130 L327.3 130.5 L332.3 131 L337.3 131.4 L342.2 131.8 L347.2 132.2 L352.2 132.7 L357.1 133 L362.1 133.4 L367.1 133.8 L372.1 134.1 L377 134.5 L382 134.8" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="137.8" font-size="9" fill="#4DB6AC" font-weight="600">q</text><path d="M34 21.3 L39 24.3 L43.9 27.3 L48.9 30.3 L53.9 33.3 L58.9 36.3 L63.8 39.3 L68.8 42.3 L73.8 45.3 L78.7 48.3 L83.7 51.3 L88.7 54.3 L93.7 57.3 L98.6 60.3 L103.6 63.3 L108.6 66.3 L113.5 69.3 L118.5 72.3 L123.5 75.3 L128.5 78.3 L133.4 81.3 L138.4 84.3 L143.4 87.3 L148.3 90.3 L153.3 93.3 L158.3 96.3 L163.3 99.3 L168.2 102.3 L173.2 105.3 L178.2 108.4 L183.1 111.4 L188.1 114.4 L193.1 117.4 L198.1 120.4 L203 123.4 L208 126.4 L213 129.4 L217.9 132.4 L222.9 135.4 L227.9 138.4 L232.9 141.4 L237.8 144.4 L242.8 147.4 L247.8 150.4 L252.7 153.4 L257.7 156.4" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="261.7" y="159.4" font-size="9" fill="#FFA726" font-weight="600">CT</text><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L) — eje vertical: Capital (K)</text></svg>

*El óptimo es el punto donde el isocosto toca la isocuanta sin cruzarla.*


## Eficiencia técnica ≠ eficiencia económica

Es **la** distinción de la unidad:

| | Eficiencia **técnica** | Eficiencia **económica** |
|---|---|---|
| Criterio | Producir el máximo con los recursos dados, sin desperdicio | Producir esa cantidad **al menor costo** |
| Cuántos puntos la cumplen | **Todos** los de la isocuanta | **Uno solo**: el de tangencia |
| Información que necesita | Solo tecnología | Tecnología **+ precios** |

Todo punto económicamente eficiente es técnicamente eficiente; **al revés no**. Y como el óptimo
depende de los precios, **si cambian los precios cambia la tecnología óptima** aunque la
tecnología disponible sea exactamente la misma: por eso donde el trabajo es barato se produce
de manera más intensiva en trabajo.

## Conexiones

- [[Isocuanta]] — aporta la restricción técnica; todos sus puntos son técnicamente eficientes
- [[Isocosto]] — aporta los precios, que es lo que permite elegir entre ellos
- [[Tasa Marginal de Sustitución Técnica]] — en el óptimo se iguala a la relación de precios $w/r$
- [[Sendero de Expansión]] — es el lugar geométrico de estos óptimos para distintas escalas
- [[Costos de Largo Plazo]] — la curva de costos de largo plazo se construye a partir de estos óptimos

## En el parcial

La condición de tangencia, la fórmula **en sus dos formas**, y la interpretación del "último
peso". Más la diferencia entre eficiencia técnica y económica, que es pregunta casi segura.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

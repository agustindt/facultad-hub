---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion, costos, largo-plazo]
---

# Isocosto

> Recta que muestra **todas las combinaciones de factores** que pueden comprarse por un **mismo
> costo total**, dados los precios de los factores.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Siendo $w$ el precio del trabajo (*wage*) y $r$ el precio del capital (*rental rate*), el costo
total de emplear cualquier volumen de $L$ y $K$ es:

$$CT_0 = wL + rK$$

Despejando $K$ para poder graficarla:

$$K = \frac{CT_0}{r} - \frac{w}{r}\,L$$

- **Ordenada al origen:** $CT_0 / r$ — todo el presupuesto gastado en capital.
- **Pendiente:** $-\dfrac{w}{r}$ — la **relación de precios** de los factores, con signo negativo.

## Las dos propiedades que se preguntan

1. **Es una recta**, no una curva. Porque los precios de los factores son **constantes**: la
   empresa los toma como dados y no cambian con la cantidad que compre.
2. **Los isocostos son paralelos entre sí.** Textual: *"Las isocostos son paralelas, los precios
   de los factores son constantes y, en consecuencia, no se altera la relación $-(w/r)$."*
   Un presupuesto mayor desplaza la recta hacia afuera **sin cambiarle la pendiente**.

> 📌 **Qué la mueve y qué la inclina** — esto se toma:
> - Cambia el **presupuesto** ($CT_0$) → la recta se **desplaza paralela**.
> - Cambia un **precio** ($w$ o $r$) → la recta **cambia de pendiente** (rota).

<svg viewBox="0 0 440 185" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="159" y2="159" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="162" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="34" x2="382" y1="110.7" y2="110.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="113.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">10</text><line x1="34" x2="382" y1="62.3" y2="62.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="65.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">30</text><line x1="34" x2="34" y1="14" y2="159" stroke="var(--background-modifier-border,#8886)"/><path d="M34 72 L39 75.1 L43.9 78.2 L48.9 81.3 L53.9 84.4 L58.9 87.5 L63.8 90.6 L68.8 93.8 L73.8 96.9 L78.7 100 L83.7 103.1 L88.7 106.2 L93.7 109.3 L98.6 112.4 L103.6 115.5 L108.6 118.6 L113.5 121.7 L118.5 124.8 L123.5 127.9 L128.5 131 L133.4 134.1 L138.4 137.3 L143.4 140.4 L148.3 143.5 L153.3 146.6 L158.3 149.7 L163.3 152.8 L168.2 155.9 L173.2 159" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><path d="M34 14 L39 17.1 L43.9 20.2 L48.9 23.3 L53.9 26.4 L58.9 29.5 L63.8 32.6 L68.8 35.8 L73.8 38.9 L78.7 42 L83.7 45.1 L88.7 48.2 L93.7 51.3 L98.6 54.4 L103.6 57.5 L108.6 60.6 L113.5 63.7 L118.5 66.8 L123.5 69.9 L128.5 73 L133.4 76.1 L138.4 79.3 L143.4 82.4 L148.3 85.5 L153.3 88.6 L158.3 91.7 L163.3 94.8 L168.2 97.9 L173.2 101 L178.2 104.1 L183.1 107.2 L188.1 110.3 L193.1 113.4 L198.1 116.5 L203 119.6 L208 122.8 L213 125.9 L217.9 129 L222.9 132.1 L227.9 135.2 L232.9 138.3 L237.8 141.4 L242.8 144.5 L247.8 147.6 L252.7 150.7 L257.7 153.8 L262.7 156.9" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="266.7" y="159.9" font-size="9" fill="#FFA726" font-weight="600">CT</text><path d="M128.5 15 L133.4 18.1 L138.4 21.3 L143.4 24.4 L148.3 27.5 L153.3 30.6 L158.3 33.7 L163.3 36.8 L168.2 39.9 L173.2 43 L178.2 46.1 L183.1 49.2 L188.1 52.3 L193.1 55.4 L198.1 58.5 L203 61.6 L208 64.8 L213 67.9 L217.9 71 L222.9 74.1 L227.9 77.2 L232.9 80.3 L237.8 83.4 L242.8 86.5 L247.8 89.6 L252.7 92.7 L257.7 95.8 L262.7 98.9 L267.7 102 L272.6 105.1 L277.6 108.3 L282.6 111.4 L287.5 114.5 L292.5 117.6 L297.5 120.7 L302.5 123.8 L307.4 126.9 L312.4 130 L317.4 133.1 L322.3 136.2 L327.3 139.3 L332.3 142.4 L337.3 145.5 L342.2 148.6 L347.2 151.8 L352.2 154.9 L357.1 158" fill="none" stroke="var(--background-modifier-border,#8886)" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="4 3"/><text x="208.0" y="182" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L) — eje vertical: Capital (K)</text></svg>

*Son rectas y paralelas entre sí: un presupuesto mayor desplaza la línea sin cambiarle la pendiente.*


## Qué aporta que la isocuanta no tiene

La [[Isocuanta]] es pura técnica: dice qué combinaciones son posibles. El isocosto trae la
información que faltaba, los **precios**. Con las dos juntas ya se puede elegir: ver
[[Eficiencia Económica en Tecnología]].

| | Isocuanta | Isocosto |
|---|---|---|
| Mantiene constante | El **producto** | El **costo** |
| Su pendiente es | La [[Tasa Marginal de Sustitución Técnica]] $= PMg_L/PMg_K$ | La relación de precios $w/r$ |
| Su forma | Curva convexa | **Recta** |
| Información que aporta | Tecnología | Precios de mercado |

## Conexiones

- [[Isocuanta]] — su complemento exacto: una fija el producto, la otra el costo
- [[Eficiencia Económica en Tecnología]] — el óptimo es la tangencia entre las dos
- [[Tasa Marginal de Sustitución Técnica]] — en el óptimo se iguala a la pendiente del isocosto
- [[Sendero de Expansión]] — se traza uniendo las tangencias con isocostos sucesivos
- [[Factores de Producción]] — $w$ y $r$ son los precios de esos factores

## En el parcial

Escribir la ecuación, despejar $K$, e interpretar la pendiente como relación de precios.
Y saber qué la desplaza (presupuesto) y qué la rota (precios).

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

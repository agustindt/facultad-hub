---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, mercados]
---

# Clasificación de Mercados

> **Cuatro estructuras ordenadas por una sola variable: cuánto poder tiene la empresa sobre el
> precio.** De competencia perfecta (cero) a monopolio (total). Esta tabla es el esqueleto de
> media unidad.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Qué es un mercado

> "Área geográfica y periodo donde compradores y vendedores interactúan determinando precios 'p' y cantidades 'q' de un bien, un servicio o un factor de producción. Es el ámbito en el que se enfrentan la oferta y la demanda para fijar un precio."

Una segunda fuente lo formula como "el espacio (**físico o virtual**)", que es la versión
actualizada de la misma idea.

## Los dos grandes tipos de mercado

| Tipo de mercado | Quién demanda | Quién ofrece | Para qué sirve |
|---|---|---|---|
| **De bienes y servicios** | Las familias | Las empresas | Son los más importantes para determinar **qué producir** |
| **De factores** | Las empresas | Las familias | Son los más relevantes para determinar **cómo y para quién producir** |

El circuito que arma el material: las familias gastan en el mercado de bienes, y de esos gastos
las empresas obtienen sus ingresos; las empresas pagan por los insumos, y esos pagos son los
ingresos de las familias. Ver [[Mercado de Trabajo]].

## La tabla de las cuatro estructuras

Los criterios de clasificación son cuatro: **número de empresas, barreras de entrada, tipo de
producto e influencia sobre el precio**.

| Estructura | N.º de empresas | Barreras de entrada | Producto | Influencia sobre el precio | Competencia | Ejemplo |
|---|---|---|---|---|---|---|
| **Competencia perfecta** | Muchas | Ninguna | Homogéneo | Nula | Total | Agrícolas |
| **Competencia monopolística** | Muchas | Bajas | Diferenciado (marca o publicidad) | Cierta | Elevada | Ropa o perfumes |
| **Oligopolio** | Pocas | Fuertes | Diferenciado (si existe rivalidad) o no | Alta | Mucha rivalidad y poca cooperación | Autos |
| **Monopolio** | Una sola | Totales | Único | Total | Nula | Agua |

```mermaid
flowchart LR
    A["<b>COMPETENCIA PERFECTA</b><br/>muchas · producto homogéneo<br/>influencia NULA"] --> B["<b>COMPETENCIA MONOPOLÍSTICA</b><br/>muchas · diferenciado<br/>influencia CIERTA"]
    B --> C["<b>OLIGOPOLIO</b><br/>pocas · barreras fuertes<br/>influencia ALTA"]
    C --> D["<b>MONOPOLIO</b><br/>una sola · barreras totales<br/>influencia TOTAL"]
    style A fill:#4DB6AC,color:#fff
    style B fill:#4DB6AC,color:#fff
    style C fill:#FFA726,color:#fff
    style D fill:#7C5CFF,color:#fff
```

De izquierda a derecha crece el poder de mercado y caen la cantidad producida y el bienestar; de
derecha a izquierda, el mercado se acerca al ideal de eficiencia. Los dos extremos son casos
teóricos de referencia; los dos del medio son donde vive casi toda la economía real.

## Un detalle que ordena todo

La única condición que **de verdad** separa las cuatro estructuras es si la empresa es
**tomadora** o **creadora** de precios. Todo lo demás (número de empresas, barreras,
diferenciación) son las **causas** de que pueda o no poner el precio.

## Conexiones

- [[Competencia Perfecta]] — el extremo de influencia nula: la empresa es precio-aceptante
- [[Monopolio]] — el extremo opuesto: una sola empresa y barreras totales
- [[Competencia Monopolística]] — muchas empresas pero producto diferenciado, que es lo que da algo de poder de precio
- [[Oligopolio]] — pocas empresas con decisiones interconectadas
- [[Concentración y Defensa de la Competencia]] — los índices de Lerner y Herfindahl ponen número a la columna "influencia sobre el precio"
- [[5 Fuerzas de Porter]] — las barreras de entrada de esta tabla son la misma variable que Porter usa para analizar el atractivo de un sector

## En el parcial

**Reproducir la tabla de las cuatro estructuras con sus cuatro criterios y un ejemplo de cada
una.** Es la pregunta de arranque más probable del bloque de mercados, y muchas veces vale como
punto entero. Practicá el camino inverso también: te dan un caso ("pocas empresas, barreras
fuertes, productos parecidos") y hay que nombrar la estructura y anticipar el resultado de
precio y cantidad. El error clásico es clasificar por número de empresas solamente: la
competencia monopolística también tiene *muchas* empresas, y lo que la distingue es la
**diferenciación del producto**.

---
Fuente: `SEGUNDO PARCIAL — Google Docs, sección Unidad 3`, con `ECONOMIA FINAL — camila arenel (feb 2025)` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

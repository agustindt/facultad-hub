---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, contabilidad-nacional]
---

# PBI Nominal y PBI Real

> El PBI nominal valúa la producción a **precios corrientes** y el real a **precios constantes del
> año base**. Sólo el real sirve para hablar de crecimiento: el nominal sube aunque no se produzca
> una unidad más.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## La diferencia, en una tabla

| | PBI nominal | PBI real |
|---|---|---|
| A qué precios | Corrientes de mercado | Constantes, del año base |
| Qué incluye | El efecto de la inflación | Sólo cantidades: es un índice de la cantidad de bienes y servicios producidos |
| Para qué sirve | Medir el valor de mercado del año | Medir el **crecimiento** |

$$PBI_{real} = \frac{PBI_{nominal}}{Índice\ de\ precios}$$

Interpretación de la fórmula: el índice de precios es el "deflactor" que saca del número la parte
que subió sólo porque subieron los precios. Lo que queda es producción comparable entre años.

## El ejemplo que resuelve la confusión

El material lo trae hecho y es el mejor argumento:

> "si el PIB nominal crece 4% y la inflación es 5%, el PIB real = -1%."

O sea: la economía facturó más y **produjo menos**. Un titular que diga "el producto creció 4%"
sin aclarar si es nominal o real no dice nada.

De ahí también sale por qué el per cápita se calcula sobre el real:

$$PBI\ per\ cápita = \frac{PBI\ real}{Población}$$

Son dos correcciones encadenadas: primero se saca la inflación, después se reparte entre la
población.

## Y con esto se define el crecimiento

> "El crecimiento económico es el aumento sostenido del PIB real a lo largo del tiempo, lo que implica una mejora del nivel de vida."

Las dos palabras a subrayar son **real** y **sostenido**: un rebote de un trimestre no es
crecimiento.

## Conexiones

- [[Producto Bruto Interno]] — el agregado del que estas dos son versiones
- [[Inflación]] — es exactamente lo que separa un PBI del otro, y se mide con el mismo índice de precios
- [[Producción Potencial y Brecha]] — el crecimiento se define como expansión sostenida del producto real
- [[Métodos de Cálculo del PBI]] — cualquiera de los tres métodos se puede expresar en nominal o en real
- [[Inflación e Interés]] — la misma corrección nominal/real, aplicada a las tasas en Ingeniería Económica

## En el parcial

**Te dan la variación del PBI nominal y la tasa de inflación y hay que decir si la economía creció
o se contrajo.** Es una resta, pero hay que justificarla en una línea: el nominal incorpora precios,
el real no. Segunda variante habitual: explicar por qué el PBI real se calcula a precios del año
base. El error clásico es festejar un aumento nominal como si fuera crecimiento — y el error más
fino, olvidar la población cuando piden per cápita.

---
Fuente: `MACROECONOMIA — manuscrito iPad, nov 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` y de `UNIDAD 4 — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

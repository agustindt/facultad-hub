---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, reemplazo]
---

# Reemplazo de Equipos

> El duelo entre el equipo que ya tenés (**defensor**) y el que podrías comprar
> (**desafiante**). Con igual producción y mismo horizonte, se decide por **costo presente
> mínimo**; y el mínimo costo anual equivalente marca la vida útil económica del activo.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Por qué es un problema de gestión, no de mantenimiento

> "Una empresa debe generar políticas eficientes de reemplazo de los activos que utiliza, ya que, de no hacerlo, se encuentra en desventaja frente a la competencia, sufre una disminución de su capital y se originan excesivos costos de mantenimiento y operación."

## Los tres motivos de reemplazo

Se listan y se preguntan:

1. **Deterioro físico** — "el rendimiento disminuido de los equipos existentes debido a un
   deterioro físico".
2. **Incumplimiento de los requerimientos de producción** de los equipos existentes.
3. **Obsolescencia** de los mismos.

Fijate que sólo el primero es desgaste: los otros dos son que el equipo **ya no sirve para lo
que hace falta**, aunque funcione perfecto.

## Defensor vs. desafiante

| | **Defensor** (el activo existente) | **Desafiante** (el activo propuesto) |
|---|---|---|
| Costo de capital | **Bajo** | **Alto** |
| Costos de operación | **Altos** | **Bajos** |
| Vida útil remanente | **Baja** | **Larga** |

Ése es exactamente el canje: el desafiante te pide plata hoy y te la devuelve en operación más
barata durante más tiempo. Por eso no se puede decidir mirando el precio: hay que actualizar,
que es de lo que se trata la unidad.

## Los supuestos y el criterio

El apunte los pone como una ficha, y así hay que saberlos:

| | |
|---|---|
| **Supuesto** | "igual producción con ambos equipos" |
| **Horizonte de análisis** | "Igual para ambos equipos" |
| **Criterio de selección** | "**Costo Presente Mínimo**" |

Y el criterio equivalente cuando se lo mira desde los beneficios: "Ante cantidades equivalentes
de producción el criterio de decisión se basa en el **mayor valor presente neto**" (ver
[[Valor Actual Neto]]).

## Cuando cambia la producción o la vida útil

Dos casos que rompen el supuesto y tienen cada uno su salida:

- **Si el desafiante produce más:** "Si existe una diferencia en la capacidad de producción en
  el equipo desafiante, corresponde realizar un **Análisis Beneficio-Costo**, considerando las
  diferencias en los ingresos y en los costos entre defensor y desafiante." No alcanza con
  comparar costos: cambiaron también los ingresos.
- **Si las vidas útiles son distintas:** "El método del **costo anual equivalente** se utiliza
  para comparar proyectos de distinta vida útil que son replicados a perpetuidad." Con vidas
  iguales podés usar cualquiera de los dos: "a través del valor presente (VP) o del costo anual
  equivalente (CAE)".

## Vida útil económica

La frase que define el tema "vida de servicio económica" del programa:

> "El **mínimo costo anual equivalente** representa la vida útil económica óptima para el activo."

O sea: la vida útil económica no es cuánto **dura** el equipo, es **hasta cuándo conviene
tenerlo**. Se busca el $n$ que minimiza el CAE — el CAE se construye con el Factor de
Recuperación de Capital de [[Factores de Equivalencia]].

## Faltante

El apunte **no escribe la fórmula del costo anual equivalente**, no da ejemplos numéricos de
comparación defensor/desafiante, y **no menciona el valor residual** del equipo reemplazado
—que es tema del programa— ni el tratamiento impositivo de la venta del defensor.

## Conexiones

- [[Comparación de Alternativas]] — el reemplazo es un caso particular, con la misma caja de herramientas
- [[Valor Actual Neto]] — el criterio con igual producción es el mayor VPN
- [[Factores de Equivalencia]] — el FRC es lo que convierte una inversión en el costo anual equivalente con que se comparan vidas útiles distintas
- [[Depreciación]] — el deterioro y la obsolescencia son lo que la depreciación intenta reflejar contablemente
- [[Valuación de Activos]] — cuánto vale el defensor hoy condiciona la decisión
- [[Erogaciones Relevantes]] — qué costos del defensor son relevantes y cuáles ya están hundidos

## En el parcial

**Comparar defensor y desafiante bajo el supuesto de igual producción e igual horizonte, y
elegir por costo presente mínimo; y saber cuándo hay que cambiar de método:** si el desafiante
produce más → análisis beneficio-costo; si las vidas útiles difieren → costo anual equivalente.

Preguntá teórica segura: **los tres motivos de reemplazo** (deterioro físico, incumplimiento de
requerimientos de producción, obsolescencia) y la definición de vida útil económica como el
$n$ que **minimiza el costo anual equivalente**.

El error clásico es comparar los dos equipos por el precio de compra, o comparar vidas útiles
distintas con valor presente sin homogeneizarlas.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

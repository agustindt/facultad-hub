---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, finanzas]
---

# Fuentes de Financiamiento

> **Dos clasificaciones cruzadas, no una.** Por *origen*: si la plata se genera dentro o fuera de
> la empresa. Por *titularidad*: si hay que devolverla o no. Son preguntas distintas y en el
> parcial se piden por separado.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Por qué una empresa necesita financiarse

El apunte da dos motivos, y son de naturaleza muy distinta:

1. **Falta de liquidez** necesaria para hacer frente a las **operaciones diarias** — es el
   problema de corto plazo, el del [[Ciclo del Capital Circulante]].
2. **Ante la posibilidad de llevar a cabo una nueva inversión** (crecimiento, expansión) "no se
   cuenta con capital propio suficiente **o no se desea comprometer 100 % capital propio**".

Esa segunda mitad es la que se pasa por alto: no siempre te financiás porque no tenés la plata.
A veces la tenés y **elegís** no ponerla toda.

## Las dos clasificaciones

### Según su origen — ¿se genera dentro o fuera de la empresa?

| | Qué incluye | Dónde figura |
|---|---|---|
| **Financiación interna** | Reservas, capital accionario, nueva emisión de acciones | Patrimonio Neto |
| **Financiación externa** | Créditos, cuentas a pagar, anticipos, aportes de socios | Pasivo exigible |

### Según la titularidad — ¿hay que devolverla?

| | Regla | Ejemplos |
|---|---|---|
| **Financiación propia** | **No** hay que devolverla | Reservas |
| **Financiación ajena** | **Sí** hay que devolverla | Préstamos, créditos, etc. |

## Ojo con una inconsistencia del apunte

En la clasificación por origen, "**aportes de socios**" aparece dentro de **financiación
externa**, mientras que "capital accionario" y "nueva emisión de acciones" aparecen dentro de
**interna**. Son cosas muy parecidas puestas en casilleros opuestos. No lo resuelvas por tu
cuenta en el parcial: reproducí la lista como está y, si te toca justificar, apoyate en el
criterio explícito (dentro o fuera de la empresa) más que en el ejemplo suelto.

Lo mismo vale para no superponer las dos clasificaciones: **interna no es sinónimo de propia**.
El criterio de una es de dónde sale la plata; el de la otra, si se devuelve.

```mermaid
flowchart TD
    N["<b>NECESIDAD DE FONDOS</b><br/>falta de liquidez<br/>o nueva inversión"] --> O["¿De dónde sale?"]
    N --> T["¿Hay que devolverla?"]
    O --> INT["<b>INTERNA</b><br/>reservas, capital accionario,<br/>emisión de acciones"]
    O --> EXT["<b>EXTERNA</b><br/>créditos, cuentas a pagar,<br/>anticipos, aportes de socios"]
    T --> PRO["<b>PROPIA</b><br/>no se devuelve"]
    T --> AJE["<b>AJENA</b><br/>se devuelve"]
    style N fill:#7C5CFF,color:#fff
    style INT fill:#FFA726,color:#fff
    style EXT fill:#4DB6AC,color:#fff
    style PRO fill:#FFA726,color:#fff
    style AJE fill:#4DB6AC,color:#fff
```

## Faltante

El programa incluye el tema "**Inversiones y el mercado de capitales**" (tema 15) y el material
**no lo trata**: no hay nada sobre instrumentos del mercado de capitales, obligaciones
negociables, bolsa, fideicomisos ni leasing. Tampoco hay ninguna comparación de **costo** entre
fuentes, ni criterios para elegir una sobre otra.

## Conexiones

- [[Estructura Financiera de la Empresa]] — es el mismo tema visto desde el balance: acá se abren las tres procedencias en dos clasificaciones cruzadas
- [[Ciclo del Capital Circulante]] — el primer motivo de financiamiento es cubrir el desfasaje entre pagos y cobros
- [[La Empresa y sus Actividades]] — "financiamiento" es la actividad 1: pedir prestado, devolver préstamos, emitir y recomprar acciones
- [[Sistemas de Amortización de Deuda]] — cómo se devuelve efectivamente la financiación ajena, que este material no cubre
- [[Costo Financiero Total]] — cuánto cuesta realmente cada fuente ajena, la pregunta que esta nota deja abierta
- [[Estados Contables Básicos]] — la financiación interna se ve en el estado de evolución del patrimonio (nuevos aportes, resultados no distribuidos)

## En el parcial

**Dada una lista de fuentes concretas (un préstamo bancario, reservas, una emisión de acciones,
crédito de proveedores), clasificar cada una por origen Y por titularidad.** Son dos columnas, no
una: el error clásico es contestar una sola clasificación o asumir que interna = propia. Y saber
enunciar los dos motivos de financiamiento, incluida la parte que se olvida: que a veces no se
desea comprometer el 100 % del capital propio aunque se lo tenga.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, empresa]
---

# La Empresa y sus Actividades

> Una empresa es un **conjunto de factores de producción coordinados** cuya función es producir
> bienes y servicios, con el objetivo de **maximizar su beneficio**. Todo lo que hace entra en
> cuatro actividades: financiamiento, inversión, operaciones y beneficios.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## La definición, textual

> "Una empresa se puede definir como un conjunto de factores de producción coordinados, cuya función es producir bienes y servicios. Objetivo: maximizar su beneficio."

Es la misma empresa de la microeconomía, mirada desde adentro: los mismos
[[Factores de Producción]], la misma [[Maximización de Beneficios]], pero la pregunta ya no es
*cuánto producir* sino *con qué plata, y cómo se registra*.

## Las cuatro actividades empresariales

Es la lista que más se pide de memoria, y cada una viene con sus ejemplos:

| Actividad | Qué resuelve | Ejemplos del apunte |
|---|---|---|
| **1. Financiamiento** | Las empresas necesitan fondos para desarrollar su actividad | Pedir prestado dinero · devolver los préstamos · emitir acciones · recomprar acciones · pagar dividendos |
| **2. Inversión** | Invierten fondos a **largo plazo** | Compra y venta de bienes de uso, incluidos inmuebles · inversiones en acciones de otras empresas y venta de esas acciones |
| **3. Operaciones** | Cumplen con su propósito como resultado de sus operaciones | Ventas a clientes · cobro de los créditos por ventas · compra de mercaderías · pago de cuentas a pagar, gastos operativos e impuestos |
| **4. Beneficios** | Qué se hace con lo ganado | Retribuir a los que invierten fondos · reinvertir fondos · distribuir dividendos |

```mermaid
flowchart LR
    F["<b>1. FINANCIAMIENTO</b><br/>conseguir fondos"] --> I["<b>2. INVERSIÓN</b><br/>fondos a largo plazo"]
    I --> O["<b>3. OPERACIONES</b><br/>el negocio en sí"]
    O --> B["<b>4. BENEFICIOS</b><br/>qué se hace con lo ganado"]
    B -->|"reinvertir fondos"| I
    B -->|"retribuir a quienes<br/>pusieron los fondos"| F
    style F fill:#4DB6AC,color:#fff
    style I fill:#FFA726,color:#fff
    style B fill:#7C5CFF,color:#fff
```

**Ojo con los dividendos:** aparecen dos veces, en financiamiento ("pagar dividendos") y en
beneficios ("distribuir dividendos"). No es un error: es la misma plata vista como salida de fondos
y como destino del resultado.

## La forma jurídica: la sociedad comercial

> "La Sociedad Comercial es la forma jurídica que la empresa toma para constituirse. Una sociedad comercial existe cuando dos o más personas en forma organizada, conforme a uno de los tipos previstos en la ley, se obligan a realizar aportes para aplicarlos a la producción o intercambio de bienes o servicios, participando de los beneficios y soportando las pérdidas."

| Sigla | Nombre | Rasgo que da el apunte |
|---|---|---|
| **S.A.** | Sociedad Anónima | Capital integrado por **acciones** |
| **S.R.L.** | Sociedad de Responsabilidad Limitada | **Capital social** |
| **S.A.U.** | Sociedad Anónima Unipersonal | Nueva persona jurídica |
| **S.A.S.** | Sociedad por Acciones Simplificada | — |

## Dos marcos que el apunte nombra

- **Ley 25.300 (MIPyMEs)**, art. 1º: tiene por objeto "el fortalecimiento competitivo de las micro,
  pequeñas y medianas empresas (MIPyMEs) que desarrollen actividades productivas en el país (…) con
  la finalidad de alcanzar un desarrollo más integrado, equilibrado, equitativo y eficiente de la
  estructura productiva".
- **RSE (Responsabilidad Social Empresaria)**: "contribución activa y voluntaria de la empresa al
  mejoramiento social y ambiental de la comunidad dónde opera".

## Faltante

El programa dice "Empresas e **integrantes**". El material define la empresa y los tipos societarios
pero **no desarrolla los integrantes** (socios, órganos de gobierno, directorio). Tampoco da los
criterios de la Ley 25.300 para clasificar una empresa como micro, pequeña o mediana.

## Conexiones

- [[Factores de Producción]] — la definición de empresa es literalmente "factores de producción coordinados"
- [[Maximización de Beneficios]] — su objetivo declarado es el que se formaliza en el análisis de mercados
- [[Estructura Financiera de la Empresa]] — la actividad 1 (financiamiento) es el tema entero de esa nota
- [[Sistemas de Información Contable]] — las cuatro actividades son lo que la contabilidad registra
- [[Estados Contables Básicos]] — el flujo de efectivo se organiza en fondos operativos, financieros y de inversión
- [[Costo Económico]] — el beneficio que la empresa maximiza no es el mismo para el contador y el economista

## En el parcial

Es la pregunta de apertura típica y es regalada si la tenés. **Definir empresa con la frase exacta
(factores de producción coordinados / producir bienes y servicios / maximizar el beneficio) y
clasificar una lista de operaciones concretas en las cuatro actividades.** El error clásico es meter
"compra de mercaderías" en inversión: es **operación**, porque la mercadería se vende; inversión son
los **bienes de uso** y las acciones de otras empresas. Y los cuatro tipos societarios con su rasgo
(S.A. = acciones, S.R.L. = capital social).

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

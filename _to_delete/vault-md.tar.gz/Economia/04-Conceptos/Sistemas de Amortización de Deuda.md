---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, finanzas]
---

# Sistemas de Amortización de Deuda

> Tres formas de repartir capital e intereses a lo largo de un préstamo. En los tres el
> interés se calcula **sobre el saldo adeudado**; lo que cambia es cómo se devuelve el
> capital, y de ahí sale todo lo demás.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## El punto de partida

Toda cuota tiene dos componentes:

> "el dinero que devuelves (la cuota) tiene dos componentes: **capital** (la parte del préstamo que estás devolviendo) e **intereses** (el costo que pagas por usar dinero)."

Y la regla común a los tres sistemas, que es la que explica las diferencias:

> "En ambos sistemas, los intereses se aplican sobre el **saldo del capital adeudado**."

## Los tres sistemas

| | **Francés** | **Alemán** | **Americano** |
|---|---|---|---|
| **Cuota total** | Igual todas las cuotas ("consecutivas e iguales") | **Decreciente** | Sólo intereses durante el plazo; el capital al final |
| **Componente capital** | Creciente: al principio poco | **Constante**: siempre el mismo monto | Todo en la última cuota |
| **Componente interés** | Decreciente: al principio mucho | Decreciente | Se paga período a período (o no) |
| **Total de intereses pagados** | **Mayor** | **Menor** | El apunte no lo compara |
| **Cuotas iniciales** | **Menores** que en el alemán | Mayores que en el francés | Las más chicas |
| **Ventaja que señala el apunte** | "Es el sistema más previsible"; contablemente permite mayor devengamiento de intereses en las primeras cuotas | Se paga menos interés total | Sirve cuando los ingresos no son continuos |

Textuales, para citar:

> "En el sistema de amortización **francés** las cuotas (capital + interés) son iguales y consecutivas, pagando al principio mayor proporción de interés que de capital, invirtiéndose los porcentajes a lo largo de la cancelación de la deuda."

> "En el sistema de amortización **alemán** las cuotas (capital + Interés) son decrecientes y consecutivas pagando siempre el mismo monto de capital a cancelar y disminuyendo el monto de interés a lo largo del periodo del crédito."

> "En el sistema de amortización **americano** se paga el capital en una sola cuota al final del periodo. Puede haber pagos intermedios de intereses o no."

## La conclusión que se pregunta

> "en el sistema alemán se abona un total de intereses menor que en el sistema francés. En el sistema francés se pagan cuotas menores al principio, en comparación con el sistema alemán."

O sea: **no hay un sistema mejor, hay un canje.** El francés te alivia el arranque y te cobra
más interés total; el alemán te aprieta al principio y te sale más barato. Y esa comparación
es exactamente la que hace visible el [[Costo Financiero Total]].

## Cuándo se usa el americano

> "Este sistema se suele utilizar por ejemplo para financiar actividades agropecuarias u otras en las que los ingresos no se dan de forma continua. El financiamiento a través de pagarés es otro ejemplo."

Tiene sentido: si tu ingreso llega de golpe con la cosecha, no podés pagar cuotas mensuales de
capital. El sistema se elige **según la forma del [[Flujo de Fondos]]**, no por gusto.

## Faltante

El apunte **no da el cuadro de marcha** de ningún sistema (saldo, interés, capital, cuota
período a período), ni la fórmula de la cuota francesa, ni ejemplos numéricos. Es lo que más
se practica del tema, así que hay que conseguirlo del teórico oficial.

## Conexiones

- [[Anualidades y Perpetuidades]] — la cuota constante del sistema francés es una anualidad
- [[Factores de Equivalencia]] — el FRC es el factor que produce esa cuota constante
- [[Costo Financiero Total]] — el sistema elegido cambia el total de intereses, y eso entra al CFT
- [[Fuentes de Financiamiento]] — cada fuente viene con su sistema de amortización asociado
- [[Flujo de Fondos]] — el sistema se elige según cómo entra la plata: por eso el americano en agro
- [[Estructura Financiera de la Empresa]] — el perfil de vencimientos del pasivo depende del sistema

## En el parcial

**Describir los tres sistemas por cómo se comporta la cuota (francés: constante; alemán:
decreciente; americano: capital al final) y justificar por qué el alemán paga menos intereses
totales** — porque amortiza capital más rápido y el interés se calcula sobre el saldo
adeudado.

El error clásico es decir que en el francés "se paga siempre lo mismo de capital": es al revés,
lo que es constante es la **cuota**; el capital arranca chico y crece. En el **alemán** es el
capital lo que se mantiene constante.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` + `Segundo parcial — sección Ingeniería financiera` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

---
tipo: concepto
materia: Economia
unidad: U6
parcial: 2
estado: pendiente
tags: [Economia, U6, tasas]
---

# Costo Financiero Total

> El CFT es **la tasa real de un préstamo**: la tasa de interés más todos los gastos e
> impuestos asociados. Es la única cifra con la que dos financiamientos se pueden comparar de
> verdad.

**Unidad:** [[U6-Ingenieria-Economica]] · **Materia:** [[Economia]]

## Qué es

Textual:

> "Es la tasa real que incluye la tasa de interés y todos los gastos relacionados al financiamiento."

La [[Tasas Nominales y Tasas Efectivas|TEA]] ya corrige por capitalización, pero sigue mirando
sólo el interés. El CFT agrega todo lo demás que te cobran por tomar la plata.

## Cómo se arma

$$CFT = \frac{\text{Interés} + \text{Gastos de Otorgamiento} + \text{Impuesto a los Sellos} + \text{IVA} + \text{Otros gastos}}{\text{Monto del préstamo}}$$

- **Numerador** — todo lo que efectivamente desembolsás por encima del capital, en **pesos**
- **Monto del préstamo** — el capital recibido, en **pesos**
- **CFT** — resultado en **tanto por uno**; por 100 queda el porcentaje

El apunte lo describe como procedimiento: "A esa suma se la divide por el monto del préstamo y
se obtiene el CFT."

| Componente | Qué es |
|---|---|
| Tasa de interés | El precio del dinero propiamente dicho |
| Gastos de otorgamiento | Lo que cobra la entidad por armar la operación |
| Impuesto a los sellos | Impuesto sobre el instrumento del préstamo |
| IVA | Ver [[Impuestos: Ganancias e IVA]] |
| Otros gastos asociados | Seguros, comisiones, todo lo que el contrato agregue |

## Para qué sirve

> "Permite comparar mejor alternativas de financiamiento. Expresa el verdadero costo del préstamo."

Ésa es la utilidad y también el criterio: entre dos ofertas, **gana la de menor CFT**, aunque
tenga la tasa de pizarrón más alta. Es perfectamente posible que un préstamo con TNA baja
termine siendo más caro por gastos de otorgamiento.

## Faltante

El apunte **no da un ejemplo numérico** de cálculo de CFT, ni aclara si el CFT se expresa
anualizado, ni cómo se trata el caso de gastos que se cobran período a período en lugar de una
sola vez al inicio.

## Conexiones

- [[Tasas Nominales y Tasas Efectivas]] — el CFT es el escalón que sigue: la TEA no incluye gastos ni impuestos
- [[Fuentes de Financiamiento]] — es el número con el que se comparan las distintas fuentes entre sí
- [[Impuestos: Ganancias e IVA]] — el IVA es uno de los componentes que engorda el CFT
- [[Estructura Financiera de la Empresa]] — el costo del pasivo de la empresa se mide con CFT, no con la tasa nominal
- [[Sistemas de Amortización de Deuda]] — el sistema elegido cambia el total de intereses y por lo tanto el CFT

## En el parcial

**Definir el CFT y decir por qué es la cifra correcta para elegir entre dos préstamos, en
lugar de la TNA o la TEA.** Si el ejercicio te da tasa + gastos + sellos + IVA, armá el
numerador con todo eso, dividilo por el monto del préstamo y comparás.

El error típico es elegir por TNA baja: **una TNA menor con gastos de otorgamiento altos puede
dar un CFT mayor**. Lo que se compara siempre es el CFT.

---
Fuente: `Unidad 6 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

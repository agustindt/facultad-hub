---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos]
---

# Proyecto de Inversión

> Una **propuesta de usar recursos hoy, sacrificando consumo presente, para conseguir
> beneficios futuros**. Y como todo se traduce en ingresos y egresos de fondos, la
> conveniencia se decide con números, no con intuición.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## La definición

Textual:

> "Propuesta de utilizar recursos, sacrificando consumos hoy, para el logro de beneficios en el futuro. En un proyecto de inversión hay **INGRESOS Y EGRESOS DE FONDOS** por los cuales determinaremos la conveniencia o no de llevarlos a cabo."

Las dos mitades importan: el **sacrificio hoy** (por eso hay una tasa que exigirle) y los
**fondos** (por eso todo termina en un [[Flujo de Fondos]], no en un resultado contable).

## Las dos grandes etapas del estudio de proyectos

| Etapa | Qué hace | Con qué termina |
|---|---|---|
| **Formulación** | Definir todas las características que tengan algún grado de efecto en el flujo de ingresos y egresos, y calcular su magnitud. Genera alternativas | El flujo de fondos armado |
| **Evaluación** | Determinar la rentabilidad de la inversión y comparar alternativas | La decisión: se hace o no |

```mermaid
flowchart LR
    A["<b>FORMULACIÓN</b><br/>definir lo que afecta al flujo<br/>y medir su magnitud"] --> B["Estudio de mercado<br/>demanda, oferta, precios"]
    A --> C["Estudio técnico<br/>tecnología, tamaño, localización"]
    A --> D["Estudio de costos<br/>inversiones y operación"]
    B --> E["<b>FLUJO DE FONDOS</b>"]
    C --> E
    D --> E
    E --> F["<b>EVALUACIÓN</b><br/>rentabilidad · comparar alternativas"]
    style A fill:#4DB6AC,color:#fff
    style E fill:#FFA726,color:#fff
    style F fill:#7C5CFF,color:#fff
```

La evaluación se abre en dos factibilidades que **no son lo mismo**:

- **Factibilidad económica**: la inversión debe ser rentable — ingresos del proyecto mayores
  que egresos del proyecto.
- **Factibilidad financiera**: debe existir **disponibilidad de recursos**.

Un proyecto rentable que no tiene con qué financiarse no se hace. Es el error de lectura más
fácil de cometer.

## Lo que mira el análisis de la oferta

Dentro del estudio de mercado, el apunte lista: **tipo de mercado** (competencia, oligopolio,
monopolio), **mercado de factores de producción**, y **otros productos, calidad, servicios y
precio**.

## Conexiones

- [[Ciclo de Vida del Proyecto]] — el orden en que se van haciendo estos estudios, de menos a más profundidad
- [[Flujo de Fondos]] — el producto concreto de la formulación y el insumo de la evaluación
- [[Valor Actual Neto]] — el indicador con el que se resuelve la factibilidad económica
- [[Comparación de Alternativas]] — la evaluación es, literalmente, comparar alternativas entre sí
- [[Clasificación de Mercados]] — el análisis de la oferta arranca preguntando en qué tipo de mercado se va a vender
- [[Estructura Financiera de la Empresa]] — la factibilidad financiera depende de con qué recursos cuenta la empresa

## En el parcial

Definir proyecto de inversión con la frase del apunte (recursos hoy → beneficios futuros) y
**separar formulación de evaluación**: qué produce cada una y en qué orden van. La pregunta
con trampa es la diferencia entre **factibilidad económica y financiera**: económica = ser
rentable; financiera = tener los recursos disponibles. Un proyecto puede aprobar una y
reprobar la otra.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

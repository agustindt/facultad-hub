---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos]
---

# Escasez

> Disparidad entre los deseos humanos y los medios disponibles para satisfacerlos: las
> necesidades son ilimitadas y los recursos, limitados.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

Es **el** axioma de la economía. No es una observación sobre países pobres: es una condición
estructural que vale para cualquier sociedad, por rica que sea, porque los deseos se expanden
más rápido que la capacidad de satisfacerlos.

Definición textual de la cátedra:

> "ESCASEZ → Disparidad entre deseos humanos y medios disponibles para satisfacerlos. Para satisfacer las ilimitadas necesidades los recursos son limitados."

Lo importante no es la definición sino **lo que se desprende de ella**:

| Porque hay escasez… | …aparece |
|---|---|
| hay que elegir | la decisión económica |
| elegir es renunciar | el [[Costo de Oportunidad]] |
| hay un límite a lo que se puede producir | la [[Frontera de Posibilidades de Producción]] |
| hay que decidir qué, cómo y para quién | el [[Problema Económico de Toda Sociedad]] |

Si la escasez desapareciera, la economía como disciplina no tendría objeto: todo el mundo
tomaría todo lo que quisiera y no habría nada que asignar.

## El detalle que se pasa por alto

Escasez **no** es lo mismo que "poco". Un bien es escaso si a precio cero la gente querría más
del que hay. El aire no es escaso; el agua potable sí. La escasez es una **relación** entre
deseos y disponibilidad, no una cantidad absoluta.

## Conexiones

- [[Costo de Oportunidad]] — es la medida de la escasez: cuánto cuesta, en unidades de otra cosa, lo que elegís
- [[Frontera de Posibilidades de Producción]] — la representación gráfica de la escasez: la curva **es** el límite
- [[Problema Económico de Toda Sociedad]] — las tres preguntas existen únicamente porque hay escasez
- [[Factores de Producción]] — los recursos limitados son concretamente estos: capital, trabajo y recursos naturales
- [[Sistemas de Organización Económica]] — las tres formas que inventaron las sociedades para resolver la escasez

## En el parcial

Definición textual + explicar que es la razón de ser de la economía. Se pregunta encadenada
con costo de oportunidad, casi nunca sola.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

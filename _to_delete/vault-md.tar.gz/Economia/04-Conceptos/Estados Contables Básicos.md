---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, contabilidad]
---

# Estados Contables Básicos

> Son **cuatro informes y cuatro ecuaciones**. Dos son fotos de un momento y dos son películas de
> un período. Si te sabés las cuatro ecuaciones, te sabés la mitad del bloque contable.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Los cuatro estados

| Estado | Qué muestra | Foto o película |
|---|---|---|
| **Situación patrimonial** (Balance General) | "Foto instantánea de la situación financiera de una entidad en un punto dado del tiempo" | Foto |
| **Resultados** | "Presenta el desarrollo de las operaciones en un periodo dado de tiempo" | Película |
| **Evolución del patrimonio** | "Resume las distintas componentes del patrimonio neto y sus cambios" | Película |
| **Flujo de efectivo** | "Vincular el beneficio contable con los movimientos de entradas y salidas de dinero" | Película |

$$\text{Activo} = \text{Pasivo} + \text{Patrimonio Neto}$$

$$\text{Beneficio} = \text{Ingresos} - \text{Costos} - \text{Gastos} = P \times Q - CU \times Q - \text{Otros gastos}$$

$$\text{Saldo final} = \text{Saldo inicial} + \text{Beneficio del período} - \text{Dividendos} + \text{Nuevos aportes}$$

$$\text{Caja final} = \text{Caja inicial} + \text{Fondos Generados} - \text{Fondos Usados}$$

En el flujo de efectivo, los fondos generados y los usados se abren en **operativos + financieros
+ de inversión** — las mismas categorías de [[La Empresa y sus Actividades]].

**Ojo: el apunte se contradice en una ecuación.** El estado de evolución del patrimonio aparece
dos veces con signos distintos; la segunda vez pone un `–` delante del beneficio del período. Es
un error de tipeo: la primera versión y el otro apunte coinciden en que **el beneficio SUMA**.

## Las tres partidas del balance

| Partida | Definición | Corte a un año |
|---|---|---|
| **Activo** | "Conjunto de bienes y derechos que pertenecen a la empresa, con la característica común de que se utilizan en la generación de ingresos" | **No corriente:** permanecen **más** de un año · **Corriente:** **menos** de un año |
| **Pasivo** | "Conjunto de obligaciones y deudas que la empresa tiene con terceros" | **No corriente:** vencimiento **superior** a un año · **Corriente:** **menor** a un año |
| **Patrimonio neto** | "Inversión neta de los propietarios en la empresa, compuesta por el capital invertido, los aportes irrevocables, las reservas y los resultados no distribuidos" | — |

$$A = P + PN \qquad A = AC + ANC \qquad P = PC + PNC \qquad PN = A - P$$

**El criterio de corte es siempre el año**, y es la única variable: no importa qué sea el bien,
importa cuánto tiempo se espera que se quede.

## Las dos lecturas del mismo balance

Es la bisagra con [[Estructura Financiera de la Empresa]]:

> "La adquisición de los bienes que conforman el ACTIVO de la empresa (**estructura económica**), obliga a disponer de RECURSOS FINANCIEROS, que constituyen la fuente de financiamiento de la empresa (**estructura financiera**)."

```mermaid
flowchart LR
    A["<b>ACTIVO</b><br/>ESTRUCTURA ECONÓMICA<br/>en qué está puesta la plata"] --- E["="]
    E --- P["<b>PASIVO</b><br/>ESTRUCTURA FINANCIERA<br/>deuda con terceros"]
    E --- PN["<b>PATRIMONIO NETO</b><br/>ESTRUCTURA FINANCIERA<br/>lo puesto por los dueños"]
    style A fill:#4DB6AC,color:#fff
    style E fill:#7C5CFF,color:#fff
    style P fill:#FFA726,color:#fff
    style PN fill:#FFA726,color:#fff
```

Un lado dice **en qué** está la plata; el otro, **de dónde** salió. Por eso siempre suman igual.

## Faltante

El programa pide "Balances" y "Cuenta de pérdidas y ganancias" como temas propios. El material da
las **ecuaciones** pero **no un modelo de formato ni un ejemplo numérico**: no hay un balance armado
ni un estado de resultados con sus escalones (utilidad bruta → operativa → antes de impuestos →
neta). Si el parcial pide armar uno, esto no alcanza.

## Conexiones

- [[Sistemas de Información Contable]] — son el producto de la contabilidad general
- [[Estructura Financiera de la Empresa]] — el lado derecho de este balance, leído como fuentes de fondos
- [[Ratios e Indicadores de Performance]] — todos los ratios son cocientes entre partidas de estos estados
- [[Valuación de Activos]] — según el método cambia el valor del inventario, y con él el activo y el resultado
- [[Depreciación]] — es lo que hace bajar el activo fijo período tras período
- [[Costeo por Absorción]] — define qué costos quedan **inventariados** en el activo y cuáles bajan como CMV

## En el parcial

**Escribir las cuatro ecuaciones fundamentales de memoria y clasificar partidas** en activo / pasivo
/ PN y en corriente / no corriente. El error clásico es clasificar por naturaleza del bien en vez de
por **plazo**: un rodado que se vende en tres meses es activo corriente, y un plazo fijo a 18 meses
es **no** corriente. Otro clásico: confundir el estado de resultados (período) con el de situación
patrimonial (momento) — si dice "al 31/12" es foto; si dice "del ejercicio 2025", es película.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

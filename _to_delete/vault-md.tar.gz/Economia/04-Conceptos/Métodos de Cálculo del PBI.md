---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, contabilidad-nacional]
---

# Métodos de Cálculo del PBI

> Tres caminos —**gasto, ingreso y valor agregado**— que tienen que dar el mismo número, porque
> lo que se produce, se gasta y se cobra son la misma cosa mirada desde tres lugares.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## La igualdad que justifica los tres métodos

Es la frase más citable de la unidad y la que explica por qué hay tres métodos y no tres números:

> "El PIB (la producción total de una economía) es igual a los ingresos generados en esa economía. Los términos 'producción' e 'ingreso' (o renta) se utilizan como si fueran sinónimos (de hecho, lo son). Si aumenta la producción, los ingresos aumentan en la misma cuantía; si la producción cae, los ingresos caen en la misma cuantía."

```mermaid
flowchart LR
    G["<b>MÉTODO DEL GASTO</b><br/>quién compra la producción"] --> P["<b>PBI</b><br/>un único número"]
    I["<b>MÉTODO DEL INGRESO</b><br/>quién cobra por producirla"] --> P
    V["<b>MÉTODO DEL VALOR AGREGADO</b><br/>cuánto añade cada etapa"] --> P
    style G fill:#4DB6AC,color:#fff
    style I fill:#FFA726,color:#fff
    style V fill:#4DB6AC,color:#fff
    style P fill:#7C5CFF,color:#fff
```

## 1. Método del gasto

Se suman las demandas (gastos) finales de bienes y servicios del período, es decir el valor de lo
adquirido por cada tipo de usuario final:

$$PBI_{pm} = C + G + I_B + (X - M)$$

| Término | Quién gasta | Qué es |
|---|---|---|
| $C$ | Las familias | Consumo privado |
| $G$ | El Estado | Gasto público, o consumo público |
| $I_B$ | Las empresas | Inversión bruta interna (incluye la depreciación) |
| $X$ | El resto del mundo | Exportaciones: producción local que se vende afuera |
| $-M$ | — | Las importaciones **restan**: son gasto local sobre bienes que no se produjeron acá |

Que la $M$ vaya restando no es un capricho: está sumada dentro de $C$, $G$ e $I_B$ (una familia
que compra un televisor importado gasta, pero eso no es producción del país), así que hay que
sacarla para que quede sólo lo producido dentro de las fronteras.

## 2. Método del ingreso (o del costo de los factores)

Se suman todos los ingresos que contribuyen al proceso productivo: "la suma del costo de los
factores adquiridos por todas las empresas", que es lo mismo que las rentas percibidas por las
economías domésticas por aportar sus factores.

| Enfoque del producto o gasto | Enfoque de los costos o ingresos |
|---|---|
| Consumo (C) | Sueldos, salarios y otros ingresos del trabajo |
| Inversión bruta privada (IB) | Intereses, alquileres y otros ingresos de la propiedad |
| Gasto público (G) | Impuestos indirectos |
| Exportaciones netas | Depreciación o amortización |
| | Beneficios |

Ojo con las dos últimas filas de la derecha: **impuestos indirectos y depreciación no son
retribución a ningún factor**, pero están adentro del precio de mercado. Por eso aparecen en la
columna del ingreso y por eso hacen falta las ecuaciones puente de
[[Ingreso Nacional e Ingreso Disponible]].

## 3. Método del valor agregado

$$VA = Precio\ de\ venta - Costo\ de\ los\ bienes\ intermedios$$

$$PBI_{pm} = \sum_i VA_i = \sum_i (VBP_i - Compras\ de\ insumos_i)$$

El precio de venta se toma **sin los impuestos indirectos**, y los valores usados son los de
mercado de productos e insumos. Cada etapa suma sólo lo que añade por encima de lo que compró;
por eso el método se apoya en los sectores productivos (ver
[[Matriz Insumo-Producto]] para la herramienta que ordena esos flujos entre sectores).

## Conexiones

- [[Producto Bruto Interno]] — el número que los tres métodos calculan
- [[Ingreso Nacional e Ingreso Disponible]] — el método del ingreso desemboca directo ahí
- [[Demanda y Oferta Agregada]] — la fórmula del gasto es, término por término, la demanda agregada
- [[Matriz Insumo-Producto]] — el instrumento sectorial del método del valor agregado
- [[Flujo Circular del Ingreso]] — la representación de por qué producción, gasto e ingreso coinciden
- [[Depreciación]] — aparece como componente del ingreso y es lo que hace "bruto" al producto

## En el parcial

Es el ejercicio numérico más probable de la unidad. **Te dan una lista de componentes y hay que
armar el PBI por el método del gasto: sumar C, G e inversión bruta, sumar exportaciones y restar
importaciones.** El error clásico es sumar las importaciones o "olvidarlas" porque están escondidas
en el consumo. La otra variante es una tabla de sectores con valor bruto de producción y compras
de insumos: ahí se resta insumo por insumo y recién después se suma. Y saber decir en una línea
por qué los tres métodos dan igual.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` y del `MACROECONOMIA — manuscrito iPad, nov 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

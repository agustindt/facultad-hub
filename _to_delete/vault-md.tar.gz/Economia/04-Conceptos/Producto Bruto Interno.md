---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, contabilidad-nacional]
---

# Producto Bruto Interno

> El PBI mide el **valor de mercado de todos los bienes y servicios finales** producidos dentro
> de un país en un período, normalmente un año. Es el indicador más amplio de la producción
> total de una economía.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Dónde vive el PBI

El PBI es el resultado estrella de la **contabilidad nacional**, que

> "mide la actividad de una economía a lo largo de un periodo, generalmente un año, registrando las transacciones realizadas entre los diferentes agentes que forman parte de dicha economía."

Cada palabra de la definición del PBI hace un trabajo: *valor de mercado* (se valúa a precios,
no en unidades físicas), *finales* (no cualquier bien), *dentro de un país* (territorio, no
nacionalidad), *período* (es un flujo, no un stock).

Para qué se usa, según el material: medir el tamaño de una economía, comparar, analizar el
crecimiento, tomar decisiones y diseñar políticas.

$$PBI\ per\ cápita = \frac{PBI\ real}{Población}$$

## Cómo leer la sigla: tres ejes independientes

Acá se pierden más puntos que en ningún otro lado de la unidad. "PBIpm" no es un nombre: son
tres decisiones apiladas, y cada una tiene su ecuación puente.

| Eje | Los dos valores | La ecuación que los une |
|---|---|---|
| Bruto / Neto | ¿Se descuenta el desgaste del capital? | $Neto = Bruto - Depreciaciones$ |
| Interno / Nacional | ¿Territorio o residentes? | $Nacional = Interno + Saldo\ de\ remesas$ |
| Precios de mercado / Costo de factores | ¿Con o sin impuestos indirectos? | $P_{mercado} = C_{factores} + Imp.Ind. - Subsidios$ |

- **Interno**: "es el producto de la actividad que se desarrolla dentro de un país, sin importar
  si los individuos o empresas que lo hacen son del país o foráneos."
- **Nacional**: "es el producto de la actividad que desarrollan habitantes de un país, ya sea que
  residan en el mismo o fuera de las fronteras." La remesa es el envío de dinero entre dos
  lugares geográficos distintos.
- **Bruto vs. neto**: la depreciación (o amortización) es la parte del gasto en capital que
  repone el capital desgastado en el período; la inversión neta es la que crea capital nuevo.
  De ahí que $Inversión\ Bruta = Inversión\ Neta + Depreciación$.

```mermaid
flowchart TD
    S["<b>PBI pm</b><br/>bruto, interno,<br/>a precios de mercado"] --> E1["<b>Eje 1 — bruto o neto</b><br/>Neto = Bruto &minus; depreciaciones"]
    S --> E2["<b>Eje 2 — interno o nacional</b><br/>Nacional = Interno + saldo de remesas"]
    S --> E3["<b>Eje 3 — pm o cf</b><br/>Pm = cf + imp. indirectos &minus; subsidios"]
    E1 --> R["<b>Cada combinación<br/>tiene su sigla</b><br/>PNNcf es la de los tres<br/>cambios aplicados"]
    E2 --> R
    E3 --> R
    style S fill:#4DB6AC,color:#fff
    style R fill:#7C5CFF,color:#fff
    style E1 fill:#FFA726,color:#fff
    style E2 fill:#FFA726,color:#fff
    style E3 fill:#FFA726,color:#fff
```

## Las tres variantes con nombre propio

| Variante | Qué es |
|---|---|
| PBI nominal | Medido a precios corrientes de mercado — ver [[PBI Nominal y PBI Real]] |
| PBI real | A precios constantes; es un índice de la cantidad de bienes y servicios producidos |
| PBI potencial | El máximo nivel de producción manteniendo estables los precios, con los factores a pleno empleo — ver [[Producción Potencial y Brecha]] |

## Conexiones

- [[Métodos de Cálculo del PBI]] — los tres caminos para llegar al mismo número
- [[PBI Nominal y PBI Real]] — la distinción sin la cual el PBI no dice nada sobre crecimiento
- [[Ingreso Nacional e Ingreso Disponible]] — el mismo flujo visto como retribución a los factores
- [[Producción Potencial y Brecha]] — el techo contra el que se compara el PBI efectivo
- [[Objeto de la Macroeconomía]] — el PBI es el indicador del primero de los objetivos macro
- [[Depreciación]] — lo que separa el bruto del neto es exactamente lo que en U5 se contabiliza como amortización

## En el parcial

**Definir el PBI con las cuatro precisiones (valor de mercado, bienes y servicios finales, dentro
del país, en un período) y saber convertir entre siglas.** Te dan, por ejemplo, PBIpm,
depreciaciones, impuestos indirectos netos y saldo de remesas, y piden el PNNcf: aplicá las tres
ecuaciones puente **una por vez** y anotá qué eje estás moviendo en cada paso. El error clásico
es mover dos ejes juntos y perder los subsidios en el camino.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes de `SEGUNDO PARCIAL — sección Macroeconomía` y del `MACROECONOMIA — manuscrito iPad, nov 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

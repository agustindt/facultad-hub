---
tipo: concepto
materia: Economia
unidad: U4
parcial: 2
estado: pendiente
tags: [Economia, U4, politicas]
---

# Política Monetaria

> El Banco Central controla la **cantidad de dinero, el crédito y la tasa de interés**, y con eso
> mueve el gasto de los sectores sensibles a la tasa. Objetivo último: estabilidad de precios y del
> tipo de cambio.

**Unidad:** [[U4-Macroeconomia]] · **Materia:** [[Economia]]

## Qué es

> "LA POLÍTICA MONETARIA es el proceso por el cual la autoridad monetaria de un país controla la evolución de la cantidad de dinero, el crédito y, en general, el funcionamiento del sistema financiero."

La cadena de transmisión, textual y en orden — hay que poder recitarla:

> "A través del control de la oferta monetaria por parte del Banco Central y su capacidad de incidir sobre las tasas de interés y las condiciones crediticias, afecta el gasto de los sectores de la economía que son sensibles a las tasas de interés, como la **inversión empresarial, el consumo y las exportaciones netas**. De esta forma, la política monetaria influye tanto en el PIB, así como en los precios."

Y el objetivo:

> "El objetivo fundamental de cualquier banco central es mantener la estabilidad de los precios y del tipo de cambio."

Fijate qué sectores nombra: inversión, consumo y exportaciones netas. Son tres de los cuatro
componentes de la [[Demanda y Oferta Agregada]] — el único que no toca es el gasto público, que es
justamente el de la [[Política Fiscal]].

## Los tres instrumentos, en las dos direcciones

| | Expansiva | Restrictiva |
|---|---|---|
| Qué hace con la oferta monetaria | La **aumenta** | La **disminuye** |
| Préstamos a los bancos | Prestar mayor cantidad | Prestar menor cantidad |
| Tipo de interés | Bajarlo | Subirlo |
| Coeficiente de caja | Disminuirlo | Aumentarlo |

**Consecuencias de la expansiva**, encadenadas:

1. El sistema bancario dispone de abundante dinero barato y lo presta en condiciones similares a las familias.
2. Baja el volumen de intereses a pagar y aumenta la renta disponible de las familias para consumir y de las empresas para invertir.
3. Al aumentar la demanda agregada, suben también la producción y el empleo.
4. Los precios no deberían subir **siempre que** las empresas sean capaces de producir todo lo que se demanda. Si eso no ocurre, hay inflación.

**Consecuencias de la restrictiva**:

1. Se incrementa el volumen de intereses a pagar, o se hace más difícil acceder a nuevos préstamos por la subida del precio del dinero.
2. Las familias consumen menos y hay menos inversiones empresariales que compensen un pago alto de intereses.
3. Desciende la demanda agregada y con ella la producción y el empleo.
4. Ante la falta de demanda, los precios se estancan e incluso pueden bajar.

```mermaid
flowchart LR
    I["<b>EXPANSIVA</b><br/>&uarr; oferta monetaria<br/>&darr; tasa &middot; &darr; coef. de caja"] --> C["Crédito barato<br/>y abundante"]
    C --> G["&uarr; consumo e inversión"]
    G --> D["&uarr; Demanda agregada"]
    D --> P["&uarr; producción y empleo<br/>e inflación si la oferta<br/>no acompaña"]
    style I fill:#4DB6AC,color:#fff
    style D fill:#FFA726,color:#fff
    style P fill:#7C5CFF,color:#fff
```

El punto 4 de la expansiva es la clave de toda la unidad: **si la economía puede producir más, la
política expansiva da producción; si no puede, da inflación.** Ese "si puede" es el producto
potencial de [[Producción Potencial y Brecha]].

## Fiscal y monetaria, comparadas

| | Política fiscal | Política monetaria |
|---|---|---|
| Quién la ejecuta | El Gobierno | La autoridad monetaria: el Banco Central |
| Instrumentos | Gasto público e impuestos | Cantidad de dinero y tasas de interés |
| Sobre qué actúa | Ingresos, consumo e incentivos a invertir | Sectores sensibles a la tasa de interés |
| Objetivo declarado | Incidir en el crecimiento económico | Estabilidad de precios y del tipo de cambio |

## Conexiones

- [[El Dinero y los Intermediarios Financieros]] — el coeficiente de caja y el multiplicador son el mecanismo sobre el que opera
- [[Política Fiscal]] — la otra política de demanda; misma dirección, distintos instrumentos y distinto ejecutor
- [[Demanda y Oferta Agregada]] — el canal por el que llega al producto y a los precios
- [[Inflación]] — el objetivo declarado del Banco Central es evitarla
- [[Balanza de Pagos y Mercado de Divisas]] — la estabilidad del tipo de cambio es el otro objetivo del BC
- [[Tasas Nominales y Tasas Efectivas]] — la tasa de interés que acá es instrumento macro, en U6 es la variable de cálculo

## En el parcial

**Dado un objetivo ("bajar la inflación", "reactivar la economía"), elegir la dirección de la
política y nombrar los tres instrumentos con su signo, encadenando los efectos hasta producción y
empleo.** La trampa favorita es el coeficiente de caja: **disminuirlo es expansivo**, aunque el
verbo suene a menos. La otra pregunta segura es la comparación con la política fiscal: quién la
ejecuta, con qué instrumentos y sobre qué gasto actúa.

---
Fuente: `UNIDAD 4 — Valentina, feb 2025`, con aportes del `MACROECONOMIA — manuscrito iPad, nov 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

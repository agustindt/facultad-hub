---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, contabilidad]
---

# Valuación de Activos

> Cuando la misma materia prima entró al depósito a **precios distintos**, hay que decidir a qué
> precio se valúa lo que se consume. Tres métodos: **PEPS, UEPS y PPP**. Y lo que decide uno,
> decide automáticamente el otro lado: el valor del stock que queda.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## El problema

Textual: *"Para calcular el costo de la materia prima que consumimos existen 3 métodos."* Ojo
con esto: **no es un problema de conteo físico, es un problema de precios.** Las unidades que
salieron son las que son; lo que está en discusión es a qué valor se las carga al costo.

## Los tres métodos

| Método | Nombre completo | El **consumo** se valúa a… | …y lo que **queda** en stock, a… |
|---|---|---|---|
| **P.E.P.S.** | Primero Entrado – Primero Salido | Precio de las **primeras** que entraron | Precio de las **últimas** que ingresaron |
| **U.E.P.S.** | Último Entrado – Primero Salido | Precio de las **últimas** que entraron | Precio de las **primeras** que ingresaron |
| **P.P.P.** | Precio Promedio Ponderado | Un **promedio** del precio al que fueron ingresando | Ese mismo promedio |

Sobre el PPP, el detalle que lo hace distinto de los otros dos: *"se irá realizando un promedio
del precio en el que fueron ingresando las mercaderías y se irán descontando a ese valor las que
se consuman. **Las nuevas que ingresen a diferente precio irán modificando el promedio.**"* O
sea: el promedio **se recalcula** con cada entrada nueva, no se calcula una sola vez al final.

## La simetría que hay que ver

Los tres métodos reparten **la misma plata total** entre dos destinos: el costo del período y el
stock final. Si un método manda más al costo, manda menos al stock, y viceversa. Por eso PEPS y
UEPS son espejos exactos: lo que uno pone en el consumo, el otro lo pone en el inventario.

Y por eso este tema toca dos estados a la vez: el consumo va al costo de mercadería vendida en
el **estado de resultados** y el remanente queda en el **activo** del balance —
[[Estados Contables Básicos]].

## Faltante

Tres huecos que conviene tener anotados:

1. **No hay ejemplo numérico** en el material. Ninguna tabla de entradas y salidas resuelta.
2. **No dice qué método admite la normativa argentina** ni si alguno está prohibido.
3. **No dice qué efecto tiene cada método sobre el resultado cuando los precios suben.** Es la
   pregunta obvia en un contexto inflacionario y el apunte no la contesta — no la completes de
   memoria sin verificarla contra el teórico.

## Conexiones

- [[Contabilidad de Costos]] — el valor de la materia prima consumida es el primer elemento del costo del producto
- [[Estados Contables Básicos]] — el método elegido parte la misma plata entre el activo (stock) y el resultado (CMV)
- [[Costeo por Absorción]] — para inventariar un costo primero hay que saber a qué valor, y ese valor sale de acá
- [[Depreciación]] — es el otro gran problema de valuación, pero de los activos **fijos** en lugar de los circulantes
- [[Sistemas de Información Contable]] — la elección de método es una política contable, y la auditoría verifica que se aplique de forma consistente

## En el parcial

**Dado un cuadro de entradas de mercadería a precios distintos y un consumo, valuar ese consumo
y el stock final por los tres métodos.** Es mecánico: identificá primero cuántas unidades salen,
después decidí de qué "capa" de precios salen según el método. Los dos errores caros: (1) en PPP,
promediar todos los precios al final en vez de recalcular el promedio con cada ingreso; (2)
olvidar valuar el **stock remanente** — la consigna casi siempre pide las dos cosas, y son las
dos mitades de la misma plata.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

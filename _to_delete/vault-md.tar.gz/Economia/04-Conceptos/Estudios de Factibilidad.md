---
tipo: concepto
materia: Economia
unidad: U7
parcial: 2
estado: pendiente
tags: [Economia, U7, proyectos]
---

# Estudios de Factibilidad

> Un proyecto es **viable** sólo si aprueba **seis** exámenes distintos: comercial, técnico,
> legal, ambiental, económico y financiero. Que sea rentable es apenas uno de los seis.

**Unidad:** [[U7-Proyectos-de-Inversion]] · **Materia:** [[Economia]]

## Prefactibilidad vs. factibilidad

| | **Prefactibilidad** | **Factibilidad** |
|---|---|---|
| Fuentes | Principalmente **secundarias** | Mayoritariamente **primarias** |
| Precisión | Define las variables principales "con cierta aproximación" | Antecedentes **precisos** |
| Variables cualitativas | Todavía pesan | **Mínimas** respecto de los estudios anteriores |
| Qué define | Mercado, alternativas técnicas de producción, capacidad financiera de los inversionistas, entre otras | El cálculo de las variables financieras y económicas, lo bastante demostrativo para justificar la valoración de cada ítem |

La palabra que resume la diferencia es **fuente**: secundaria contra primaria. Todo lo demás
(precisión, peso de lo cualitativo, costo del estudio) se sigue de ahí.

## Las seis viabilidades

Que el proyecto sea "viable" implica serlo en estos aspectos:

| Aspecto | Qué exige, según el apunte |
|---|---|
| Viabilidad **comercial** | Sólo la enumera |
| Viabilidad **técnica** | Sólo la enumera |
| Viabilidad **legal** | Sólo la enumera |
| Viabilidad **ambiental** | Sólo la enumera |
| Factibilidad **económica** | La inversión debe ser rentable |
| Factibilidad **financiera** | Debe existir disponibilidad de recursos |

De las seis, el apunte sólo desarrolla las dos últimas, y con una distinción que hay que tener
afilada:

- **Económica**: la inversión debe ser **rentable** — ingresos del proyecto mayores que egresos
  del proyecto.
- **Financiera**: debe existir **disponibilidad de recursos**.

Son independientes. Un proyecto rentable sin financiamiento no se ejecuta, y plata disponible
para un proyecto que pierde tampoco sirve.

## Faltante

El apunte **enumera** las viabilidades comercial, técnica, legal y ambiental pero **no las
define ni dice qué se analiza en cada una**. Tampoco indica en qué etapa del ciclo se verifica
cada una. Verificar cuando se publique el teórico de la unidad.

## Conexiones

- [[Ciclo de Vida del Proyecto]] — prefactibilidad y factibilidad son dos de sus tres etapas de estudio
- [[Proyecto de Inversión]] — la evaluación es la que resuelve las factibilidades económica y financiera
- [[Fuentes de Financiamiento]] — la factibilidad financiera se contesta mirando de dónde sale la plata
- [[Valor Actual Neto]] — es la herramienta con la que se responde la factibilidad económica
- [[Erogaciones Relevantes]] — los costos de un proyecto de cambio se calculan a nivel factibilidad

## En el parcial

**Distinguir prefactibilidad de factibilidad por el tipo de fuente** (secundaria vs. primaria) y
**enumerar las seis viabilidades**. La pregunta que separa el 4 del 8 es la diferencia entre
factibilidad económica y financiera: rentabilidad contra disponibilidad de recursos. Si te dan
un caso con VAN positivo y sin acceso al crédito, la respuesta es que es económicamente factible
pero financieramente inviable.

---
Fuente: `UNIDAD 7 final — Valentina, feb 2025` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

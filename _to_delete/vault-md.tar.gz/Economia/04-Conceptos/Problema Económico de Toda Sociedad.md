---
tipo: concepto
materia: Economia
unidad: U1
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U1, fundamentos]
---

# Problema Económico de Toda Sociedad

> Las tres preguntas que cualquier sociedad, sea cual sea su organización, está obligada a
> contestar: **qué producir**, **cómo producir** y **para quién producir**.

**Unidad:** [[U1-Introduccion-a-la-Economia]] · **Materia:** [[Economia]]

## Desarrollo

No son tres preguntas cualesquiera: son *las* tres, y cada una tiene un **carácter** distinto.
Ese apareo pregunta ↔ carácter se toma tal cual en el parcial.

| Pregunta | Qué decide | Carácter |
|---|---|---|
| **¿Qué producir?** | Qué bienes y servicios, en qué cantidad. Qué necesidades satisfacer | **Económico** |
| **¿Cómo producir?** | Qué tecnología, materiales y mano de obra emplear | **Técnico** |
| **¿Para quién producir?** | Quiénes son los destinatarios. Cómo se distribuye | **Social** |

```mermaid
flowchart TD
    E["<b>ESCASEZ</b>"] --> P["El problema económico"]
    P --> Q1["¿QUÉ producir?<br/><i>carácter económico</i>"]
    P --> Q2["¿CÓMO producir?<br/><i>carácter técnico</i>"]
    P --> Q3["¿PARA QUIÉN producir?<br/><i>carácter social</i>"]
    Q1 --> S["Se contestan con un<br/><b>sistema económico</b>"]
    Q2 --> S
    Q3 --> S
    style E fill:#FFA726,color:#fff
    style P fill:#7C5CFF,color:#fff
    style S fill:#4DB6AC,color:#fff
```

## Por qué el "cómo" es la pregunta del ingeniero

De las tres, la segunda es la que va a ocupar tu vida profesional: elegir tecnología,
materiales y combinación de factores. Toda la U2 —
[[Función de Producción]], [[Isocuanta]], [[Eficiencia Económica en Tecnología]] — es el
desarrollo formal de "¿cómo producir?".

La tercera, en cambio, no tiene respuesta técnica: es una decisión de distribución, y por eso
la cátedra la marca como de carácter **social**.

## Conexiones

- [[Escasez]] — las tres preguntas existen solo porque los recursos no alcanzan para todo
- [[Sistemas de Organización Económica]] — son las tres formas de contestar estas tres preguntas
- [[Frontera de Posibilidades de Producción]] — elegir un punto de la FPP es responder "qué producir"
- [[Costo de Oportunidad]] — cada respuesta implica renunciar a las alternativas
- [[Eficiencia Económica en Tecnología]] — la respuesta formal al "cómo" a nivel de una empresa

## En el parcial

Las tres preguntas **con su carácter**. Es una pregunta de definición pura y es plata fácil:
no la regales.

---
Fuente: `99-Material-Catedra/Un 1 - Introducción a la economía CÁTEDRA A.pdf` (2026)

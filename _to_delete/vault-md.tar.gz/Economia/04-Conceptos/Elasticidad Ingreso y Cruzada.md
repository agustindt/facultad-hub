---
tipo: concepto
materia: Economia
unidad: U3
estado: pendiente
tags: [Economia, U3, demanda]
---

# Elasticidad Ingreso y Cruzada

> **Las otras dos elasticidades: una mide la respuesta al ingreso del consumidor, la otra al
> precio de otro bien.** Lo que se pregunta no es la fórmula: es la clasificación de bienes que
> sale del **signo**.

**Unidad:** [[U3-Demanda-y-Mercados]] · **Materia:** [[Economia]]

## Las tres elasticidades comparten formato

Todas son "una medida de la capacidad de respuesta de la cantidad demandada ante un cambio en
uno de sus determinantes". Cambia sólo qué va en el denominador.

| Elasticidad | Denominador | Responde a |
|---|---|---|
| Precio (ver [[Elasticidad Precio de la Demanda]]) | $\Delta P_x / P_{ix}$ | El precio del propio bien |
| **Cruzada** | $\Delta P_y / P_{iy}$ | El precio de **otro** bien |
| **Ingreso** | $\Delta Y / Y_i$ | El ingreso del consumidor |

## Elasticidad precio cruzada

Mide "qué tanto responde la cantidad demandada de un bien respecto al cambio en el precio de
otro bien":

$$\varepsilon_{Q_x,P_y} = \frac{\dfrac{\Delta Q}{Q_i}}{\dfrac{\Delta P_y}{P_{iy}}}$$

| Si sube el precio del bien $y$ y la cantidad demandada de $x$… | Los bienes son |
|---|---|
| **Disminuye** | **Complementarios** |
| **Aumenta** | **Sustitutos** |

La lógica es intuitiva: si sube la nafta comprás menos autos (complementarios); si sube el té,
comprás más café (sustitutos).

## Elasticidad ingreso

Mide "qué tanto responde la cantidad demandada de un bien a un cambio en el ingreso del
consumidor":

$$\varepsilon_{Q_x,Y} = \frac{\dfrac{\Delta Q}{Q_i}}{\dfrac{\Delta Y}{Y_i}}$$

| Tipo de bien | Qué pasa al subir el ingreso | Elasticidad ingreso | Ejemplos del material |
|---|---|---|---|
| **Inferiores** | La cantidad demandada **disminuye** | Negativa | Artículos de segunda mano, comidas baratas |
| **Normales** | La cantidad demandada **aumenta** | Positiva | — |
| Normales **de lujo** | Aumenta **más** que proporcionalmente | Mayor a 1 | Joyas, yates |
| Normales **necesarios** | Aumenta **menos** que proporcionalmente | Entre 0 y 1 | Alimentos, ropa, estudios |

```mermaid
flowchart TD
    A["<b>SUBE EL INGRESO</b>"] --> B{"¿Qué pasa con<br/>la cantidad demandada?"}
    B -->|"baja"| C["<b>BIEN INFERIOR</b><br/>elasticidad negativa"]
    B -->|"sube"| D["BIEN NORMAL<br/>elasticidad positiva"]
    D --> E["De LUJO<br/>&epsilon; &gt; 1"]
    D --> F["NECESARIO<br/>0 &lt; &epsilon; &lt; 1"]
    style A fill:#4DB6AC,color:#fff
    style C fill:#FFA726,color:#fff
    style D fill:#7C5CFF,color:#fff
```

## Dónde se usan

Las dos miden lo que **desplaza** la curva de demanda, no lo que hace moverse sobre ella. Un
cambio de ingreso o del precio de un bien relacionado corre la curva entera a derecha o
izquierda — el material lo usa directamente en el análisis de mercado: *"si aumentan los
ingresos, la demanda de bienes normales crece → se desplaza hacia la derecha"*.

## Conexiones

- [[Elasticidad Precio de la Demanda]] — misma fórmula, distinto determinante; conviene estudiarlas juntas
- [[Curva de Demanda]] — el ingreso $Y$ y el precio de otros bienes $P_b$ son dos de los cuatro determinantes de la función de demanda
- [[Equilibrio de Mercado]] — un cambio de ingreso desplaza la demanda y por lo tanto mueve el precio y la cantidad de equilibrio
- [[Monopolio]] — la definición de monopolio exige que **no haya sustitutos cercanos**, o sea elasticidad cruzada baja
- [[Competencia Monopolística]] — los productos son similares pero no idénticos: sustitutos imperfectos entre sí

## En el parcial

**Dado un dato de variación porcentual, calcular la elasticidad y clasificar el bien por el
signo y la magnitud.** Concretamente: elasticidad cruzada positiva = sustitutos, negativa =
complementarios; elasticidad ingreso negativa = inferior, entre 0 y 1 = normal necesario, mayor
a 1 = normal de lujo. El error clásico es mezclar las dos clasificaciones y contestar "sustituto"
cuando la pregunta era de elasticidad ingreso. Tener a mano un ejemplo de cada categoría.

---
Fuente: `ECONOMIA FINAL — camila arenel (feb 2025)`, con `Resumen temas coloquio` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

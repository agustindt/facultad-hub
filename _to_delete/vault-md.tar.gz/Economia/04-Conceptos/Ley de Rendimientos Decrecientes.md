---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, produccion]
---

# Ley de Rendimientos Decrecientes

> El producto marginal de un factor variable **disminuye**, traspasado cierto nivel, al
> incrementarse la cantidad empleada de ese factor **permaneciendo todos los demás constantes**.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

Textual:

> "LA LEY DE LOS RENDIMIENTOS DECRECIENTES establece que el producto marginal de un factor variable de producción disminuye, traspasado un cierto nivel, al incrementarse la cantidad empleada de ese factor permaneciendo todos los demás factores constantes."

Y la explicación que da la cátedra:

> "cuando permanece fija la cantidad de un factor (por ejemplo el capital) y se añaden sucesivamente unidades de un recurso variable (por ejemplo el trabajo), hay un punto a partir del cual disminuye el producto marginal del recurso variable. Primero la productividad total del factor variable aumenta con la cantidad empleada de dicho factor variable, pero a partir de un determinado momento lo hace **menos que proporcionalmente**."

## Las tres condiciones que la hacen válida

La ley no dice "producir más rinde menos". Dice algo mucho más preciso, y las tres condiciones
son parte de la respuesta:

1. Es de **corto plazo** — tiene que haber al menos un factor fijo.
2. **Todos los demás factores permanecen constantes** — si se mueven todos, ya no es esta ley
   sino [[Rendimientos de Escala]].
3. Es **a partir de cierto nivel** — al principio el producto marginal puede perfectamente
   crecer.

Si te olvidás de la segunda, la respuesta está mal aunque el resto esté bien.

## Por qué pasa

Porque el factor fijo se satura. Con una sola máquina y un operario, agregar un segundo
operario ayuda muchísimo: se reparten tareas, la máquina no para. Con diez operarios y la misma
máquina, el que entra hace cola. El factor variable tiene cada vez **menos factor fijo por
cabeza** con el que trabajar.

Al principio pasa lo contrario: con muy poco trabajo para mucho capital, la máquina está
subutilizada y cada operario adicional rinde más que el anterior. Por eso el producto marginal
primero sube.

<svg viewBox="0 0 440 170" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="34" x2="382" y1="144" y2="144" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="147" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">-8</text><line x1="34" x2="382" y1="100.7" y2="100.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="103.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">6</text><line x1="34" x2="382" y1="57.3" y2="57.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="60.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">20</text><line x1="34" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="29" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">34</text><line x1="34" x2="34" y1="14" y2="144" stroke="var(--background-modifier-border,#8886)"/><line x1="179" x2="179" y1="14" y2="144" stroke="#FFA726" stroke-width="1" stroke-dasharray="3 3" opacity=".8"/><circle cx="179" cy="26.4" r="3.4" fill="#FFA726"/><text x="179" y="155" text-anchor="middle" font-size="8" fill="#FFA726" font-weight="600">acá empieza a caer</text><path d="M34 119.2 L39 113 L43.9 106.9 L48.9 101.1 L53.9 95.5 L58.9 90.1 L63.8 85 L68.8 80 L73.8 75.3 L78.7 70.8 L83.7 66.5 L88.7 62.4 L93.7 58.5 L98.6 54.9 L103.6 51.5 L108.6 48.3 L113.5 45.3 L118.5 42.5 L123.5 40 L128.5 37.7 L133.4 35.6 L138.4 33.7 L143.4 32 L148.3 30.5 L153.3 29.3 L158.3 28.3 L163.3 27.5 L168.2 26.9 L173.2 26.5 L178.2 26.4 L183.1 26.5 L188.1 26.7 L193.1 27.3 L198.1 28 L203 28.9 L208 30.1 L213 31.5 L217.9 33.1 L222.9 34.9 L227.9 36.9 L232.9 39.2 L237.8 41.7 L242.8 44.4 L247.8 47.3 L252.7 50.4 L257.7 53.7 L262.7 57.3 L267.7 61.1 L272.6 65.1 L277.6 69.3 L282.6 73.8 L287.5 78.4 L292.5 83.3 L297.5 88.4 L302.5 93.7 L307.4 99.2 L312.4 105 L317.4 110.9 L322.3 117.1 L327.3 123.5 L332.3 130.2 L337.3 137" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="341.3" y="140.0" font-size="9" fill="#FFA726" font-weight="600">PMg</text><text x="208.0" y="167" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Trabajo (L) — el resto de los factores, fijos</text></svg>

*El producto marginal primero sube y, pasado cierto punto, empieza a caer. Esa caída es la ley.*


## La consecuencia del lado de los costos

Esta ley es la razón de que el [[Costo Marginal]] tenga forma de U:

> si cada unidad adicional de factor rinde **menos**, entonces cada unidad adicional de
> producto cuesta **más**.

Literalmente la misma información leída al revés. Textual de la cátedra:
*"la evolución del costo marginal se explica por la existencia de rendimientos crecientes en
una primera fase, mientras que en una segunda fase, los rendimientos marginales son
decrecientes."*

## Conexiones

- [[Corto Plazo y Largo Plazo]] — la ley es exclusivamente de corto plazo, y ese es su requisito central
- [[Producto Total Medio y Marginal]] — es la ley que explica la forma de esas curvas
- [[Etapas de la Producción]] — la etapa 2 es justamente la de rendimientos decrecientes
- [[Rendimientos de Escala]] — el fenómeno análogo de largo plazo, con el que se confunde constantemente
- [[Costo Marginal]] — el tramo creciente del CMg es esta ley vista desde los costos

## En el parcial

Enunciado textual **con la cláusula de los demás factores constantes**, la explicación
intuitiva, y la conexión con la forma de las curvas de costos. Es de las preguntas de
desarrollo más probables de la unidad.

**La trampa:** que te pidan diferenciarla de los rendimientos decrecientes *de escala*. Corto
plazo vs. largo plazo, un factor vs. todos.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

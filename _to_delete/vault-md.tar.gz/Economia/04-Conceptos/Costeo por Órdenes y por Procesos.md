---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, costos]
---

# Costeo por Órdenes y por Procesos

> Los dos sistemas de **acumulación** de costos, y la regla para elegir es de una línea: si los
> productos son **distintos entre sí**, órdenes; si son **muchos y homogéneos**, procesos. No es
> una elección de gusto: la decide el proceso productivo.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## La regla de decisión

> "Si se producen productos que son bastantes distintos entre sí, se utiliza entonces el **costeo por órdenes** (los costos se acumulan por cada pedido del cliente). Si se producen grandes cantidades de productos homogéneos, se utiliza el **costeo por procesos** (los costos se acumulan por dichos procesos o por departamentos o secciones durante un período de tiempo dado)."

| | **Costeo por órdenes** | **Costeo por procesos** |
|---|---|---|
| Cuándo se aplica | Producción "de acuerdo a especificaciones del cliente"; productos únicos, personalizados o en lotes pequeños | "Producción en masa o procesos continuos": continua, uniforme y masiva |
| **Unidad de costeo** | La **orden** de trabajo o de producción | El **proceso o departamento** productivo, no el pedido |
| Ejemplos del apunte | Construcción, consultoría, publicitarios, imprentas, plásticos | Acero, alimentación, refinerías de petróleo, químicos, textiles |
| Cómo se acumula | Se abre una **hoja de costos** por orden; los costos se acumulan por separado para cada cliente, lote o pedido | Se acumulan materiales, MO y CIF **en cada proceso o etapa** |
| Costo unitario | El de esa orden en particular | **Promedio**: costos totales del período ÷ unidades producidas en ese período |
| Para qué sirve además | "Base de comparación con el precio de venta y referencia para futuras **cotizaciones**" | Se usa cuando "no se pueden identificar los costos por pedido" |

```mermaid
flowchart TD
    P["¿Cómo son los productos<br/>entre sí?"] --> D1["Distintos entre sí,<br/>según especificaciones<br/>del cliente"]
    P --> D2["Grandes cantidades<br/>de productos<br/>homogéneos"]
    D1 --> O["<b>COSTEO POR ÓRDENES</b><br/>unidad de costeo:<br/>la orden de trabajo"]
    D2 --> PR["<b>COSTEO POR PROCESOS</b><br/>unidad de costeo:<br/>el proceso o departamento"]
    PR --> CJ["<b>Producción conjunta</b><br/>variante, no sistema nuevo"]
    style P fill:#7C5CFF,color:#fff
    style O fill:#FFA726,color:#fff
    style PR fill:#4DB6AC,color:#fff
    style CJ fill:#4DB6AC,color:#fff
```

## Detalles de cada uno

**Por órdenes.** Se acumulan por orden materia prima, mano de obra, costos indirectos, gastos
generales y beneficios. Generalmente se acumulan los **costos primos**, y los CIF y gastos del
período se incluyen por centro de costo o se determinan sobre la base de MP y MOD:

$$\text{Margen Bruto (CIF + GP)} = (MP + MOD) \times MB$$

Está escrita así en el material: el bloque CIF + gastos del período sale de aplicar un coeficiente
sobre los costos primos.

**Por procesos.** "Los costos primos son siempre individualizables. Los CIF se registran en centros
de costos (departamentos)." El costo total se arma encadenando:

$$\text{Costo proceso A} + \text{Costo proceso B} + \text{Costo proceso C} = \text{Costo de producción}$$

La estructura de costos se expresa como el costo unitario desagregado en **% MP, % MOD y % CIF**, y
las bases de prorrateo son **cantidad ($q$)** o **facturación ($p \times q$)**.

## Producción conjunta: una variante, no un sistema nuevo

> "Se utiliza cuando a partir de la misma materia prima, de un proceso productivo, se dan **más de un producto resultante**. **No son un nuevo sistema de costeo. Es una variante del costo por procesos.**"

Se comparten costos primos y CIF hasta un **punto de separación (PS)**. Ejemplos: petróleo (nafta,
gas oil, kerosene, asfalto) y frigorífico (carne, cuero, grasa, huesos).

| Método de asignación en el PS | Base | Qué hace falta conocer |
|---|---|---|
| **Unidades físicas** ($Q$) | Costo medio | Sólo las cantidades |
| **Valor de venta** ($P \times Q$) | Valor de venta en el punto de separación | El precio $P$ **en el PS** |
| **Valor Neto Realizable (VNR)** | Precio final menos el costo separable | El precio final de cada producto o coproducto |

## Conexiones

- [[Contabilidad de Costos]] — los dos sistemas de acumulación del bloque
- [[Costeo por Absorción]] — define **qué** costos se acumulan; esta nota, **cómo** y **dónde**
- [[Costeo Basado en Actividades]] — la alternativa a prorratear el CIF por una base única
- [[Costos Medios]] — el costo unitario por procesos es literalmente un costo medio: total del período sobre unidades del período
- [[Costeo Variable]] — es una decisión independiente de ésta: se combinan

## En el parcial

**Dado un tipo de empresa, decir qué sistema le corresponde y justificar con la unidad de costeo.**
Una constructora o una imprenta → órdenes (la unidad es el pedido). Una refinería o una acería →
procesos (la unidad es el departamento). El error clásico es elegir por el tamaño de la empresa en
vez de por la **homogeneidad del producto**. Y saber que **la producción conjunta no es un sistema
aparte**: es una variante de procesos.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) + `SEGUNDO PARCIAL` — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

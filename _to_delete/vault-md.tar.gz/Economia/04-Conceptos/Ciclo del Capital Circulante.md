---
tipo: concepto
materia: Economia
unidad: U5
parcial: 2
estado: pendiente
tags: [Economia, U5, finanzas]
---

# Ciclo del Capital Circulante

> Son **dos relojes distintos**. El ciclo **económico** mide desde que comprás la mercadería
> hasta que cobrás. El ciclo **financiero** mide desde que **pagás** hasta que cobrás. La
> diferencia entre los dos es lo que te financian los proveedores.

**Unidad:** [[U5-Economia-de-Empresas]] · **Materia:** [[Economia]]

## Los dos períodos de maduración

| | **Período de maduración ECONÓMICO** | **Período de maduración FINANCIERO** |
|---|---|---|
| Otro nombre | Ciclo Operativo (CO) | Ciclo de Efectivo (CE) |
| Arranca cuando… | La empresa **invierte** en el proceso productivo, comprando existencias (materias primas y mercaderías) | La empresa **paga a los proveedores** |
| Termina cuando… | Recupera la inversión **cobrando a los clientes** | Cobra de los clientes |
| Qué mide | El ciclo del negocio | Los días que la empresa tiene que poner plata propia |

$$CO = \text{Días de inventarios} + PCC$$

$$CE = CO - \text{Período de cuentas por pagar}$$

donde **PCC** es el Período de Cuentas por Cobrar: "el período de días que se requieren para
cobrar una venta".

## La versión desagregada

El mismo ciclo, abierto en los cinco giros — es la forma en que se pide calcularlo:

$$\text{Ciclo económico} = \text{Giro MP}(d_1) + \text{Giro PP}(d_2) + \text{Giro PT}(d_3) + \text{Giro CC}(d_4)$$

$$\text{Ciclo financiero} = \text{Ciclo económico} - \text{Giro SP}(d_5)$$

MP = materia prima · PP = producción en proceso · PT = producto terminado · CC = cuentas a
cobrar · SP = saldo de proveedores (la financiación que dan los proveedores).

```mermaid
flowchart LR
    MP["Compra de MP<br/>d1"] --> PP["Producción<br/>en proceso<br/>d2"]
    PP --> PT["Producto<br/>terminado<br/>d3"]
    PT --> CC["Cuentas a cobrar<br/>d4"]
    CC --> COB["<b>COBRO</b>"]
    MP -.->|"d5: lo que tardo<br/>en pagarle al proveedor"| PAGO["<b>PAGO A PROVEEDORES</b>"]
    PAGO -->|"desde acá corre el<br/>CICLO FINANCIERO"| COB
    style MP fill:#4DB6AC,color:#fff
    style PAGO fill:#FFA726,color:#fff
    style COB fill:#7C5CFF,color:#fff
```

La idea que hay que ver en el diagrama: **el ciclo financiero empieza más tarde que el económico**
(cuando pagás, no cuando comprás) pero termina en el mismo punto. Por eso siempre es más corto —
y por eso estirar el plazo de pago a proveedores lo acorta todavía más.

## Para qué sirve: es un indicador de gestión

> "Las relaciones entre CO y CE se puede utilizar como indicador de la gestión empresarial: **la reducción en los plazos implica por lo general una mayor eficacia en la gestión**, ya que los desfasajes entre las entradas y salidas de efectivo obligan a un financiamiento."

Ésa es la conexión con el resto del bloque: **cada día de ciclo es un día que hay que financiar**.
Un ciclo largo no es un problema contable, es una necesidad concreta de plata que sale de las
[[Fuentes de Financiamiento]].

## Faltante

El material da las fórmulas pero **no da las de los giros individuales** (cómo se calculan los
días de inventario, el PCC o el período de cuentas por pagar a partir de las partidas del
balance). Tampoco hay un ejemplo numérico resuelto.

## Conexiones

- [[Estructura Financiera de la Empresa]] — cada día de ciclo financiero es un día que hay que cubrir con recursos financieros
- [[Fuentes de Financiamiento]] — el crédito de proveedores (giro SP) es en sí mismo una fuente de financiamiento, y es la que acorta el ciclo
- [[Ratios e Indicadores de Performance]] — el CO y el CE son ratios expresados en **días**, del grupo que mide eficiencia operativa
- [[Estados Contables Básicos]] — los tres giros salen de partidas del activo corriente y el cuarto del pasivo corriente
- [[La Empresa y sus Actividades]] — este ciclo es la actividad "operaciones" medida en días

## En el parcial

**Calcular CO y CE con los cinco giros y explicar qué significa la diferencia entre ambos.** El
error clásico es sumar el giro de proveedores en vez de **restarlo**: el proveedor te financia,
así que sus días **acortan** tu ciclo financiero. Segunda cosa que se pregunta: interpretar el
resultado — un ciclo más corto es mejor gestión, porque un ciclo largo obliga a conseguir
financiamiento para tapar el desfasaje entre lo que pagás y lo que cobrás.

---
Fuente: `UNIDAD 5 final` (Valentina, feb 2025) — apuntes de compañeros (2025). **No es material oficial de la cátedra 2026**: verificar cuando se publique el teórico de la unidad.

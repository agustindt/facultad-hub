---
tipo: concepto
materia: Economia
unidad: U2
parcial: 1
autor: Mochón & Beker
estado: estudiado
tags: [Economia, U2, costos]
---

# Costos Fijos, Variables y Totales

> La clasificación básica del **corto plazo**: los costos de los factores fijos no dependen de
> la producción; los de los factores variables, sí.

**Unidad:** [[U2-Teoria-de-la-Produccion-y-de-los-Costos]] · **Materia:** [[Economia]]

## Desarrollo

$$CT = CF + CV$$

| | Definición | Depende de $Q$ | Ejemplos |
|---|---|---|---|
| **Costo fijo (CF)** | Costo de los factores fijos. *"a corto plazo son independientes del nivel de producción"* | ❌ No | Alquiler de la planta, amortización del equipo, seguros |
| **Costo variable (CV)** | *"dependen de la cantidad empleada de los factores variables y, por lo tanto, del nivel de producción"* | ✅ Sí | Materias primas, mano de obra directa, energía de proceso |
| **Costo total (CT)** | La suma de los dos | ✅ Sí | |

## La cláusula que hace toda la diferencia

**"A corto plazo".** Textual de la cátedra:

> "En Economía, la distinción entre corto y largo plazo se establece únicamente atendiendo o no a la existencia de factores fijos. En consecuencia, en el corto plazo distinguiremos entre costos relacionados a factores fijos y costos relacionados a factores variables, mientras que **en el largo plazo guarda relación con la posibilidad de modificar los factores fijos, por lo que todos los factores se tornan variables**."

O sea: **en el largo plazo no existen los costos fijos.** Toda esta clasificación se
desvanece, y por eso los [[Costos de Largo Plazo]] se estudian con otras herramientas.

Si en un parcial te preguntan por "los costos fijos de largo plazo", la respuesta es que no
existen — no es una pregunta con truco menor, es el concepto.

<svg viewBox="0 0 440 180" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:440px;height:auto;font-family:system-ui,sans-serif"><line x1="40" x2="382" y1="154" y2="154" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="35" y="157" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">0</text><line x1="40" x2="382" y1="107.3" y2="107.3" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="35" y="110.3" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">173</text><line x1="40" x2="382" y1="60.7" y2="60.7" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="35" y="63.7" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">347</text><line x1="40" x2="382" y1="14" y2="14" stroke="var(--background-modifier-border,#8886)" stroke-width="1"/><text x="35" y="17" text-anchor="end" font-size="8" fill="var(--text-muted,#999)">520</text><line x1="40" x2="40" y1="14" y2="154" stroke="var(--background-modifier-border,#8886)"/><path d="M40 127.1 L44.9 125.6 L49.8 124.2 L54.7 122.8 L59.5 121.6 L64.4 120.4 L69.3 119.3 L74.2 118.2 L79.1 117.3 L84 116.3 L88.9 115.5 L93.7 114.6 L98.6 113.9 L103.5 113.1 L108.4 112.4 L113.3 111.8 L118.2 111.1 L123.1 110.5 L127.9 110 L132.8 109.4 L137.7 108.9 L142.6 108.3 L147.5 107.8 L152.4 107.3 L157.3 106.8 L162.1 106.3 L167 105.8 L171.9 105.2 L176.8 104.7 L181.7 104.1 L186.6 103.5 L191.5 102.9 L196.3 102.3 L201.2 101.6 L206.1 100.9 L211 100.2 L215.9 99.4 L220.8 98.5 L225.7 97.6 L230.5 96.7 L235.4 95.7 L240.3 94.6 L245.2 93.5 L250.1 92.3 L255 91 L259.9 89.6 L264.7 88.2 L269.6 86.7 L274.5 85.1 L279.4 83.4 L284.3 81.6 L289.2 79.6 L294.1 77.6 L298.9 75.5 L303.8 73.3 L308.7 71 L313.6 68.5 L318.5 65.9 L323.4 63.2 L328.3 60.4 L333.1 57.4 L338 54.3 L342.9 51 L347.8 47.6 L352.7 44 L357.6 40.3 L362.5 36.5 L367.3 32.5 L372.2 28.3 L377.1 23.9 L382 19.4" fill="none" stroke="#7C5CFF" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="22.4" font-size="9" fill="#7C5CFF" font-weight="600">CT</text><path d="M40 154 L44.9 152.5 L49.8 151.1 L54.7 149.8 L59.5 148.5 L64.4 147.3 L69.3 146.2 L74.2 145.2 L79.1 144.2 L84 143.3 L88.9 142.4 L93.7 141.6 L98.6 140.8 L103.5 140 L108.4 139.4 L113.3 138.7 L118.2 138.1 L123.1 137.5 L127.9 136.9 L132.8 136.3 L137.7 135.8 L142.6 135.3 L147.5 134.7 L152.4 134.2 L157.3 133.7 L162.1 133.2 L167 132.7 L171.9 132.1 L176.8 131.6 L181.7 131 L186.6 130.5 L191.5 129.8 L196.3 129.2 L201.2 128.5 L206.1 127.8 L211 127.1 L215.9 126.3 L220.8 125.4 L225.7 124.6 L230.5 123.6 L235.4 122.6 L240.3 121.5 L245.2 120.4 L250.1 119.2 L255 117.9 L259.9 116.6 L264.7 115.1 L269.6 113.6 L274.5 112 L279.4 110.3 L284.3 108.5 L289.2 106.6 L294.1 104.6 L298.9 102.4 L303.8 100.2 L308.7 97.9 L313.6 95.4 L318.5 92.8 L323.4 90.1 L328.3 87.3 L333.1 84.3 L338 81.2 L342.9 77.9 L347.8 74.5 L352.7 71 L357.6 67.3 L362.5 63.4 L367.3 59.4 L372.2 55.2 L377.1 50.8 L382 46.3" fill="none" stroke="#4DB6AC" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="49.3" font-size="9" fill="#4DB6AC" font-weight="600">CV</text><path d="M40 127.1 L44.9 127.1 L49.8 127.1 L54.7 127.1 L59.5 127.1 L64.4 127.1 L69.3 127.1 L74.2 127.1 L79.1 127.1 L84 127.1 L88.9 127.1 L93.7 127.1 L98.6 127.1 L103.5 127.1 L108.4 127.1 L113.3 127.1 L118.2 127.1 L123.1 127.1 L127.9 127.1 L132.8 127.1 L137.7 127.1 L142.6 127.1 L147.5 127.1 L152.4 127.1 L157.3 127.1 L162.1 127.1 L167 127.1 L171.9 127.1 L176.8 127.1 L181.7 127.1 L186.6 127.1 L191.5 127.1 L196.3 127.1 L201.2 127.1 L206.1 127.1 L211 127.1 L215.9 127.1 L220.8 127.1 L225.7 127.1 L230.5 127.1 L235.4 127.1 L240.3 127.1 L245.2 127.1 L250.1 127.1 L255 127.1 L259.9 127.1 L264.7 127.1 L269.6 127.1 L274.5 127.1 L279.4 127.1 L284.3 127.1 L289.2 127.1 L294.1 127.1 L298.9 127.1 L303.8 127.1 L308.7 127.1 L313.6 127.1 L318.5 127.1 L323.4 127.1 L328.3 127.1 L333.1 127.1 L338 127.1 L342.9 127.1 L347.8 127.1 L352.7 127.1 L357.6 127.1 L362.5 127.1 L367.3 127.1 L372.2 127.1 L377.1 127.1 L382 127.1" fill="none" stroke="#FFA726" stroke-width="1.8" stroke-linecap="round"/><text x="386.0" y="130.1" font-size="9" fill="#FFA726" font-weight="600">CF</text><text x="211.0" y="177" text-anchor="middle" font-size="8.5" fill="var(--text-muted,#999)">Cantidad producida (Q)</text></svg>

*La distancia vertical entre CT y CV es constante: es exactamente el CF.*


## Un detalle que confunde

Costo fijo **no** significa "que no se puede evitar". Significa que **no varía con la
cantidad producida**. Si la fábrica produce 0 unidades o 10.000, el alquiler es el mismo. Por
eso el costo fijo medio —ver [[Costos Medios]]— cae continuamente al aumentar $Q$: el mismo
monto se reparte entre más unidades.

## Conexiones

- [[Corto Plazo y Largo Plazo]] — la clasificación solo existe en el corto plazo, y esa es su condición
- [[Costos Medios]] — se obtienen dividiendo cada uno de estos por la cantidad producida
- [[Costo Marginal]] — se calcula sobre el costo total, y por eso el costo fijo no lo afecta
- [[Costos de Largo Plazo]] — en el largo plazo todo es variable y esta clasificación desaparece
- [[Costo Económico]] — tanto CF como CV se miden a costo económico, no solo contable

## En el parcial

Definiciones, la fórmula, y **la aclaración de que es una distinción de corto plazo**. Es la
base de la tabla de costos que casi seguro te van a hacer completar.

---
Fuente: `99-Material-Catedra/Un 2 - Teoría de la producción y de los costos.pdf` (2026)

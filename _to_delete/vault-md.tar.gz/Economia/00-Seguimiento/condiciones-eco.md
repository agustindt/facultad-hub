---
tipo: seguimiento
materia: Economia
estado: estudiado
tags: [Economia, seguimiento, condiciones]
---

**Materia:** [[Economia]] · Ver también [[cronograma-eco]]

# Condiciones de cursada — Economía Cátedra A 2026

Fuente: PDF de presentación de la cátedra 2026 y texto de bienvenida del aula. **Las dos
fuentes coinciden**, lo cual es buena señal.

## Regular

- Asistir como mínimo al **65 % de las clases**.
- Aprobar **2 exámenes parciales teórico-prácticos con nota ≥ 4**.
- Se puede recuperar **1 parcial por aplazo o por ausencia**, debiendo aprobarlo y alcanzar
  con todos los parciales rendidos un **promedio ≥ 4**. Textual: *"(se promedian las 3 notas)"*.

## Promoción

> 🔑 En esta materia la promoción es **solo del práctico**, no de la materia completa.

- Asistir como mínimo al **65 % de las clases**.
- Aprobar **2 parciales teórico-prácticos con nota ≥ 7**.
- Se puede recuperar **1 parcial por ausencia** — ⚠️ **solo por ausencia**, no por aplazo, a
  diferencia de la regularidad. Y alcanzar un **promedio ≥ 7**.
- Textual: *"La condición de promoción de práctico se conserva hasta los turnos programados
  para la primera época ordinaria de exámenes inmediata posterior al cierre de condiciones del
  dictado de la asignatura."*

## Recuperatorios

**Uno solo**, el 12/11/2026. Para regularidad recupera aplazo **o** ausencia; para promoción,
solo ausencia.

## Examen final

| Condición | Formato |
|---|---|
| Regulares y libres | Ejercicios prácticos (escrito) + teórico oral |
| Promoción del práctico | Solo teórico oral |

## Trabajos prácticos

**El régimen 2026 no los menciona como condición.** Lo único exigido es asistencia + 2 parciales.

⚠️ Esto **contradice** el programa 2019, que pedía "aprobar los Trabajos prácticos y la
Monografía" para regularizar. **Confirmar con la cátedra** — es la diferencia más importante
entre las dos fuentes.

## Escala de notas

No publicada. Solo se conocen los umbrales: **4** para aprobar/regularizar, **7** para
promoción del práctico.

## Lo que la cátedra remarcó en la presentación

> "PUNTUALIDAD · ASISTENCIAS · AUSENCIAS · DINÁMICA DE CLASES: TEÓRICO-PRÁCTICO · PARTICIPACIÓN · PRESTAR ATENCIÓN EN CLASES Y TOMAR NOTA · **PRESENTACIONES DE CLASES (NO SON EL MATERIAL DE ESTUDIO)** · **NO USAR MATERIAL DE ESTUDIO VIEJO/AÑOS ANTERIORES** · CONSULTAS · KAHOOT DE REPASO"

Dos de esas viñetas mandan sobre cómo estudiar esta materia:

1. **Los PDF de teórico son apoyo, no el material de estudio.** La fuente es el libro.
2. **No usar material de años anteriores** — aplica a la carpeta `~/Downloads/Economia`, que
   es un volcado 2016–2019 de otra cátedra.

## ⚠️ Faltantes

- Qué unidades entra en cada parcial: **no publicado**.
- Escala de notas: no publicada.
- Si los TPs y la monografía cuentan: contradictorio entre fuentes.

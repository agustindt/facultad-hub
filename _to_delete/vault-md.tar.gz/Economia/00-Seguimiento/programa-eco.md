---
tipo: seguimiento
materia: Economia
estado: pendiente
tags: [Economia, programa, seguimiento]
---

# Programa de Economia

> Los temas que la cátedra dice que entran, uno por fila. El hub los compara contra las notas
> que existen y marca los huecos.

**Materia:** [[Economia]]

**Fuente:** Contenidos numerados 1 a 16, textuales del aula virtual de la cátedra (relevados en `00-Sistema/_scrape/economia.md`).

⚠️ **Conviven dos numeraciones de unidades.** Esta tabla usa la del **aula virtual (7 unidades)**,
que es la que numeran U1…U7 las notas del vault. El PDF de la cátedra 2026 usa 6 unidades e
**invierte Macroeconomía con Economía de Empresas**. Antes del segundo parcial hay que
confirmarle al docente cuál manda.

## Índice

- **U1** — Introducción a la economía · 12 temas
- **U2** — Teoría de la Producción y de los Costos · 23 temas
- **U3** — Demanda y Mercados · 31 temas
- **U4** — Macroeconomía · 25 temas
- **U5** — Economía de empresas · 29 temas
- **U6** — Ingeniería Económica · 31 temas
- **U7** — Formulación y evaluación de proyectos de inversión · 0 temas

Total: **151 temas** en 7 unidades.

## Temas

La columna **Nota** es un override manual: si el hub no encuentra la nota que cubre un tema y
vos sabés cuál es, poné el wikilink ahí y deja de marcarlo como hueco. Vacía, el hub busca solo.

| Unidad | Tema | Nota |
|---|---|---|
| U1 | Economía positiva y normativa |  |
|  | Teoría económica y política económica |  |
|  | Los instrumentos del análisis económico |  |
|  | Modelos e investigación |  |
|  | Variables económicas |  |
|  | El principio de escasez |  |
|  | Los factores de la producción |  |
|  | La frontera de las posibilidades de producción |  |
|  | Costo de oportunidad |  |
|  | Problemas económicos básicos |  |
|  | Economía de mercado y economía planificada |  |
|  | Problemas económicos de ingeniería |  |
| U2 | La empresa y la producción |  |
|  | Tecnologías |  |
|  | Cadenas de abastecimiento |  |
|  | Funciones de producción |  |
|  | Producto total, medio y producto marginal |  |
|  | El corto plazo y los rendimientos decrecientes |  |
|  | Isocuantas |  |
|  | Tasa marginal de sustitución técnica |  |
|  | Rendimientos de escala |  |
|  | Eficiencia técnica y económica |  |
|  | Isocostos |  |
|  | Sendero de expansión |  |
|  | El equilibrio del productor respecto a la tecnología |  |
|  | Función de producción Cobb-Douglas |  |
|  | Costos de corto plazo |  |
|  | Fijos y variables |  |
|  | Costo total, medio y marginal |  |
|  | El equilibrio del productor respecto a la tasa de producción |  |
|  | Costos de largo plazo |  |
|  | Costos medios y marginales de largo plazo |  |
|  | Economías y deseconomías de escala |  |
|  | El equilibrio del productor respecto al tamaño de planta |  |
|  | Escala mínima eficiente |  |
| U3 | Teoría de la utilidad |  |
|  | La utilidad total y marginal |  |
|  | Equilibrio del consumidor |  |
|  | La demanda |  |
|  | Función de demanda |  |
|  | Elasticidad-precio, elasticidad-ingreso, elasticidades cruzadas |  |
|  | El excedente del consumidor |  |
|  | Clasificación de mercados |  |
|  | Mercados de bienes y servicios |  |
|  | Equilibrio del productor respecto al mercado |  |
|  | Principio marginal de maximización de beneficios |  |
|  | Precio y producción en competencia perfecta y en monopolio |  |
|  | Competencia monopolística |  |
|  | Oligopolios |  |
|  | Índice de Herfindhal |  |
|  | Defensa de la competencia |  |
|  | Mercado de factores |  |
|  | Demanda y oferta |  |
|  | Distribución del ingreso |  |
|  | Mercado del trabajo |  |
|  | Sindicatos |  |
|  | Mercado de capitales |  |
|  | Rendimientos y riesgo |  |
|  | Eficiencia económica y fallas del mercado |  |
|  | Mercados estrechos |  |
|  | Externalidades |  |
|  | Bienes públicos |  |
|  | El rol del Estado |  |
|  | Regulaciones |  |
|  | Medio ambiente y desarrollo sustentable |  |
|  | Economía ambiental |  |
| U4 | Problemas macroeconómicos |  |
|  | Objetivos |  |
|  | Instrumentos de política macroeconómica |  |
|  | Demanda y oferta agregada |  |
|  | Contabilidad Nacional |  |
|  | Producto Bruto y Neto |  |
|  | Métodos del gasto, del ingreso y del valor agregado |  |
|  | Matriz insumo producto y coeficientes técnicos |  |
|  | Consumo y ahorro |  |
|  | Demanda de inversión |  |
|  | Modelo de Keynes |  |
|  | Flujo circular del ingreso |  |
|  | Presupuesto público y Política fiscal |  |
|  | Sector financiero |  |
|  | El Dinero |  |
|  | Intermediarios financieros |  |
|  | Política monetaria |  |
|  | Desempleo, Inflación |  |
|  | Economía internacional |  |
|  | Comercio exterior |  |
|  | Balanza de pagos |  |
|  | Mercado de divisas |  |
|  | Crecimiento económico y desarrollo |  |
|  | Mercados comunes |  |
|  | Nueva economía y tecnologías de la información |  |
| U5 | Empresas e integrantes |  |
|  | Sistemas de información contable |  |
|  | Contabilidad general |  |
|  | Estados financieros básicos |  |
|  | Balances |  |
|  | Cuenta de pérdidas y ganancias |  |
|  | Procedimientos contables |  |
|  | Auditorías |  |
|  | Depreciación funcional y contable |  |
|  | Distintos métodos |  |
|  | Impuesto a las ganancias |  |
|  | Estructura financiera de las empresas |  |
|  | Giro del capital circulante |  |
|  | Fuentes de financiamiento |  |
|  | Inversiones y el mercado de capitales |  |
|  | Indicadores y ratios de perfomance |  |
|  | Solvencia, Rentabilidad |  |
|  | Tablero de comando financiero |  |
|  | Contabilidad de costos |  |
|  | Elementos |  |
|  | Costeo por absorción |  |
|  | Costos indirectos de fabricación |  |
|  | Costos por órdenes y procesos |  |
|  | Costos en producción conjunta |  |
|  | Costos basados en actividades |  |
|  | Costeo variable |  |
|  | Estimación de costos |  |
|  | Métodos estadísticos y de ingeniería |  |
|  | Enfoque de la teoría de las restricciones |  |
| U6 | Valor del dinero en el tiempo |  |
|  | Tasas de interés |  |
|  | Factores de equivalencias de pago único y anualidades |  |
|  | Efecto de la inflación |  |
|  | Bases para comparación de alternativas |  |
|  | Flujo de fondos |  |
|  | Período de análisis y valor residual |  |
|  | Tasa de descuento |  |
|  | Análisis beneficio-costo |  |
|  | Alternativa nula |  |
|  | Valor Presente (VAN) |  |
|  | Tasa interna de retorno (TIR) |  |
|  | Otros indicadores |  |
|  | Reemplazo de equipos |  |
|  | Vida de servicio económica |  |
|  | Análisis de costo presente |  |
|  | Análisis de Punto de equilibrio |  |
|  | Fabricar o comprar |  |
|  | Alquilar o comprar |  |
|  | Selección de equipos |  |
|  | Teoría de decisión |  |
|  | Riesgo e incertidumbre |  |
|  | Escenarios |  |
|  | La matriz de pagos |  |
|  | Criterios de decisión bajo riesgo |  |
|  | Probabilidades |  |
|  | Valor esperado |  |
|  | Árboles de decisión |  |
|  | Métodos de Simulación (Montecarlo) |  |
|  | Criterios de decisión bajo incertidumbre |  |
|  | Laplace, Hurwics, Savage |  |
| U7 | *(sin contenidos publicados)* |  |

## Faltantes

- La UNIDAD 7 (Formulación y evaluación de proyectos de inversión) está **vacía en el aula**: solo el título, sin contenidos publicados. No hay temas que listar.
- No está publicado **qué unidades entran en cada parcial**. El reparto del programa 2019 (I-II-III / IV-V-VI-VII) no está confirmado para 2026.
- El cronograma semanal del aula no dice qué unidad se ve cada semana.

---
tipo: seguimiento
materia: Economia
estado: borrador
tags: [Economia, seguimiento, cronograma]
---

**Materia:** [[Economia]] · Ver también [[condiciones-eco]]

# Cronograma Economía 2026 — Cátedra A

Fuente: `Un 0 - INTRODUCCIÓN A LA MATERIA CÁT A.pdf` (cátedra 2026) y el aula del campus.

## Horarios fijos

| Día | Horario | Qué |
|---|---|---|
| **Jueves** | 18:30 – 20:30 | Clases **teóricas** |
| **Viernes** | 17:15 – 19:15 | Clases **prácticas** — comisión **A1** |
| **Viernes** | 19:45 – 21:45 | Clases **prácticas** — comisión **A2** |

> ⚠️ **Falta confirmar en qué comisión de práctico estás (A1 o A2).** El campus no asigna grupos.

## Fechas clave

| Fecha | Evento | Tipo |
|---|---|---|
| 11/09/2026 | **Primer parcial** teórico-práctico — en horario del práctico (viernes) | Parcial |
| 29/10/2026 | **Segundo parcial** teórico-práctico — en horario del teórico (jueves) | Parcial |
| 12/11/2026 | **Recuperatorio** — en horario del teórico (jueves) | Recuperatorio |

Los tres días coinciden con el calendario 2026: 11/09 es viernes, 29/10 y 12/11 son jueves. ✔️

## ⚠️ Faltantes

- **No hay cronograma semana a semana publicado.** Solo los días fijos y estas tres fechas.
- **No se publicó qué unidades entra en cada parcial.** El reparto del programa 2019
  (I-II-III en el primero; IV-V-VI-VII en el segundo) **no está confirmado para 2026** y
  además la numeración de unidades cambió. Ver [[condiciones-eco]].
- No figuran fecha de inicio ni de fin de cursada, ni las aulas.

---
tipo: seguimiento
materia: Ing-Software-III
estado: pendiente
tags: [Ing-Software-III, seguimiento, cronograma]
---

# Cronograma de Ingeniería de Software III

**Materia:** [[Ing-Software-III]] · Ver también [[condiciones-isw3]]

> 🚩 **El repo de la cátedra no tiene ni una sola fecha.** Numera las doce clases pero no
> las fecha. Esta tabla está lista para completarse: cuando consigas las fechas, escribilas
> en la columna y el calendario del hub las levanta solas.

## Fechas clave

| Fecha | Evento | Tipo |
|---|---|---|
| | P1 — Defensa oral de los TPs 1 a 4 (clase 5) | Defensa |
| | P2 — Defensa oral de los TPs 5 a 9 (clase 11) | Defensa |
| | Recuperatorio de un bloque (clase 12) | Recuperatorio |

## Clase por clase

| Sem | Fecha | Clase | TP |
|---|---|---|---|
| 1 | | C1 — Cultura DevOps + Git para equipos | TP1 Git colaborativo |
| 2 | | C2 — Contenedores: Docker + Compose | TP2 Contenedores |
| 3 | | C3 — Plataformas DevOps + planificación ágil | TP3 Planificación |
| 4 | | C4 — CI: Pipelines as Code | TP4 CI |
| 5 | | **P1 — Defensa oral TPs 1 a 4** | — |
| 6 | | C5 — Testing en el pipeline | TP5 Testing |
| 7 | | C6 — CD: environments y aprobaciones | TP6 CD |
| 8 | | C7 — Contenedores en el pipeline + e2e | TP7 |
| 9 | | C8 — Infraestructura como Código | TP8 IaC |
| 10 | | C9 — DevSecOps + Observabilidad | TP9 DevSecOps |
| 11 | | **P2 — Defensa oral TPs 5 a 9** | — |
| 12 | | **Recuperatorio** | — |

## Horarios

Sin publicar en el repo. **Buscar en el aula del campus (curso 15011).**

## ⚠️ Faltantes

- Todas las fechas.
- Días, horarios y aula.
- Fecha de inicio y de fin de cursada.

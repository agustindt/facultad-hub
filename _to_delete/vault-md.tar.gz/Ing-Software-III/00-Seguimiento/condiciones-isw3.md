---
tipo: seguimiento
materia: Ing-Software-III
estado: pendiente
tags: [Ing-Software-III, seguimiento, condiciones]
---

# Condiciones de Ingeniería de Software III

**Materia:** [[Ing-Software-III]] · Ver también [[cronograma-isw3]]

Fuente: `README.md` y `reglamento` del repo de la cátedra, relevados el 13/08/2026.

> ⚠️ **El régimen es distinto a todo lo demás del vault: no hay parciales escritos.**

Textual:

> "**No hay parciales escritos**: tus notas son **dos**, y salen de las dos presentaciones (P1 sobre los TPs 1–4, P2 sobre los TPs 5–9). La materia se aprueba **trabajando todas las semanas** — está diseñada para que cada TP tome una semana si venís al día, y para que se acumule mal si no."

## Regular

| Condición | Detalle |
|---|---|
| P1 aprobada | Nota ≥ 4, escala 1 a 10 |
| P2 aprobada | Nota ≥ 4, escala 1 a 10 |
| Las dos notas | **No se promedian ni se compensan entre sí** |
| Los 9 TPs | Obligatorios, sin nota propia |

## Promoción

No figura régimen de promoción. El repo sólo habla de regularizar y de rendir final.

## Recuperatorio

> "**Recuperatorio (clase 12): es tu única segunda oportunidad, y alcanza para un solo bloque.** Si una presentación quedó abajo de 4, en la clase 12 volvés a presentar **ese bloque completo** — los TPs 1–4 o los 5–9, según cuál haya sido. Si **las dos** quedaron abajo de 4, la materia queda **libre** (la recursás) — y lo mismo si vas al recuperatorio y tampoco lo aprobás."

Nota de la cátedra: *"Ante la duda, avisá temprano y lo acomodamos en el momento, no en la clase 12."*

## Cuánto pesa cada TP dentro de su presentación

| P1 | TP1 Git | TP2 Docker | TP3 Planificación | TP4 CI |
|---|---|---|---|---|
| Peso | 5 % | **35 %** | 20 % | **40 %** |

| P2 | TP5 Testing | TP6 CD | TP7 Contenedores + e2e | TP8 IaC | TP9 DevSecOps |
|---|---|---|---|---|---|
| Peso | 20 % | 25 % | 25 % | 15 % | 15 % |

## Con qué criterio se mira cada TP

| Criterio | Peso |
|---|---|
| Configuración técnica funcionando y reproducible, con evidencias | 25 % |
| Claridad y justificación en `decisiones.md` y `evidencias.md` | 25 % |
| **Defensa oral: comprensión y argumentación** | **50 %** |

La mitad de la nota es poder explicarlo. Por eso el checklist de entregables del hub
verifica lo verificable y nada más: el otro 50 % no lo mide ninguna herramienta.

## Final

El **TP Integrador** es condición para rendir el final, y se valida **en vivo** en la mesa.
El enunciado se publica en `trabajos/` durante la cursada — todavía no está.

## ⚠️ Faltantes

- No hay fecha para P1, P2 ni el recuperatorio.
- No figura si hay requisito de asistencia.
- El enunciado del TP Integrador.

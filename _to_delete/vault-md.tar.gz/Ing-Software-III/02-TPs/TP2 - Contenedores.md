---
tipo: tp
materia: Ing-Software-III
estado: pendiente
tags: [Ing-Software-III, TP2, docker, entrega]
---

# TP2 — Contenedores

> El orden completo, de Docker instalado hasta la entrega. Cada paso dice qué
> tiene que pasar para saber que salió bien.

**Materia:** [[Ing-Software-III]] · Repo: `~/Documents/github.com/facultad-hub`

## 0 · Docker andando

```bash
docker ps
```

Tiene que devolver una tabla vacía con encabezados, no un error. Si dice
`Cannot connect to the Docker daemon`, abrí Docker Desktop (o `colima start`).

## 1 · Configurar el entorno

```bash
cd ~/Documents/github.com/facultad-hub
cp .env.example .env
```

Editá `.env` y completá dos cosas:

| Variable | Qué poner |
|---|---|
| `DB_PASSWORD` | Cualquier cosa que no sea `cambiame` |
| `VAULT_PATH` | `/Users/agusditomaso/Documents/Facultad` |

El `.env` está en `.gitignore`: **no se commitea**. El `.env.example` sí.

## 2 · Levantar

```bash
docker compose up -d
docker compose ps
```

Los tres servicios tienen que decir `healthy`. La primera vez tarda: baja
`postgres:16-alpine`, `node:22-alpine` y `nginx:1.27-alpine`, y construye.

Si un servicio queda en `starting` para siempre, mirá por qué:

```bash
docker compose logs backend --tail 40
docker compose logs db --tail 20
```

Abrí **http://localhost:8080**. Tenés que ver tus notas.

> ⚠️ **Qué NO va a andar adentro del contenedor, y está bien.** El Asistente y el
> botón "Ordenar con Claude" van a fallar: el CLI de Claude Code no está en la
> imagen y no está autenticado ahí. Lo mismo el modo directo, que necesita `git`.
> Eso es una decisión, no un bug — meter un CLI autenticado con mis credenciales
> adentro de una imagen pública sería exactamente lo que no hay que hacer.
> **Anotalo en `decisiones.md`: es una pregunta de defensa servida en bandeja.**

## 3 · 📸 Evidencia: levantado desde cero

Captura de `docker compose ps` con los tres en `healthy`.

## 4 · 📸 Evidencia: funciona de punta a punta

Dos cosas distintas, en una o dos capturas:

- El hub mostrando notas → frontend → backend → **bind mount del vault**
- Calificar una tarjeta en **Repaso** → frontend → backend → **Postgres**

La segunda es la que importa: prueba que la base está haciendo algo real.

## 5 · 📸 Evidencia: persistencia

Es la evidencia que más se explica en la defensa. Tres pasos:

```bash
# 1. calificá algunas tarjetas en Repaso, en el navegador

# 2. apagar y prender: los datos SIGUEN
docker compose down
docker compose up -d
#    → volvé a Repaso: el calendario está como lo dejaste

# 3. apagar borrando volúmenes: los datos SE VAN
docker compose down -v
docker compose up -d
#    → Repaso arrancó de cero
```

La diferencia entre 2 y 3 es todo el punto del volumen nombrado. **Tus notas no
se tocan en ninguno de los dos casos** porque viven en tu disco por el bind
mount, no adentro del volumen. Esa distinción es la respuesta a "¿qué pasa con
los datos si borro el contenedor de la BD?".

## 6 · 📸 Evidencia: tamaño de las imágenes

```bash
docker images | grep -E "facultad-hub|node|nginx|postgres"
```

Compará el backend contra `node:22` a secas. La diferencia es lo que compró el
multi-stage.

## 7 · Publicar en el registry

**El token tiene que ser classic** (`ghp_…`), con scope `write:packages`. Los
fine-grained (`github_pat_…`) **no sirven** para GitHub Packages.

```bash
docker login ghcr.io -u agustindt
# pega el token cuando lo pida — así no queda en el historial del shell
```

> ⚠️ **Si tu Mac es Apple Silicon (M1/M2/M3), leé esto antes de buildear.**
> Por defecto las imágenes salen `arm64`. Si el docente las baja en una máquina
> Intel, no arrancan. Para la entrega conviene construir para las dos:
>
> ```bash
> docker buildx build --platform linux/amd64,linux/arm64 \
>   -t ghcr.io/agustindt/facultad-hub-backend:v0.1.0 --push ./backend
> docker buildx build --platform linux/amd64,linux/arm64 \
>   -t ghcr.io/agustindt/facultad-hub-frontend:v0.1.0 --push ./frontend
> ```
>
> `buildx` con `--push` construye y sube en un solo paso: no hace falta el
> `docker push` de abajo. Si preferís lo simple, usá los comandos de abajo y
> anotá en `decisiones.md` que las imágenes son arm64 — declararlo vale más que
> que lo descubran en la demo.

Camino simple, una sola arquitectura:

```bash
docker build -t ghcr.io/agustindt/facultad-hub-backend:v0.1.0 ./backend
docker build -t ghcr.io/agustindt/facultad-hub-frontend:v0.1.0 ./frontend
docker push ghcr.io/agustindt/facultad-hub-backend:v0.1.0
docker push ghcr.io/agustindt/facultad-hub-frontend:v0.1.0
```

## 8 · Hacerlas públicas ⚠️

**Las imágenes nacen privadas.** Este es el paso que más se olvida y hace fallar
la evidencia del punto 10.

`github.com/agustindt?tab=packages` → cada imagen → **Package settings** →
**Change visibility** → **Public**.

Mientras estás ahí, conectá cada paquete al repo (**Connect repository** →
`facultad-hub`): así aparecen enlazados desde el repo.

## 9 · 📸 Evidencia: imágenes públicas

Captura de la página del paquete mostrando **Public**.

## 10 · 📸 Evidencia: levantar desde el registry, sin código

```bash
mkdir ~/prueba-registry && cd ~/prueba-registry
cp ~/Documents/github.com/facultad-hub/docker-compose.registry.yml .
cp ~/Documents/github.com/facultad-hub/.env .
docker compose -f docker-compose.registry.yml up -d
```

Carpeta con dos archivos y nada más: ni un `Dockerfile`, ni el código. Si levanta
y abre en `localhost:8080`, las imágenes publicadas están bien.

Para probarlo de verdad, borrá primero las locales:

```bash
docker rmi ghcr.io/agustindt/facultad-hub-backend:v0.1.0 \
           ghcr.io/agustindt/facultad-hub-frontend:v0.1.0
```

Así el `up` está obligado a bajarlas del registry en vez de usar las que ya
tenías.

## 11 · Cerrar el TP

Completá `decisiones.md` y `evidencias.md` — las secciones marcadas
`⚠️ COMPLETAR VOS` son las que se defienden. Después:

```bash
cd ~/Documents/github.com/facultad-hub
git add -A
git commit -m "TP2: evidencias y decisiones"
git tag -a tp2 -m "TP2 cerrado"
git push origin main
git push origin tp2
```

Y cargá la URL del repo en el formulario de entrega.

## En el parcial

En la defensa de P1 el TP2 pesa **35 %**, el más alto del bloque junto con el TP4.
La mitad de esa nota es explicarlo. Las preguntas publicadas:

| Pregunta | Dónde está la respuesta |
|---|---|
| Imagen vs contenedor · `CMD` vs `ENTRYPOINT` | El `Dockerfile` del backend dice por qué usa `CMD` |
| ¿Por qué multi-stage? ¿Y si no lo fuera? | La evidencia del punto 6 |
| ¿Qué pasa con los datos si borro el contenedor de la BD? ¿Y con `down -v`? | La evidencia del punto 5, y la distinción bind mount / volumen nombrado |
| ¿Cómo se encuentra el backend con la BD? ¿Qué es `db`? | DNS interno de la red de compose; está en `DATABASE_URL` |
| ¿Por qué `depends_on` solo no alcanza? | `pg_isready` vs "el contenedor arrancó" |
| ¿Por qué el `.env` no está en el repo? | `.gitignore`, con `.env.example` commiteado |
| **En vivo:** cloná el repo limpio y levantalo con tu README | El punto 10, ensayado |

La última es la que hay que **ensayar**, no leer.

---
Fuente: `trabajos/02-docker-compose.md` del repo de la cátedra.

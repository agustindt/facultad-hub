---
tipo: moc
materia: Ing-Software-III
anio: 4
semestre: 2
estado: cursando
tags: [moc, ing-software-iii, devops]
---

# Ingeniería de Software III

> **La fuente de verdad no es el campus: es un repo.**
> [`github.com/ingsoft3ucc/TPs_2026`](https://github.com/ingsoft3ucc/TPs_2026)
> El aula del campus (curso 15011) no se relevó — puede tener las fechas, que es justo
> lo que al repo le falta.

**Año:** 4º · **Semestre:** 2º · **Vault:** [[Facultad]]
**Seguimiento:** [[cronograma-isw3]] · [[condiciones-isw3]]

Docente de la práctica: **Ing. Ariel Schwindt**.

## Objetivo, textual

> "Vas a construir, con tus manos y semana a semana, el **sistema de entrega profesional** completo de una aplicación: integración continua con gates de calidad, entrega continua con aprobaciones, releases inmutables verificadas end-to-end, infraestructura como código, seguridad automatizada y observabilidad. No es una materia de 'ver herramientas': es una materia de **construir el sistema y poder defender cada decisión**."

## La regla que ordena todo

> "*si no lo podés explicar, no lo aprobás — aunque funcione.* Y su reversa: un repo con cicatrices bien explicadas vale más que uno perfecto defendido con silencios."

## Cómo está armada

No hay unidades: la unidad de avance es **el TP de la semana**. Doce clases, dos defensas
orales y un recuperatorio.

| # | Clase | Tema | TP |
|---|---|---|---|
| 1 | C1 | Cultura DevOps + Git para equipos | TP1 Git colaborativo |
| 2 | C2 | Contenedores: Docker + Compose | TP2 Contenedores |
| 3 | C3 | Plataformas DevOps + planificación ágil | TP3 Planificación |
| 4 | C4 | CI: Pipelines as Code | TP4 CI |
| 5 | **P1** | **Defensa oral de los TPs 1 a 4** | — |
| 6 | C5 | Testing en el pipeline | TP5 Testing |
| 7 | C6 | CD: environments y aprobaciones | TP6 CD |
| 8 | C7 | Contenedores en el pipeline + e2e | TP7 |
| 9 | C8 | Infraestructura como Código | TP8 IaC |
| 10 | C9 | DevSecOps + Observabilidad | TP9 DevSecOps |
| 11 | **P2** | **Defensa oral de los TPs 5 a 9** | — |
| 12 | **R** | Recuperatorio de un solo bloque | — |

Estructura de cada clase, textual: *"bloque teórico + pausa + demo en vivo + presentación del
TP + **manos a la obra** (trabajás sobre tu propio TP en el aula, con soporte)"*.

**Requisito material:** *"Traé tu notebook con Docker funcionando desde la C2."*

## Trabajos prácticos

Se entregan cargando la **URL del repo público** en un formulario, antes de la clase de
defensa. Los nueve son obligatorios y **ninguno lleva nota propia**: son lo que se defiende.

| # | TP | Consigna |
|---|---|---|
| 1 | Git colaborativo | [`trabajos/01-git-colaborativo.md`](https://github.com/ingsoft3ucc/TPs_2026/blob/main/trabajos/01-git-colaborativo.md) |
| 2 | Contenedores: Docker + Compose | [`trabajos/02-docker-compose.md`](https://github.com/ingsoft3ucc/TPs_2026/blob/main/trabajos/02-docker-compose.md) |
| 3 | Planificación ágil | No liberado |
| 4 | CI: Pipelines as Code | No liberado |
| 5 | Testing en el pipeline | No liberado |
| 6 | CD: environments y aprobaciones | No liberado |
| 7 | Contenedores en el pipeline + e2e | No liberado |
| 8 | Infraestructura como Código | No liberado |
| 9 | DevSecOps + Observabilidad | No liberado |

**Dónde van `decisiones.md` y `evidencias.md`:** en la **raíz** del repo, acumulativos —
cada TP agrega su título, no se reemplaza. Y entran **por PR**, no directo a `main`.

## ⚠️ Faltantes

- **Ni una sola fecha.** El repo numera las clases pero no las fecha. Sin eso no se sabe
  cuándo caen P1 y P2, que son las dos únicas notas de la materia. Es lo primero que hay
  que conseguir.
- Días, horarios y aula.
- El enunciado del TP Integrador, que es condición para el final.
- Existe una **cátedra teórica aparte** que este repo no cubre: *"La teoría acá es la de la
  práctica […] no repite ni reemplaza a la materia teórica."*

## Bibliografía

No hay. El repo es la fuente de verdad, más las filminas por clase.

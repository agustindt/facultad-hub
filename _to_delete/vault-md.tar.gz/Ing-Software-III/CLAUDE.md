# Ingeniería de Software III — contexto para Claude Code

## Qué tiene de distinto

**El material y la entrega viven en GitHub, no en el campus.** La fuente de verdad es
`github.com/ingsoft3ucc/TPs_2026`. El hub tiene un módulo (vista **Código**) que sigue ese
repo: novedades desde el último commit visto, matriz de actividad y checklist de entregables.

**No hay parciales escritos.** Las dos únicas notas son las defensas orales P1 (TPs 1–4) y
P2 (TPs 5–9). El 50 % de cada TP es la defensa: *"si no lo podés explicar, no lo aprobás —
aunque funcione"*.

## Reglas de esta materia

- Se respeta `00-Sistema/Convenciones.md`.
- Archivos de seguimiento sufijados con `-isw3`.
- No hay unidades: la unidad de avance es **el TP de la semana**. Las notas de TP van en
  `02-TPs/`, no en `01-Unidades/`.
- `decisiones.md` y `evidencias.md` van en la raíz del **repo de entrega**, no en el vault.
  Son acumulativos: cada TP agrega un título, no reemplaza.
- **La declaración de uso de IA es obligatoria** dentro de `decisiones.md`. El hub la genera
  desde `_hub/datos/ia-log.json`, que es el registro real de cada llamada que hizo.

## Ojo con esto

- **El repo no tiene ni una fecha.** Sin las fechas de P1 y P2 no se puede planificar nada.
  Es el dato más importante que falta.
- Existe una **cátedra teórica aparte** que este repo no cubre.
- El aula del campus (curso 15011) no se relevó: puede tener las fechas.

## Qué falta

- [ ] Fechas de P1, P2 y el recuperatorio
- [ ] Días, horarios y aula
- [ ] Enunciado del TP Integrador (condición para el final)
- [ ] Enunciados de los TPs 3 a 9 (se liberan durante la cursada)

---
tipo: moc
materia: CompuGrafica
anio: 4
semestre: 2
catedra: UCC Facultad de Ingeniería — Plan 2016
docentes: por definir
estado: cursando
objetivo: por definir
tags: [moc, CompuGrafica]
---

# Computación Gráfica

> Cómo se representan, transforman y rasterizan objetos para que terminen siendo píxeles
> en una pantalla.
>
> *(Descripción provisoria — reemplazar por la del programa oficial cuando esté.)*

**Año:** 4º · **Semestre:** 2º · **Docentes:** por definir · **Condición buscada:** por definir · [[condiciones-cg]]

> 🚧 **Materia recién dada de alta (13/08/2026).** Este MOC es un esqueleto. Las unidades,
> fechas y condiciones se completan cuando llegue el material de cátedra. Nada de lo que
> figure acá debe darse por cierto hasta entonces.

## ⏰ Próximas fechas

| Fecha | Qué | |
|---|---|---|
| — | *Sin fechas cargadas todavía* | ⚪ |

Cronograma completo: [[cronograma-cg]]

## 📚 Unidades

| # | Unidad | Parcial | Estado |
|---|---|---|---|
| — | *Pendiente de cargar el programa* | — | ⚪ |

## 🧠 Mapa de conceptos

*Todavía sin conceptos atomizados. A medida que se cursa, cada nota de `04-Conceptos/`
se enlaza acá agrupada por tema.*

## ✍️ Trabajos prácticos

| # | TP | Unidad | Estado |
|---|---|---|---|
| — | *Sin TPs liberados* | — | ⚪ |

## 🚀 Proyecto / trabajo final

Todavía **no se sabe** si la materia tiene un proyecto integrador. La carpeta
`03-Proyecto-Catedra/` está creada y vacía a la espera de esa confirmación.

## 📎 Seguimiento

[[cronograma-cg]] · [[condiciones-cg]]

## 🗓️ Clases

*Sin clases registradas.*

## 📁 Material de cátedra

Los PDFs y PPTs oficiales van en `99-Material-Catedra/`. **No se editan** — son la fuente
de verdad; todo lo demás es elaboración propia.

## 🔧 Recursos

`05-Recursos/` — links, papers, videos y documentación de las librerías que use la cátedra
(el stack todavía está por confirmar).

# Computación Gráfica (2026)

Proyecto de estudio de la materia. Cátedra UCC Facultad de Ingeniería, Plan 2016. 4º año, 2º semestre — se cursa en paralelo con [[OAE]].

> ⚠️ **Estado: esqueleto recién creado (13/08/2026).** Todavía no hay programa, cronograma,
> régimen de cursada ni material de cátedra cargado. **No inventar** unidades, fechas,
> nombres de docentes ni contenidos: los campos marcados como `POR DEFINIR` se completan
> cuando Agustín traiga el material. Si falta un dato, preguntarle.

## Esto es un vault de Obsidian

La carpeta raíz `~/Documents/Facultad/` es un **vault de Obsidian**. Antes de crear o editar notas, leer `../00-Sistema/Convenciones.md` — ahí están las reglas de nombres, frontmatter y enlaces.

Reglas que hay que respetar sí o sí al escribir notas:

- **Frontmatter YAML obligatorio** en toda nota nueva (`tipo`, `materia`, `unidad`, `parcial`, `estado`, `tags`).
- **Wikilinks `[[Nombre exacto]]`**, no rutas relativas ni markdown links. Obsidian resuelve por nombre de archivo, así que el enlace tiene que coincidir con el `stem` del `.md`.
- **Nunca dejar un wikilink roto.** Después de editar, validar con (ignora los enlaces que estén dentro de bloques o spans de código, que Obsidian no resuelve):
  ```bash
  cd ~/Documents/Facultad && python3 -c "
  import pathlib,re; V=pathlib.Path('.')
  n={p.stem for p in V.rglob('*.md')}
  strip=lambda s: re.sub(r'\`[^\`\n]*\`','',re.sub(r'\`\`\`.*?\`\`\`','',s,flags=re.S))
  r=[(str(p),t) for p in V.rglob('*.md') if 'Plantillas' not in str(p)
     for t in re.findall(r'\[\[([^\]|#]+)', strip(p.read_text())) if t.strip() not in n]
  print(r or 'OK')"
  ```
- **Diagramas en Mermaid, nunca en ASCII art.** Vale tanto para teóricos (unidades, conceptos)
  como para prácticos (TPs, entregas). Obsidian renderiza Mermaid nativo, no hay que instalar
  nada. `flowchart` para casi todo, `quadrantChart` para matrices 2×2, `mindmap` para mapas de
  tema, y SVG inline solo cuando Mermaid no da. Paleta y detalles en
  `../00-Sistema/Convenciones.md`; tipos probados en `../00-Sistema/_test-render.md`.
- Cada concepto nuevo va como **nota atómica** en `04-Conceptos/` con su bloque `## Conexiones` (3-6 enlaces, cada uno con el motivo). Un enlace sin explicación no sirve para estudiar.
- Conceptos transversales **no se duplican** por materia: se enlaza la misma nota.

### Particularidad de esta materia: matemática y código

Computación Gráfica es más formal que OAE. Dos convenciones extra:

- **Fórmulas en LaTeX**, que Obsidian renderiza nativo: `$...$` inline y `$$...$$` en bloque.
  Las transformaciones, matrices y productos vectoriales van así, nunca como texto plano.
- **Código y pseudocódigo en bloques con lenguaje** (` ```glsl `, ` ```cpp `, ` ```python `).
  Los shaders y algoritmos (Bresenham, scanline, etc.) se guardan como código real, no como
  descripción en prosa.
- Los ejemplos visuales (imágenes renderizadas, capturas) van junto a la nota que los usa,
  con nombre descriptivo, igual que en OAE (`Actividad5-Infografia-...png`).

## Estructura

```
CompuGrafica/
├── CompuGrafica.md         ← MOC de la materia, puerta de entrada
├── CLAUDE.md               ← este archivo
├── 00-Seguimiento/         cronograma · condiciones
├── 01-Unidades/            UX-Nombre/UX-Nombre.md (nota índice + resumen extendido)
├── 02-TPs/
├── 03-Proyecto-Catedra/    vacía — todavía no se sabe si la materia tiene proyecto integrador
├── 04-Conceptos/           notas atómicas ← el corazón del grafo
├── 05-Recursos/            links, papers, videos, docs de librerías
├── 06-Clases/              YYYY-MM-DD - Clase UX.md
└── 99-Material-Catedra/    PDFs y PPTs oficiales — FUENTE DE VERDAD, no se editan
```

## Método de trabajo: aprendizaje asistido / progresivo

Igual que en OAE: **no volcar resúmenes completos de una sola vez.** Por cada Unidad:

1. **Diagnóstico**: preguntar qué ya sabe Agustín del tema antes de explicar.
2. **Explicación guiada**: ir concepto por concepto, chequeando comprensión (preguntas socráticas, no monólogos).
3. **Resumen incremental**: recién ahí escribir/actualizar `01-Unidades/UX-.../UX-....md` con lo ya visto.
4. **Atomizar**: crear las notas de `04-Conceptos/` correspondientes y enlazarlas desde la nota de unidad.
5. **Autoevaluación**: 5-10 preguntas de repaso al cerrar la unidad, en `autoevaluacion.md` de esa unidad.
6. **Repaso espaciado**: antes de arrancar una unidad nueva, repasar brevemente la anterior.

Las Unidades y TPs se crean progresivamente a medida que se cursan, no todas de una.

**Ajuste para materia técnica:** en Computación Gráfica la autoevaluación no puede ser solo
teórica. Cuando el tema lo permita, la ejercitación incluye **resolver a mano** (multiplicar
la matriz, trazar la línea con Bresenham, calcular la normal) y **verificar con código** si
hay entorno disponible. Una fórmula que no se sabe aplicar a un caso concreto no está estudiada.

## Trigger de contexto

Cuando el usuario escriba `/compugrafica`, cargar este archivo + `00-Seguimiento/cronograma.md` + `00-Seguimiento/condiciones.md` antes de responder — ver `~/.claude/commands/compugrafica.md`.

## Estado de la cursada

- **Docentes: POR DEFINIR.**
- **Programa y unidades: POR DEFINIR** — falta el PDF del programa 2026.
- **Fechas de parciales y entregas: POR DEFINIR** — ver `00-Seguimiento/cronograma.md`.
- **Régimen de cursada / condición buscada: POR DEFINIR** — Agustín todavía no decidió si va
  por promoción directa o regular; ver `00-Seguimiento/condiciones.md`.
- **¿Tiene proyecto integrador? POR DEFINIR.** La carpeta `03-Proyecto-Catedra/` está creada
  pero vacía a propósito.
- **Herramientas / lenguaje de la cursada: POR DEFINIR** (OpenGL, WebGL, Processing, Unity,
  Blender…). Dato importante: condiciona cómo se escriben los TPs y qué va en `05-Recursos/`.

## Cómo se completa este esqueleto

Cuando llegue el material, en este orden:

1. Agustín mueve los PDFs oficiales a `99-Material-Catedra/`.
2. Leer el **programa** completo → llenar la tabla de unidades en `CompuGrafica.md` y el
   bloque "Estado de la cursada" de acá.
3. Leer el **régimen de cursada / condiciones** → completar `00-Seguimiento/condiciones.md`
   y fijar el objetivo de nota.
4. Leer el **cronograma** → completar `00-Seguimiento/cronograma.md` y la tabla de próximas
   fechas del MOC.
5. Actualizar la fila de la materia en `../Facultad.md`.
6. Recién ahí arrancar con la Unidad 1 siguiendo el método progresivo.

## Reglas heredadas de OAE que aplican acá

- **Calendario / Recordatorios de Apple:** antes de crear nada en Apple Calendar o Reminders,
  mostrarle a Agustín la lista propuesta para que la confirme. No ejecutar `osascript` para
  crear eventos sin esa confirmación explícita previa. Si se crean, usar un calendario y una
  lista dedicados llamados **"CompuGrafica"** (en OAE existen los suyos, no mezclar).
- **No inventar consignas de TPs** que la cátedra todavía no liberó. Esperar a que Agustín
  las cargue y mientras tanto trabajar solo con la unidad teórica.
- **Versionado del material:** si la cátedra reemplaza un PDF, archivar el viejo en
  `99-Material-Catedra/_archivo-versiones-viejas/` con el sufijo
  `(version AAAA - REEMPLAZADA)`, releer el nuevo completo y actualizar las notas afectadas
  **marcando explícitamente qué cambió** — Agustín puede haber estudiado la versión anterior.

## Pendientes abiertos

- Conseguir el programa 2026 de la materia.
- Confirmar docentes y comisión.
- Confirmar régimen de cursada (promoción directa vs. regular) y fechas de parciales.
- Confirmar si hay proyecto/trabajo final integrador.
- Confirmar el stack técnico de la cursada.

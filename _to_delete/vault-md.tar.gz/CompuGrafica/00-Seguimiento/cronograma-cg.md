---
tipo: seguimiento
materia: CompuGrafica
tags: [CompuGrafica, seguimiento, cronograma]
---

**Materia:** [[CompuGrafica]] · Ver también [[condiciones-cg]]

# Cronograma Computación Gráfica 2026

> 🚧 **Sin cargar.** Falta el programa / cronograma oficial de la cátedra.
> **Fuente pendiente:** PDF del programa, a guardar en `99-Material-Catedra/`.
> No completar esta tabla con fechas estimadas — solo con las oficiales.

**Día y horario de cursada:** por definir.

| Sem | Fecha | Teórico | Práctico / Hitos |
|---|---|---|---|
| 1 | — | — | — |

## Fechas clave

*(Cuando estén las fechas reales: listar acá parciales, entregas y recuperatorios. Antes de
cargarlas en Apple Calendar / Reminders, mostrarle la lista a Agustín para que la confirme —
regla del vault. Si se cargan, usar un calendario y una lista dedicados llamados
**"CompuGrafica"**.)*

| Fecha | Evento | Tipo |
|---|---|---|
| — | — | — |

## Registro de clases

Cada clase cursada se anota en `06-Clases/` con el formato `YYYY-MM-DD - Clase UX.md`
y se enlaza desde acá.

*Sin clases registradas todavía.*

---
tipo: seguimiento
materia: CompuGrafica
objetivo: por-definir
tags: [CompuGrafica, seguimiento, condiciones]
---

**Materia:** [[CompuGrafica]] · Ver también [[cronograma-cg]]

# Condiciones de aprobación — Computación Gráfica 2026

> 🚧 **Sin cargar.** Falta el régimen de cursada oficial.
> **Fuente pendiente:** programa / documento de condiciones de la cátedra, a guardar en
> `99-Material-Catedra/`. No suponer que el régimen es igual al de [[OAE]]: cambia por cátedra.

## Qué hay que averiguar

- [ ] % de asistencia mínimo para regular y para promoción.
- [ ] Cantidad de parciales, qué unidades cubre cada uno y si son teóricos, prácticos o mixtos.
- [ ] Nota mínima por evaluación y promedio exigido en cada condición.
- [ ] Cuántos parciales se pueden recuperar y qué pasa si se pierde el recuperatorio.
- [ ] Si los TPs son obligatorios y si tienen nota o son solo aprobado/desaprobado.
- [ ] Si hay trabajo final integrador y cuánto pesa en la nota.
- [ ] Fecha y modalidad del examen final (si la condición no es promoción).

## Regular

*Por definir.*

## Promoción directa

*Por definir.*

## Objetivo de Agustín

**Todavía sin decidir.** Se define cuando se conozca el régimen. En [[OAE]] el objetivo es
promoción directa (≥7); acá queda abierto hasta ver la carga real de la materia.

## Escala de notas

*Por confirmar si la cátedra usa la misma escala porcentual que el resto de la facultad.*

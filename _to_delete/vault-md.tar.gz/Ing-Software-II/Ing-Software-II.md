---
tipo: moc
materia: Ing-Software-II
anio: 4
semestre: 1
estado: cursada
tags: [moc, ing-software-ii]
---

# Ingeniería de Software II

**Año:** 4º · **Semestre:** 1º · **Estado:** cursada · **Vault:** [[Facultad]]

## Material

- `Ingeneiria de Software II.zip` — sin descomprimir

> Materia ya cursada. La estructura está creada por si hace falta recuperar algo (final,
> consulta, o reutilizar conceptos transversales). Si en algún momento se descomprime el
> zip, seguir [[Convenciones]]: carpetas `01-Unidades/`, `04-Conceptos/`, etc.

## Conceptos transversales que podrían compartirse con otras materias

*(a completar si se abre el material)*

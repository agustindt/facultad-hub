---
tipo: moc
materia: OAE
anio: 4
semestre: 2
catedra: UCC Facultad de Ingeniería — Plan 2016
docentes: Judith Disderi (cátedra A) / María Pilar Jular (cátedra B)
estado: cursando
objetivo: promoción directa (≥7)
tags: [moc, OAE]
---

# OAE — Organización y Administración de Empresas

> Cómo se estructuran, dirigen y controlan las organizaciones, y cómo el entorno y la
> cultura condicionan lo que un gerente puede efectivamente hacer.

**Objetivo:** promoción directa → asistencia ≥80% y todas las notas ≥7 · [[condiciones]]

## ⏰ Próximas fechas

| Fecha | Qué | |
|---|---|---|
| **31/08** | [[Entrega 1 - Ambiente Organizacional]] | 🌸 |
| **07/09** | **Parcial 1** — U1 a U4 | 📝 |
| 28/09 | [[Entrega 2 - Guia GestionaRSE]] | 🌸 |
| 12/10 | [[Entrega 3 - Perfiles de Puestos]] | 🌸 |
| 26/10 | [[Entrega 4 - Indicadores de Gestion]] | 🌸 |
| 02/11 | [[Informe Final del Proyecto]] | 🌸 |
| 09/11 | [[Defensa Oral del Proyecto]] | 🎤 |

Cronograma completo: [[cronograma]]

## 📚 Unidades

| # | Unidad | Parcial | Estado |
|---|---|---|---|
| 1 | [[U1-Organizacion-y-Administracion]] | 1 | 🟡 Teoría vista, resumen pendiente |
| 2 | [[U2-Entorno-y-Cultura-Organizacional]] | 1 | 🟢 Resumen escrito, conceptos atomizados |
| 3 | Planificación | 1 | ⚪ 24/08 |
| 4 | Toma de decisiones | 1 | ⚪ 31/08 |
| 5 | RSE | 2 | ⚪ 14/09 |
| 6 | Administración de RRHH | 2 | ⚪ 21/09 |
| 7 | Tablero de Comando | 2 | ⚪ 28/09 |
| 8 | Control y Auditoría | 2 | ⚪ 26/10 |

## 🧠 Mapa de conceptos

### El gerente y su trabajo
[[Administración]] · [[Niveles Gerenciales]] · [[Habilidades Administrativas (Katz)]] ·
[[Roles Gerenciales (Mintzberg)]] · [[Funciones Gerenciales (Fayol)]] · [[Trilema EEE]] ·
[[Toma de Decisiones]]

### La organización
[[Organización]] · [[Organización como Sistema]] · [[Clasificación de Organizaciones]] ·
[[Organización que Aprende]] · [[Organizaciones Exponenciales (ExO)]] ·
[[PTM - Propósito de Transformación Masiva]]

### Las restricciones del gerente ← *la idea que articula la U2* (Figura 3.1)
[[Gerente Omnipotente vs Simbólico]]

### Cultura (restricción interna)
[[Cultura Organizacional]] · [[Dimensiones de la Cultura Organizacional]] ·
[[Cultura Fuerte vs Débil]] · [[Origen y Sostenimiento de la Cultura]] ·
[[Transmisión de la Cultura]] · [[Iceberg de la Cultura Organizacional]] ·
[[Efectos de la Cultura sobre Roles y Misiones]]

### Entorno (restricción externa)
[[Entorno Organizacional]] · [[Entorno General y Específico]] · [[Componentes del Entorno]] ·
[[Incertidumbre Ambiental]] · [[Partes Interesadas]] · [[Gestión y Control del Entorno]] ·
[[Entorno Global y Globalización]] · [[Posturas ante el Entorno Global]] ·
[[Hofstede y GLOBE]]

### Herramientas de análisis
[[PESTEL]] · [[FODA]] · [[5 Fuerzas de Porter]] *(⚠️ fuera del deck 2026)*

## ✍️ Trabajos prácticos

| # | TP | Unidad | Estado |
|---|---|---|---|
| 1 | [[TP1-Organizacion-y-Administracion]] | U1 | 📄 Entregado (`.docx`) |
| 2 | [[TP2-Entorno-y-Cultura-Organizacional]] | U2 | 🟢 Resuelto sobre **McDonald's** · PDF listo, falta entregar |

> ✅ **11/08/2026 — guía de TPs actualizada.** La versión nueva trae el **TP2 y el TP3
> completos** y el **TP4 a medias** (solo la reflexión final sobre la entrevista a Woods
> Staton). Del TP5 al TP8 siguen vacíos: se liberan semana a semana. **No inventar consignas.**
> Mover `~/Downloads/OAE-Guia-TP .docx.pdf` a `99-Material-Catedra/` y archivar la vieja.

> 📌 **10/08/2026 — la profe reemplazó el PDF de U2** por una versión 2026 (Robbins & Coulter).
> Varios términos evaluables cambiaron y se eliminaron temas. Ver el detalle en
> [[U2-Entorno-y-Cultura-Organizacional]] y [[2026-08-10 - Clase U2]].

## 🚀 Proyecto de cátedra (= Parcial 2)

Empresa: [[Clickie iA - Perfil de la Empresa]] · Seguimiento: [[tracker-proyecto]]

## 📎 Seguimiento

[[cronograma]] · [[condiciones]] · [[tracker-proyecto]]

## 🗓️ Clases

[[2026-08-10 - Clase U2]]

## 📁 Material de cátedra

Los PDFs y PPTs oficiales están en `99-Material-Catedra/`. **No se editan** — son la fuente
de verdad; todo lo demás es elaboración propia.

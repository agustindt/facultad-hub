---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, cultura]
---

# Origen y Sostenimiento de la Cultura

> Proceso por el cual una cultura nace de la filosofía de los fundadores y se mantiene mediante la selección, la alta dirección y la socialización (Figura 3.8).

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**Figura 3.8 — Establecimiento y mantenimiento de la cultura:**

```mermaid
flowchart LR
    F["<b>Filosofía de los<br/>fundadores</b><br/><i>el origen</i>"] --> S["<b>Criterios de<br/>selección</b><br/><i>quién entra</i>"]
    S --> AD["<b>Alta dirección</b><br/><i>qué se premia y tolera</i>"]
    S --> SOC["<b>Socialización</b><br/><i>el nuevo se adapta</i>"]
    AD --> CU["<b>CULTURA<br/>ORGANIZACIONAL</b>"]
    SOC --> CU
    style F fill:#4DB6AC,stroke:#00897B,color:#fff
    style CU fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

1. **Filosofía de los fundadores de la organización** — el origen. Imprimen su visión de lo
   que la organización debe ser; no arrastran hábitos previos.
2. **Criterios de selección** — se filtra el ingreso: entran quienes calzan con esos valores.
   Primer mecanismo de sostenimiento.
3. Desde ahí, **dos vías**:
   - **Alta dirección** — lo que los directivos dicen y sobre todo **hacen** fija las normas:
     qué se premia, cuánta libertad se da, qué conducta se tolera.
   - **Socialización** — el empleado nuevo **se adapta** a la cultura existente; evita que
     traiga hábitos que perturben las creencias establecidas.

> **Detalle del diagrama que conviene reproducir bien:** la alta dirección alimenta a la
> socialización (hay una flecha de una a otra), y **ambas** desembocan en la cultura. No es
> una cadena lineal ni dos ramas totalmente independientes.

**Distinción origen / sostenimiento:** el paso 1 explica de dónde *viene* la cultura; los
pasos 2 y 3 explican por qué *no se disuelve* con la rotación de personal.

## Conexiones

- [[Cultura Organizacional]] — es lo que este proceso produce
- [[Transmisión de la Cultura]] — el mecanismo concreto por el que se socializa a los nuevos
- [[Cultura Fuerte vs Débil]] — la fuerza de la cultura de origen es uno de los factores del tipo
- [[Clickie iA - Perfil de la Empresa]] — hay que reconstruir este proceso para la empresa del proyecto

## En el parcial

Reproducir la Figura 3.8 con las flechas correctas y aplicarla a un caso (Netflix).

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

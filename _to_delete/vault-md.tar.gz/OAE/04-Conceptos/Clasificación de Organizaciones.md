---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, organizacion, taxonomia]
---

# Clasificación de Organizaciones

> Criterios con los que se tipifica una organización: capital, finalidad, forma jurídica, tamaño, alcance, duración y actividad.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

**Taxonomía por estructura y capital**

| Criterio | Categorías |
|---|---|
| **Integración del capital** | Privadas · Estatales · Mixtas |
| **Origen del capital** | Nacional · Extranjera · Mixta |
| **Finalidad** | Con fines de lucro · Sin fines de lucro (comunitarias, educativas, culturales) |
| **Forma jurídica** | Unipersonal · Colegiada (SA, SRL) · Cooperativa · Fundación |

**Taxonomía por operación y alcance**

| Criterio | Categorías |
|---|---|
| **Tamaño** | Grandes · Medianas · Pequeñas (categorización MiPymes) |
| **Alcance geográfico** | Locales · Nacionales · Multinacionales · Globales |
| **Duración** | Permanentes · Temporales |
| **Tipo de actividad** | Industriales (extractivas, manufactureras) · Comerciales · Servicios |

**Sobre el tamaño:** no se mide sólo por cantidad de empleados. La categorización MiPymes
argentina (ARCA) combina **facturación anual, cantidad de personal y sector de actividad**.
Esto importa para el proyecto: una startup puede facturar como mediana con plantilla chica.

## Conexiones

- [[Organización]] — es lo que se está clasificando
- [[Entorno Global y Globalización]] — el alcance geográfico se cruza con las formas de internacionalización
- [[Posturas ante el Entorno Global]] — multinacional/global se corresponde con una postura del gerente

## En el parcial

Dan una empresa y piden clasificarla por **todos** los criterios. Respondé criterio por criterio, no en prosa.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

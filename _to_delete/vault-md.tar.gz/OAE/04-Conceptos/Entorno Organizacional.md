---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno]
---

# Entorno Organizacional

> Conjunto de fuerzas e instituciones fuera de la organización que pueden influir en su desempeño; fuente de recursos, oportunidades y amenazas.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**Objetivo del tema** (efecto **acción-reacción**): comprender su **naturaleza e
importancia**, sus **parámetros y determinantes**, para que el gerente logre **ventajas
competitivas** al estructurar su organización dentro de la dinámica que esos ambientes
poseen.

La relación es de **doble vía**: el entorno **influye** y la organización **reacciona**.

## Naturaleza dual

Como fuente de los recursos necesarios para la supervivencia, del entorno surgen a la vez:

- **OPORTUNIDADES**
- **AMENAZAS**

Por eso no puede evaluarse como "bueno" o "malo" en bloque.

**Carácter:** local, regional, nacional o internacional.

**Regla textual de la cátedra:**

> **NO SE LO PUEDE IGNORAR · REACCIONAR e INTENTAR CONTROLAR**

## Cómo se organiza el tema

```mermaid
flowchart LR
    E["<b>ENTORNO<br/>ORGANIZACIONAL</b>"] --> G["<b>GENERAL</b><br/><i>efecto indirecto</i>"]
    E --> S["<b>ESPECÍFICO</b><br/><i>efecto directo e inmediato</i>"]
    G --> G1["6 componentes<br/>(Figura 3.2)"] --> G2(["se analiza con<br/>PESTEL"])
    S --> S1["Participantes<br/>(Figura 3.4)"] --> S2(["gestión de<br/>stakeholders"])
    style G fill:#4DB6AC,stroke:#00897B,color:#fff
    style S fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

Y afecta al gerente por **dos vías**: la [[Incertidumbre Ambiental]] y las
[[Partes Interesadas]].

## Conexiones

- [[Gerente Omnipotente vs Simbólico]] — el entorno es la restricción EXTERNA de la Figura 3.1
- [[Entorno General y Específico]] — la división principal del entorno
- [[Componentes del Entorno]] — el desglose del entorno general
- [[Incertidumbre Ambiental]] — primera vía por la que afecta al gerente
- [[Partes Interesadas]] — segunda vía por la que afecta al gerente
- [[Gestión y Control del Entorno]] — qué puede hacer el gerente al respecto
- [[FODA]] — oportunidades y amenazas son la mitad externa del FODA
- [[Organización como Sistema]] — el entorno aparece en los dos extremos del sistema abierto

## En el parcial

La naturaleza dual (oportunidades **y** amenazas) es la respuesta esperada, no sólo una de las dos.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, organizacion, fundamentos]
---

# Organización

> Sistema social con un propósito definido que interactúa con el medio que lo circunda.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

**Concepto ampliado:** conjunto **interrelacionado e interdependiente** de recursos
—humanos, materiales, tecnológicos, de información y financieros— que **interactúan en un
accionar sinérgico**, orientados hacia objetivos determinados, con permanente intercambio
con el medio ambiente (macroambiente y ambiente intermedio).

**Propósito:** producción y distribución de los medios necesarios para cumplir los
**reclamos y demandas de la sociedad**.

**Tres características que la definen:**

1. **Propósito definido** — existe por una razón, no por accidente.
2. **Estructura deliberada** — el orden interno es diseñado, no espontáneo.
3. **Personas** — sin gente no hay organización.

La palabra "sinérgico" no es decorativa: implica que el resultado del conjunto es mayor
que la suma de los recursos por separado. Ese excedente es lo que justifica que la
organización exista en vez de que cada recurso opere suelto.

## Conexiones

- [[Organización como Sistema]] — es el modelo que muestra ese intercambio con el medio en forma de insumos, proceso y productos
- [[Administración]] — es la disciplina que estudia y opera sobre las organizaciones
- [[Clasificación de Organizaciones]] — los criterios con que se las tipifica
- [[Entorno Organizacional]] — el 'medio que la circunda' del que habla la definición

## En el parcial

Piden la definición breve y las 3 características. No confundir *organización* (la entidad) con *organizar* (la función gerencial de Fayol).

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

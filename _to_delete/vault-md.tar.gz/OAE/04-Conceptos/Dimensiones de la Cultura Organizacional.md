---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, cultura]
---

# Dimensiones de la Cultura Organizacional

> Las siete dimensiones con las que se describe el perfil cultural de una organización (Figura 3.5).

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

| Dimensión | Grado en que… |
|---|---|
| **Atención a los detalles** | …se espera que los empleados exhiban precisión, capacidad de análisis y atención a los detalles |
| **Orientación hacia los resultados** | …los gerentes se enfocan en el logro de resultados más que en la manera de alcanzarlos |
| **Orientación hacia la gente** | …las decisiones administrativas toman en cuenta los efectos que tendrán en el personal |
| **Orientación hacia los equipos** | …el trabajo se organiza en equipos y no en función del esfuerzo individual |
| **Agresividad** | …los empleados son más agresivos y competitivos que cooperativos |
| **Estabilidad** | …las decisiones y acciones hacen hincapié en mantener el *statu quo* |
| **Innovación y toma de riesgos** | …los empleados son alentados a innovar y asumir riesgos |

> ⚠️ **Cambió respecto de la versión vieja:** la dimensión **"Energía"** ya no existe — fue
> reemplazada por **"Agresividad"**. Si estudiaste de un resumen viejo, corregí esto.

Cada organización tiene un **perfil** distinto según cuánto puntúa en cada dimensión. No son
categorías excluyentes: son **escalas**.

Notar la tensión interna del listado: *estabilidad* vs. *innovación y riesgos*, y
*orientación a resultados* vs. *orientación a la gente*. Un perfil cultural es en buena
medida cómo la organización resolvió esas tensiones.

**Ejercicio de la cátedra:** comparar **Organización A vs. Organización B** (Robbins), y
describir la cultura de la propia clase usando las 7 dimensiones.

## Conexiones

- [[Cultura Organizacional]] — son las variables con que se la describe
- [[Cultura Fuerte vs Débil]] — la fuerza es cuánto se comparten estos valores, no qué valores son
- [[Iceberg de la Cultura Organizacional]] — las dimensiones se manifiestan en la parte visible e invisible del iceberg
- [[Hofstede y GLOBE]] — el equivalente para culturas nacionales en vez de organizacionales

## En el parcial

Puntuar las 7 dimensiones de una empresa dada, o describir la cultura de la clase con ellas. **Agresividad, no Energía.**

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

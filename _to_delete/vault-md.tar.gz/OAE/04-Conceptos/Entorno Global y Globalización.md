---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno, globalizacion]
---

# Entorno Global y Globalización

> El componente global del entorno: la globalización de los mercados y las seis formas en que una organización se internacionaliza.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**CMN — Corporación Multinacional:** empresa que opera en varios países. Es el término
paraguas del que cuelgan los tres tipos de [[Posturas ante el Entorno Global]].

## Globalización de los mercados

- Apertura del comercio
- Mayor competencia
- Eliminación de las barreras geográficas
- Apertura "a lo bueno y lo malo"
- Efecto dominó
- Pregunta abierta de la cátedra: *¿equivale a **AMERICANIZACIÓN**?*

**¿Cómo administrarlo?** Empresas heterogéneas → más crecimiento en ventas y más
rentabilidad. Y adoptar una postura ante el mundo: etnocéntrica (patria), policéntrica
(país local), geocéntrica (mundo).

## Cómo se vuelven globales las organizaciones — Figura 4.4

Escalera de **inversión global creciente**, de mínima a cuantiosa:

```mermaid
flowchart BT
    E1["<b>1 · Abastecimiento global</b><br/><i>inversión mínima</i>"] --> E2["<b>2 · Exportación e importación</b>"]
    E2 --> E3["<b>3 · Otorgamiento de licencias</b>"]
    E3 --> E4["<b>4 · Franquicia</b>"]
    E4 --> E5["<b>5 · Alianza estratégica<br/>Empresa conjunta</b>"]
    E5 --> E6["<b>6 · Subsidiaria extranjera</b><br/><i>inversión cuantiosa</i>"]
    style E1 fill:#4DB6AC,stroke:#00897B,color:#fff
    style E6 fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

A medida que se **sube**, aumentan la **inversión** y el **compromiso/riesgo**.

> ⚠️ **Cambió respecto de la versión vieja:** antes eran **3 fases** agrupadas; ahora la
> cátedra usa los **6 escalones** de la Figura 4.4. Memorizá los seis y el orden.

Regla: a medida que se sube, **aumentan la inversión y el compromiso/riesgo**.

## Acuerdos y bloques regionales de comercio

**Organismos globales:** OMC (vigila y promueve el comercio mundial).
**Regionales:** Mercosur · UE · NAFTA/USMCA · Alianza del Pacífico · CARICOM · SICA · ASEAN ·
RCEP · CFTA, entre otros (la cátedra mostró el mapa de bloques de elordenmundial.com).

## Conexiones

- [[Posturas ante el Entorno Global]] — las tres posturas de la CMN ante el mundo
- [[Componentes del Entorno]] — es el desarrollo del componente global
- [[Clasificación de Organizaciones]] — el alcance geográfico se define acá
- [[Hofstede y GLOBE]] — operar globalmente exige caracterizar culturas nacionales
- [[Gestión y Control del Entorno]] — las alianzas estratégicas son a la vez estrategia de control y escalón 5

## En el parcial

Ordenar los **6 escalones** de la Figura 4.4 de menor a mayor inversión. Es el cambio más concreto respecto de la versión vieja.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

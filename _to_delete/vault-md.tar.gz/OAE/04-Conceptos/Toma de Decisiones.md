---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: borrador
tags: [OAE, U1, decisiones, gerencia]
---

# Toma de Decisiones

> Elección entre dos o más alternativas. Está en el centro de las cuatro funciones gerenciales.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

**Alcance del tema** (se desarrolla en profundidad en U4):

- Clases de problemas y de decisiones
- Proceso de toma de decisiones
- Decisiones en las funciones gerenciales
- Condiciones para decidir
- Estilos de toma de decisiones
- Herramientas

**Lo que hay que tener claro desde U1:** decidir no es una función más al lado de planear,
organizar, dirigir y controlar. Es lo que ocurre **dentro** de cada una de ellas. Por eso
en el diagrama del ciclo de Fayol aparece en el centro y no como quinta caja.

Cuatro de los diez roles de Mintzberg son **roles de decisión**, lo que confirma cuánto
del trabajo gerencial es esencialmente decidir.

## Conexiones

- [[Funciones Gerenciales (Fayol)]] — está en el centro del ciclo
- [[Roles Gerenciales (Mintzberg)]] — cuatro de los diez roles son de decisión
- [[Incertidumbre Ambiental]] — es lo que vuelve difícil decidir: a más incertidumbre, más información necesaria
- [[Cultura Organizacional]] — la cultura define qué grado de riesgo se tolera al decidir

## En el parcial

Se profundiza en **U4 — Toma de decisiones**. Desde U1 basta con la definición y la ubicación en el ciclo.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

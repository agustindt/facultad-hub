---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
estado: borrador
tags: [OAE, U2, entorno, herramienta, transversal]
---

# FODA

> Matriz que cruza el análisis interno (fortalezas y debilidades) con el externo (oportunidades y amenazas).

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

```mermaid
quadrantChart
    title Matriz FODA
    x-axis "POSITIVO" --> "NEGATIVO"
    y-axis "EXTERNO (entorno)" --> "INTERNO (organizacion)"
    quadrant-1 "D — DEBILIDADES"
    quadrant-2 "F — FORTALEZAS"
    quadrant-3 "O — OPORTUNIDADES"
    quadrant-4 "A — AMENAZAS"
```

**El eje que ordena la matriz** es el mismo de toda la unidad: lo **interno** (cultura y
recursos propios) frente a lo **externo** (el entorno) — la Figura 3.1 otra vez.

- **F y D** salen del análisis interno — recursos, capacidades, cultura.
- **O y A** salen del entorno, y se corresponden con su **naturaleza dual**. Se alimentan de
  la matriz [[PESTEL]] para el entorno general.

**Error clásico a evitar:** poner en Oportunidades algo que la empresa ya tiene (eso es una
Fortaleza) o en Amenazas una carencia propia (eso es una Debilidad). El criterio es **quién
controla el factor**: si es la organización, es interno.

> 📌 **Estado del material:** el deck 2026 de U2 desarrolla PESTEL y su matriz, pero **no
> incluye una lámina de FODA**. El `.pptx` "OAE U2 FODA y PESTEL" sigue siendo casi todo
> imágenes. Lo de arriba es la matriz estándar; si la cátedra pide la versión cruzada
> (estrategias FO-FA-DO-DA), hay que pedirle el material.

**Nota transversal:** herramienta de uso general. Es la misma nota para todas las materias.

## Conexiones

- [[Entorno Organizacional]] — O y A son la naturaleza dual del entorno
- [[PESTEL]] — su matriz alimenta el lado externo del FODA
- [[Cultura Organizacional]] — es parte del análisis interno: fortalezas y debilidades
- [[Gerente Omnipotente vs Simbólico]] — el eje interno/externo del FODA es el de la Figura 3.1
- [[Entrega 1 - Ambiente Organizacional]] — es una de las herramientas a aplicar sobre Clickie

## En el parcial

El criterio interno/externo es lo que se corrige con más rigor.

---
Fuente: deck 2026 de U2 (no trae lámina de FODA) + `99-Material-Catedra/OAE U2 FODA y PESTEL.pptx`

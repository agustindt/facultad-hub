---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno]
---

# Entorno General y Específico

> División del ambiente externo según incida de manera indirecta (general) o directa e inmediata (específico).

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**Ambiente externo:** conjunto de fuerzas e instituciones **fuera** de la organización que
pueden influir en su desempeño.

> **Cada organización tiene un entorno ÚNICO.**

| | **GENERAL** | **ESPECÍFICO** |
|---|---|---|
| Definición | Condiciones generales externas que inciden **indirectamente** | **Efecto directo e inmediato** de las decisiones y actos de los gerentes, y pertinentes para el logro de las metas de la organización |
| Se ve en | **Figura 3.2** — Componentes del entorno externo | **Figura 3.4** — Participantes de la organización |
| Contenido | Político/Legal · Económico · Sociocultural · Demográfico · Tecnológico · Global | Empleados · Clientes · Sindicatos · Accionistas · Comunidades · Proveedores · Medios de comunicación · Gobiernos · Competidores · Asociaciones comerciales e industriales · Grupos de acción política y social |
| Herramienta | [[PESTEL]] | Gestión de [[Partes Interesadas]] |

## El criterio que decide, y que se pregunta

No es la distancia física ni el tamaño: es la **inmediatez del efecto**. Un cambio en la tasa
de interés (general) afecta a todas las empresas; que tu principal proveedor suba el precio
(específico) te afecta mañana.

> 📌 **Novedad importante del deck 2026:** el entorno específico ya **no** se presenta como
> una lista corta (clientes / proveedores / competencia / grupos de presión), sino con la
> **Figura 3.4 de participantes**, que es la misma lista de los stakeholders. Es decir:
> **entorno específico ≈ partes interesadas**. Antes eran dos temas separados.

**Actividad de la cátedra:** ¿cuáles son los participantes internos de la universidad?
Y: *¿cómo podría un gerente mantenerse informado sobre el impacto que tendrá el entorno
externo en su negocio?*

**➡️ Es la consigna del [[TP2-Entorno-y-Cultura-Organizacional]]** (TP2.1: clasificar las
fuerzas según pertenezcan al entorno general o específico).

## Conexiones

- [[Entorno Organizacional]] — es la división principal del concepto
- [[Componentes del Entorno]] — el desglose de los 6 componentes del entorno general
- [[Partes Interesadas]] — el entorno específico se presenta con la misma figura de participantes
- [[PESTEL]] — la herramienta para analizar el entorno general
- [[TP2-Entorno-y-Cultura-Organizacional]] — el TP2.1 pide exactamente esta clasificación

## En el parcial

Clasificar fuerzas sueltas en general o específico, **con el criterio de inmediatez** explicitado. Es el TP2.1, así que es casi seguro que cae.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

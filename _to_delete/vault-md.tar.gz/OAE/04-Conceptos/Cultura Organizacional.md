---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, cultura]
---

# Cultura Organizacional

> Sistema de significados e ideas compartidas por los miembros de una organización, que determina su comportamiento interno y externo (I+E).

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

Es la **personalidad** de la organización — *"el modo de cómo se hacen las cosas"*.

Se compone de **valores, símbolos, ritos, mitos y usos**, que:
- **evolucionan con el tiempo**,
- determinan la **percepción y reacción** de los empleados,
- **influyen en la resolución de problemas**.

## Tres características

- **PERCEPTIVA** — es lo que los miembros *perciben*, no lo que la organización declara.
- **COMPARTIDA** — no es la opinión de uno; hay significados comunes.
- **DESCRIPTIVA** — describe cómo se perciben las cosas, **no las evalúa** como buenas o malas.

La tercera es la que más se equivoca: la cultura no se juzga, se describe.

## Decisiones gerenciales en las que influye

| Función | Qué define la cultura |
|---|---|
| **Planeación** | Grado de riesgo de los planes · si planifican individuos o grupos · cuánto investiga la dirección el ambiente |
| **Organización** | Autonomía de los puestos · tareas individuales o en equipo · trato entre gerentes de distintos departamentos |
| **Dirección** | Interés de los gerentes por la satisfacción del empleado · estilos de liderazgo apropiados · si se suprimen los desacuerdos, incluso los constructivos |
| **Control** | Controles externos vs. autocontrol · criterios de evaluación de desempeño · repercusiones de excederse del presupuesto |

## Temas actuales

Creación de culturas **ética**, de **innovación**, **sensible a clientes** y de
**espiritualidad** (trabajo–vida interior). **Apertura a la diversidad** (género, cultura,
raza). Y la pregunta de si existe una **cultura uniforme**: hay denominadores comunes,
afectados por el progreso de comunicaciones y transporte, y el **idioma** es el factor que a
la vez conecta e inhibe una cultura global.

**Caso de aplicación de la cátedra:** *Libertad y responsabilidad en **Netflix*** (Robbins,
pág. 102). Cultura arraigada en libertad y responsabilidad: contratan gente inteligente y
les dan libertad de hacer lo que mejor hacen; sin revisiones de desempeño anuales ni
burocracia; sin política de gastos ni proceso de aprobación; vacaciones ilimitadas.

## Conexiones

- [[Gerente Omnipotente vs Simbólico]] — la cultura es la restricción INTERNA de la Figura 3.1
- [[Dimensiones de la Cultura Organizacional]] — las 7 variables con que se la describe
- [[Cultura Fuerte vs Débil]] — los dos tipos según cuán arraigada esté
- [[Origen y Sostenimiento de la Cultura]] — de dónde viene y cómo se perpetúa
- [[Transmisión de la Cultura]] — cómo la aprenden los miembros
- [[Iceberg de la Cultura Organizacional]] — el modelo visible/invisible de la cultura
- [[Efectos de la Cultura sobre Roles y Misiones]] — cómo moldea lo que cada persona hace
- [[Funciones Gerenciales (Fayol)]] — condiciona las decisiones dentro de las cuatro funciones

## En el parcial

Definición + las 3 características. Y aplicar la influencia sobre las 4 funciones a un caso (Netflix es el caso que dio la cátedra).

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

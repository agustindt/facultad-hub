---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, gerencia, niveles, ETO]
---

# Niveles Gerenciales

> Pirámide de tres niveles administrativos —Estratégico, Táctico y Operativo— que ordena quién decide qué y con qué horizonte temporal.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

También llamado **triángulo E-T-O**.

<svg viewBox="0 0 560 285" width="100%" style="max-width:600px" role="img" aria-label="Pirámide de niveles gerenciales estratégico, táctico y operativo">
  <polygon points="230,20 296,80 164,80" fill="#7C5CFF"/>
  <polygon points="164,82 296,82 363,142 97,142" fill="#4DB6AC"/>
  <polygon points="97,144 363,144 430,204 30,204" fill="#FFA726"/>
  <rect x="30" y="212" width="400" height="36" rx="4" fill="var(--background-modifier-border)"/>
  <g text-anchor="middle" font-weight="bold" fill="#fff">
    <text x="230" y="68" font-size="13">E — ESTRATÉGICO</text>
    <text x="230" y="118" font-size="13">T — TÁCTICO</text>
    <text x="230" y="180" font-size="13">O — OPERATIVO</text>
  </g>
  <text x="230" y="235" text-anchor="middle" font-size="12" fill="var(--text-normal)">Niveles organizativos — empleados NO gerenciales</text>
  <g font-size="11" fill="var(--text-muted)">
    <text x="444" y="56">Largo plazo</text>
    <text x="444" y="118">Mediano plazo</text>
    <text x="444" y="180">Corto plazo</text>
  </g>
  <line x1="14" y1="204" x2="14" y2="30" stroke="var(--text-accent)" stroke-width="2" marker-end="url(#ar)"/>
  <defs><marker id="ar" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto">
    <path d="M0,0 L8,4 L0,8 Z" fill="var(--text-accent)"/></marker></defs>
  <text x="8" y="272" font-size="11" fill="var(--text-muted)">↑ más abstracto y orientado al entorno · ↓ más concreto y orientado a la tarea</text>
</svg>

| Nivel | Quién | Qué decide | Horizonte |
|---|---|---|---|
| **E — Estratégico** | Alta gerencia, directores | Rumbo, objetivos globales, relación con el entorno | Largo plazo |
| **T — Táctico** | Gerencia media | Cómo bajar la estrategia a cada área; traduce y coordina | Mediano plazo |
| **O — Operativo** | Gerencia de 1ª línea, supervisores | Ejecución diaria, supervisión directa del trabajo | Corto plazo |

Debajo de la pirámide gerencial están los **niveles organizativos**: empleados no
gerenciales — oficinistas y operativos (directos e indirectos).

**El principio que ordena todo:** cuanto más se sube, más **abstracto** y más orientado al
**entorno**; cuanto más se baja, más **concreto** y más orientado a la **tarea**.

Esa sola gradación explica por qué las habilidades de Katz se distribuyen como se
distribuyen y por qué la mezcla de roles de Mintzberg cambia según el nivel. No memorices
las tres tablas por separado: memorizá el principio y deducí las tablas.

## Conexiones

- [[Habilidades Administrativas (Katz)]] — su peso relativo se distribuye según este eje abstracto↔concreto
- [[Roles Gerenciales (Mintzberg)]] — la mezcla de roles varía según el nivel
- [[Funciones Gerenciales (Fayol)]] — las cuatro funciones se ejercen en los tres niveles, con distinto alcance
- [[Administración]] — es la jerarquía donde se ejerce
- [[Gerente Omnipotente vs Simbólico]] — la discusión sobre cuánto influye realmente quien ocupa estos niveles

## En el parcial

Ubicar puestos concretos en el nivel que corresponde y justificar por horizonte temporal.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

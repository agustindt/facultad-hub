---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
estado: estudiado
tags: [OAE, U2, cultura]
---

# Efectos de la Cultura sobre Roles y Misiones

> Circuito de retroalimentación entre la cultura y el marco social que moldea los roles y misiones dentro de la organización.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

```mermaid
flowchart LR
    CU(["<b>CULTURA</b>"])
    A["Valores, actitudes,<br/>conductas"] --> INST
    CU --> A
    INST["<b>REGLAS, COSTUMBRES,<br/>TRADICIÓN, FOLK-LORE</b>"] --> B["Valores, normas,<br/>creencias, pautas<br/>de comportamiento"]
    B --> CU
    style CU fill:#7C5CFF,stroke:#5B3FD9,color:#fff
    style INST fill:#FFA726,stroke:#F57C00,color:#fff
```

La cultura **baja** hacia la organización como **reglas, costumbres, tradición y folk-lore**,
y esas instituciones **devuelven** valores, normas, creencias y pautas de comportamiento.

> ⚠️ **Cambió en el deck 2026:** antes decía *"LEYES, COSTUMBRES, RELIGIÓN, TRADICIÓN"*;
> ahora es **"REGLAS, COSTUMBRES, TRADICIÓN, FOLK-LORE"**. Salieron *leyes* y *religión*,
> entró **folk-lore**.

**Consecuencia:** los roles y misiones que cada persona asume dentro de la organización
quedan moldeados por ese circuito — **no se definen sólo por el organigrama**. Dos personas
en el mismo casillero, en culturas distintas, hacen trabajos distintos.

**Ejemplos del alcance:** restricciones de horarios comerciales, formas de vestir, modales,
estilos de negociación, protocolos de visita.

## Conexiones

- [[Cultura Organizacional]] — es el concepto que produce estos efectos
- [[Transmisión de la Cultura]] — los vehículos por los que ese circuito opera
- [[Roles Gerenciales (Mintzberg)]] — los roles formales se ven moldeados por la cultura
- [[Componentes del Entorno]] — el componente socio-cultural es la contraparte externa de este circuito

## En el parcial

Explicar por qué el organigrama no alcanza para saber qué hace realmente cada persona. Reproducir el circuito con los términos nuevos.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

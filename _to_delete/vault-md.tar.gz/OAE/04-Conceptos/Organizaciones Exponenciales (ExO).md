---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
autor: Salim Ismail
estado: estudiado
tags: [OAE, U1, organizacion, ExO, innovacion]
---

# Organizaciones Exponenciales (ExO)

> Organizaciones que logran un impacto al menos diez veces mayor que otras de su mismo sector, apoyadas en tecnologías de la información.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

> *"Logran un impacto al menos diez veces mayor que otras de su mismo sector."* — Salim Ismail

Se apoyan en tecnologías de la información, obtienen resultados **exponenciales** frente al
crecimiento aritmético tradicional, y **transforman la abundancia en ventaja competitiva**.

La fórmula tiene un núcleo (el **PTM**) y dos hemisferios de cinco atributos cada uno:

```mermaid
mindmap
  root(("PTM<br/>el núcleo"))
    SCALE["SCALE<br/>hemisferio EXTERNO<br/>creatividad, escalamiento,<br/>incertidumbre"]
      S1["S · Staff on Demand<br/>talento según necesidad,<br/>sin plantilla fija"]
      C1["C · Community & Crowd<br/>co-creación con el público"]
      A1["A · Algorithms<br/>decisiones basadas en datos"]
      L1["L · Leveraged Assets<br/>recursos de terceros<br/>en vez de poseerlos"]
      E1["E · Engagement<br/>fidelidad de los usuarios"]
    IDEAS["IDEAS<br/>hemisferio INTERNO<br/>orden, control,<br/>estabilidad"]
      I2["I · Interfaces<br/>entre equipo y cliente"]
      D2["D · Dashboards<br/>desempeño en tiempo real"]
      E2["E · Experimentation<br/>probar ideas nuevas rápido"]
      A2["A · Autonomy<br/>equipos empoderados"]
      S2["S · Social Technologies<br/>colaboración"]
```

Regla mnemotécnica: **SCALE mira hacia afuera** (aprovecha lo que no es tuyo),
**IDEAS mira hacia adentro** (ordena lo que sí lo es).

## Conexiones

- [[PTM - Propósito de Transformación Masiva]] — es el núcleo de la fórmula ExO
- [[Organización que Aprende]] — la ExO es su versión llevada al extremo
- [[Clickie iA - Perfil de la Empresa]] — la empresa del proyecto encaja en varios atributos SCALE: staff on demand y algoritmos
- [[Trilema EEE]] — los dashboards del atributo D son el mecanismo de la efectividad

## En el parcial

Evaluar si una empresa dada cumple los atributos SCALE e IDEAS (lo hicieron con Epic Games en clase, y la Actividad 5 fue la infografía de Clickie).

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

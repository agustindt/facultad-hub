---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, administracion, fundamentos]
---

# Administración

> Ciencia cuyo objeto de estudio son las organizaciones, y conjunto de técnicas, reglas, principios y normas para operar y transformar esa realidad.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

Tiene **doble carácter**: es *ciencia* (tiene objeto de estudio propio: las organizaciones)
y es *técnica* (conjunto de herramientas para intervenir sobre ellas).

**Jerarquía:** proceso de **adoptar decisiones e impartir órdenes** en representación de los
grupos de miembros de la organización. Apunta a **definir el trabajo y el comportamiento**
necesarios para cumplir los objetivos.

**Por qué estudiarla** — la administración es necesaria en:
- organizaciones de cualquier tamaño (pequeñas ↔ grandes),
- todo tipo de organización (lucrativas ↔ no lucrativas),
- todos los niveles (inferiores ↔ superiores),
- todas las áreas (manufactura, marketing, RRHH, contabilidad, sistemas…).

El argumento de la cátedra es directo: en la vida laboral vas a **administrar o ser
administrado**. No hay tercera opción.

## Conexiones

- [[Organización]] — es su objeto de estudio
- [[Niveles Gerenciales]] — la jerarquía en la que se ejerce
- [[Funciones Gerenciales (Fayol)]] — el proceso concreto que ejecuta
- [[Trilema EEE]] — los criterios con que se juzga si administra bien

## En el parcial

Pregunta corta de definición. Mencioná el doble carácter ciencia/técnica.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
autor: Fayol
estado: estudiado
tags: [OAE, U1, gerencia, funciones, Fayol, POD-C]
---

# Funciones Gerenciales (Fayol)

> Las cuatro funciones del proceso administrativo —planear, organizar, dirigir y controlar— que operan como ciclo cerrado con la decisión en el centro.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

**Gerencia:** coordinación de actividades para que se cumplan con eficiencia, eficacia y
efectividad **por medio de otras personas**.

| Función | Pregunta que responde | Alcance |
|---|---|---|
| **Planear** | QUÉ (metas) y CÓMO (estrategias) | Objetivos, tipos de metas y planes, administración estratégica, técnicas de evaluación del entorno |
| **Organizar** | QUÉ hay que hacer, CÓMO y QUIÉN | Estructuras, diseño organizacional, comunicación, RRHH, cambio e innovación |
| **Dirigir** | Conducir a los participantes y resolver conflictos | Comportamiento organizacional, grupos y equipos, motivación, liderazgo |
| **Controlar** | ¿Se hizo según lo planeado? | Enfoques y tipos de control, proceso de control, herramientas de desempeño |

```mermaid
flowchart LR
    P["PLANEAR<br/><small>qué y cómo</small>"] --> O["ORGANIZAR<br/><small>quién</small>"]
    O --> D["DIRIGIR<br/><small>conducir</small>"]
    D --> C["CONTROLAR<br/><small>¿se cumplió?</small>"]
    C -->|retroalimenta| P
    DEC{{"TOMA DE<br/>DECISIONES"}}
    P -.- DEC
    O -.- DEC
    D -.- DEC
    C -.- DEC
    style DEC fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

**Dos cosas que definen el modelo:**

1. Es un **ciclo cerrado** — el control retroalimenta a la planeación. No es una lista de
   cuatro pasos que termina.
2. En el centro de las cuatro está la **toma de decisiones**. Decidir **no es una quinta
   función**: atraviesa a las otras cuatro.

El conjunto apunta a lograr **eficacia + eficiencia** y, con ellas, los propósitos de la
organización.

## Conexiones

- [[Toma de Decisiones]] — está en el centro del ciclo, atravesando las cuatro funciones
- [[Trilema EEE]] — son los criterios de logro que las funciones persiguen
- [[Roles Gerenciales (Mintzberg)]] — Fayol dice qué debería hacer el gerente; Mintzberg observó qué hace
- [[Cultura Organizacional]] — la cultura condiciona cómo se ejerce cada una de las cuatro funciones
- [[Niveles Gerenciales]] — las cuatro se ejercen en los tres niveles, con distinto alcance

## En el parcial

Clasificar tareas sueltas en una de las cuatro funciones (fue la Actividad FFGG). Ojo: 'asignar responsabilidades' es organizar, 'motivar al personal' es dirigir.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

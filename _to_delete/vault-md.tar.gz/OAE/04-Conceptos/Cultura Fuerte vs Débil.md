---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, cultura]
---

# Cultura Fuerte vs Débil

> Clasificación de las culturas según cuán arraigados y compartidos estén sus valores.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**Factores que definen el tipo:** tamaño, antigüedad, rotación y fuerza de la cultura de origen.

| **FUERTES** | **DÉBILES** |
|---|---|
| Valores **arraigados** e **historias compartidas** | Sin compromiso |
| | Menor dedicación |
| | Menor desempeño |

**Cadena causal textual de la cátedra:**

```mermaid
flowchart LR
    A["Valores<br/>claros"] --> B["Los empleados<br/>saben qué hacer"] --> C["<b>+ DESEMPEÑO</b>"]
    style C fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

## La contracara: ¿la cultura puede ser un lastre?

Es una de las tres preguntas de la actividad "Trends", así que conviene tenerla lista.
Una cultura fuerte no es sin más "la buena". Cuanto más fuerte es:

- **más estrecha el criterio del gerente** — es la restricción interna de la Figura 3.1;
- **más resiste el cambio** — lo que en un entorno dinámico (celda 4) se vuelve una
  desventaja seria.

En síntesis: la fuerza de la cultura es un **activo en entornos estables** y un **pasivo en
entornos turbulentos**.

## Conexiones

- [[Cultura Organizacional]] — es el concepto que se está tipificando
- [[Gerente Omnipotente vs Simbólico]] — una cultura fuerte es lo que estrecha el criterio gerencial
- [[Incertidumbre Ambiental]] — en entornos dinámicos la cultura fuerte se vuelve un obstáculo
- [[Organización que Aprende]] — el paradigma flexible es la respuesta a la rigidez de las culturas fuertes

## En el parcial

«¿La cultura puede ser un lastre para la organización? Explicar» — pregunta textual de la actividad Trends.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

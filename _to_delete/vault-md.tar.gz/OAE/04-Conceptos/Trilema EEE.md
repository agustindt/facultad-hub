---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, gerencia, desempeno, EEE]
---

# Trilema EEE

> Eficiencia, eficacia y efectividad: los tres criterios con que se juzga el rendimiento de la administración.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

| | Foco | Objetivo | Frase | Mecanismo |
|---|---|---|---|---|
| **Eficiencia** (medios) | Aprovechamiento de recursos | Minimizar desperdicios | Hacer las cosas **correctamente** | — |
| **Eficacia** (fines) | Consecución de metas | Maximizar logros | Hacer las cosas **correctas** | — |
| **Efectividad** | Impacto real | — | Hacer las cosas **que corresponden** | **Tableros de comando** |

**Por qué es un trilema y no una lista:** las tres pueden ir en direcciones distintas.

- Se puede ser **eficiente sin ser eficaz**: gastar poquísimos recursos para llegar a la
  meta equivocada.
- Se puede ser **eficaz sin ser eficiente**: alcanzar la meta quemando el triple de
  recursos de lo necesario.
- Y se pueden lograr ambas **sin efectividad**: cumplir la meta con pocos recursos, pero
  que esa meta no genere ningún impacto real.

La administración se esfuerza por las tres a la vez: desperdiciar pocos recursos (alta
eficiencia) **y** lograr grandes objetivos (alta eficacia).

## Conexiones

- [[Funciones Gerenciales (Fayol)]] — las funciones son el medio para lograr las tres E
- [[Administración]] — es el criterio con que se evalúa si administra bien
- [[Organizaciones Exponenciales (ExO)]] — la efectividad se mide con tableros, uno de los atributos IDEAS

## En el parcial

Dar un ejemplo de cada combinación (eficiente-no eficaz, etc.). Es pregunta casi segura.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

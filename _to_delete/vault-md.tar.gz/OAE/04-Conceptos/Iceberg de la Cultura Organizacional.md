---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
estado: estudiado
tags: [OAE, U2, cultura, modelo]
---

# Iceberg de la Cultura Organizacional

> Modelo que separa la cultura en una parte visible (pequeña, sobre el agua) y una invisible (mucho mayor, bajo el agua) que la sostiene.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**VISIBLE** (sobre la línea de flotación) — lo que se percibe entrando a la organización:

> Personas · Beneficios · Amenidades · Ubicación · Código de vestimenta ·
> Ambiente de oficina

**INVISIBLE** (bajo el agua, la masa mayor) — lo que realmente la explica:

> Seguridad · Confianza · Resultados · Valores centrales · Ética de trabajo · Apertura ·
> Diferencias · Disfrute · Flexibilidad · Espacio personal · Orden · Narrativa · Sesgos ·
> Autoridad · Propósito · Misión · Oportunidades de aprendizaje · Expectativas ·
> Declaración de visión · Disciplina

## Cómo leerlo

Lo visible es la **manifestación**; lo invisible es la **causa**. La proporción del dibujo es
parte del argumento: la mayor parte de lo que determina el comportamiento de una organización
**no se ve** en una visita.

De ahí que se pueda "leer" una cultura mirando cosas aparentemente triviales —cómo se
saludan, qué se cuelga en la pared, qué abreviaturas usan— porque son la superficie visible
de valores que nadie enuncia.

> ⚠️ **Reemplaza al "modelo de 2 niveles"** (características observables / inobservables) de
> la versión vieja del deck. Es la misma idea con otro nombre y mucho más desarrollada; usá
> *iceberg*, *visible* e *invisible*.

Fuente citada por la cátedra: <https://esie.es/teoria-del-iceberg-empresarial>

## Conexiones

- [[Cultura Organizacional]] — es el objeto que el modelo describe
- [[Transmisión de la Cultura]] — relatos, rituales, símbolos y lenguaje son la parte visible
- [[Dimensiones de la Cultura Organizacional]] — las 7 dimensiones se manifiestan en ambos niveles

## En el parcial

«¿Se trata de características visibles o invisibles?» aplicado a un caso. Antes se preguntaba como observables/inobservables.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

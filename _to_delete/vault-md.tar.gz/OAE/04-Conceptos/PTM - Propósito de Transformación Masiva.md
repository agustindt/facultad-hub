---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
autor: Salim Ismail
estado: estudiado
tags: [OAE, U1, organizacion, ExO, PTM]
---

# PTM - Propósito de Transformación Masiva

> Propósito ambicioso y centrado en lo externo que reemplaza a la declaración de misión tradicional y da dirección a una organización exponencial.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

**Fórmula:**

```mermaid
flowchart LR
    Q["¿POR QUÉ?"] --> S(("+"))
    H["¿CÓMO?"] --> S
    S --> M(("×"))
    G["IMPACTO<br/>GLOBAL"] --> M
    M --> PTM["<b>PTM</b>"]
    style PTM fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

**Los tres pasos para crearlo:**

1. **¿Por qué** existe la organización? → define la zona problemática
2. **¿Cómo** lo resolverá? → visualiza la transformación
3. **¿Cuál** será el impacto global? → asegura un enfoque global

**Un PTM es:** emocional (toca el corazón y la mente), creíble (los interesados deben estar
convencidos desde su trabajo diario), simple (claro y fácil de entender), orientativo,
atractivo y transformativo.

**Un PTM NO es:** una declaración de visión (que está centrada en la organización; el PTM
está centrado en lo externo), una declaración de misión (que es sólo el "cómo"), un lema de
marketing, ni la propuesta de valor.

**Ejemplos:** TED → *"Ideas worth spreading"* · Google → *"Organizar la información del
mundo"* · Tesla → *"Pioneros del futuro de los automóviles"*.

**Cómo se evalúa si un PTM es sólido** (checklist usado en el caso TED): ¿genera un
movimiento cultural? ¿atrae talento? ¿promueve agilidad y aprendizaje continuo? ¿alinea
expectativas colectivas? ¿aumenta la fidelidad del cliente? ¿genera ventaja competitiva?

## Conexiones

- [[Organizaciones Exponenciales (ExO)]] — el PTM es el núcleo de la fórmula
- [[Organización como Sistema]] — el sistema se orienta por una misión o PTM
- [[Clickie iA - Perfil de la Empresa]] — hay que poder formular el PTM de la empresa del proyecto

## En el parcial

Distinguir PTM de misión y de visión — es la confusión que más se penaliza. Y saber formular uno.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

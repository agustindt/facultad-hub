---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, organizacion, cambio, paradigma]
---

# Organización que Aprende

> Nuevo paradigma organizacional: dinámica, flexible, en equipos y redes, frente a la organización tradicional estable y jerárquica.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

| **Organización tradicional** | **Organización que aprende** |
|---|---|
| Estable, inflexible | Dinámica, flexible |
| Puestos permanentes | Trabajo en equipos y redes |
| Trabajo individual, de 9 a 5 | Sin horarios fijos, en cualquier lugar |
| Foco en la jerarquía | Empoderamiento |
| *"Si funciona, no lo cambies"* | *"Si no lo cambias, dejará de funcionar"* |

Las dos frases del final resumen el cambio de actitud: la organización tradicional trata la
estabilidad como un activo; la que aprende la trata como un riesgo.

Este contraste es el puente hacia las **organizaciones exponenciales**: el modelo ExO es la
versión llevada al extremo de la columna derecha.

## Conexiones

- [[Organizaciones Exponenciales (ExO)]] — es la versión radicalizada de este paradigma
- [[Entorno Global y Globalización]] — el cambio de paradigma responde a un entorno más dinámico
- [[Incertidumbre Ambiental]] — la flexibilidad es la respuesta organizacional a entornos turbulentos
- [[Cultura Organizacional]] — el empoderamiento y la tolerancia al cambio son rasgos culturales

## En el parcial

Comparación en dos columnas. Fácil de puntuar si citás las dos frases-actitud.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
autor: Katz
estado: estudiado
tags: [OAE, U1, gerencia, habilidades, Katz]
---

# Habilidades Administrativas (Katz)

> Tres habilidades —conceptuales, humanas y técnicas— presentes en todos los niveles gerenciales pero con peso relativo distinto.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

- **Conceptuales** — pensar la organización como un todo, abstraer, ver el sistema y su entorno.
- **Humanas** — trabajar con y a través de otras personas: comunicar, motivar, liderar.
- **Técnicas** — conocimiento específico del campo, métodos y herramientas del oficio.

**Distribución según el nivel:**

<svg viewBox="0 0 520 200" width="100%" style="max-width:560px" role="img" aria-label="Distribución de habilidades administrativas por nivel gerencial">
  <text x="0" y="14" fill="var(--text-muted)" font-size="11">Proporción de cada habilidad según el nivel</text>
  <g font-size="12" fill="var(--text-normal)">
    <text x="0" y="52">Alto nivel</text>
    <text x="0" y="100">Nivel medio</text>
    <text x="0" y="148">Niveles inferiores</text>
  </g>
  <g>
    <rect x="150" y="30" width="221" height="34" fill="#7C5CFF"/>
    <rect x="371" y="30" width="83"  height="34" fill="#4DB6AC"/>
    <rect x="454" y="30" width="56"  height="34" fill="#FFA726"/>
    <rect x="150" y="78" width="138" height="34" fill="#7C5CFF"/>
    <rect x="288" y="78" width="111" height="34" fill="#4DB6AC"/>
    <rect x="399" y="78" width="111" height="34" fill="#FFA726"/>
    <rect x="150" y="126" width="55"  height="34" fill="#7C5CFF"/>
    <rect x="205" y="126" width="83"  height="34" fill="#4DB6AC"/>
    <rect x="288" y="126" width="222" height="34" fill="#FFA726"/>
  </g>
  <g font-size="11" font-weight="bold" fill="#fff" text-anchor="middle">
    <text x="260" y="52">CONCEPTUALES</text>
    <text x="343" y="100">HUMANAS</text>
    <text x="399" y="148">TÉCNICAS</text>
  </g>
  <g font-size="11" fill="var(--text-normal)">
    <rect x="150" y="176" width="11" height="11" fill="#7C5CFF"/><text x="167" y="186">Conceptuales</text>
    <rect x="253" y="176" width="11" height="11" fill="#4DB6AC"/><text x="270" y="186">Humanas</text>
    <rect x="340" y="176" width="11" height="11" fill="#FFA726"/><text x="357" y="186">Técnicas</text>
  </g>
</svg>

**Las dos reglas que hay que saber:**

1. Las **humanas se mantienen relativamente constantes** en los tres niveles — en cualquier
   posición se trabaja con gente.
2. **Conceptuales y técnicas son inversas**: las conceptuales crecen hacia arriba, las
   técnicas crecen hacia abajo.

Consecuencia práctica poco intuitiva: el mejor técnico no es automáticamente el mejor
candidato a gerente. Ascender cambia la habilidad que el puesto exige.

## Conexiones

- [[Niveles Gerenciales]] — el eje sobre el que se distribuyen
- [[Roles Gerenciales (Mintzberg)]] — las habilidades son la aptitud; los roles, la conducta observable
- [[Funciones Gerenciales (Fayol)]] — son las habilidades necesarias para ejecutar las funciones

## En el parcial

«¿Qué habilidad predomina en un supervisor de primera línea?» → técnica. Y justificar con la regla de la inversión.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

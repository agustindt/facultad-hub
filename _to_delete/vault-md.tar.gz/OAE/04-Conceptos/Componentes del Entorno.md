---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno]
---

# Componentes del Entorno

> Los seis componentes del entorno general (Figura 3.2): económico, político-legal, sociocultural, demográfico, tecnológico y global.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

> Nota de terminología: la cátedra ahora dice **"componentes"** del entorno (Figura 3.2), no
> "sectores". La clasificación de **Hodge** ya no figura en el deck 2026 — ver el aviso al final.

## ECONÓMICO

Red de medios para la producción y distribución de bienes y servicios. Abarca organizaciones
**con y sin fines de lucro**. Determina técnicas, recursos e instrumentos para los gerentes.

*Condiciones económicas:* tasas de interés y bolsa · inflación (precios altos, costo de vida,
confianza) · tasas de cambio y devaluaciones · políticas fiscales · desempleo y costo de MO ·
demografía.

*Funciones:* distribución de recursos (agotamiento como factor de medición) · mantenimiento
de la demanda total del sistema (empleos) · distribución e intercambio de productos
(qué, cuánto, cómo, dónde, cuándo).

*Sistemas económicos:*

| **PLANIFICADA / CONTROLADA** | **CAPITALISTA / LIBRE MERCADO** |
|---|---|
| Regímenes comunistas y socialistas | Regímenes democráticos |
| Menor competencia | Mayor competencia |
| Elección de empleo limitada | La innovación recae sobre la organización |
| Poder en el gobierno | Conocer gustos del consumidor final · poder en la org. |
| Centralización | Descentralización |
| Asigna recursos por políticas de racionalización | Asigna por ley de oferta-demanda y precios |

Ejemplos: planificada → China, Cuba, Corea del N · capitalista → Norteamérica, Europa
Occidental, Japón · en transición → Europa del Este.

*Comercio mundial:* importación/exportación · espacio-tiempo comprimido por transporte y
almacenamiento · conocer reglamentos, costumbres y condiciones propias y ajenas ·
**organismos de comercio globales** (OMC, que vigila y promueve el comercio mundial) y
**regionales** (Mercosur, UE, NAFTA) · globalización = productos **diseñados, fabricados y
vendidos** en distintos lugares.

## POLÍTICO-LEGAL

*Alcance:* municipal – provincial – nacional. *Ramas:* legislativa – ejecutiva – judicial.

*Efectos del gobierno:* estabilidad del ambiente → economía · leyes y reglamentos para la
creación y funcionamiento de organizaciones (código laboral, código de comercio, organismos
fiscales) · **lobbying** (influencia de grupos de poder).

| Adaptación (−) | Beneficios (+) |
|---|---|
| Mayor influencia del gobierno · expertos legales y financieros por complejidad operacional · sistemas informatizados para reportar al Estado · mayores costos · presión impositiva y regulatoria | Leyes de competencia · protección (policía, bomberos) · prevención de prácticas ilegales · marco para litigio · publicaciones · salud · seguridad social · educación · subsidios |

## SOCIOCULTURAL

Cambio de valores, usos y gustos de la sociedad. Colegios, instituciones políticas, medios e
iglesia **moldean, transforman y difunden** la cultura.

Con la globalización: entender valores de otras naciones · **cultura organizacional vs.
cultura nacional** · costos de violar normas y culturas locales. Se caracteriza con
[[Hofstede y GLOBE]].

## DEMOGRÁFICO

Tendencias en género · edad · escolaridad · región · ingresos · estructura familiar.

**Generaciones según año de nacimiento** (la cátedra lo dio con gráfico):

| Generación | Años |
|---|---|
| Silenciosa | 1925-1945 |
| Baby Boomers | 1946-1964 |
| Generación X | 1965-1979 |
| Millennials | 1980-1994 |
| Generación Z | 1995-2009 |
| Generación Alfa | 2010-2024 |
| Generación Beta | 2025-2039 |

## TECNOLÓGICO

Cambios rápidos y continuos → **INNOVACIÓN DISRUPTIVA**. Dado por competencias específicas,
conocimientos, herramientas y habilidades para producir el bien/servicio.

*Ventajas competitivas que otorga:* nuevas estructuras organizativas · **nuevas metodologías
y técnicas (agilismo, métricas)** · nuevos productos o servicios.

*Ejemplos:* avances científicos (física/computación cuántica, genoma humano) · aparatos más
pequeños y potentes · informatización, automatización, robotización, **GenIA** · medios de
comunicación y de almacenamiento · **modelos de negocios exponenciales**.

## GLOBAL

Ver [[Entorno Global y Globalización]].

---

> ⚠️ **Ya NO figura en el deck 2026** (estaba en la versión vieja): la clasificación de
> **sectores de Hodge**, y los sectores propios de **RRHH**, **RR Físicos**,
> **Consumidores y Clientes** y **Industrial** con las [[5 Fuerzas de Porter]]. Sus
> contenidos quedaron absorbidos por los seis componentes de arriba y por el entorno
> específico. Confirmá con la profe antes de descartarlos del todo para el parcial.

## Conexiones

- [[Entorno General y Específico]] — estos seis componen el lado general
- [[PESTEL]] — sus seis letras mapean casi uno a uno con estos componentes
- [[Hofstede y GLOBE]] — las herramientas del componente sociocultural
- [[Entorno Global y Globalización]] — el componente global desarrollado
- [[5 Fuerzas de Porter]] — estaba en la versión vieja del deck; ya no figura en 2026

## En el parcial

Identificar a qué componente pertenece un hecho dado. Ojo: **son 6 y se llaman componentes**, no sectores.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

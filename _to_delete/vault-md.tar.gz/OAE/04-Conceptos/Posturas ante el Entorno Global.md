---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno, globalizacion]
---

# Posturas ante el Entorno Global

> Las tres actitudes de una corporación multinacional frente al mundo —etnocéntrica, policéntrica y geocéntrica— y el tipo de organización que resulta de cada una.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

| Postura | Referencia | Tipo de CMN | Rasgo | Ejemplos |
|---|---|---|---|---|
| **ETNOCÉNTRICA** | La **patria** (país de origen) | **Empresa global** | CMN que **centraliza** en el país de origen (casa matriz) | Sony, Unilever |
| **POLICÉNTRICA** | El **país local** (de residencia) | **Corporación multidoméstica** | CMN **descentralizada** en cada país | Nestlé, Frito-Lay (división Pepsi-Co) |
| **GEOCÉNTRICA** | El **mundo** | **Organización trasnacional (sin fronteras)** | CMN que **suprime barreras geográficas artificiales** | IBM (grupos industriales), Telefónica de España |

## El error frecuente

Confundir *global* con *geocéntrica*. La empresa **global** es la **etnocéntrica** —opera en
muchos países pero se dirige desde la matriz—. La geocéntrica es la **trasnacional / sin
fronteras**. El nombre "global" engaña.

> Nota de terminología 2026: la cátedra ahora dice **"Corporación multidoméstica"** (antes
> "empresa multidoméstica") y **"Organización trasnacional (sin fronteras)"** (antes "empresa
> sin fronteras o trasnacionales"). Las tres se presentan como variantes de **CMN**.

## Conexiones

- [[Entorno Global y Globalización]] — estas posturas son las de la CMN, que se materializa en la Figura 4.4
- [[Clasificación de Organizaciones]] — define el alcance geográfico de la organización
- [[Hofstede y GLOBE]] — la postura policéntrica exige entender las culturas nacionales locales
- [[Cultura Organizacional]] — la tensión cultura organizacional vs. cultura nacional

## En el parcial

Asociar postura ↔ tipo de CMN ↔ ejemplo. **Global = etnocéntrica**, no geocéntrica: es la trampa clásica.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
estado: estudiado
tags: [OAE, U2, entorno, herramienta, transversal]
---

# PESTEL

> Herramienta para analizar el entorno general en seis dimensiones: político, económico, social, tecnológico, ecológico y legal.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

```mermaid
mindmap
  root(("PESTEL"))
    P["P · POLÍTICO"]
      p1["Gobierno y clima político"]
      p2["Conflictos"]
      p3["Iniciativas y ayudas"]
    E1["E · ECONÓMICO"]
      e1["Tendencias, crisis y ciclos"]
      e2["Tipos de cambio e interés"]
      e3["Políticas de innovación"]
    S["S · SOCIAL"]
      s1["Demografía y estilo de vida"]
      s2["Actitudes y aspectos éticos"]
      s3["Educación y patrones culturales"]
    T["T · TECNOLÓGICO"]
      t1["TIC e infraestructuras"]
      t2["Patentes e investigación"]
      t3["Acceso tecnológico"]
    E2["E · ECOLÓGICO"]
      x1["Problemas medioambientales"]
      x2["Procesos de producción y consumo"]
      x3["Políticas medioambientales"]
    L["L · LEGAL"]
      l1["Legislación y derecho internacional"]
      l2["Reglamentación nacional y decretos"]
      l3["Regulación de precios"]
```

Si se usan sólo las cuatro primeras es un **PEST**; con ecológico y legal, **PESTEL**.

## La MATRIZ PESTEL — el entregable, no la lista

La cátedra no pide enumerar factores sino **volcarlos en una matriz** con plazo e impacto:

| Factor | Detalle | Corto plazo (1 mes o menos) | Mediano plazo (1 a 3 años) | Largo plazo (más de 3 años) | Impacto |
|---|---|:---:|:---:|:---:|---|
| *Político* — cambio de presidente | El programa de gobierno se adecua a las necesidades empresariales | ✕ | | | 🟩 Positivo |
| *Político* — elecciones de alcaldes | No suponen beneficio ni riesgo para el mercado | | ✕ | | 🟨 Indiferente |
| *Económico* — divisa | La devaluación aumentó el precio de la materia prima | ✕ | | | 🟥 Negativo |
| *Tecnológico* — robo de información | Se perdió el 15% de la información digital por accesos indebidos | ✕ | | | 🟥 Negativo |
| *Ambiental* — licencia ambiental | La empresa necesita renovar sus licencias | ✕ | | | 🟥 Negativo |
| *Legal* — legislación alimentaria | Cumple la norma ISO 22000 | ✕ | | | 🟩 Positivo |

**Columnas:** Factor · Detalle · Plazo (corto / mediano / largo) · **Impacto** (Positivo /
Indiferente / Negativo).
**Filas agrupadas por:** Político · Económico · Social · Tecnológico · Ambiental · Legal.

> ✅ Esta es la lámina "MATRIZ" que faltaba en el `.pptx` viejo de FODA y PESTEL. Es el
> formato exacto que va a pedir la cátedra en la [[Entrega 1 - Ambiente Organizacional]].

**Relación con la teoría:** PESTEL es la herramienta operativa para relevar el **entorno
general**, y sus seis letras mapean casi uno a uno con los seis
[[Componentes del Entorno]] — con la diferencia de que PESTEL separa **ecológico** y
**legal**, y no tiene una letra para *global* ni para *demográfico* (que cae dentro de
*social*).

**Nota transversal:** herramienta de uso general en gestión. Es la misma nota para todas las
materias.

## Conexiones

- [[Entorno General y Específico]] — es la herramienta del entorno general
- [[Componentes del Entorno]] — sus seis letras mapean casi uno a uno con los componentes
- [[FODA]] — PESTEL alimenta el lado de oportunidades y amenazas del FODA
- [[Entrega 1 - Ambiente Organizacional]] — la matriz PESTEL es un entregable concreto del proyecto
- [[TP2-Entorno-y-Cultura-Organizacional]] — clasificar fuerzas del entorno general es el TP2.1

## En el parcial

Completar la **matriz** (factor, detalle, plazo, impacto) para una empresa concreta — no alcanza con listar las seis letras. Ojo con no meter en 'Político' cosas que son 'Legal'.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

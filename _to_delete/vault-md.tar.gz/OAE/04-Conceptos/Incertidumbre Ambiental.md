---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno, incertidumbre]
---

# Incertidumbre Ambiental

> Grado de imprevisibilidad del entorno, evaluado cruzando su grado de cambio con su grado de complejidad (Figura 3.3).

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

Es una de las **dos vías** por las que el entorno afecta a los gerentes (la otra son las
[[Partes Interesadas]]).

## Dimensiones

- **GRADO DE CAMBIO** (impredecible): **ESTABLE ↔ DINÁMICO**
- **GRADO DE COMPLEJIDAD** (nº de componentes): **SIMPLE ↔ COMPLEJO**

> ⚠️ **La MUNIFICENCIA ya no figura en el deck 2026.** La versión vieja incluía una tercera
> dimensión (abundancia de recursos del entorno). Ahora son **dos**. Si la mencionás, aclarala
> como agregado.

## Matriz de incertidumbre ambiental — Figura 3.3

```mermaid
quadrantChart
    title Grado de incertidumbre ambiental
    x-axis "ESTABLE" --> "DINAMICO"
    y-axis "SIMPLE" --> "COMPLEJO"
    quadrant-1 "CELDA 4 — mayor incertidumbre"
    quadrant-2 "CELDA 3"
    quadrant-3 "CELDA 1 — menor incertidumbre"
    quadrant-4 "CELDA 2"
```

| Celda | Componentes | Cambio | Conocimiento que exige |
|---|---|---|---|
| **1** — simple + estable | Pocos y similares | Sin cambio | **Mínimo** · predecible · *ideal para el gerente* |
| **2** — simple + dinámico | Pocos y similares | **Cambian continuamente** | Mínimo, pero hay que actualizarlo seguido |
| **3** — complejo + estable | Muchos y **no similares** | Sin cambio | **Alto**, pero se aprende una vez |
| **4** — complejo + dinámico | Muchos y no similares | **Cambian continuamente** | Alto **y** siempre desactualizado · *la más exigente* |

**La lógica de fondo:** el eje *simple↔complejo* determina **cuánto conocimiento** hace falta;
el eje *estable↔dinámico* determina **cada cuánto hay que actualizarlo**.

*Ejemplo que dio la cátedra:* análisis de los monopolios.

## Conexiones

- [[Entorno Organizacional]] — es una de las dos vías por las que el entorno afecta al gerente
- [[Partes Interesadas]] — la otra vía
- [[Gerente Omnipotente vs Simbólico]] — es la forma concreta de la restricción externa
- [[Toma de Decisiones]] — a más incertidumbre, más información hace falta para decidir
- [[Cultura Fuerte vs Débil]] — en celda 4 una cultura fuerte se vuelve un obstáculo
- [[Gestión y Control del Entorno]] — las estrategias para reducir esta incertidumbre

## En el parcial

Ubicar una organización en una celda **y justificar** con las dos dimensiones. Practicalo con Clickie. **Son 2 dimensiones, no 3.**

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, gerencia, cultura, entorno]
---

# Gerente Omnipotente vs Simbólico

> Dos visiones opuestas sobre cuánto influye realmente un gerente en los resultados de la organización.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

La cátedra lo titula **"ADMINISTRACIÓN: Visiones"**.

| | **Gerente OMNIPOTENTE** | **Gerente SIMBÓLICO** |
|---|---|---|
| Premisa | **Responsable** del resultado | **Efectos limitados** sobre los resultados |
| Causa de los resultados | Su propia gestión | Factores **no controlables**: economía, política, clientes, competencia |
| Consecuencia | Éxito → **MÉRITO** / Fracaso → **DESPIDO** | El gerente es un símbolo, no la causa |

## La síntesis — Figura 3.1 (Robbins & Coulter)

**"Restricciones en el criterio de un gerente":**

```mermaid
flowchart LR
    E["<b>ENTORNO<br/>ORGANIZACIONAL</b><br/><i>restricción externa</i>"] --> C
    C{{"<b>CRITERIO<br/>GERENCIAL</b>"}}
    K["<b>CULTURA<br/>ORGANIZACIONAL</b><br/><i>restricción interna</i>"] --> C
    style C fill:#7C5CFF,stroke:#5B3FD9,color:#fff
    style E fill:#4DB6AC,stroke:#00897B,color:#fff
    style K fill:#FFA726,stroke:#F57C00,color:#fff
```

El **criterio gerencial** (el margen real de decisión) queda apretado entre dos restricciones:
una **externa** (el entorno) y una **interna** (la cultura).

> **Esta figura es la bisagra de toda la U2.** Cultura y entorno no son dos temas sueltos que
> comparten unidad: son literalmente las dos restricciones al criterio del gerente. Si
> entendés la Figura 3.1, la unidad entera se ordena sola.

**Ojo con el cambio de versión:** el deck 2026 reemplazó el esquema viejo
(FUERTE/DÉBIL + "limitaciones internas f(cultura) / externas f(entorno)") por esta figura.
Citá **"Figura 3.1, restricciones en el criterio de un gerente"** — es el lenguaje de la
cátedra ahora.

## Conexiones

- [[Cultura Organizacional]] — es la restricción INTERNA al criterio gerencial
- [[Entorno Organizacional]] — es la restricción EXTERNA al criterio gerencial
- [[Funciones Gerenciales (Fayol)]] — son las funciones sobre las que se ejerce ese criterio
- [[Cultura Fuerte vs Débil]] — una cultura fuerte estrecha más el criterio del gerente
- [[Incertidumbre Ambiental]] — es la forma concreta que toma la restricción externa

## En el parcial

Explicar ambas visiones **y** la síntesis de la Figura 3.1. Responder sólo el cuadro comparativo deja la mitad del puntaje.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
estado: estudiado
tags: [OAE, U1, organizacion, sistemas, SIPOC]
---

# Organización como Sistema

> La organización vista como sistema abierto que toma insumos del entorno, los transforma y devuelve productos, con retroalimentación.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

**Modelo básico:**

```mermaid
flowchart LR
    ENT1(["ENTORNO"]) --> I
    subgraph SIS["SISTEMA ORGANIZACIÓN"]
        direction LR
        I["<b>INSUMOS</b><br/>Materia prima<br/>RRHH<br/>Capital<br/>Tecnología<br/>Información"]
        T["<b>PROCESO DE<br/>TRANSFORMACIÓN</b><br/>Actividades laborales<br/>Actividades gerenciales<br/>Métodos tecnológicos"]
        P["<b>PRODUCTOS</b><br/>Productos y servicios<br/>Result. financieros<br/>Información<br/>Resultados humanos"]
        I --> T --> P
    end
    P --> ENT2(["ENTORNO"])
    P -.->|RETROALIMENTACIÓN| I
    style T fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

Es un sistema **abierto** (intercambia con el entorno), **social** (hecho de personas) y
con **misión / PTM**.

**Diagrama SIPOC** — vista de alto nivel del *cómo es* el sistema:

```mermaid
flowchart LR
    S["<b>S</b><br/>Suppliers<br/><i>quién provee materias primas,<br/>información o tecnología</i>"]
    I["<b>I</b><br/>Inputs<br/><i>material, datos,<br/>especificaciones</i>"]
    P["<b>P</b><br/>Process<br/><i>flujograma de alto nivel<br/>de las actividades clave</i>"]
    O["<b>O</b><br/>Output<br/><i>productos, servicios,<br/>información, tecnología</i>"]
    C["<b>C</b><br/>Customers<br/><i>quién recibe el resultado<br/>(interno o externo)</i>"]
    S --> I --> P --> O --> C
    style P fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

Que sea **abierto** es la clave conceptual: por eso el entorno no es un decorado sino una
variable que entra y sale del sistema todo el tiempo.

## Conexiones

- [[Organización]] — es el sujeto que se está modelando
- [[Entorno Organizacional]] — aparece en los dos extremos del modelo: fuente de insumos y destino de productos
- [[Gestión y Control del Entorno]] — aplica este mismo esquema input–proceso–output al manejo del entorno
- [[PTM - Propósito de Transformación Masiva]] — el sistema se orienta por una misión o PTM

## En el parcial

Suelen pedir armar el SIPOC de una organización concreta (fue la Actividad TP1.1/1.2). Practicalo con Clickie.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

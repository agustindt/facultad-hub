---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Porter
estado: pendiente
tags: [OAE, U2, entorno, Porter, competencia, transversal]
---

# 5 Fuerzas de Porter

> Modelo de análisis de la competencia en un sector industrial mediante cinco fuerzas que determinan su atractivo.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

> ⚠️ **Ya no figura en el deck 2026 de U2.** Estaba en la versión vieja, dentro del "sector
> industrial" de la clasificación de Hodge, que la cátedra eliminó. **Confirmá con la profe
> si entra en el Parcial 1** antes de descartarlo — y si no entra por U2, igual es probable
> que vuelva en Planificación (U3) como herramienta de análisis estratégico.

## El modelo

1. **Amenaza de nuevos entrantes**
2. **Amenaza de productos sustitutos**
3. **Rivalidad entre firmas**
4. **Poder de negociación del comprador** → lado del **mercado**
5. **Poder de negociación del proveedor** → lado de los **RRFF**

## Barreras de entrada

Economías de escala · requerimientos de capital (RRHH, RRFF) · diferenciación del producto ·
costos de cambio para el cliente · canales de distribución · políticas gubernamentales ·
desventajas en costes.

Cuantas más y más altas sean, menor la amenaza de nuevos entrantes y más atractivo el sector
para quien ya está adentro.

**Sigue siendo útil para el proyecto:** aunque no esté en el deck, es la mejor herramienta
para analizar el entorno específico de Clickie en la
[[Entrega 1 - Ambiente Organizacional]] — técnicos como proveedores, usuarios como
compradores, marketplaces de oficios como rivales.

**Nota transversal:** modelo de uso general en gestión. Es la misma nota para todas las materias.

## Conexiones

- [[Componentes del Entorno]] — estaba en el sector industrial de Hodge, eliminado en 2026
- [[Entorno General y Específico]] — analiza el entorno específico
- [[Partes Interesadas]] — proveedores, clientes y competencia son partes interesadas
- [[FODA]] — las cinco fuerzas alimentan el análisis de amenazas
- [[Entrega 1 - Ambiente Organizacional]] — sigue siendo útil para aplicarlo a Clickie

## En el parcial

**Verificar si entra.** No está en el deck 2026 de U2.

---
Fuente: `99-Material-Catedra/_archivo-versiones-viejas/OAE U2 Entorno y cultura organizacional (version 2018 - REEMPLAZADA).pdf`

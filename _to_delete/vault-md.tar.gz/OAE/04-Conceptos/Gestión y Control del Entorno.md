---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
estado: estudiado
tags: [OAE, U2, entorno, estrategia]
---

# Gestión y Control del Entorno

> Qué puede hacer el gerente frente al entorno: conocerlo sistémicamente y aplicar estrategias para reducir su incertidumbre.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

## Conocimiento sistémico

```mermaid
flowchart LR
    FI(["<b>Fuentes de input</b><br/>y restricciones"]) --> I
    subgraph ORG[" "]
        direction LR
        I["<b>INPUT</b><br/>Recursos:<br/>humanos<br/>materiales<br/>financieros<br/>de información"]
        P["<b>PROCESO</b><br/>Transformación:<br/>funciones gerenciales<br/>producción<br/>mantenimiento"]
        O["<b>OUTPUT</b><br/>Bienes y servicios:<br/>ventas<br/>publicidad<br/>rel. públicas<br/>grupos de poder"]
        I --> P --> O
    end
    O --> OP(["<b>Oportunidades</b><br/>del output y<br/>restricciones"])
    style FI fill:#4DB6AC,stroke:#00897B,color:#fff
    style OP fill:#4DB6AC,stroke:#00897B,color:#fff
    style P fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

> 🔑 El **entorno está en los dos extremos** (los dos bloques verdes): entra como recursos y
> restricciones, y sale como oportunidades y restricciones.

El entorno aparece **en los dos extremos**: fuente de recursos y restricciones a la entrada,
y fuente de oportunidades y restricciones a la salida. Es el mismo esquema de
[[Organización como Sistema]] leído desde el entorno.

## Estrategias de control (9)

1. Selección del **nicho o dominio**
2. Estrategias de **vinculación por incertidumbre**
3. **Acuerdos, normas y contratos** de reciprocidad y ayuda mutua
4. **Joint ventures** o alianzas específicas
5. **Fusiones y adquisiciones** con integración — **vertical** (hacia atrás/adelante) u
   **horizontal** (diversificada o no) → **organización VIRTUAL o en RED**
6. **Consejos de administración** (ONG, cooperativas)
7. **Captación de directivos** de la competencia
8. **Asociaciones de empresarios** (lobbying)
9. **Publicidad y relaciones públicas**

## Los dos límites del control

- **ILEGALIDAD** — a entornos más difíciles, mayor probabilidad de actividades ilegales:
  sobornos en ambientes competitivos (para conseguir contratos, exportación-importación),
  acuerdos de precios entre 2 dominantes, división del mercado entre 2 dominantes.
- **ECOLOGÍA DE LA POBLACIÓN** — el entorno produce incertidumbre que **atenta contra la
  existencia** de las organizaciones, con independencia de si el cambio fue intencional o
  accidental, aleatorio o no. *Ej: estaciones de servicio self-service.*

> Estos dos límites responden a "¿puede el gerente controlar el entorno?". La respuesta:
> parcialmente, y en el intento aparecen tanto la tentación de la ilegalidad como un techo
> duro que no depende de él.

## Conexiones

- [[Entorno Organizacional]] — es la respuesta práctica al problema que plantea
- [[Incertidumbre Ambiental]] — es lo que estas estrategias buscan reducir
- [[Partes Interesadas]] — los acuerdos con ellas son una de las estrategias
- [[Organización como Sistema]] — reutiliza el esquema input-proceso-output
- [[Gerente Omnipotente vs Simbólico]] — la ecología de la población es el argumento más fuerte a favor de la visión simbólica

## En el parcial

Proponer estrategias de control para un caso concreto, y conocer los dos límites.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

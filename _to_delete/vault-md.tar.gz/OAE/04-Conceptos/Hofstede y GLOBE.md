---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Hofstede / GLOBE
estado: estudiado
tags: [OAE, U2, entorno, cultura-nacional]
---

# Hofstede y GLOBE

> Los dos esquemas para caracterizar culturas nacionales, dentro del componente sociocultural del entorno.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

Responden a: *¿cómo caracterizar la cultura propia (y la ajena)?*

## Teoría de HOFSTEDE — 5 dimensiones (Figura 4.6)

Cada dimensión es un **eje con dos extremos** y países ubicados a lo largo:

| # | Extremo A | Extremo B |
|---|---|---|
| 1 | **Individualista** — las personas sólo se interesan por sus propios intereses y los de su familia · *EEUU, Canadá, Australia* | **Colectivista** — la gente busca pertenecer a un grupo y confía en que éste la protegerá · *México, Tailandia* |
| 2 | **Mucha distancia del poder** — se aceptan amplias diferencias de poder; elevado respeto a la autoridad · *México, Singapur, Francia* | **Poca distancia del poder** — poca aquiescencia hacia las desigualdades; los empleados no temen aproximarse a sus superiores · *EEUU, Suecia* |
| 3 | **Gran evitación de la incertidumbre** — sensación de amenaza y ansiedad ante la ambigüedad · *Italia, México, Francia* | **Poca evitación de la incertidumbre** — comodidad ante los riesgos; tolerancia a distintos comportamientos y opiniones · *Canadá, EEUU, Singapur* |
| 4 | **Logro** — prevalecen la asertividad, la adquisición de dinero y bienes, la competencia · *EEUU, Japón, México* | **Cuidado y protección** — prevalecen el cuidado de las relaciones humanas y el interés por los demás · *Francia, Suecia* |
| 5 | **Orientación al largo plazo** — ojos puestos en el futuro; se valoran frugalidad y persistencia · *Alemania, Australia, EEUU, Canadá* | **Orientación al corto plazo** — se valoran las tradiciones y el pasado · *China, Taiwán, Japón* |

Japón, Italia y Canadá aparecen en posiciones intermedias en varios ejes: la escala es un
continuo, no una dicotomía.

## Esquema GLOBE — 8 dimensiones

**G**lobal **L**eadership and **O**rganizational **B**ehavior **E**ffectiveness — *programa de
liderazgo global y efectividad del comportamiento organizacional*. Indica el **grado en que
la sociedad alienta/acepta**…

Individualismo o colectivismo · distancia del poder · evasión de la incertidumbre ·
**asertividad** · **orientación al desempeño** · **orientación humana** · orientación al
futuro · **diferenciación de género** · colectivismo grupal.

GLOBE **extiende** a Hofstede: conserva sus dimensiones centrales y agrega asertividad,
orientación al desempeño, orientación humana y diferenciación de género.

**Para qué sirve:** una CMN con postura policéntrica lo necesita para operar en cada país; y
toda organización necesita distinguir su **cultura organizacional** de la **cultura
nacional** en la que está inmersa.

## Conexiones

- [[Componentes del Entorno]] — son las herramientas del componente sociocultural
- [[Cultura Organizacional]] — la cultura nacional es distinta de la organizacional, y la condiciona
- [[Dimensiones de la Cultura Organizacional]] — el equivalente a nivel organización
- [[Posturas ante el Entorno Global]] — la postura policéntrica exige aplicarlos

## En el parcial

Enumerar las 5 de Hofstede con sus dos extremos, y ubicar un país. GLOBE: alcanza con saber qué significa la sigla y que extiende a Hofstede.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

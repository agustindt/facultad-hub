---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, entorno, stakeholders]
---

# Partes Interesadas

> Entes externos e internos afectados por las decisiones y acciones de la organización. Coinciden con el entorno específico.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

**Modelo Organización-Actor.** Es la segunda vía por la que el entorno afecta a los gerentes.

**Quiénes son** (Figura 3.4, participantes de la organización): empleados · clientes ·
competencia · proveedores · gobiernos · sindicatos · accionistas · comunidades · medios ·
activistas (sociales/políticas) · asociaciones (industrial/comercial) · grupos de acción
política y social.

## Lógica del modelo

- La organización **depende del entorno** en la **entrada** (recursos) y en la **salida**
  (bienes y servicios).
- Cuanto **más segura la relación**, más control tienen los gerentes sobre los resultados.
- **Efectos de gestionarlas bien:** + innovación, + confianza, + flexibilidad, + pronósticos
  → repercuten en el **desempeño** de la organización.

## Etapas para manejar stakeholders

1. **Identificar** las partes interesadas.
2. **Determinar sus intereses concretos** — calidad, finanzas, seguridad, ecología…
3. **Decidir su importancia** sobre las decisiones y acciones de la organización.
4. **Decidir el manejo de la relación**, en función de:
   1. la **importancia de cada parte**,
   2. la **incertidumbre del ambiente**
   → **ACUERDO EXPLÍCITO organización–parte**.

El paso 4 depende de la incertidumbre ambiental: no es un procedimiento aislado, se calibra
según cuán turbulento sea el entorno.

> 📌 En el deck 2026 el **entorno específico** se presenta con esta misma figura de
> participantes. Para la cátedra, entorno específico y stakeholders son prácticamente el
> mismo conjunto.

## Conexiones

- [[Entorno Organizacional]] — es una de las dos vías por las que el entorno afecta al gerente
- [[Entorno General y Específico]] — el entorno específico se presenta con esta misma figura
- [[Incertidumbre Ambiental]] — la otra vía; y calibra el paso 4 de este proceso
- [[Gestión y Control del Entorno]] — los acuerdos con las partes son una estrategia de control
- [[Entrega 1 - Ambiente Organizacional]] — hay que mapear las partes interesadas de Clickie

## En el parcial

Identificar y priorizar los stakeholders de una organización siguiendo las 4 etapas. La actividad de clase fue: participantes internos de la universidad.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

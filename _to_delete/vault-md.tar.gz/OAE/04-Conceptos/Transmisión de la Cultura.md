---
tipo: concepto
materia: OAE
unidad: U2
parcial: 1
autor: Robbins & Coulter
estado: estudiado
tags: [OAE, U2, cultura]
---

# Transmisión de la Cultura

> Los cuatro vehículos por los que los miembros aprenden la cultura: relatos, rituales, objetos y símbolos materiales, y lenguaje.

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]]

## Desarrollo

La cátedra lo titula **"Cultura organizacional: Aprendizaje"**.

- **RELATOS** — anécdotas sobre hechos o personas, que **arraigan el presente en el pasado**
  y legitiman las prácticas actuales.
- **RITUALES** — actos repetidos sobre valores, metas y personas.
- **OBJETOS y SÍMBOLOS MATERIALES** — instalaciones, vestimenta, autos, **carteles**;
  comunican quién es importante y qué conducta se espera.
- **LENGUAJE** — abreviaturas y vocabulario común; identifica y cohesiona a los miembros.

> ⚠️ **Cambió la terminología en el deck 2026:** antes decía *ANÉCDOTAS* y *RITOS*; ahora es
> **RELATOS** y **RITUALES**, y se agregó *objetos* y *carteles*. Usá los términos nuevos.

**Actividad de la cátedra:** *"y si lo aplicamos a nuestra facultad o universidad…"* —
identificar los relatos, rituales, símbolos y lenguaje propios de la UCC / la Facultad de
Ingeniería. Es candidato firme a pregunta de parcial por lo fácil que es de evaluar.

**Dónde encaja:** estos cuatro vehículos son la parte **visible** del
[[Iceberg de la Cultura Organizacional]]. Lo que transmiten son los valores y supuestos de la
parte **invisible**.

## Conexiones

- [[Cultura Organizacional]] — es lo que se transmite
- [[Iceberg de la Cultura Organizacional]] — los cuatro vehículos son la parte visible del iceberg
- [[Origen y Sostenimiento de la Cultura]] — la transmisión es el mecanismo de la etapa de socialización
- [[Efectos de la Cultura sobre Roles y Misiones]] — lo transmitido moldea lo que cada uno hace

## En el parcial

Identificar los cuatro vehículos en un caso. Aplicalo a la UCC, que es el ejercicio que propuso la profe.

---
Fuente: `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` (versión 2026)

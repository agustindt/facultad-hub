---
tipo: concepto
materia: OAE
unidad: U1
parcial: 1
autor: Mintzberg
estado: estudiado
tags: [OAE, U1, gerencia, roles, Mintzberg]
---

# Roles Gerenciales (Mintzberg)

> Diez categorías particulares del comportamiento administrativo, agrupadas en tres familias: interpersonales, informativos y de decisión.

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]]

## Desarrollo

```mermaid
mindmap
  root(("10 ROLES<br/>Mintzberg"))
    INT["INTERPERSONALES<br/>relaciones con personas"]
      Representante["Representante<br/>(figura de proa)"]
      Lider["Líder"]
      Enlace["Enlace"]
    INF["INFORMATIVOS<br/>recibir, procesar<br/>y transmitir info"]
      Monitor["Monitor"]
      Difusor["Difusor"]
      Portavoz["Portavoz"]
    DEC["DE DECISIÓN<br/>elegir y comprometer<br/>recursos"]
      Emprendedor["Emprendedor"]
      Conflictos["Solucionador<br/>de conflictos"]
      Recursos["Asignador<br/>de recursos"]
      Negociador["Negociador"]
```

**3 · 3 · 4** — así se cuentan los diez sin olvidarse ninguno.

**Cómo leerlos bien:**

- Los roles **no son excluyentes ni sucesivos**: un mismo gerente los alterna durante el día.
- Lo que cambia entre niveles es la **mezcla**, no el repertorio. Arriba pesan más los de
  decisión y el de portavoz; abajo, los de líder y solucionador de conflictos.
- Son **descriptivos**: Mintzberg observó lo que los gerentes hacen realmente, en contraste
  con lo que Fayol dice que deberían hacer. Por eso los dos modelos conviven sin
  contradecirse.

Diferencia con Katz, que se confunde en el parcial: **habilidad = aptitud que se posee**;
**rol = conducta que se ejerce**.

## Conexiones

- [[Habilidades Administrativas (Katz)]] — habilidad es la aptitud, rol es la conducta — no son lo mismo
- [[Niveles Gerenciales]] — la mezcla de roles varía según el nivel
- [[Funciones Gerenciales (Fayol)]] — Fayol es normativo (qué debería hacer), Mintzberg descriptivo (qué hace)
- [[Toma de Decisiones]] — cuatro de los diez roles son de decisión

## En el parcial

Dan una situación ('el gerente firma un acuerdo con un proveedor') y piden identificar el rol → negociador.

---
Fuente: `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

---
tipo: seguimiento
materia: OAE
tags: [OAE, seguimiento, cronograma]
---

**Materia:** [[OAE]] · Ver también [[condiciones]] · [[tracker-proyecto]]

# Cronograma OAE 2026

Fuente: `OAE - Programa 2026.pdf` (6.1) y `OAE 2026_ Condiciones - Parciales.pdf`. Clases todos los lunes.

| Sem | Fecha | Teórico | Práctico / Hitos |
|---|---|---|---|
| 1 | 03/08 | U1: Organización y Administración | TP1: Organización y Administración |
| 2 | 10/08 | U2: Entorno y Cultura Organizacional | TP2 + explicación Entrega 1 |
| 3 | 17/08 | *(feriado)* | *(feriado)* |
| 4 | 24/08 | U3: Planificación | TP3: Planificación |
| 5 | 31/08 | U4: Toma de decisiones | TP4 + **Entrega 1: Ambiente organizacional** |
| 6 | 07/09 | **Parcial 1 (Unidades 1,2,3,4)** | Seguimiento de proyectos por turnos |
| 7 | 14/09 | U5: RSE | TP5 + explicación Entrega 2 (GestionaRSE) |
| 8 | 21/09 | U6: Administración de RRHH | TP6 + explicación Entrega 3 (Perfiles de Puestos) |
| 9 | 28/09 | U7: Tablero de Comando | TP7 + **Entrega 2: Guía GestionaRSE** |
| 10 | 05/10 | U7: Tablero de Comando (cont.) | TP7 + explicación Entrega 4 (Indicadores) |
| 11 | 12/10 | *(feriado)* | **Entrega 3: Perfiles de Puestos** |
| 12 | 19/10 | Disertación de invitados | Seguimiento de proyectos por turnos |
| 13 | 26/10 | U8: Control y Auditoría | TP8 + **Entrega 4: Indicadores de gestión** |
| 14 | 02/11 | Recuperatorio Regularidad Parcial 1 (U1-4) | **Entrega final del proyecto** (U2,5,6,7) |
| 15 | 09/11 | Recuperatorio Promoción Parcial 2 (U5-8) | **Defensa oral del proyecto** |

## Fechas clave (ya cargadas en Apple Calendar y Reminders — calendario/lista "OAE")

| Fecha | Evento | Tipo |
|---|---|---|
| 31/08/2026 | Entrega 1 — Ambiente organizacional | Deadline proyecto |
| 07/09/2026 | Parcial 1 (Unidades 1,2,3,4) | Examen |
| 28/09/2026 | Entrega 2 — Guía GestionaRSE | Deadline proyecto |
| 12/10/2026 | Entrega 3 — Perfiles de Puestos | Deadline proyecto |
| 26/10/2026 | Entrega 4 — Indicadores de gestión | Deadline proyecto |
| 02/11/2026 | Entrega final del proyecto + Recuperatorio Parcial 1 (si aplica) | Deadline / Examen |
| 09/11/2026 | Defensa oral del proyecto + Recuperatorio Parcial 2 (si aplica) | Examen / Defensa |

Nota: "entrega fuera de tiempo resta 1 punto" — conviene recordatorio 2-3 días *antes* de cada entrega, no solo el día.

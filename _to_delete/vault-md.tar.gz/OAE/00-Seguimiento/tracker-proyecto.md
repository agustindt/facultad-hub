---
tipo: seguimiento
materia: OAE
proyecto: Clickie iA
tags: [OAE, seguimiento, proyecto]
---

**Materia:** [[OAE]] · **Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]

# Tracker — Proyecto de Cátedra (Parcial 2)

**Empresa:** Clickie iA — perfil completo en `../03-Proyecto-Catedra/00-empresa-clickie.md`.
**Requisito de cátedra:** empresa en Córdoba Capital, 5+ integrantes → Clickie cumple ubicación (sede Córdoba); tamaño de equipo a confirmar en la Entrega 1 (probablemente <5 en plantilla directa, pero con red de 5.000+ técnicos verificados — vale la pena aclarar esto en el informe).

## Equipo del TP (máx. 4 integrantes)
- Agustín Di Tomaso — rol: *(a definir)*
- *(a definir)*
- *(a definir)*
- *(a definir)*

> Roles pendientes de definición — actualizar esta tabla cuando el grupo se organice.

## Estado de las entregas

| # | Entrega | Vencimiento | Estado | Nota | Notas |
|---|---|---|---|---|---|
| 1 | Ambiente organizacional | 31/08/2026 | Sin empezar | — | — |
| 2 | Guía GestionaRSE | 28/09/2026 | Sin empezar | — | — |
| 3 | Perfiles de Puestos | 12/10/2026 | Sin empezar | — | — |
| 4 | Indicadores de gestión | 26/10/2026 | Sin empezar | — | — |
| — | Informe final (integra U2,5,6,7) | 02/11/2026 | Sin empezar | — | — |
| — | Defensa oral | 09/11/2026 | Sin empezar | — | — |

Estados posibles: Sin empezar / En investigación / Borrador / Listo para revisar / Entregado.

## Criterios de evaluación de la cátedra (para autochequeo antes de entregar)
- Comprensión de la realidad de la empresa.
- Cumplimiento de presentación, redacción, contenido y puntualidad (tarde = -1 punto).
- Calidad del trabajo en equipo.
- Claridad conceptual y capacidad de análisis/búsqueda.
- Responsabilidad, predisposición e interés demostrados.

## Técnicas de relevamiento sugeridas por la guía
Entrevistas, observación directa, cuestionarios, investigación (sitios web, informes, artículos). Para Clickie iA: combinar fuentes públicas (prensa, web oficial) con acceso directo al equipo/repo interno del usuario — más rico que un relevamiento externo típico.

---
tipo: seguimiento
materia: OAE
estado: pendiente
tags: [OAE, programa, seguimiento]
---

# Programa de OAE

> Los temas que la cátedra dice que entran, uno por fila. El hub los compara contra las notas
> que existen y marca los huecos.

**Materia:** [[OAE]]

**Fuente:** Tabla de unidades del aula virtual 12680, relevada en `00-Sistema/_scrape/oae.md`.

⚠️ **El aula de la que sale esta tabla es de 2020–2022, no de esta cursada.** Hay tres pruebas
en el archivo de scraping (fechas de entrega de 2020 y 2022, un "Programa 2022" y una carpeta
de Drive llamada "-Actividades 2021-"). Los temas siguen siendo la referencia más detallada
disponible, pero **no son un programa verificado de 2026**: tratalos como un borrador hasta
confirmarlos con la cátedra.

⚠️ Además, **el aula lista 7 unidades y el vault tiene 8.** Esa diferencia sigue sin resolverse.

## Índice

- **U1** — UNIDAD 1 · 0 temas
- **U2** — UNIDAD 2 · 0 temas
- **U3** — Estructuras organizacionales / RR.HH. · 1 temas
- **U4** — Tablero de Comando · 4 temas
- **U5** — Toma de decisiones y Planificación · 6 temas
- **U6** — RSU / Responsabilidad Social · 1 temas
- **U7** — Control y Auditoría Interna · 5 temas

Total: **17 temas** en 7 unidades.

## Temas

La columna **Nota** es un override manual: si el hub no encuentra la nota que cubre un tema y
vos sabés cuál es, poné el wikilink ahí y deja de marcarlo como hueco. Vacía, el hub busca solo.

| Unidad | Tema | Nota |
|---|---|---|
| U1 | *(sin contenidos publicados)* |  |
| U2 | *(sin contenidos publicados)* |  |
| U3 | Sistema de RR.HH., proceso de administración de RR.HH., contrato psicológico |  |
| U4 | Control de gestión |  |
|  | Tablero de Comando: concepto, objetivos, funciones, arquitectura, metodología para su construcción |  |
|  | Cuadro de Mando Integral (CMI): perspectivas, matriz, inductores |  |
|  | Indicadores de gestión: concepto, tipos, clasificación |  |
| U5 | Toma de decisiones: concepto, proceso, racionalidad, tipos de problemas y decisiones, condiciones para decidir, estilos, prejuicios y errores, técnicas |  |
|  | Decisiones inherentes a cada función gerencial |  |
|  | Planificación: concepto, propósitos, tipos de planes |  |
|  | Proceso de Administración Estratégica |  |
|  | Análisis FODA |  |
|  | Estrategias organizacionales |  |
| U6 | RSE, desarrollo sostenible, ODS, PROÉTICA |  |
| U7 | Control: concepto, proceso, tipos, cualidades de un sistema de control efectivo y sus disfuncionalidades |  |
|  | Auditoría: concepto, elementos, tipos, etapas, proceso |  |
|  | Riesgo y Control Interno: concepto, importancia, factores y tipos de riesgo, objetivos del control interno |  |
|  | Influencia del control interno en auditoría |  |
|  | Normas generales y particulares del Control Interno |  |

## Faltantes

- Los temas de U1 y U2 no están en la tabla del aula (dice solo "ya cargada en el vault"): habría que transcribirlos del programa oficial cuando aparezca.
- El programa 2026 de la cátedra no está publicado en ningún lado accesible.
- No está confirmado qué unidades entran en el parcial.

---
tipo: seguimiento
materia: OAE
objetivo: promocion-directa
tags: [OAE, seguimiento, condiciones]
---

**Materia:** [[OAE]] · Ver también [[cronograma]] · [[tracker-proyecto]]

# Condiciones de aprobación — OAE 2026

Fuente: `OAE - Programa 2026.pdf` (7.3) y `OAE 2026_ Condiciones - Parciales.pdf`.

## Regular
- Asistencia ≥ 65% (teórico y práctico).
- Notas ≥ 4 en parcial 1 (U1-4) y parcial 2 / proyecto de cátedra (U2,5,6,7).
- Promedio general ≥ 4.
- Se puede recuperar 1 parcial por ausencia o por estar desaprobado.

## Promoción Directa (objetivo del usuario: nota ≥7)
- Asistencia ≥ 80% (teórico y práctico).
- Todas las evaluaciones con nota ≥ 7 en primera instancia, **o** promedio ≥7 en todos los parciales.
- Solo se puede recuperar 1 parcial (para promocionar, el parcial 2 recuperatorio es teórico-práctico escrito U5-8, no el proyecto).
- Si se reprueba el recuperatorio → condición LIBRE.

## Regla de oro del régimen
Solo se recupera **un** parcial, sea el 1 o el 2/proyecto. Perder ambos (o reprobar el recuperatorio) = libre. Por eso el objetivo es no necesitar recuperatorio en ninguno de los dos.

## Escala de notas
| % | Nota | Calificación |
|---|---|---|
| 0-18% | 1 | Reprobado |
| 19-36% | 2 | Reprobado |
| 37-54% | 3 | Reprobado |
| 55-58% | 4 | Regular |
| 59-66% | 5 | Regular |
| 67-74% | 6 | Bueno |
| 75-81% | 7 | Bueno |
| 82-88% | 8 | Muy Bueno |
| 89-96% | 9 | Muy Bueno |
| 97-100% | 10 | Excelente |

## Checklist de seguimiento (actualizar a medida que avanza la cursada)

- [ ] Asistencia semana 1 (03/08)
- [ ] Asistencia semana 2 (10/08)
- [ ] Asistencia semana 4 (24/08) — 17/08 es feriado
- [ ] Asistencia semana 5 (31/08)
- [ ] Parcial 1 rendido (07/09) — nota: ___
- [ ] Asistencia semanas 7-13 (14/09 a 26/10)
- [ ] % asistencia acumulado ≥ 80% verificado antes del cierre

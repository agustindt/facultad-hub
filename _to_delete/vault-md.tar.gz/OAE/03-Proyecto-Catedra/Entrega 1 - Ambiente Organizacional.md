---
tipo: entrega
materia: OAE
proyecto: Clickie iA
vencimiento: 2026-08-31
estado: sin-empezar
nota:
tags: [OAE, proyecto, entrega]
---

# Entrega 1 - Ambiente Organizacional

**Vence:** 31/08/2026 · **Estado:** ⚪ sin empezar ·
⚠️ entrega tardía = −1 punto
**Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]
**Unidad que aplica:** [[U2-Entorno-y-Cultura-Organizacional]]

## Qué pide la cátedra

Analizar el **ambiente organizacional** de Clickie iA: el entorno en el que opera y la
cultura que la caracteriza.

> ⚠️ La consigna detallada se explica en clase (semana del 10/08, junto al TP2). Cargar acá
> la versión textual de la cátedra cuando la den — no dar por buena esta estructura tentativa.

## Conceptos que hay que aplicar

- [[Entorno Organizacional]]
- [[Entorno General y Específico]]
- [[Componentes del Entorno]]
- [[PESTEL]]
- [[5 Fuerzas de Porter]]
- [[Incertidumbre Ambiental]]
- [[Partes Interesadas]]
- [[Cultura Organizacional]]
- [[Origen y Sostenimiento de la Cultura]]
- [[Cultura Fuerte vs Débil]]
- [[FODA]]

## Estructura tentativa

1. **Entorno general** → **matriz [[PESTEL]]** (factor / detalle / plazo / impacto) sobre el
   mercado argentino de servicios del hogar. El formato de matriz está en el deck 2026
2. **Entorno específico** → [[Partes Interesadas]] (Figura 3.4, participantes): técnicos,
   usuarios, inversores, competencia. Complementar con [[5 Fuerzas de Porter]] si la profe
   confirma que sigue vigente — salió del deck 2026
3. **Partes interesadas** → usuarios, técnicos verificados, inversores (Toronto Trust,
   Canzani), municipios, gremios de oficios
4. **Incertidumbre ambiental** → ubicar Clickie en la matriz y justificar
5. **Cultura organizacional** → origen (filosofía de los fundadores), dimensiones, si es
   fuerte o débil
6. **Síntesis** → [[FODA]]

## Nota de la cátedra a resolver

El requisito es una empresa de Córdoba Capital con **5+ integrantes**. Clickie cumple la
ubicación; el tamaño hay que aclararlo: plantilla directa probablemente <5, pero con red de
**+5.000 técnicos verificados**. Conviene explicitarlo en el informe antes de que lo
pregunten.

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Entregado **en fecha**
- [ ] Claridad conceptual y análisis propio

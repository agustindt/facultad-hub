---
tipo: entrega
materia: OAE
proyecto: Clickie iA
vencimiento: 2026-09-28
estado: sin-empezar
nota:
tags: [OAE, proyecto, entrega]
---

# Entrega 2 - Guia GestionaRSE

**Vence:** 28/09/2026 · **Estado:** ⚪ sin empezar ·
⚠️ entrega tardía = −1 punto
**Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]

## Qué pide la cátedra

Aplicar la **guía GestionaRSE** (ICDA) sobre Clickie iA.

> Consigna se explica el 14/09 junto a la U5.

## Conceptos que hay que aplicar

*(se definen cuando se libere la consigna)*

## Ángulo a explorar

Tensión propia del modelo de negocio: **impacto social positivo** (democratizar el acceso a
oficios de confianza, formalizar técnicos) frente a las **condiciones de los técnicos
independientes** (sin relación de dependencia). Es exactamente el tipo de tensión que una
guía de RSE busca sacar a la luz — mejor abordarla de frente que esquivarla.

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Entregado **en fecha**
- [ ] Claridad conceptual y análisis propio

---
tipo: referencia
materia: OAE
proyecto: Clickie iA
tags: [OAE, proyecto, empresa]
---

**Proyecto:** [[Proyecto de Catedra]] · **Seguimiento:** [[tracker-proyecto]] · **Materia:** [[OAE]]

# Perfil de empresa — Clickie iA

Compilado inicial para arrancar el Proyecto de Cátedra. Es punto de partida, no el informe final — completar/verificar con el equipo real de Clickie antes de cada entrega.

## Qué es
Startup argentina (con sede en **Córdoba Capital**) de servicios del hogar potenciados con IA: los usuarios piden un plomero, gasista, electricista, etc. desde una app; un asistente de IA (chat + video-llamada) diagnostica el problema, da un precio estimado y asigna un técnico verificado. Categorías: gas, electricidad, plomería, carpintería, pintura, albañilería, herrería, y reparación de heladeras/aires/lavarropas.

## Datos de tracción (fuentes públicas, ago-2026)
- +25.000 usuarios y +5.000 técnicos verificados.
- Ronda de inversión ángel cerrada por US$150.000 (participan Fernando Canzani y Toronto Trust, del grupo Banco Hipotecario).
- Operativa en Córdoba Capital, CABA y GBA; expansión anunciada a Chile.
- ~85% de los diagnósticos preliminares se resuelven sin intervención humana (IA).

Fuentes:
- [Cronista — "Crearon plataforma que soluciona arreglos del hogar y ahora consiguieron inversión para expandirse a Chile"](https://www.cronista.com/infotechnology/entreprenerds/crearon-plataforma-que-soluciona-arreglos-del-hogar-y-ahora-consiguieron-inversion-para-expandirse-a-chile/)
- [Emprelatam — "Clickie cierra ronda de inversión por US$150.000"](https://blog.emprelatam.com/2026/04/22/clickie-cierra-ronda-de-inversion-por-us-150-000-para-transformar-los-servicios-del-hogar-con-ia/)
- [La Nación — "Empezaron con menos de US$100 y cerraron una inversión de US$150.000"](https://www.lanacion.com.ar/economia/IA/empezaron-con-menos-de-us100-y-cerraron-una-inversion-de-us150000-nid22062026/)
- [Yahoo Noticias — "El momento Uber de los oficios: la startup cordobesa..."](https://es-us.noticias.yahoo.com/uber-oficios-startup-cordobesa-usa-130600327.html)
- [Sitio oficial — clickie.com.ar](https://clickie.com.ar/)

## Fuente interna (repo del usuario)
`~/Documents/github.com/ClickieiA-siliconvalley` — monorepo mobile (Expo/React Native) + docs de arquitectura. Backend FastAPI (conversation_service, diagnostico_service, description_service) fuera del repo, en easypanel.

Personas mencionadas en los docs internos (`docs/presentacion/`, `docs/handoff/`): Agustín (usuario), Juan, Gonza (CTO) — a confirmar roles exactos y organigrama real para la Unidad 6/Entrega 3 (Perfiles de Puestos).

## Para completar en cada entrega
- **Entrega 1 (Ambiente organizacional):** entorno general (PESTEL) y específico, cultura organizacional — usar TP2 cuando se libere + Unidad 2.
- **Entrega 2 (GestionaRSE):** aplicar guía ICDA sobre Clickie — pensar en impacto social del modelo (democratizar acceso a oficios de confianza) vs. condiciones de los técnicos independientes (posible tensión RSE).
- **Entrega 3 (Perfiles de Puestos):** estructura real del equipo (fundadores + quién hace qué) — entrevistar a Juan/Gonza si es necesario.
- **Entrega 4 (Indicadores):** el producto ya tiene métricas propias (usuarios activos, técnicos verificados, % diagnóstico automático, tiempo de asignación) — buena base real para un Tablero de Comando en vez de inventar indicadores genéricos.


## Conceptos de OAE que se le aplican

| Concepto | Dónde se usa |
|---|---|
| [[Organizaciones Exponenciales (ExO)]] | Actividad 5 (infografía) — staff on demand, algoritmos, activos apalancados |
| [[PTM - Propósito de Transformación Masiva]] | TP1 y Actividad 5 |
| [[Organización como Sistema]] | SIPOC del [[TP1-Organizacion-y-Administracion]] |
| [[Clasificación de Organizaciones]] | Privada, nacional, con fines de lucro, servicios, MiPyme |
| [[PESTEL]] · [[5 Fuerzas de Porter]] · [[FODA]] | [[Entrega 1 - Ambiente Organizacional]] |
| [[Cultura Organizacional]] · [[Origen y Sostenimiento de la Cultura]] | [[Entrega 1 - Ambiente Organizacional]] |
| [[Incertidumbre Ambiental]] · [[Partes Interesadas]] | [[Entrega 1 - Ambiente Organizacional]] |

---
tipo: entrega
materia: OAE
proyecto: Clickie iA
vencimiento: 2026-11-02
estado: sin-empezar
nota:
tags: [OAE, proyecto, entrega]
---

# Informe Final del Proyecto

**Vence:** 02/11/2026 · **Estado:** ⚪ sin empezar ·
⚠️ entrega tardía = −1 punto
**Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]

## Qué pide la cátedra

Informe final que **integra** las cuatro entregas (U2, U5, U6, U7).

## Conceptos que hay que aplicar

*(se definen cuando se libere la consigna)*

## Qué integra

| Sección | Viene de |
|---|---|
| Ambiente organizacional | [[Entrega 1 - Ambiente Organizacional]] |
| RSE | [[Entrega 2 - Guia GestionaRSE]] |
| Perfiles de puestos | [[Entrega 3 - Perfiles de Puestos]] |
| Indicadores | [[Entrega 4 - Indicadores de Gestion]] |

No es un pegado de las cuatro: hay que darle hilo conductor.

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Entregado **en fecha**
- [ ] Claridad conceptual y análisis propio

---
tipo: entrega
materia: OAE
proyecto: Clickie iA
vencimiento: 2026-10-26
estado: sin-empezar
nota:
tags: [OAE, proyecto, entrega]
---

# Entrega 4 - Indicadores de Gestion

**Vence:** 26/10/2026 · **Estado:** ⚪ sin empezar ·
⚠️ entrega tardía = −1 punto
**Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]

## Qué pide la cátedra

Construir el **tablero de comando** con indicadores de gestión de Clickie iA.

> Consigna se explica el 05/10 junto a la U7.

## Conceptos que hay que aplicar

*(se definen cuando se libere la consigna)*

## Ventaja del caso

El producto **ya tiene métricas propias reales**: usuarios activos, técnicos verificados,
% de diagnósticos resueltos sin intervención humana (~85%), tiempo de asignación. Es una base
concreta para un tablero, en vez de inventar indicadores genéricos. Aprovechar eso es
justamente lo que la cátedra puntúa como "comprensión de la realidad de la empresa".

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Entregado **en fecha**
- [ ] Claridad conceptual y análisis propio

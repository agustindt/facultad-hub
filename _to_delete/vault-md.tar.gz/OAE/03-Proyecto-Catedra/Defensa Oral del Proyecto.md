---
tipo: entrega
materia: OAE
proyecto: Clickie iA
vencimiento: 2026-11-09
estado: sin-empezar
nota:
tags: [OAE, proyecto, entrega]
---

# Defensa Oral del Proyecto

**Vence:** 09/11/2026 · **Estado:** ⚪ sin empezar ·
⚠️ entrega tardía = −1 punto
**Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]

## Qué pide la cátedra

Defensa oral del proyecto ante la cátedra. Forma parte del promedio del Parcial 2.

## Conceptos que hay que aplicar

*(se definen cuando se libere la consigna)*

## Preparación

- [ ] Repartir quién expone qué
- [ ] Ensayo cronometrado
- [ ] Anticipar preguntas sobre el tamaño de la empresa (ver [[Entrega 1 - Ambiente Organizacional]])
- [ ] Tener a mano los números de tracción de [[Clickie iA - Perfil de la Empresa]]

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Entregado **en fecha**
- [ ] Claridad conceptual y análisis propio

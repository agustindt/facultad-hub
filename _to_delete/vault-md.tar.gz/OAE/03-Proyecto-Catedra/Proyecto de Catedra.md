---
tipo: moc
materia: OAE
proyecto: Clickie iA
estado: en-curso
tags: [moc, OAE, proyecto]
---

# Proyecto de Cátedra — Clickie iA  *(= Parcial 2)*

**Empresa:** [[Clickie iA - Perfil de la Empresa]] · **Materia:** [[OAE]] ·
**Seguimiento:** [[tracker-proyecto]]

La nota del proyecto es el **promedio de las etapas + la defensa oral**.
⚠️ **Entrega tardía = −1 punto.**

## Entregas

| # | Entrega | Vence | Unidad que aplica | Estado |
|---|---|---|---|---|
| 1 | [[Entrega 1 - Ambiente Organizacional]] | 31/08 | [[U2-Entorno-y-Cultura-Organizacional]] | ⚪ Sin empezar |
| 2 | [[Entrega 2 - Guia GestionaRSE]] | 28/09 | U5 — RSE | ⚪ Sin empezar |
| 3 | [[Entrega 3 - Perfiles de Puestos]] | 12/10 | U6 — RRHH | ⚪ Sin empezar |
| 4 | [[Entrega 4 - Indicadores de Gestion]] | 26/10 | U7 — Tablero de Comando | ⚪ Sin empezar |
| — | [[Informe Final del Proyecto]] | 02/11 | Integra U2, U5, U6, U7 | ⚪ Sin empezar |
| — | [[Defensa Oral del Proyecto]] | 09/11 | — | ⚪ Sin empezar |

## Equipo

⚠️ **Sin definir.** Máximo 4 integrantes. La Entrega 1 es grupal — esto es lo más urgente
del proyecto. Ver [[tracker-proyecto]].

## Criterios de evaluación de la cátedra

- Comprensión de la realidad de la empresa
- Cumplimiento de presentación, redacción, contenido y **puntualidad**
- Calidad del trabajo en equipo
- Claridad conceptual y capacidad de análisis/búsqueda
- Responsabilidad, predisposición e interés

## Técnicas de relevamiento

Entrevistas · observación directa · cuestionarios · investigación (sitios web, informes,
artículos). Ventaja del caso: hay **acceso directo al equipo y al repo interno**, mucho más
rico que un relevamiento externo típico.

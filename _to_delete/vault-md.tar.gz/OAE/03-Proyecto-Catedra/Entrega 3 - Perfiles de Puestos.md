---
tipo: entrega
materia: OAE
proyecto: Clickie iA
vencimiento: 2026-10-12
estado: sin-empezar
nota:
tags: [OAE, proyecto, entrega]
---

# Entrega 3 - Perfiles de Puestos

**Vence:** 12/10/2026 · **Estado:** ⚪ sin empezar ·
⚠️ entrega tardía = −1 punto
**Proyecto:** [[Proyecto de Catedra]] · **Empresa:** [[Clickie iA - Perfil de la Empresa]]

## Qué pide la cátedra

Definir los **perfiles de puestos** de Clickie iA.

> Consigna se explica el 21/09 junto a la U6.

## Conceptos que hay que aplicar

*(se definen cuando se libere la consigna)*

## Insumos que ya existen

Estructura real del equipo a relevar: fundadores y quién hace qué. En los docs internos
(`docs/presentacion/`, `docs/handoff/`) aparecen Agustín, Juan y Gonza (CTO) — hay que
confirmar roles exactos y armar el organigrama real. Requiere entrevista.

## Checklist antes de entregar

- [ ] Comprensión de la realidad de la empresa
- [ ] Presentación y redacción
- [ ] Contenido completo según consigna
- [ ] Entregado **en fecha**
- [ ] Claridad conceptual y análisis propio

# OAE — Organización y Administración de Empresas (2026)

Proyecto de estudio para aprobar la materia con nota ≥7 (promoción directa). Cátedra UCC Facultad de Ingeniería, Plan 2016. Profesores titulares: Judith Disderi (cátedra A) / María Pilar Jular (cátedra B).

## Esto es un vault de Obsidian

La carpeta raíz `~/Documents/Facultad/` es un **vault de Obsidian**. Antes de crear o editar notas, leer `../00-Sistema/Convenciones.md` — ahí están las reglas de nombres, frontmatter y enlaces.

Reglas que hay que respetar sí o sí al escribir notas:

- **Frontmatter YAML obligatorio** en toda nota nueva (`tipo`, `materia`, `unidad`, `parcial`, `estado`, `tags`).
- **Wikilinks `[[Nombre exacto]]`**, no rutas relativas ni markdown links. Obsidian resuelve por nombre de archivo, así que el enlace tiene que coincidir con el `stem` del `.md`.
- **Nunca dejar un wikilink roto.** Después de editar, validar con (ignora los enlaces que estén dentro de bloques o spans de código, que Obsidian no resuelve):
  ```bash
  cd ~/Documents/Facultad && python3 -c "
  import pathlib,re; V=pathlib.Path('.')
  n={p.stem for p in V.rglob('*.md')}
  strip=lambda s: re.sub(r'\`[^\`\n]*\`','',re.sub(r'\`\`\`.*?\`\`\`','',s,flags=re.S))
  r=[(str(p),t) for p in V.rglob('*.md') if 'Plantillas' not in str(p)
     for t in re.findall(r'\[\[([^\]|#]+)', strip(p.read_text())) if t.strip() not in n]
  print(r or 'OK')"
  ```
- **Diagramas en Mermaid, nunca en ASCII art.** Vale tanto para teóricos (unidades, conceptos)
  como para prácticos (TPs, entregas). Obsidian renderiza Mermaid nativo, no hay que instalar
  nada. `flowchart` para casi todo, `quadrantChart` para matrices 2×2, `mindmap` para mapas de
  tema, y SVG inline solo cuando Mermaid no da (barras proporcionales, pirámides). Paleta y
  detalles en `../00-Sistema/Convenciones.md`; tipos probados en `../00-Sistema/_test-render.md`.
- Cada concepto nuevo va como **nota atómica** en `04-Conceptos/` con su bloque `## Conexiones` (3-6 enlaces, cada uno con el motivo). Un enlace sin explicación no sirve para estudiar.
- Conceptos transversales (Porter, PESTEL, FODA) **no se duplican** por materia: se enlaza la misma nota.

## Estructura

```
OAE/
├── OAE.md                  ← MOC de la materia, puerta de entrada
├── CLAUDE.md               ← este archivo
├── 00-Seguimiento/         cronograma · condiciones · tracker-proyecto
├── 01-Unidades/            UX-Nombre/UX-Nombre.md (nota índice + resumen extendido)
├── 02-TPs/
├── 03-Proyecto-Catedra/    MOC del proyecto + 6 notas de entrega + perfil de Clickie
├── 04-Conceptos/           notas atómicas ← el corazón del grafo
├── 05-Recursos/
├── 06-Clases/              YYYY-MM-DD - Clase UX.md
└── 99-Material-Catedra/    PDFs y PPTs oficiales — FUENTE DE VERDAD, no se editan
```

Material oficial (no duplicar, solo referenciar): `99-Material-Catedra/OAE - Programa 2026.pdf`, `OAE 2026_ Condiciones - Parciales.pdf`, `OAE-Guia-TP 2026.pdf`, y los `OAE U1..U7...pdf` / `OAE U2 FODA y PESTEL.pptx`.

## Método de trabajo: aprendizaje asistido / progresivo

No volcar resúmenes completos de una sola vez. Por cada Unidad, avanzar en este orden:

1. **Diagnóstico**: preguntar qué ya sabe el usuario del tema antes de explicar.
2. **Explicación guiada**: ir concepto por concepto, chequeando comprensión (preguntas socráticas, no monólogos).
3. **Resumen incremental**: recién ahí escribir/actualizar `01-Unidades/UX-.../UX-....md` con lo ya visto.
4. **Atomizar**: crear las notas de `04-Conceptos/` correspondientes y enlazarlas desde la nota de unidad.
5. **Autoevaluación**: 5-10 preguntas de repaso (V/F, casos cortos) al cerrar la unidad, en `autoevaluacion.md` de esa unidad.
6. **Repaso espaciado**: antes de arrancar una unidad nueva, repasar brevemente la anterior.

Las Unidades y TPs se crean progresivamente a medida que se cursan, no todas de una. Unidad y TP correspondiente van de la mano (misma semana de cursada).

## Trigger de contexto

Cuando el usuario escriba `/oae`, cargar este archivo + `00-Seguimiento/cronograma.md` + `00-Seguimiento/tracker-proyecto.md` antes de responder — ver `~/.claude/commands/oae.md`.

## Estado de la cursada (ver `00-Seguimiento/cronograma.md` para fechas completas)

- Cursada arrancada la semana del 03/08/2026 con Unidad 1.
- **U1**: teoría vista, TP1 entregado, conceptos atomizados. **Falta el resumen narrativo y la autoevaluación.**
- **U2**: clase del 10/08, resumen y conceptos **actualizados al deck 2026**. **TP2 resuelto** sobre McDonald's/Arcos Dorados (PDF en `~/Desktop`, sin entregar). Falta la autoevaluación.
- Parcial 1 (Unidades 1-4, escrito, teórico-práctico): **07/09/2026**.
- Proyecto de Cátedra = Parcial 2, con 4 entregas + informe final + defensa oral.
- Meta: promoción directa → asistencia ≥80% y todas las notas ≥7 (ver `00-Seguimiento/condiciones.md`).
- Solo se puede recuperar 1 parcial (parcial 1 o proyecto/parcial 2, no ambos). Si se desaprueba el recuperatorio, la condición pasa a LIBRE.

## Guía de TPs — ojo con esto

**Actualizada el 11/08/2026.** La versión nueva de la guía (`OAE-Guia-TP .docx.pdf`, todavía en `~/Downloads` — hay que moverla a `99-Material-Catedra/` y archivar la vieja) ya trae:

- **TP1, TP2 y TP3 completos.**
- **TP4 a medias**: las actividades 1 a 5 figuran vacías, solo está la *Reflexión final* sobre la entrevista a Woods Staton (ex CEO de Arcos Dorados / McDonald's Latinoamérica).
- **TP5 a TP8 vacíos**, se liberan semana a semana en clase.

**No inventar** el contenido de un TP que todavía no se liberó; pedirle al usuario que lo cargue cuando la cátedra lo publique, y mientras tanto trabajar solo con la unidad teórica correspondiente.

⚠️ **La guía usa nomenclatura vieja en las 7 dimensiones**: dice *"Energía"* donde el deck 2026 dice **"Agresividad"**. No son sinónimos (ritmo vs. rivalidad interna). Al resolver, conservar el rótulo de la guía pero aclarar el cambio.

⚠️ La carpeta `99-Material-Catedra/` está **bloqueada a nivel de sistema operativo** (`Operation not permitted` incluso sin sandbox). No se puede listar ni escribir desde Bash/Python — los PDFs los tiene que mover el usuario a mano.

## Proyecto de Cátedra (Parcial 2)

Empresa elegida: **Clickie iA** (startup cordobesa de servicios del hogar con IA — clickie.com.ar). Perfil compilado en `03-Proyecto-Catedra/Clickie iA - Perfil de la Empresa.md`.

Equipo: **sin definir** (máx. 4 integrantes) — es lo más urgente, la Entrega 1 es grupal. Ver `00-Seguimiento/tracker-proyecto.md`.

Entregas (fechas exactas en `00-Seguimiento/cronograma.md`, una nota por entrega en `03-Proyecto-Catedra/`):

1. Ambiente organizacional — 31/08
2. Guía GestionaRSE — 28/09
3. Perfiles de Puestos — 12/10
4. Indicadores (Tablero de Comando) — 26/10
5. Informe final — 02/11
6. Defensa oral — 09/11

Regla de la cátedra: **entrega tardía resta 1 punto**. La nota del proyecto es el promedio de las etapas + defensa oral.

## Versiones del material — ojo con esto

**El 10/08/2026 la profe reemplazó el PDF de U2** por una versión 2026 basada en Robbins & Coulter. La versión anterior (2018) está en `99-Material-Catedra/_archivo-versiones-viejas/` y **no debe usarse para estudiar**. Cambios evaluables: "Energía"→**Agresividad**, "Anécdotas/Ritos"→**Relatos/Rituales**, modelo de 2 niveles→**Iceberg**, "religión"→**folk-lore**, incertidumbre de 3→**2 dimensiones**, 3 fases→**6 escalones** de globalización. Salieron del deck: sectores de Hodge, 5 Fuerzas de Porter, sectores RRHH/RRFF/Consumidores.

Si la cátedra vuelve a reemplazar un PDF: archivar el viejo en `_archivo-versiones-viejas/` con el sufijo `(version AAAA - REEMPLAZADA)`, releer el nuevo completo, y actualizar las notas de concepto afectadas **marcando explícitamente qué cambió** — Agustín puede haber estudiado la versión anterior.

## Pendientes abiertos

- Confirmar con la profe qué es el **"triángulo E-T-O"** (interpretado como pirámide Estratégico-Táctico-Operativo).
- **¿Entran las 5 Fuerzas de Porter en el Parcial 1?** Salieron del deck 2026 de U2.
- **FODA**: el deck 2026 no trae lámina y el `.pptx` sigue siendo imágenes. Falta el material de la cátedra.
- Consigna textual de la **Entrega 1**: verificar si se dio en la clase del 10/08.
- **TP2 — Actividad 2**: depende del *formulario de afinidad cultural* que comparte el docente por comisión. Todavía no se distribuyó; el entregable lleva un perfil preliminar a validar.
- **TP2 — Actividad 4**: el reparto de líderes (Juan/Lucía/Martín/Paula) lo asigna la profe por grupo. Se resolvió tomando a **Paula**; si a Agustín le toca otro, hay que rehacer solo los puntos 1 y 2.

## Calendario / Recordatorios de Apple

El usuario pidió que **antes de crear nada** en Apple Calendar / Reminders se le muestre la lista propuesta para confirmar. No ejecutar `osascript` para crear eventos/recordatorios sin esa confirmación explícita previa.

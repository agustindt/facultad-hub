---
tipo: tp
materia: OAE
unidad: U1
estado: entregado
fecha-clase: 2026-08-03
tags: [OAE, U1, tp]
---

# TP1 — Organización y Administración

**Unidad:** [[U1-Organizacion-y-Administracion]] · **Materia:** [[OAE]] · **Entregado:** sí

## Archivos

- `TP1-Organizacion-y-Administracion.docx` — la resolución entregada
- `Actividad5-Infografia-ExO-Clickie.png` — infografía de la Actividad 5

## Consigna (Actividad TP1.1 / 1.2)

Caracterizar una organización como Sistema:

1. ¿Cuál es su **razón de ser** (misión vs. visión, PTM)?
2. ¿Cuáles serían sus **componentes** (diagrama SIPOC)?
3. ¿Con qué **actores del medio** intercambia recursos, insumos y productos
   (entorno general y específico)?
4. ¿Cómo se la puede **clasificar**?

Actividad complementaria: ¿en base a qué criterios se mide el tamaño de una empresa?
(categorización MiPymes de ARCA, rankings Fortune 500 / Forbes).

**Actividad 5:** infografía de una organización exponencial → se hizo sobre
[[Clickie iA - Perfil de la Empresa]].

## Conceptos que aplica

- [[Organización como Sistema]] — el SIPOC del punto 2
- [[PTM - Propósito de Transformación Masiva]] — la razón de ser del punto 1
- [[Entorno General y Específico]] — los actores del punto 3
- [[Clasificación de Organizaciones]] — el punto 4
- [[Organizaciones Exponenciales (ExO)]] — la Actividad 5

## Devolución de la cátedra

*(pendiente de cargar)*

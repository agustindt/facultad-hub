---
tipo: tp
materia: OAE
unidad: U2
parcial: 1
estado: resuelto
fecha-clase: 2026-08-10
entregable: "TP2 - Entorno y Cultura Organizacional - McDonalds.pdf"
empresa: McDonald's / Arcos Dorados
tags: [OAE, U2, tp]
---

# TP2 — Entorno y Cultura Organizacional

**Unidad:** [[U2-Entorno-y-Cultura-Organizacional]] · **Materia:** [[OAE]] · **Entregado:** no

> ✅ **11/08/2026 — la guía oficial se actualizó.** La versión nueva
> (`OAE-Guia-TP .docx.pdf`) ya trae el **TP2 completo**, y también el **TP3** y parte del
> **TP4**. Reemplaza a la versión con las actividades vacías. Las consignas de acá abajo son
> **textuales de la guía**, no reconstruidas del deck.

**Empresa de análisis:** McDonald's (operada en Argentina por **Arcos Dorados S.A.**).
**Entregable:** `~/Desktop/TP2 - Entorno y Cultura Organizacional - McDonalds.pdf` (14 pág.,
con el formato de la guía de cátedra).

## Resultados de aprendizaje

a. Reconocer los componentes del entorno general y específico de una organización.
b. Identificar la influencia de la cultura en los comportamientos de los empleados.
c. Visualizar las relaciones causa-efecto de la globalización.

---

## Actividad 1 — Fuerzas del entorno *(teórico)*

**Consigna:** marcar a qué ambiente pertenece cada fuerza.

> ⚠️ **La guía ya trae las cruces puestas.** O sea: es la respuesta de la cátedra, no una
> incógnita. Lo que hay que aportar es la **justificación** y el ejemplo aplicado.

| Fuerza | General | Específico | Componente / Participante |
|---|:---:|:---:|---|
| Económicas | **X** | | Económico |
| Competidores | | **X** | Competidores |
| Clientes | | **X** | Clientes |
| **Sindicatos** | **X** | **X** | ⚠️ doble |
| Entidades financieras | | **X** | Proveedores (financiamiento) |
| Variables político-legales | **X** | | Político/Legal |
| Grupos de presión | | **X** | Grupos de acción política y social |
| Proveedores de bienes y servicios | | **X** | Proveedores |
| Evolución tecnológica | **X** | | Tecnológico |
| **Transporte** | **X** | **X** | ⚠️ doble |
| **Instituciones gubernamentales** | | **X** | Gobiernos ⚠️ |
| Socio-culturales | **X** | | Sociocultural |

### Las tres filas donde se juega la nota

```mermaid
flowchart LR
    F["Una fuerza<br/>del entorno"] --> P{"¿La organización puede<br/><b>negociar</b> con ella,<br/>o recibir un acto<br/><b>dirigido a ella</b>?"}
    P -->|"No · es contexto"| G["<b>GENERAL</b><br/>Figura 3.2<br/><i>seis componentes</i>"]
    P -->|"Sí · es contraparte"| E["<b>ESPECÍFICO</b><br/>Figura 3.4<br/><i>participantes</i>"]
    style G fill:#4DB6AC,stroke:#00897B,color:#fff
    style E fill:#FFA726,stroke:#EF6C00,color:#fff
    style P fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

- **Sindicatos** y **Transporte** llevan **las dos marcas**, y no por ambigüedad: cada una
  tiene una capa de contexto (la paritaria del rubro / la infraestructura vial y el
  combustible) y un actor identificable con el que se intercambia (el gremio que negocia con
  *esta* empresa / el operador logístico y las plataformas de delivery contratadas).
- **Instituciones gubernamentales** queda del lado **específico**, y parece contradecir la
  fila "variables político-legales". No hay contradicción: la **norma** es general porque rige
  para todos; el **organismo que la aplica sobre esta empresa** es un participante.
  **Decide a quién apunta el acto**, no quién lo emite.

> 🔑 **Regla de bolsillo:** *general = contexto · específico = contraparte.*

## Actividad 2 — Perfil sobre afinidad cultural

**Consigna:** completar el formulario que comparte el docente según cátedra/comisión y sacar
conclusiones de los gráficos en línea que muestra en clase.

> ⏸️ **Bloqueada:** el formulario todavía no se distribuyó. En el entregable va un perfil
> individual preliminar con las mismas 7 dimensiones, listo para volcar cuando aparezca.

**Conclusión que sí se puede adelantar:** la afinidad cultural opera **en las dos
direcciones** — la organización filtra candidatos por ajuste cultural en la selección
([[Origen y Sostenimiento de la Cultura|Figura 3.8]]) y el candidato filtra organizaciones por
lo mismo, casi siempre sin poder nombrarlo.

## Actividad 3 — Dimensión cultural *(el núcleo del TP)*

**Consigna:** tomar la organización del TP1.2 u otra que se conozca en profundidad o de la que
se sea cliente frecuente. Puntuar cada dimensión de **1 (baja presencia) a 5 (alta)** en dos
columnas —**Autopercepción** y **Objetivo de desarrollo**— justificar cada una, y responder:
*¿hay gap entre una columna y otra? ¿cuál? ¿por qué?*

> ⚠️ **Ojo con el nombre de la dimensión 5.** La guía dice **"Energía"** (nomenclatura vieja);
> el deck 2026 la reemplazó por **"Agresividad"**, definida como *cuán agresivos y competitivos
> son los empleados en vez de cooperativos*. **No son sinónimos.** En el entregable se puntúan
> las dos lecturas por separado, porque en McDonald's dan resultados opuestos. Ver
> [[Dimensiones de la Cultura Organizacional]].

### Perfil de McDonald's

| # | Dimensión | Autopercep. | Objetivo | Gap |
|---|---|:---:|:---:|:---:|
| 1 | Atención a los detalles | 5 | 5 | 0 |
| 2 | Orientación a los resultados | 4 | 4 | 0 |
| 3 | **Orientación a las personas** | 2 | 4 | **+2** |
| 4 | Orientación a los equipos | 4 | 5 | +1 |
| 5 | Energía *(/ agresividad interna)* | 4 *(2)* | 4 *(2)* | 0 |
| 6 | **Estabilidad** | 5 | 3 | **−2** |
| 7 | **Innovación y riesgos** | 3 | 5 | **+2** |

### El argumento

McDonald's no vende hamburguesas: vende un **sistema replicable**. Todo el perfil sale de ahí.

- **Cuatro dimensiones sin gap** → en su núcleo operativo la cultura está **alineada** con lo
  que el negocio necesita. Es una [[Cultura Fuerte vs Débil|cultura fuerte]] de manual.
- **Dos gaps de +2** (personas, innovación) → son las dimensiones que el sistema **sacrificó
  deliberadamente** para poder estandarizar. No son fallas de implementación: son el **costo
  estructural** del modelo.
- **Un gap de −2** en estabilidad → el **único** caso donde el "deber ser" está *por debajo*
  de lo observado. Es la contracara exacta: la misma rigidez que garantiza el estándar es la
  que hace lento el cambio.

> 🎯 **Los tres gaps son un solo gap dicho de tres maneras:** pasar de una cultura optimizada
> para **ejecutar un estándar conocido** a una capaz de **revisar ese estándar mientras lo
> ejecuta**.

**El remate teórico.** McDonald's construyó su liderazgo en un entorno que para su negocio era
estable; el entorno se volvió dinámico (delivery por plataformas, etiquetado frontal,
hamburgueserías de especialidad, cambio de hábitos) → se desplazó de **celda 3 a celda 4** de
[[Incertidumbre Ambiental]]. Y ahí aparece la tesis de la unidad: **es la misma propiedad la
que produce el beneficio y el perjuicio**.

> **Una cultura fuerte es un activo en entornos estables y un pasivo en entornos turbulentos.**

**El contraste que hay que saber decir:** Netflix *también* tiene cultura fuerte, pero
orientada **en la dirección del cambio** (su valor central es que el *statu quo* es el
enemigo). **Fuerza cultural y flexibilidad son dimensiones independientes** — confundirlas es
el error más común al responder esto.

## Actividad 4 — Caso Pinturerías Apex Color

**Consigna:** rol de consultor organizacional. El curso se divide en 4 grupos, uno por líder
(Juan, Lucía, Martín, Paula); cada grupo hace las consignas 1 y 2 y las 3 restantes se
responden en conjunto.

**Rol tomado:** **Paula** — Responsable del Equipo de Atención al Cliente Digital.

### La clave del caso: cuatro entornos dentro de una misma empresa

| Líder | Entorno | Celda | Método que usa |
|---|---|:---:|---|
| **Juan** — mantenimiento | Pocos componentes, conocidos, sin cambios | **1** | Procedimiento (manual de 450 pág., 99,2% de los casos) |
| **Lucía** — grandes clientes | Muchos y heterogéneos, pero estables | **3** | Análisis profundo, comités, hipótesis, laboratorio |
| **Martín** — programación | Pocos, pero todos en movimiento | **2→4** | Patrones emergentes, reprogramación diaria, algoritmos |
| **Paula** — atención digital | Muchos, heterogéneos y cambiando por minuto | **4** | Decisión inmediata con info incompleta |

Ver [[Incertidumbre Ambiental]] para las celdas.

### Las respuestas, en una línea cada una

1. **PESTEL de Paula** → 5 de 6 factores impactan en el **corto plazo** y todos son negativos.
   Esa concentración temporal es el rasgo del caso. Los actores son **todos del entorno
   específico** (el influencer entra como *medio de comunicación*). Problema **mal
   estructurado**, decisión **no programada**, condición de **incertidumbre**, restricción
   dominante: **el tiempo**.
2. **La más cómoda es la de Juan** — celda 1, la de menor incertidumbre. Pero **no se mantiene
   inalterable**: el IoT de Martín ya está entrando a la planta, cada producto nuevo invalida
   el manual, y la crisis de Paula alcanza a toda la empresa. **La celda 1 es transitoria.**
3. **Si Paula usara el método de Lucía** → el método de Lucía no es malo, es **correcto para su
   celda**. El error no sería usar un método malo sino uno **diseñado para otra celda**. En
   celda 4 produce vacío informativo (el silencio se lee como confirmación), pérdida del canal,
   daño irreversible en góndola y — paradoja — **más** exposición legal, no menos.
4. **Martín y los manuales** → un manual es **experiencia pasada codificada**: sirve cuando el
   futuro se parece al pasado. En su sector la **relación causa-efecto cambia entre corridas**
   (personalización masiva, viscosidad según temperatura, aduana). Por eso pasa de plan
   **específico** a plan **direccional**.
5. **Mayor influencia de la globalización: Lucía** — cliente multinacional que es el 25% de la
   facturación, pigmento importado de Alemania, carta de crédito, ISO 14001, auditorías
   alemanas, y una demanda que existe por la transición global al vehículo eléctrico.
   **Trampa de la pregunta:** Paula parece global porque la viralización lo es en *velocidad*,
   pero el daño que administra es de **mercado local**. Ver
   [[Entorno Global y Globalización]].

## Síntesis

Las tres actividades resueltas convergen en la [[Gerente Omnipotente vs Simbólico|Figura 3.1]]:
el margen del gerente está acotado por una restricción **externa** (entorno) y una **interna**
(cultura).

- **Act. 1** → la restricción externa en su forma básica: qué es contexto y qué es contraparte.
- **Act. 3** → la restricción interna: la cultura de McDonald's es su mayor activo *y* lo que
  demora su respuesta.
- **Act. 4** → las dos juntas: 4 líderes de **una misma empresa**, 4 entornos, 4 métodos.

> **No existe una buena cultura ni un buen método de decisión en abstracto.** Existen culturas
> y métodos **ajustados o desajustados respecto del entorno**.

## Conceptos que aplica

- [[Entorno General y Específico]] — el criterio de la Actividad 1
- [[Componentes del Entorno]] — los seis del lado general
- [[Partes Interesadas]] — los participantes del lado específico
- [[Dimensiones de la Cultura Organizacional]] — las 7 de la Actividad 3
- [[Cultura Fuerte vs Débil]] — el argumento del gap y del lastre
- [[Origen y Sostenimiento de la Cultura]] — selección y socialización como palanca real
- [[Incertidumbre Ambiental]] — las celdas de la Actividad 4
- [[PESTEL]] — la matriz de la Actividad 4.1
- [[Toma de Decisiones]] — problema mal estructurado / decisión no programada
- [[Entorno Global y Globalización]] — la Actividad 4.5

---

## Anexo — Actividades del deck teórico

Estas **no** son el TP2 de la guía, pero salieron del deck 2026 de U2 y son material de
estudio válido para el [[cronograma|Parcial 1]]. Se conservan del trabajo previo.

### Clasificación de fuerzas — casos límite

| Caso | | Por qué |
|---|---|---|
| AFIP saca un régimen de retención para todo el rubro | **G** | Político/Legal. Pero si fiscaliza **a esta empresa** → participante (Gobiernos) → E |
| Google cambia el algoritmo y se pierde medio tráfico | **E** | La tecnología *como tendencia* es general; una **plataforma concreta de la que se depende** es proveedor del canal |
| Sube el salario mínimo (SMVM) | **G** | Rige para toda la economía y no se negoció con la empresa |
| La cámara del sector firma un acuerdo de precios | **E** | *Asociaciones comerciales e industriales*, literal en la Figura 3.4 |
| El banco niega la renovación del crédito | **E** | **La tasa del BCRA es general; que tu banco te corte es específico** |
| Cae la natalidad (empresa de pañales) | **G** | **El impacto es devastador y aun así es general**: la intensidad no cambia la clasificación |

### Una misma fuerza puede cambiar de lado

Ocurre cuando hay una **relación de intercambio identificable** con ese actor.

- **El Estado.** Para una software factory que vende a privados, una ley de contrataciones es
  general. Para una empresa que vive de **licitaciones públicas**, el Estado es su cliente →
  específico. Misma ley, distinto lado.
- **La IA.** Para una panadería es tecnológico/general. Para
  [[Clickie iA - Perfil de la Empresa]], cuyo producto *es* un matcher con IA, un cambio de
  precios en las APIs es un **proveedor** apretando el margen → específico.

### ¿Cómo se mantiene informado el gerente?

1. **Exploración del entorno** (*environmental scanning*) — rastreo sistemático con fuentes
   fijas. No es leer noticias cuando hay un incendio.
2. **Inteligencia competitiva** — el subconjunto dedicado a la competencia, con fuentes
   públicas y legales.
3. **Pronósticos** — proyectar lo detectado para decidir hoy.
4. **Benchmarking** — comparar contra los mejores del rubro.

Y el remate: **los propios participantes son la antena más barata del entorno específico**.

### Caso Netflix — libertad y responsabilidad

Contratar **adultos de alto desempeño** y darles **contexto en lugar de controles**: sin
política de vacaciones ni de gastos, sueldos al tope, franqueza radical, *keeper test*.

| Dimensión | | Por qué |
|---|:---:|---|
| Resultados | alta | Solo se mide el desempeño |
| Innovación y riesgos | alta | Se espera que la gente decida sola y se equivoque |
| Agresividad | alta | Franqueza brutal, competencia por permanecer |
| Detalles | media | Alta exigencia técnica, sin procedimientos formales |
| Equipos | media | *"Somos un equipo, no una familia"* |
| Gente | baja | Paga excelente y despide sin culpa |
| Estabilidad | muy baja | El *statu quo* es explícitamente el enemigo |

**Las dos cosas que casi nadie dice:**

1. **Netflix tiene una cultura FUERTE, no una cultura amable.** Valores escritos, conocidos y
   aplicados sin excepción — la definición de fuerza cultural. Desarma el error de creer que
   *fuerte = buen clima*.
2. **La libertad no es ausencia de control: es control por valores en vez de por reglas.**
   Reemplazó el manual por la **socialización**. Es más restrictivo, no menos.

### Participantes internos de la universidad

Estudiantes · docentes · personal no docente · autoridades · investigadores y becarios ·
órganos de gobierno.

> 🔑 **Donde se puntúa es en el corte:** graduados, empleadores, el Estado, la CONEAU y la
> Compañía de Jesús son **externos**. Están en el entorno específico, pero no son internos.

### Los 4 vehículos aplicados a la UCC

| Vehículo | En la UCC / Facultad de Ingeniería |
|---|---|
| **Relatos** | La fundación jesuita de 1956 · "la materia que voltea a todos" · el profesor mítico |
| **Rituales** | El ingreso · la semana de parciales · la colación y el juramento profesional |
| **Objetos y símbolos** | El campus · el escudo · la capilla · el aula magna |
| **Lenguaje** | *cursar · regularizar · quedar libre · promocionar · recuperatorio · cátedra A/B · el Guaraní · parcialito* |

### Pendientes del anexo (requieren input propio)

- [ ] **Cultura del curso con las 7 dimensiones** (+ ¿restringe a la profe? ¿y al estudiante?)
- [ ] **Generaciones** — año de nacimiento propio, de padres y abuelos → tabla de
      [[Componentes del Entorno]]
- [ ] **Artículo "Tendencias en Culturas Organizacionales en América Latina"** (Café con la
      gerencia) — conseguir el texto

## Devolución de la cátedra

*(pendiente)*

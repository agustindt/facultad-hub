---
tipo: unidad
materia: OAE
unidad: U1
parcial: 1
estado: borrador
fecha-clase: 2026-08-03
tags: [OAE, U1]
---

# U1 — Organización y Administración

**Materia:** [[OAE]] · **Clase:** 03/08/2026 · **TP:** [[TP1-Organizacion-y-Administracion]]
**Material:** `99-Material-Catedra/OAE U1. Organizacion y Administracion.pdf`

> ⚠️ **Resumen largo pendiente.** Los conceptos ya están atomizados abajo (se escribieron al
> hacer la U2, porque el bloque gerencial de U1 se retomó en esa clase), pero falta el
> recorrido narrativo de la unidad y la autoevaluación.

## Idea que ordena la unidad

Qué es una organización, qué es administrarla, y quién la administra. Es la unidad de
definiciones: instala el vocabulario que las siete unidades siguientes dan por sabido.

## Conceptos de la unidad

### Qué es una organización
- [[Organización]] — definición, propósito y las 3 características
- [[Organización como Sistema]] — modelo abierto insumos → transformación → productos, y SIPOC
- [[Clasificación de Organizaciones]] — capital, finalidad, forma jurídica, tamaño, alcance, actividad

### Qué es administrar
- [[Administración]] — ciencia y técnica; jerarquía
- [[Funciones Gerenciales (Fayol)]] — el ciclo planear-organizar-dirigir-controlar
- [[Trilema EEE]] — eficiencia, eficacia, efectividad
- [[Toma de Decisiones]] — en el centro del ciclo *(se profundiza en U4)*

### Quién administra
- [[Niveles Gerenciales]] — el triángulo E-T-O
- [[Habilidades Administrativas (Katz)]] — conceptuales, humanas, técnicas
- [[Roles Gerenciales (Mintzberg)]] — los 10 roles en 3 familias

### Hacia dónde van las organizaciones
- [[Organización que Aprende]] — el cambio de paradigma
- [[Organizaciones Exponenciales (ExO)]] — fórmula SCALE + IDEAS
- [[PTM - Propósito de Transformación Masiva]] — el núcleo del modelo ExO

## Ligada a

- Unidad siguiente: [[U2-Entorno-y-Cultura-Organizacional]] — retoma el bloque gerencial y
  le agrega los dos límites (cultura y entorno)

## Estado

- [x] Teoría vista en clase
- [x] Conceptos atomizados
- [ ] Resumen narrativo escrito
- [ ] Autoevaluación hecha
- [x] TP1 entregado

---
tipo: unidad
materia: OAE
unidad: U2
parcial: 1
estado: estudiado
fecha-clase: 2026-08-10
version-material: 2026 (Robbins & Coulter)
tags: [OAE, U2, cultura, entorno]
---

# U2 — Entorno y Cultura Organizacional

**Materia:** [[OAE]] · **Clase:** [[2026-08-10 - Clase U2]] · **TP:** [[TP2-Entorno-y-Cultura-Organizacional]]
**Entra en:** Parcial 1 (U1-U4) — **07/09/2026**
**Material:** `99-Material-Catedra/OAE U2. Entorno y cultura organizacional.pdf` — **versión 2026**

> ⚠️ **La profe reemplazó el PDF el 10/08/2026.** La versión anterior (2018) quedó archivada en
> `99-Material-Catedra/_archivo-versiones-viejas/`. Los cambios están listados abajo — son
> varios y algunos cambian directamente una respuesta de parcial.

## La idea que ordena la unidad — Figura 3.1

```mermaid
flowchart LR
    E["<b>ENTORNO<br/>ORGANIZACIONAL</b><br/><i>restricción externa</i>"] --> C
    C{{"<b>CRITERIO<br/>GERENCIAL</b>"}}
    K["<b>CULTURA<br/>ORGANIZACIONAL</b><br/><i>restricción interna</i>"] --> C
    style C fill:#7C5CFF,stroke:#5B3FD9,color:#fff
    style E fill:#4DB6AC,stroke:#00897B,color:#fff
    style K fill:#FFA726,stroke:#F57C00,color:#fff
```

*Restricciones en el criterio de un gerente* (Robbins & Coulter).

Cultura y entorno **no son dos temas sueltos que comparten unidad**: son literalmente las dos
restricciones al criterio del gerente. Todo lo demás cuelga de ahí.

## Conceptos de la unidad

**La bisagra:** [[Gerente Omnipotente vs Simbólico]]

**Cultura (restricción interna):** [[Cultura Organizacional]] ·
[[Dimensiones de la Cultura Organizacional]] · [[Cultura Fuerte vs Débil]] ·
[[Origen y Sostenimiento de la Cultura]] · [[Transmisión de la Cultura]] ·
[[Iceberg de la Cultura Organizacional]] · [[Efectos de la Cultura sobre Roles y Misiones]]

**Entorno (restricción externa):** [[Entorno Organizacional]] ·
[[Entorno General y Específico]] · [[Componentes del Entorno]] · [[Incertidumbre Ambiental]] ·
[[Partes Interesadas]] · [[Gestión y Control del Entorno]] ·
[[Entorno Global y Globalización]] · [[Posturas ante el Entorno Global]] ·
[[Hofstede y GLOBE]]

**Herramientas:** [[PESTEL]] · [[FODA]] · [[5 Fuerzas de Porter]] *(⚠️ ya no está en el deck)*

**Repaso gerencial de [[U1-Organizacion-y-Administracion]]:** [[Niveles Gerenciales]] ·
[[Habilidades Administrativas (Katz)]] · [[Roles Gerenciales (Mintzberg)]] ·
[[Funciones Gerenciales (Fayol)]] · [[Trilema EEE]]

## Se aplica en

[[Entrega 1 - Ambiente Organizacional]] — el ambiente organizacional de
[[Clickie iA - Perfil de la Empresa]] es literalmente esta unidad aplicada.

## Estado

- [x] Teoría vista en clase
- [x] Resumen escrito (actualizado al deck 2026)
- [x] Conceptos atomizados
- [ ] Autoevaluación hecha
- [ ] [[TP2-Entorno-y-Cultura-Organizacional]] resuelto

---

# Qué cambió respecto de la versión vieja

Comparación deck 2018 → deck 2026. **Esto es lo primero que hay que revisar si estudiaste de
un resumen anterior.**

## Cambios que afectan una respuesta de parcial

| Tema | Antes (2018) | Ahora (2026) |
|---|---|---|
| **Dimensiones de la cultura** | Energía | **Agresividad** |
| **Aprendizaje de la cultura** | Anécdotas · Ritos | **Relatos · Rituales** (+ objetos, carteles) |
| **Niveles de la cultura** | Modelo de 2 niveles: observables / inobservables | **Iceberg**: visible / invisible |
| **Efectos sobre roles-misiones** | Leyes, costumbres, **religión**, tradición | Reglas, costumbres, tradición, **folk-lore** |
| **Cultura fuerte** | Valores arraigados + **difundidos** | Valores arraigados + **historias compartidas** |
| **Incertidumbre ambiental** | 3 dimensiones (con **munificencia**) | **2 dimensiones**: cambio y complejidad |
| **Globalización** | 3 fases agrupadas | **6 escalones** (Figura 4.4) |
| **Síntesis sobre el gerente** | "Limitaciones internas f(cultura) / externas f(entorno)" | **Figura 3.1 — criterio gerencial** |

## Contenido que se eliminó

- **Clasificación de sectores de Hodge** (industrial, cultural, RRHH, RRFF, consumidores…)
- **Sector Industrial y las [[5 Fuerzas de Porter]]**, con sus barreras de entrada
- **Sector RRHH** (disponibilidad de MO, Córdoba polo informático, flex-time)
- **Sector RR Físicos** (monopolios, condiciones físicas, planes de contención)
- **Sector Consumidores y Clientes** como sector propio
- La **munificencia** como dimensión de la incertidumbre
- Casos Mary Kay, Siemens, NBA, Budweiser, SAP, "Colillas fuera"

## Contenido nuevo

- **Figura 3.1** — restricciones en el criterio de un gerente
- **Iceberg de la cultura** (visible / invisible)
- Dimensiones con **definiciones textuales** (Figura 3.5) + ejercicio Organización A vs. B
- Slide de **Great Place to Work / Forbes** — mejores empresas para trabajar en Argentina
- **Caso Netflix** — libertad y responsabilidad (Robbins pág. 102)
- **Actividad "Trends"** — 3 preguntas sobre cultura
- **MATRIZ PESTEL** (factor / detalle / plazo / impacto) ← *la lámina que faltaba*
- **TP2.1 liberado** — clasificar fuerzas en entorno general o específico
- Entorno específico = **Figura 3.4, participantes** (fusiona con stakeholders)
- **CMN** (corporación multinacional) como término paraguas
- **6 escalones** de internacionalización (Figura 4.4)
- **Hofstede con la Figura 4.6 completa** (ejes con países en cada extremo)
- Mapa de **bloques comerciales regionales**
- **Generaciones** por año de nacimiento (Silenciosa → Beta)
- Tecnológico: **innovación disruptiva**, agilismo, GenIA, modelos de negocios exponenciales

---

# Resumen extendido

*Desarrollo largo para leer de corrido antes del parcial. Cada tema tiene su nota atómica
enlazada.*

## 1. La visión sobre el gerente: omnipotente vs. simbólico

*→ [[Gerente Omnipotente vs Simbólico]]*

La cátedra abre la unidad con **"ADMINISTRACIÓN: Visiones"**. Dos hipótesis sobre cuánto
influye un gerente en los resultados:

| | **OMNIPOTENTE** | **SIMBÓLICO** |
|---|---|---|
| Premisa | Responsable del resultado | Efectos limitados sobre los resultados |
| Causa | Su propia gestión | Factores no controlables: economía, política, clientes, competencia |
| Consecuencia | Éxito → **mérito** / Fracaso → **despido** | El gerente es un símbolo, no la causa |

**La síntesis — Figura 3.1:** el **criterio gerencial** queda apretado entre el **entorno
organizacional** (restricción externa) y la **cultura organizacional** (restricción interna).
Ni omnipotente ni impotente: con margen, pero acotado.

Esta figura es el mapa de la unidad entera.

## 2. Cultura organizacional

*→ [[Cultura Organizacional]]*

> **Sistema de significados e ideas compartidas por los miembros de una organización, que
> determina su comportamiento interno y externo (I+E).**

Es la **personalidad** de la organización — *"el modo de cómo se hacen las cosas"*. Compuesta
por **valores, símbolos, ritos, mitos y usos**, que evolucionan con el tiempo, determinan la
percepción y reacción de los empleados, e influyen en la resolución de problemas.

### Tres características

- **PERCEPTIVA** — es lo que los miembros *perciben*, no lo que la organización declara.
- **COMPARTIDA** — hay significados comunes, no opiniones individuales.
- **DESCRIPTIVA** — describe cómo se perciben las cosas, **no las evalúa**.

### Siete dimensiones (Figura 3.5)

*→ [[Dimensiones de la Cultura Organizacional]]*

| Dimensión | Grado en que… |
|---|---|
| Atención a los detalles | …se espera precisión, capacidad de análisis y atención al detalle |
| Orientación hacia los resultados | …los gerentes se enfocan en resultados más que en la manera de alcanzarlos |
| Orientación hacia la gente | …las decisiones toman en cuenta los efectos sobre el personal |
| Orientación hacia los equipos | …el trabajo se organiza en equipos y no por esfuerzo individual |
| **Agresividad** | …los empleados son más agresivos y competitivos que cooperativos |
| Estabilidad | …las decisiones hacen hincapié en mantener el *statu quo* |
| Innovación y toma de riesgos | …se alienta a innovar y asumir riesgos |

⚠️ **Agresividad**, no *Energía*. Es el cambio más fácil de que te descuenten puntos.

### Fuerte vs. débil

*→ [[Cultura Fuerte vs Débil]]*

Factores que definen el tipo: tamaño, antigüedad, rotación, fuerza de la cultura de origen.

| **FUERTES** | **DÉBILES** |
|---|---|
| Valores **arraigados**, **historias compartidas** | Sin compromiso, − dedicación, − desempeño |

Cadena causal: **valores claros → los empleados saben qué hacer → + desempeño.**

Contracara (pregunta de la actividad Trends): *¿la cultura puede ser un lastre?* Sí — una
cultura fuerte estrecha el criterio del gerente y **resiste el cambio**. Es un activo en
entornos estables y un pasivo en entornos turbulentos.

### Origen y sostenimiento (Figura 3.8)

*→ [[Origen y Sostenimiento de la Cultura]]*

```mermaid
flowchart LR
    F["<b>Filosofía de los<br/>fundadores</b><br/><i>el origen</i>"] --> S["<b>Criterios de<br/>selección</b><br/><i>quién entra</i>"]
    S --> AD["<b>Alta dirección</b><br/><i>qué se premia y tolera</i>"]
    S --> SOC["<b>Socialización</b><br/><i>el nuevo se adapta</i>"]
    AD --> CU["<b>CULTURA<br/>ORGANIZACIONAL</b>"]
    SOC --> CU
    style F fill:#4DB6AC,stroke:#00897B,color:#fff
    style CU fill:#7C5CFF,stroke:#5B3FD9,color:#fff
```

Los **fundadores** imprimen su visión; los **criterios de selección** filtran el ingreso; la
**alta dirección** fija normas con lo que hace, y alimenta la **socialización**, que adapta
al empleado nuevo. Ambas desembocan en la cultura.

### Cómo se aprende

*→ [[Transmisión de la Cultura]]*

- **RELATOS** — anécdotas que arraigan el presente en el pasado
- **RITUALES** — actos repetidos sobre valores, metas y personas
- **OBJETOS y SÍMBOLOS MATERIALES** — instalaciones, vestimenta, autos, carteles
- **LENGUAJE** — abreviaturas y vocabulario común

Actividad de la cátedra: aplicarlo *"a nuestra facultad o universidad"*.

### El iceberg

*→ [[Iceberg de la Cultura Organizacional]]*

Lo **VISIBLE** (personas, beneficios, amenidades, ubicación, código de vestimenta, ambiente
de oficina) es una fracción de lo **INVISIBLE** (seguridad, confianza, resultados, valores
centrales, ética de trabajo, apertura, propósito, misión, expectativas, disciplina,
narrativa, sesgos, autoridad…).

Lo visible es la manifestación; lo invisible, la causa.

### Efectos sobre roles y misiones

*→ [[Efectos de la Cultura sobre Roles y Misiones]]*

La cultura baja como **reglas, costumbres, tradición y folk-lore**, y esas instituciones
devuelven valores, normas, creencias y pautas de comportamiento. Los roles no se definen sólo
por el organigrama.

### Decisiones en las que influye

| Función | Qué define la cultura |
|---|---|
| **Planeación** | Riesgo de los planes · individuos o grupos · cuánto se investiga el ambiente |
| **Organización** | Autonomía de los puestos · individual o equipos · trato entre departamentos |
| **Dirección** | Interés por la satisfacción · estilos de liderazgo · si se suprimen desacuerdos |
| **Control** | Control externo o autocontrol · criterios de evaluación · exceso de presupuesto |

### Actualidad

Culturas **ética**, de **innovación**, **sensible a clientes**, **espiritualidad**. Apertura a
la **diversidad**. ¿Existe una cultura uniforme? El **idioma** conecta e inhibe a la vez.

**Caso de la cátedra:** *Libertad y responsabilidad en Netflix*.

## 3. Entorno organizacional

*→ [[Entorno Organizacional]]*

**Objetivo (efecto acción-reacción):** comprender su naturaleza e importancia, sus parámetros
y determinantes, para que el gerente logre **ventajas competitivas** al estructurar su
organización dentro de la dinámica de esos ambientes.

**Naturaleza dual:** fuente de recursos de donde surgen **oportunidades y amenazas**.
**Carácter:** local, regional, nacional, internacional.
**Regla:** *no se lo puede ignorar; reaccionar e intentar controlar*.

### General vs. específico

*→ [[Entorno General y Específico]]*

**Ambiente externo:** fuerzas e instituciones fuera de la organización que pueden influir en
su desempeño. **Cada organización tiene un entorno único.**

| | **GENERAL** | **ESPECÍFICO** |
|---|---|---|
| Incidencia | **Indirecta** | **Directa e inmediata**, y pertinente para el logro de las metas |
| Figura | 3.2 — componentes del entorno externo | 3.4 — participantes de la organización |
| Contenido | Político/Legal · Económico · Sociocultural · Demográfico · Tecnológico · Global | Empleados · clientes · sindicatos · accionistas · comunidades · proveedores · medios · gobiernos · competidores · asociaciones · grupos de acción política y social |

📌 Novedad 2026: el entorno específico **es** la lista de participantes/stakeholders. Antes
eran dos temas separados.

**➡️ TP2.1:** clasificar fuerzas según pertenezcan al general o al específico.

### Los seis componentes

*→ [[Componentes del Entorno]]*

- **ECONÓMICO** — red de medios de producción y distribución. Condiciones: tasas de interés,
  inflación, tipo de cambio, políticas fiscales, desempleo, demografía. Sistemas
  **planificado vs. capitalista**. Comercio mundial: OMC (global), Mercosur/UE/NAFTA
  (regionales).
- **POLÍTICO-LEGAL** — alcance municipal/provincial/nacional; ramas legislativa/ejecutiva/
  judicial; estabilidad, leyes, **lobbying**. Costos de adaptación vs. beneficios.
- **SOCIOCULTURAL** — cambio de valores, usos y gustos; colegios, medios e iglesia moldean,
  transforman y difunden. Cultura organizacional vs. nacional.
- **DEMOGRÁFICO** — género, edad, escolaridad, región, ingresos, estructura familiar.
  Generaciones: Silenciosa (1925-45) · Boomers (46-64) · X (65-79) · Millennials (80-94) ·
  Z (95-2009) · Alfa (2010-24) · Beta (2025-39).
- **TECNOLÓGICO** — **innovación disruptiva**; agilismo y métricas; GenIA, robotización,
  computación cuántica, modelos de negocios exponenciales.
- **GLOBAL** — ver abajo.

### Incertidumbre ambiental (Figura 3.3)

*→ [[Incertidumbre Ambiental]]*

Dos dimensiones: **grado de cambio** (estable ↔ dinámico) y **grado de complejidad**
(simple ↔ complejo).

```mermaid
quadrantChart
    title Grado de incertidumbre ambiental
    x-axis "ESTABLE" --> "DINAMICO"
    y-axis "SIMPLE" --> "COMPLEJO"
    quadrant-1 "CELDA 4 — mayor incertidumbre"
    quadrant-2 "CELDA 3"
    quadrant-3 "CELDA 1 — menor incertidumbre"
    quadrant-4 "CELDA 2"
```

*Simple↔complejo* decide **cuánto** conocimiento hace falta; *estable↔dinámico*, **cada cuánto**
hay que actualizarlo.

⚠️ **Son dos dimensiones**, no tres: la munificencia salió del deck.

### Partes interesadas

*→ [[Partes Interesadas]]*

Modelo **Organización-Actor**. Etapas: (1) identificar · (2) determinar intereses concretos ·
(3) decidir su importancia · (4) decidir el manejo de la relación en función de la
importancia de cada parte y la incertidumbre del ambiente → **acuerdo explícito**.

Efectos de gestionarlas bien: + innovación, + confianza, + flexibilidad, + pronósticos.

### Gestión del entorno

*→ [[Gestión y Control del Entorno]]*

**Conocimiento sistémico:** el entorno aparece a la entrada (fuentes de input y restricciones)
y a la salida (oportunidades del output y restricciones).

**9 estrategias de control:** nicho o dominio · vinculación por incertidumbre · acuerdos y
contratos · joint ventures · fusiones y adquisiciones (integración vertical u horizontal →
**organización virtual o en red**) · consejos de administración · captación de directivos de
la competencia · asociaciones de empresarios (lobbying) · publicidad y RRPP.

**Dos límites:** **ilegalidad** (sobornos, acuerdos de precios, división del mercado) y
**ecología de la población** (el entorno atenta contra la existencia misma de las
organizaciones, sea el cambio intencional o accidental).

## 4. Componente global

*→ [[Entorno Global y Globalización]] · [[Posturas ante el Entorno Global]]*

**CMN — corporación multinacional:** opera en varios países.

**Globalización de los mercados:** apertura del comercio · mayor competencia · eliminación de
barreras geográficas · apertura a lo bueno y lo malo · efecto dominó · *¿equivale a
americanización?*

### Posturas y tipos de CMN

| Postura | Referencia | Tipo | Ejemplos |
|---|---|---|---|
| **ETNOCÉNTRICA** | Patria | **Empresa global** — centraliza en casa matriz | Sony, Unilever |
| **POLICÉNTRICA** | País local | **Corporación multidoméstica** — descentralizada | Nestlé, Frito-Lay |
| **GEOCÉNTRICA** | Mundo | **Organización trasnacional (sin fronteras)** | IBM, Telefónica de España |

⚠️ *Global = etnocéntrica*, no geocéntrica. Es la trampa clásica.

### Cómo se vuelven globales (Figura 4.4)

De inversión mínima a cuantiosa:

1. Abastecimiento global
2. Exportación e importación
3. Otorgamiento de licencias
4. Franquicia
5. Alianza estratégica – empresa conjunta
6. Subsidiaria extranjera

### Cultura nacional

*→ [[Hofstede y GLOBE]]*

**Hofstede (5 dim., Figura 4.6):** individualista ↔ colectivista · mucha ↔ poca distancia del
poder · gran ↔ poca evitación de la incertidumbre · logro ↔ cuidado y protección ·
orientación al largo ↔ corto plazo.

**GLOBE (8 dim.):** *Global Leadership and Organizational Behavior Effectiveness*. Indica el
grado en que la sociedad alienta/acepta. Extiende a Hofstede con asertividad, orientación al
desempeño, orientación humana y diferenciación de género.

## 5. Herramientas de análisis

*→ [[PESTEL]] · [[FODA]]*

**PESTEL** para el entorno general — y no basta con listar las seis letras: la cátedra pide la
**MATRIZ** con columnas *Factor · Detalle · Plazo (corto/mediano/largo) · Impacto
(positivo/indiferente/negativo)*.

**FODA** para sintetizar interno (F, D) y externo (O, A). El eje interno/externo es el mismo
de la Figura 3.1.

---

## Preguntas frecuentes de parcial

1. Explicar las dos visiones sobre el gerente **y la Figura 3.1**.
2. Las 3 características de la cultura. ¿Por qué es descriptiva y no evaluativa?
3. Las 7 dimensiones. Describir la cultura de una organización con ellas.
4. ¿Qué hace fuerte a una cultura? ¿Puede ser un lastre?
5. Reproducir y explicar la Figura 3.8 (origen y sostenimiento).
6. Los cuatro vehículos de aprendizaje. ¿Visible o invisible?
7. Diferencia entre entorno general y específico, con el criterio de inmediatez.
8. Ubicar una organización en la matriz de incertidumbre y justificar.
9. Las 4 etapas de manejo de stakeholders.
10. Los 6 escalones de internacionalización, en orden.
11. Postura ↔ tipo de CMN ↔ ejemplo.
12. Las 5 dimensiones de Hofstede con sus extremos.

## Pendientes

- [ ] **Autoevaluación** de la unidad
- [ ] Resolver [[TP2-Entorno-y-Cultura-Organizacional]]
- [ ] **Confirmar si las [[5 Fuerzas de Porter]] entran en el Parcial 1** — ya no están en el deck
- [ ] Confirmar qué es el **"triángulo E-T-O"** (ver [[2026-08-10 - Clase U2]])
- [ ] Conseguir material de **[[FODA]]** — el deck 2026 no trae lámina y el `.pptx` es imágenes
